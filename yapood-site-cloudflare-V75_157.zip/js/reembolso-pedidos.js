// V75.16 — Meus pedidos: botão de política/reclamações e situação do reembolso em cada pedido.
import { auth } from './firebase.js';
import { escapeHtml } from './regras.js';
import { podeSolicitarReembolso, rotuloReembolso } from './reembolso.js?v=75.145';
import { abrirPolitica } from './reembolso-ui.js';

const lista = document.getElementById('lista-pedidos-historico');
const header = document.querySelector('.header-pedidos');

if (header && !document.getElementById('btn-politica')) {
  const b = document.createElement('button');
  b.type = 'button'; b.id = 'btn-politica'; b.className = 'rb-header-btn';
  b.innerHTML = '<i class="fa-solid fa-circle-info"></i> Reclamações e política';
  b.addEventListener('click', abrirPolitica);
  header.appendChild(b);
}

function complementar() {
  const cache = window.__yapoodPedidos?.cache || {};
  lista?.querySelectorAll('.card-pedido').forEach((card) => {
    if (card.dataset.rb) return;
    const chave = card.querySelector('[data-key]')?.dataset.key;
    const num = card.querySelector('[data-num]')?.dataset.num;
    const p = chave ? cache[chave] : Object.values(cache).find((x) => x.numeroPedido === num);
    if (!p) return;
    card.dataset.rb = '1';
    const acoes = card.querySelector('.acoes-card-pedido');
    if (p.reembolso) {
      const tag = document.createElement('div');
      tag.className = `rb-tag rb-${p.reembolso.status}`;
      tag.innerHTML = `<i class="fa-solid fa-rotate-left"></i> Reembolso: ${escapeHtml(rotuloReembolso(p.reembolso))}`;
      acoes?.before(tag);
    } else if (podeSolicitarReembolso(p, auth.currentUser?.uid) && acoes) {
      const a = document.createElement('a');
      a.className = 'btn-status rb-link-pedido';
      a.href = `status.html?num=${encodeURIComponent(p.numeroPedido)}`;
      a.innerHTML = '<i class="fa-solid fa-rotate-left"></i> Reembolso';
      acoes.appendChild(a);
    }
  });
}
if (lista) new MutationObserver(() => { try { complementar(); } catch (e) { console.warn('Reembolso:', e); } }).observe(lista, { childList: true, subtree: true });
