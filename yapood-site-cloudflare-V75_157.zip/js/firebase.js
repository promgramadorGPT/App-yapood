// Importações via CDN oficial do Firebase (v10.12.0). Ponto ÚNICO de import: os demais módulos usam este arquivo.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getDatabase, ref, set, get, child, onValue, push, update, remove,
  query, orderByChild, equalTo, limitToLast, runTransaction, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// A apiKey do Firebase Web NÃO é segredo: a proteção real está nas Security Rules (veja database.rules.json).
const firebaseConfig = {
  apiKey: "AIzaSyDJAKE0w6YeGjos9E21SnsLEh0PIEhK5hI",
  authDomain: "yapoodbr-delivery.firebaseapp.com",
  databaseURL: "https://yapoodbr-delivery-default-rtdb.firebaseio.com",
  projectId: "yapoodbr-delivery",
  storageBucket: "yapoodbr-delivery.firebasestorage.app",
  messagingSenderId: "469832240218",
  appId: "1:469832240218:web:868056b23bf792fc005c63",
  measurementId: "G-QTRWSV9F7C"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
// V75.48: sempre mostra a escolha de conta do Google (celular compartilhado; cliente, lojista, entregador e Master podem usar contas diferentes).
googleProvider.setCustomParameters({ prompt: 'select_account' });

export {
  app, db, auth, googleProvider,
  ref, set, get, child, onValue, push, update, remove,
  query, orderByChild, equalTo, limitToLast, runTransaction, serverTimestamp,
  signInWithPopup, onAuthStateChanged, signOut
};
