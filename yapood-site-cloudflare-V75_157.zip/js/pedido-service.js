// js/pedido-service.js — acesso a dados de pedidos/lojas (browser + Firebase).
import { db, ref, get, set, push, update, remove, runTransaction, query, orderByChild, equalTo } from './firebase.js';
import {
  calcularTotais, contarUsoCupom, limitesDoCupom, gerarCodigoPedido, normalizarPagamento, STATUS, PAGO, somarAvaliacao
} from './regras.js';
import { configFidelidade, calcularTotaisComPremio, progressoFidelidade } from './fidelidade.js';
import { formatarMoeda } from './utils.js';
import { validarTroco, textoTroco, trocoSeguro } from './troco.js';
import { listarEnderecos, validarEndereco, idParaSalvar } from './enderecos.js';
import { resolverBairro, textoBairro, bairroConhecido, montarSugestao } from './bairros.js';
import { NOTPUSH_API } from './notificaciones-config.js';
import { avisarEvento } from './notpush-evento.js';
import { distanciaParaEndereco, TEMPO_MAX_MS } from './distancia.js';
import { coordParaPedido } from './rastreio.js';
import { detalhesDaLinha } from './combo.js';

export async function buscarLoja(lojaId) {
  const snap = await get(ref(db, `restaurantes/${lojaId}`));
  return snap.exists() ? snap.val() : null;
}

export const cuponsDaLoja = (loja) =>
  Object.entries(loja?.cupones || {}).map(([id, c]) => ({ id, ...c }));

export const telefoneLoja = (loja) =>
  String(loja?.whatsapp || loja?.telefono || '').replace(/\D/g, '');

/**
 * Cria o pedido. Totais são SEMPRE recalculados aqui a partir dos itens já reconciliados com o cardápio.
 * O código público (numeroPedido) tem 6 caracteres aleatórios; o id interno é a push-key do Firebase.
 */

async function notificarNovoPedido(user, pedidoKey) {
  try {
    const idToken = await user.getIdToken(true);
    const r = await fetch(`${NOTPUSH_API}/notificar-pedido`, {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${idToken}`},
      body:JSON.stringify({pedidoKey, evento:'novo'}),
      keepalive: true
    });
    const data = await r.json().catch(()=>({}));
    if (!r.ok || !data.ok) console.warn('[NotPush] nuevo pedido:', data.error || `HTTP ${r.status}`);
    else console.log('[NotPush] ADM notificado:', data);
  } catch(e) { console.warn('[NotPush] não foi possível notificar o ADM:', e); }
}

// Pedidos do próprio cliente (as rules só deixam ler os dele). Usado para o progresso do presente fidelidade.
export async function buscarPedidosDoCliente(uid) {
  const snap = await get(query(ref(db, 'pedidos'), orderByChild('clienteUid'), equalTo(uid)));
  return snap.exists() ? Object.entries(snap.val()).map(([key, p]) => ({ key, ...p })) : [];
}

// % da plataforma vigente (config do Master). As rules exigem que o pedido grave exatamente este valor.
export async function buscarPercentualPlataforma() {
  try {
    const snap = await get(ref(db, 'config_plataforma/comissao/percentual'));
    const n = Number(snap.val());
    return snap.exists() && Number.isFinite(n) ? n : null;
  } catch (err) { console.warn('Comissão: % não carregada:', err); return null; }
}

/**
 * V75.84 — Loja fundadora: dentro do prazo de isenção (isencao_comissao/{lojaId}/ate, gravado só pela API) o pedido
 * grava comissaoPercentual 0, que é o que as Rules aceitam para essa loja. Falha de leitura = % normal (nunca deixa de cobrar sem saber).
 */
export async function lojaIsentaDeComissao(lojaId, agora = Date.now()) {
  try {
    const ate = Number((await get(ref(db, `isencao_comissao/${lojaId}/ate`))).val());
    return Number.isFinite(ate) && ate > agora;
  } catch (err) { console.warn('Isenção de comissão não carregada:', err); return false; }
}

/**
 * V75.25 — Conta bloqueada / loja suspensa pelo Master. As Rules do banco também recusam o pedido;
 * esta checagem só dá uma mensagem clara. Falha de rede ou de leitura não impede (as Rules decidem).
 */
export async function verificarPodePedir(uid, lojaId) {
  let bloqueada = false, suspensa = false;
  try {
    const [b, s] = await Promise.all([get(ref(db, `usuarios_bloqueados/${uid}`)), get(ref(db, `lojas_suspensas/${lojaId}`))]);
    bloqueada = b.exists(); suspensa = s.exists();
  } catch (err) { console.warn('Bloqueios não verificados:', err); }
  if (bloqueada) throw new Error('Sua conta está bloqueada e não pode fazer pedidos. Fale com o suporte do YAPOOD.');
  if (suspensa) throw new Error('Esta loja está temporariamente indisponível.');
}

/**
 * V75.38 — Uso dos cupons com limite: { CODIGO: { total, porCliente } }.
 * porCliente vem dos pedidos do próprio cliente; total vem do contador que o painel da loja mantém (cupons_uso/{loja}/{CODIGO}).
 * Falha de leitura não bloqueia a compra (o limite por cliente continua valendo e a loja confere ao aceitar).
 */
export async function buscarUsoCupons(lojaId, uid, cupons, pedidosCliente = null) {
  const comLimite = (cupons || []).filter((c) => { const l = limitesDoCupom(c); return l.maxUsos || l.maxPorCliente; });
  if (!comLimite.length || !uid) return null;
  const uso = {};
  try {
    const meus = pedidosCliente || await buscarPedidosDoCliente(uid);
    let contador = {};
    try { const snap = await get(ref(db, `cupons_uso/${lojaId}`)); contador = snap.exists() ? snap.val() : {}; } catch (e) { console.warn('Contador de cupons:', e); }
    for (const c of comLimite) {
      const cod = String(c.codigo).toUpperCase();
      const meu = contarUsoCupom(meus, cod, lojaId, uid);
      uso[cod] = { total: Math.max(Number(contador?.[cod]) || 0, meu.total), porCliente: meu.porCliente };
    }
  } catch (e) { console.warn('Uso de cupons não verificado:', e); return null; }
  return uso;
}

export async function registrarPedido({ user, lojaId, loja, itens, cliente, formaPagamento, codigoCupom, tipoEntrega = 'delivery', pagoStatus = PAGO.NA_ENTREGA, usarPremio = false, bairro = '', troco = null, entregaCoord = null, abaterTroco = 0 }) {
  await verificarPodePedir(user.uid, lojaId);
  const retirada = tipoEntrega === 'retirada';
  if (retirada && loja.aceitaRetirada === false) throw new Error('Esta loja não oferece retirada na loja.');
  // Presente fidelidade: revalidado aqui contra o histórico real do cliente (não confia no que a tela mostrou).
  let premioCfg = null;
  if (usarPremio) {
    premioCfg = configFidelidade(loja.fidelidade);
    const pr = premioCfg ? progressoFidelidade(await buscarPedidosDoCliente(user.uid), user.uid, lojaId, premioCfg) : null;
    if (!premioCfg || pr.disponiveis < 1) throw new Error('O presente de fidelidade não está disponível.');
  }
  // Taxa de entrega: padrão da loja ou do bairro (V75.22). As Rules conferem o mesmo valor.
  const rb = retirada ? null : resolverBairro(loja, bairro);
  if (rb && !rb.permitido) throw new Error(rb.estado === 'informar' ? 'Informe o bairro da entrega.' : textoBairro(rb));
  const cuponsLoja = cuponsDaLoja(loja);
  const uso = codigoCupom && !premioCfg ? await buscarUsoCupons(lojaId, user.uid, cuponsLoja) : null;
  const t = calcularTotaisComPremio(itens, retirada ? 0 : rb.taxa, cuponsLoja, codigoCupom, premioCfg, uso);
  if (codigoCupom && !premioCfg && !t.cupom && /esgotou|já usou|expirou|ainda não começou/.test(t.erroCupom || '')) throw new Error(t.erroCupom); // não cria o pedido sem o desconto que o cliente viu
  if (premioCfg && !(t.desconto > 0)) throw new Error('O presente de fidelidade não gera desconto neste pedido.');
  if (t.total <= 0 && t.subtotal <= 0) throw new Error('Pedido vazio.');

  // V75.60: troco só vale para dinheiro; o valor a devolver é recalculado aqui com o total real do pedido.
  let trocoPedido = null;
  if (formaPagamento === 'Dinheiro' && troco && typeof troco === 'object') {
    const v = validarTroco({ precisa: troco.precisa === true, texto: String(troco.paraValor ?? '') }, Math.max(0, t.total - (Number(abaterTroco) || 0))); // V75.145: com saldo da loja, o troco é sobre o que falta pagar
    if (!v.ok) throw new Error(v.erro);
    trocoPedido = v.troco;
  }

  const percentualGlobal = await buscarPercentualPlataforma();
  // V75.84: loja dentro do prazo de isenção grava 0 (as Rules só aceitam 0 para quem tem isencao_comissao vigente).
  const comissaoPercentual = percentualGlobal > 0 && await lojaIsentaDeComissao(lojaId) ? 0 : percentualGlobal;
  const coordEntrega = coordParaPedido(entregaCoord, retirada ? 'retirada' : 'delivery');
  const novaRef = push(ref(db, 'pedidos'));
  const codigo = gerarCodigoPedido();
  const pedido = {
    id: novaRef.key,
    numeroPedido: codigo,
    lojaId,
    lojaNome: loja.nombre || 'Restaurante',
    lojaLogo: loja.logo || loja.foto || '',
    lojaTelefone: telefoneLoja(loja),
    tipoEntrega: retirada ? 'retirada' : 'delivery',
    metodoEntrega: retirada ? 'Retirada na loja' : 'Delivery',
    clienteUid: user.uid,
    cliente,
    formaPagamento,
    ...(trocoPedido ? { troco: trocoPedido } : {}),
    pagoStatus: normalizarPagamento(pagoStatus),
    itens,
    subtotal: t.subtotal,
    precioEnvio: t.envio,
    ...(rb && rb.bairroId ? { bairro: rb.nome, bairroId: rb.bairroId } : {}),
    ...(coordEntrega ? { entregaCoord: coordEntrega } : {}), // V75.86: opcional; só entrega; alimenta o rastreio por distância
    desconto: t.desconto,
    cupomCodigo: t.cupom ? t.cupom.codigo : null,
    ...(comissaoPercentual !== null ? { comissaoPercentual } : {}),
    ...(t.premio ? { premioFidelidade: { tipo: t.premio.tipo, titulo: t.premio.titulo, desconto: t.premio.desconto } } : {}),
    total: t.total,
    status: STATUS.PENDENTE,
    criadoEm: new Date().toISOString()
  };
  // V75.42: bairro novo → estima a distância loja→cliente em paralelo à gravação (limite de tempo; falha = sem km).
  const distanciaP = rb && !bairroConhecido(loja, rb.nome || bairro) ? comLimite(distanciaParaEndereco({ lojaId, loja, direccion: cliente?.direccion, bairro: rb.nome || bairro })) : null;
  await set(novaRef, pedido);
  if (rb) await sugerirBairro(lojaId, loja, rb.nome || bairro, user.uid, distanciaP ? await distanciaP : null);
  // Aguarda a tentativa de notificação antes de a página poder navegar para o status.
  // A função trata os próprios erros, portanto uma falha de push não cancela o pedido.
  // Espera no máximo 3 s: se o serviço de avisos estiver "dormindo" (plano gratuito do Render leva ~50 s para acordar),
  // o cliente não fica preso na tela. O envio continua em segundo plano (keepalive) e o ADM ainda é avisado.
  await Promise.race([notificarNovoPedido(user, novaRef.key), new Promise((r) => setTimeout(r, 3000))]);
  return { key: novaRef.key, codigo, totais: t, pedido };
}

/**
 * Cadastro automático (V75.22): bairro que a loja ainda não conhece vira sugestão para o ADM aprovar.
 * Só cria (as Rules não deixam o cliente alterar nem ler); falhas nunca atrapalham o pedido.
 */
export const comLimite = (promessa, ms = TEMPO_MAX_MS + 500) => {
  let relogio;
  const limite = new Promise((r) => { relogio = setTimeout(() => r(null), ms); });
  return Promise.race([Promise.resolve(promessa).catch(() => null), limite]).finally(() => clearTimeout(relogio));
};

export async function sugerirBairro(lojaId, loja, nome, uid, distancia = null) {
  try {
    if (!lojaId || !uid || bairroConhecido(loja, nome)) return false;
    const sug = montarSugestao(nome, uid, new Date(), distancia);
    if (!sug) return false;
    const chave = `bairroSug_${lojaId}_${sug.id}`;
    const DIA = 24 * 60 * 60 * 1000;
    try {
      const marca = localStorage.getItem(chave);
      if (marca === '1') return false;                                  // já enviada com sucesso
      if (marca && Date.now() - Number(marca) < DIA) return false;      // falhou há pouco (ex.: já sugerido por outro cliente): tenta de novo só depois de 1 dia
    } catch { /* sem storage */ }
    let enviada = true;
    await set(ref(db, `bairros_sugeridos/${lojaId}/${sug.id}`), sug.dados).catch(() => { enviada = false; });
    try { localStorage.setItem(chave, enviada ? '1' : String(Date.now())); } catch { /* sem storage */ }
    if (enviada) avisarEvento({ evento: 'bairro', lojaId, bairroId: sug.id }); // push para o ADM (não espera)
    return enviada;
  } catch (e) { console.warn('Bairro não sugerido:', e); return false; }
}

// Cliente só pode cancelar o próprio pedido enquanto Pendente (garantido pelas rules).
export const cancelarPedidoCliente = (key) => update(ref(db, `pedidos/${key}`), { status: STATUS.CANCELADO });

export async function salvarPerfilCliente(uid, cliente) {
  await update(ref(db, `usuarios/${uid}`), {
    nome: cliente.nombre, email: cliente.email, telefone: cliente.telefono,
    ...(cliente.direccion ? { direccion: cliente.direccion } : {}), ...(cliente.referencia ? { referencia: cliente.referencia } : {}), observacion: cliente.observacion, atualizadoEm: new Date().toISOString()
  });
}

// ---------- Endereços salvos (V75.21) ----------
export async function buscarEnderecos(uid) {
  const snap = await get(ref(db, `usuarios/${uid}/enderecos`));
  return listarEnderecos(snap.exists() ? snap.val() : {});
}

/** Salva (ou atualiza) um endereço. Casa/Trabalho sobrescrevem; "Outro" cria novo (máx. 5). Devolve { id, endereco }. */
export async function salvarEndereco(uid, dados) {
  const v = validarEndereco(dados);
  if (!v.ok) throw new Error(v.erro);
  const existentes = await buscarEnderecos(uid);
  const id = idParaSalvar(v.endereco.rotulo, existentes);
  const anterior = existentes.find((e) => e.id === id);
  const registro = { ...v.endereco, criadoEm: anterior?.criadoEm || new Date().toISOString(), atualizadoEm: new Date().toISOString() };
  await set(ref(db, `usuarios/${uid}/enderecos/${id}`), registro);
  return { id, endereco: registro };
}

export async function removerEndereco(uid, id) {
  if (!/^(casa|trabalho|outro_[a-z0-9]+)$/.test(String(id))) throw new Error('Endereço inválido.');
  await remove(ref(db, `usuarios/${uid}/enderecos/${id}`));
}

export async function lembrarUltimoEndereco(uid, id) {
  await update(ref(db, `usuarios/${uid}`), { ultimoEndereco: id || null });
}

export function montarMensagemWhatsApp(p, linkStatus) {
  const L = [];
  L.push(`*NOVO PEDIDO #${p.numeroPedido}*`, '');
  L.push(`*Cliente:* ${p.cliente.nombre}`, `*Telefone:* ${p.cliente.telefono}`);
  if (p.tipoEntrega === 'retirada') L.push('*MODALIDADE:* RETIRADA NA LOJA');
  else L.push(`*Endereço:* ${p.cliente.direccion}`);
  if (p.tipoEntrega !== 'retirada' && p.cliente.referencia) L.push(`*Referência:* ${p.cliente.referencia}`);
  if (p.cliente.observacion) L.push(`*Obs:* ${p.cliente.observacion}`);
  L.push(`*Pagamento:* ${p.formaPagamento} (${p.pagoStatus})`);
  { const tt = textoTroco(trocoSeguro(p.troco), formatarMoeda); if (tt) L.push(`*Troco:* ${tt}`); }
  L.push('', '*PRODUTOS:*');
  p.itens.forEach((i) => { L.push(`- ${i.qtd}x ${i.nombre} (${formatarMoeda(i.precio * i.qtd)})`); detalhesDaLinha(i).forEach((x) => L.push(`   • ${x}`)); });
  L.push('', `*Subtotal:* ${formatarMoeda(p.subtotal)}`, `*Entrega:* ${p.precioEnvio ? formatarMoeda(p.precioEnvio) : 'Grátis'}`);
  if (p.desconto > 0) L.push(`*Desconto (${p.premioFidelidade ? `Presente fidelidade: ${p.premioFidelidade.titulo}` : p.cupomCodigo}):* -${formatarMoeda(p.desconto)}`);
  L.push(`*TOTAL:* ${formatarMoeda(p.total)}`, '', `*Acompanhamento:* ${linkStatus}`);
  return L.join('\n');
}

export function urlWhatsApp(fone, texto) {
  return `https://wa.me/${String(fone).replace(/\D/g, '')}?text=${encodeURIComponent(texto)}`;
}

// Agregado de notas por loja com TRANSAÇÃO (a versão antiga lia tudo e regravava: perdia notas em concorrência).
export function registrarNotaNoAgregado(lojaId, notas) {
  return runTransaction(ref(db, `lojas/${lojaId}`), (atual) => somarAvaliacao(atual, notas));
}
