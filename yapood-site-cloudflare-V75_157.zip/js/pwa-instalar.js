// js/pwa-instalar.js — botão "Instalar app" (PWA). Usa [data-instalar] (botão) e [data-instalar-dica] (texto para iPhone).
// Chrome/Edge/Android: usa o evento beforeinstallprompt. iPhone/iPad: não existe evento; mostra como instalar pelo Compartilhar.

import './ui-mensagens.js';

/** Decide o que mostrar. Pura, testada em tests/pwa.test.mjs. */
export function estadoInstalar({ instalado = false, temEvento = false, ios = false } = {}) {
  if (instalado) return 'nenhum';
  if (temEvento) return 'botao';
  return ios ? 'dica' : 'nenhum';
}

const DICA_IOS = 'No iPhone: toque em Compartilhar e depois em "Adicionar à Tela de Início".';
let evento = null;

const instalado = () => { try { return matchMedia('(display-mode: standalone)').matches || navigator.standalone === true; } catch { return false; } };
const ios = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

function atualizar() {
  const modo = estadoInstalar({ instalado: instalado(), temEvento: !!evento, ios: ios() });
  document.querySelectorAll('[data-instalar]').forEach((b) => { b.hidden = modo === 'nenhum'; });
  document.querySelectorAll('[data-instalar-dica]').forEach((d) => { d.textContent = modo === 'dica' ? DICA_IOS : ''; d.hidden = modo !== 'dica'; });
}

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); evento = e; atualizar(); });
  window.addEventListener('appinstalled', () => { evento = null; atualizar(); });
  document.addEventListener('click', async (ev) => {
    if (!ev.target.closest?.('[data-instalar]')) return;
    if (evento) {
      try { evento.prompt(); await evento.userChoice; } catch { /* usuário fechou */ }
      evento = null; atualizar();
    } else if (!document.querySelector('[data-instalar-dica]')) {
      alert(DICA_IOS);
    }
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', atualizar); else atualizar();
}
