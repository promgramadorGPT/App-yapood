// js/midia.js — V75.148: banner e popup aceitam imagem, GIF e vídeo curto (MP4/WebM). Uma só função decide se o endereço é vídeo e monta a tag certa.
// Não precisa de campo novo no banco: o endereço do Cloudinary já diz o tipo (".../video/upload/..." ou termina em .mp4/.webm).

import { imgOtimizada } from './utils.js';
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** O endereço é de um vídeo? */
export function ehVideo(url) {
  const u = String(url || '');
  return /\/video\/upload\//i.test(u) || /\.(mp4|webm)(\?|#|$)/i.test(u);
}

/**
 * Tag da mídia. Imagem/GIF → <img>. Vídeo → <video> mudo, em loop e sem controles (celular só toca sozinho se estiver mudo).
 * opcoes: { alt, classe, onerror, tocar (padrão true: false mostra só o primeiro quadro, para miniaturas), extra (atributos já seguros) }
 */
export function tagMidia(url, { alt = '', classe = '', onerror = '', tocar = true, extra = '', largura = 1000 } = {}) {
  const c = classe ? ` class="${esc(classe)}"` : '';
  const er = onerror ? ` onerror="${onerror}"` : '';
  const ex = extra ? ` ${extra}` : '';
  if (ehVideo(url)) {
    const play = tocar ? ' autoplay loop' : '';
    const src = tocar ? esc(url) : `${esc(url)}#t=0.1`;
    return `<video${c} src="${src}"${play} muted playsinline webkit-playsinline preload="metadata" disablepictureinpicture aria-label="${esc(alt)}"${er}${ex}></video>`;
  }
  return `<img${c} src="${esc(imgOtimizada(url, largura))}" alt="${esc(alt)}" loading="lazy"${er}${ex}>`;
}
