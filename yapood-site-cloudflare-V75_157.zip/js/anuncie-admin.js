// V75.39 — Painel da loja: convite "Anuncie no YAPOOD" + rodapé "Suporte | Anuncie no YAPOOD".
// Módulo isolado (mesmo padrão do reembolso/relato): se falhar, o painel segue igual. O WhatsApp vem do Master (config_plataforma/anuncie).
import { auth, db, ref, onValue, onAuthStateChanged } from './firebase.js';
import { configAnuncie, urlWhatsApp, mensagemAnuncie, mensagemSuporte, deveMostrarConvite, ATRASO_POPUP_MS, DIAS_SILENCIO } from './anuncie.js';

const CHAVE_FECHADO = 'yapood_anuncie_fechado_em';
const el = (id) => document.getElementById(id);
const convite = el('anuncie-convite'), rodape = el('adm-rodape');
if (convite && rodape) {
  const inicio = Date.now();
  let cfg = null, timer = null;

  const lerFechado = () => { try { return Number(localStorage.getItem(CHAVE_FECHADO)) || 0; } catch { return 0; } };
  const gravarFechado = () => { try { localStorage.setItem(CHAVE_FECHADO, String(Date.now())); } catch { /* sem storage: volta na próxima visita */ } };
  const nomeLoja = () => (el('store-name-display')?.textContent || '').trim();
  // Alerta em tela (novo pedido, reembolso, relato, modais) tem prioridade: o convite espera.
  const visivel = (n) => { const r = n.getBoundingClientRect(); const cs = getComputedStyle(n); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const alertaVisivel = () => [...document.querySelectorAll('.novo-pedido-overlay, [role="dialog"], .modal-overlay, #faixa-relatos')].some((n) => !n.hidden && visivel(n));

  function atualizarLinks() {
    if (!cfg) { rodape.hidden = true; convite.hidden = true; return; }
    const nome = nomeLoja();
    el('adm-rodape-suporte').href = urlWhatsApp(cfg.suporte, mensagemSuporte(nome));
    el('adm-rodape-anuncie').href = urlWhatsApp(cfg.comercial, mensagemAnuncie(nome));
    el('anuncie-falar').href = urlWhatsApp(cfg.comercial, mensagemAnuncie(nome));
    rodape.hidden = false;
  }

  function tentarMostrar() {
    clearTimeout(timer);
    if (!cfg || !convite.hidden) return;
    const abertoDesdeMs = Date.now() - inicio;
    if (deveMostrarConvite({ cfg, ultimoFechadoEm: lerFechado(), abertoDesdeMs, alertaVisivel: alertaVisivel() })) {
      atualizarLinks();
      convite.hidden = false;
    } else if (!(lerFechado() && Date.now() - lerFechado() < DIAS_SILENCIO * 24 * 3600 * 1000)) {
      timer = setTimeout(tentarMostrar, abertoDesdeMs < ATRASO_POPUP_MS ? ATRASO_POPUP_MS - abertoDesdeMs + 200 : 15000);
    }
  }

  const esconder = () => { convite.hidden = true; gravarFechado(); };
  convite.addEventListener('click', (e) => {
    if (e.target.closest('[data-anuncie-fechar], [data-anuncie-depois]')) esconder();
    else if (e.target.closest('#anuncie-falar')) gravarFechado(); // quem foi falar com o YAPOOD não precisa do convite de novo por 7 dias
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !convite.hidden) esconder(); });

  // A configuração só pode ser lida depois do login.
  let ouvindo = false;
  onAuthStateChanged(auth, (user) => {
    if (!user || ouvindo) return;
    ouvindo = true;
    try {
      onValue(ref(db, 'config_plataforma/anuncie'), (snap) => {
        cfg = configAnuncie(snap.val());
        atualizarLinks();
        tentarMostrar();
      }, () => { cfg = null; atualizarLinks(); });
    } catch (e) { console.warn('Anuncie:', e); }
  });
  // O nome da loja carrega depois do painel: atualiza o texto das mensagens quando mudar.
  const nome = el('store-name-display');
  if (nome) new MutationObserver(() => { if (cfg) atualizarLinks(); }).observe(nome, { childList: true, characterData: true, subtree: true });
}
