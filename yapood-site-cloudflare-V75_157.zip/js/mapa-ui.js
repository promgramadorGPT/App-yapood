// js/mapa-ui.js — "Ver mapa" do entregador (V75.90): rota pronta com as entregas que a loja atribuiu, ordem das paradas
// com setas, navegação com voz (estilo Waze), mapa que gira com a moto do YAPOOD e semáforos. Funciona sobre o motor
// puro de mapa-nav.js e a API (/entregador/mapa/*). A chave do provedor de rotas nunca chega ao aparelho.
import {
  construirRota, paradaAlvo, posicaoAoLongo, projetar, passoAtual, proximaManobra, anunciosPendentes, juntarFalas, textoPasso,
  semaforosNaRota, proximoSemaforo, sinalDoPasso, iconeSinal, formatarDist, formatarTempo, horaChegada, haversine, rumoEntre,
  suavizarAngulo, motoVirada, melhorOrdem, rumoDaRotaEm, escolherRumo
} from './mapa-nav.js?v=75.152';
import { ordenarParadas, moverParada, urlRota } from './rota.js';
import { abrirGoogleComAviso } from './aviso-google.js?v=75.102';

const MAPLIBRE_JS = 'https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js';
const MAPLIBRE_CSS = 'https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.css';
const DESVIO_M = 80, DESVIO_FIXES = 3, RECALC_MIN_MS = 20000, DEBOUNCE_ORDEM_MS = 1500;
const CHAVE_VOZ = 'yapood_mapa_voz';

const ICONE_LOJA = '<i class="fa-solid fa-store" aria-hidden="true"></i>';
const ICONE_CASA = '<i class="fa-solid fa-house" aria-hidden="true"></i>';
const SVG_MOTO_TOPO = '<svg viewBox="0 0 32 48" width="30" height="45" aria-hidden="true"><g fill="currentColor"><rect x="14" y="1" width="4" height="11" rx="2"/><rect x="6" y="12" width="20" height="3" rx="1.5"/><rect x="13" y="12" width="6" height="15" rx="3"/><ellipse cx="16" cy="22" rx="7.5" ry="4.2"/><rect x="7.5" y="28" width="17" height="14" rx="2.8"/><rect x="14" y="41" width="4" height="6" rx="2"/></g><circle cx="16" cy="20" r="3.4" fill="#fff"/><rect x="10" y="31" width="12" height="2" rx="1" fill="#fff"/></svg>';

// ---------------- utilidades ----------------
const ler = (k) => { try { return localStorage.getItem(k) || ''; } catch { return ''; } };
const guardar = (k, v) => { try { localStorage.setItem(k, v); } catch { /* noop */ } };
const rotuloCurto = (end) => String(end || '').split(',').slice(0, 2).join(',').trim();
const icone = (nome) => { const i = document.createElement('i'); i.className = 'fa-solid fa-' + nome; i.setAttribute('aria-hidden', 'true'); return i; }; // V75.94: todos os ícones são do Font Awesome
const IC = (nome) => '<i class="fa-solid fa-' + nome + '" aria-hidden="true"></i>';
const limpar = (el) => { while (el.firstChild) el.removeChild(el.firstChild); };
const el = (tag, cls, texto) => { const e = document.createElement(tag); if (cls) e.className = cls; if (texto !== undefined) e.textContent = texto; return e; };

let libPromise = null;
function carregarLib() {
  if (window.maplibregl) return Promise.resolve(window.maplibregl);
  if (libPromise) return libPromise;
  libPromise = new Promise((resolve, reject) => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = MAPLIBRE_CSS; document.head.appendChild(css);
    const s = document.createElement('script'); s.src = MAPLIBRE_JS; s.async = true;
    const t = setTimeout(() => { libPromise = null; reject(new Error('A biblioteca do mapa demorou demais.')); }, 20000);
    s.onload = () => { clearTimeout(t); window.maplibregl ? resolve(window.maplibregl) : (libPromise = null, reject(new Error('Biblioteca do mapa inválida.'))); };
    s.onerror = () => { clearTimeout(t); libPromise = null; reject(new Error('Não consegui carregar o mapa (internet ou bloqueio).')); };
    document.head.appendChild(s);
  });
  return libPromise;
}
function posicaoUnica() {
  return new Promise((resolve) => {
    if (!('geolocation' in navigator)) return resolve(null);
    navigator.geolocation.getCurrentPosition((p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }), () => resolve(null), { enableHighAccuracy: true, maximumAge: 15000, timeout: 8000 });
  });
}

// ---------------- estado da sessão ----------------
let S = null; // null = sem mapa aberto

function novaSessao(opts) {
  return {
    opts, mapa: null, pronto: false, dom: null,
    stops: new Map(), ordem: [], semCoord: [], visitadas: new Set(), loja: null, estilo: null,
    origem: null, rota: null, pos: null, m: 0, desvioM: 0, desvios: 0, feitos: new Set(), aguardando: null,
    navegando: false, calculando: false, ultimoCalculo: 0, gpsId: null, wake: null,
    voz: ler(CHAVE_VOZ) !== '0', ultimaFala: '', ultimaFalaEm: 0, rumoMoto: null, rumoCam: null, motoEsq: false,
    seguir: true, mkMoto: null, mkPinos: [], timerOrdem: null, semPontos: new Map(), semFeitos: new Set(), semTimer: null,
    minimizado: false, encerrado: false
  };
}

// ---------------- tela ----------------
function montarDom() {
  const raiz = el('div', 'me'); raiz.id = 'me-raiz'; raiz.setAttribute('role', 'dialog'); raiz.setAttribute('aria-label', 'Mapa da rota');
  raiz.innerHTML = `
    <div id="me-mapa" class="me-mapa"></div>
    <p id="me-aviso" class="me-aviso" role="status" hidden></p>
    <header class="me-topo">
      <button type="button" id="me-voltar" class="me-btn" aria-label="Voltar para as entregas">${IC('arrow-left')} Entregas</button>
      <span id="me-titulo" class="me-titulo">Mapa</span>
      <button type="button" id="me-voz" class="me-btn me-icone" aria-label="Voz">${IC('volume-high')}</button>
      <button type="button" id="me-paradas" class="me-btn" aria-label="Paradas">${IC('list-ol')} Paradas</button>
    </header>
    <button type="button" id="me-seg" class="me-btn me-seg" aria-label="Seguir a moto" hidden>${IC('location-crosshairs')}</button>
    <button type="button" id="me-tudo" class="me-btn me-tudo" aria-label="Ver todas as paradas">${IC('maximize')}</button>
    <section id="me-hud" class="me-hud" aria-live="polite">
      <div id="me-sinal" class="me-sinal" hidden aria-hidden="true"></div>
      <div id="me-txt" class="me-txt"><b>Preparando o mapa…</b></div>
      <div id="me-acao" class="me-acao" hidden></div>
    </section>
    <section id="me-folha" class="me-folha" hidden aria-label="Paradas da rota">
      <div class="me-folha-topo"><strong>Paradas</strong><button type="button" id="me-folha-fechar" class="me-btn me-icone" aria-label="Fechar">${IC('xmark')}</button></div>
      <p class="me-ajuda">Use as setas para mudar a ordem. A rota é refeita sozinha.</p>
      <ol id="me-lista" class="me-lista"></ol>
      <p id="me-sem-coord" class="me-aviso-linha" hidden></p>
      <div class="me-folha-acoes">
        <button type="button" id="me-auto" class="me-btn">Melhor ordem</button>
        <button type="button" id="me-atualizar" class="me-btn">${IC('rotate')} Atualizar entregas</button>
        <a id="me-google" class="me-btn" data-google target="_blank" rel="noopener" hidden>Abrir no Google Maps</a>
        <button type="button" id="me-encerrar" class="me-btn me-perigo">Encerrar navegação</button>
      </div>
    </section>`;
  document.body.appendChild(raiz);
  return raiz;
}
const $ = (id) => document.getElementById(id);
function aviso(t, tom) { const a = $('me-aviso'); if (!a) return; const temp = !t && S && S.avisoTemp && S.avisoTemp.ate > Date.now() ? S.avisoTemp.t : ''; const fundo = !t && !temp && S && S.avisoFundo; const txt = t || temp || (fundo ? S.avisoFundo : ''); a.textContent = txt; a.hidden = !txt; a.className = 'me-aviso' + (tom ? ' me-' + tom : (fundo ? ' me-aviso' : '')); } // V75.96: o aviso do fundo do mapa não some quando outro aviso é limpo
function hudTexto(titulo, sub, extra) {
  const box = $('me-txt'); limpar(box);
  box.appendChild(el('b', '', titulo));
  if (sub) box.appendChild(el('span', '', sub));
  if (extra) { const x = el('span', 'me-sem', Array.isArray(extra) ? '' : extra); if (Array.isArray(extra)) { x.appendChild(icone(extra[0])); x.appendChild(document.createTextNode(' ' + extra[1])); } box.appendChild(x); }
}
function acoes(lista) {
  const box = $('me-acao'); limpar(box);
  lista.forEach(([rotulo, fn, cls]) => { const b = el('button', 'me-btn me-grande ' + (cls || ''), Array.isArray(rotulo) ? '' : rotulo); if (Array.isArray(rotulo)) { b.appendChild(icone(rotulo[0])); b.appendChild(document.createTextNode(' ' + rotulo[1])); } b.type = 'button'; b.addEventListener('click', fn); box.appendChild(b); });
  box.hidden = !lista.length;
}
function marcador(cls, conteudo) { const e = el('div', cls); e.innerHTML = conteudo; return e; } // só SVG fixo deste arquivo

// ---------------- mapa ----------------
function estiloVazio() { return { version: 8, sources: {}, layers: [{ id: 'fundo', type: 'background', paint: { 'background-color': '#e9eef2' } }] }; }
// V75.98: fundo de reserva sem chave nem cadastro (OpenFreeMap, dados do OpenStreetMap). Ordem: fundo do servidor (Geoapify, se configurado) → OpenFreeMap → fundo liso.
const FUNDO_RESERVA = 'https://tiles.openfreemap.org/styles/liberty';
function criarMapa() {
  const ml = window.maplibregl;
  const estilos = [S.estilo, FUNDO_RESERVA].filter(Boolean);
  const m = new ml.Map({ container: 'me-mapa', style: estilos[0], center: S.loja && S.loja.lng !== undefined ? [S.loja.lng, S.loja.lat] : [-52, -14], zoom: S.loja && S.loja.lng !== undefined ? 12 : 3.4, attributionControl: true });
  S.mapa = m;
  // O desenho não depende do fundo: rota e marcadores saem assim que o estilo é lido ("style.load"). Se o fundo falhar (chave recusada,
  // internet fraca, lento), passa sozinho para o próximo da lista e, no fim, para um fundo liso — a rota aparece de qualquer jeito.
  const ativo = () => S && S.mapa === m;
  let etapa = 0, esperaErro = false, falhasTile = 0, timer = null;
  const pronto = () => { if (!ativo()) return; clearTimeout(timer); S.pronto = true; desenharTudo(); desenharSemaforos(); if (!S.navegando && !S.rota) enquadrar(); };
  const armar = () => { clearTimeout(timer); esperaErro = false; falhasTile = 0; timer = setTimeout(() => { if (ativo() && !S.pronto) proximo(); }, 8000); };
  const proximo = () => {
    if (!ativo() || etapa >= estilos.length) return;
    etapa++; S.pronto = false;
    const fim = etapa >= estilos.length;
    if (fim) { clearTimeout(timer); S.avisoFundo = 'O fundo do mapa não carregou. Mostro a rota sem as ruas ao redor.'; aviso(S.avisoFundo, 'aviso'); } else armar();
    try { m.setStyle(fim ? estiloVazio() : estilos[etapa], { diff: false }); } catch { pronto(); }
  };
  m.on('style.load', pronto);
  m.on('load', pronto);
  m.on('moveend', () => {});
  m.on('movestart', (e) => { if (e && e.originalEvent && S.navegando) desligarSeguir(); }); // quem arrasta ou dá zoom assume o mapa
  m.on('error', (e) => {
    if (!ativo()) return;
    const st = e && e.error && e.error.status;
    if (S.pronto) { if ((st === 401 || st === 403) && ++falhasTile === 3 && etapa < estilos.length) proximo(); return; } // estilo veio, mas os blocos do mapa foram recusados
    if (esperaErro) return; esperaErro = true;
    const daEtapa = etapa;
    setTimeout(() => { if (ativo() && !S.pronto && etapa === daEtapa) proximo(); }, 1500);
  });
  armar();
  desenharPinos(); desenharMoto();
  enquadrar(); // já mostra a partida e todas as paradas, antes mesmo de a rota chegar
  requestAnimationFrame(() => { try { if (ativo()) m.resize(); } catch { /* noop */ } }); // garante o tamanho depois que o CSS do MapLibre entrou
}
const margemHud = () => ($('me-hud') && $('me-hud').offsetHeight ? $('me-hud').offsetHeight : 90) + 24;
function desenharRota() {
  if (!S.mapa || !S.pronto) return;
  const fc = { type: 'FeatureCollection', features: S.rota ? [{ type: 'Feature', properties: {}, geometry: { type: 'LineString', coordinates: S.rota.coords } }] : [] };
  const src = S.mapa.getSource('rota');
  if (src) { src.setData(fc); return; }
  S.mapa.addSource('rota', { type: 'geojson', data: fc });
  S.mapa.addLayer({ id: 'rota-borda', type: 'line', source: 'rota', layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': '#ffffff', 'line-width': 9 } });
  S.mapa.addLayer({ id: 'rota-linha', type: 'line', source: 'rota', layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': '#e8590c', 'line-width': 5 } });
}
function desenharPinos() {
  if (!S.mapa || !window.maplibregl) return;
  S.mkPinos.forEach((p) => p && p.remove()); S.mkPinos = [];
  const ml = window.maplibregl;
  if (S.origem && S.origem.fonte === 'loja') S.mkPinos.push(new ml.Marker({ element: marcador('me-pino a', ICONE_LOJA) }).setLngLat([S.origem.lng, S.origem.lat]).addTo(S.mapa));
  const vistos = new Map(); // paradas no mesmo ponto (mesmo prédio, endereço repetido): os pinos ficam lado a lado em vez de um em cima do outro
  S.ordem.forEach((id, i) => {
    const s = S.stops.get(id); if (!s || S.visitadas.has(id)) return;
    const pino = marcador('me-pino b' + (s.fraca ? ' fraca' : ''), ICONE_CASA + '<i class="num">' + (i + 1) + '</i>');
    const ch = s.coord.lat.toFixed(5) + ',' + s.coord.lng.toFixed(5), rep = vistos.get(ch) || 0; vistos.set(ch, rep + 1);
    const opt = { element: pino }; if (rep) opt.offset = [rep % 2 ? 22 * Math.ceil(rep / 2) : -22 * (rep / 2), 0];
    S.mkPinos.push(new ml.Marker(opt).setLngLat([s.coord.lng, s.coord.lat]).addTo(S.mapa));
  });
}
function desenharMoto() {
  if (!S.mapa || !window.maplibregl || !S.pos) return;
  // V75.153: a moto é alinhada ao MAPA e gira para onde anda. Antes ela só ficava "para cima da tela": fora do modo seguir
  // (antes de Iniciar, depois de arrastar o mapa, recalculando) parecia andar na contramão, porque o mapa continuava com o norte para cima.
  if (!S.mkMoto) S.mkMoto = new window.maplibregl.Marker({ element: marcador('me-moto', SVG_MOTO_TOPO), rotationAlignment: 'map', pitchAlignment: 'map' }).setLngLat([S.pos.lng, S.pos.lat]).addTo(S.mapa);
  else S.mkMoto.setLngLat([S.pos.lng, S.pos.lat]);
  let rumo = S.rumoMoto;
  if (typeof rumo !== 'number' && S.rota) { try { rumo = rumoDaRotaEm(S.rota, projetar(S.rota, S.pos.lng, S.pos.lat, S.m || 0).m); } catch { rumo = null; } }
  if (typeof rumo === 'number' && Number.isFinite(rumo) && typeof S.mkMoto.setRotation === 'function') S.mkMoto.setRotation(rumo);
}
function desenharTudo() { desenharPinos(); desenharRota(); desenharMoto(); }
/** Pontos que precisam caber na tela: partida, paradas que faltam e a rota inteira (se já existe). */
function pontosDoEnquadro() {
  const pts = [];
  if (S.rota) S.rota.coords.forEach((p) => pts.push(p));
  if (S.origem) pts.push([S.origem.lng, S.origem.lat]);
  if (S.pos) pts.push([S.pos.lng, S.pos.lat]);
  idsPendentes().forEach((id) => { const st = S.stops.get(id); if (st) pts.push([st.coord.lng, st.coord.lat]); });
  return pts;
}
// V75.99: o enquadramento não depende mais da rota estar pronta: se o cálculo falhar (limite, internet), as paradas continuam à vista.
function enquadrar() {
  if (!S.mapa) return;
  const pts = pontosDoEnquadro();
  if (!pts.length) return;
  const padding = { top: 70, left: 40, right: 40, bottom: margemHud() + 30 };
  let w = 180, s = 90, e = -180, n = -90;
  pts.forEach((p) => { w = Math.min(w, p[0]); e = Math.max(e, p[0]); s = Math.min(s, p[1]); n = Math.max(n, p[1]); });
  try { S.mapa.fitBounds([[w, s], [e, n]], { padding, duration: S.pronto ? 600 : 0, bearing: 0, maxZoom: 17 }); } catch { /* noop */ }
}
function verTudo() { if (S.navegando) desligarSeguir(); enquadrar(); }
function centralizar(forcar) {
  if (!S.mapa || !S.pos || (!forcar && !S.seguir)) return;
  const cam = { center: [S.pos.lng, S.pos.lat], zoom: Math.max(S.mapa.getZoom(), 16), duration: 900, easing: (t) => t, essential: true,
    padding: { top: Math.round(($('me-mapa').clientHeight || 600) * 0.30), left: 0, right: 0, bottom: margemHud() } };
  if (typeof S.rumoCam === 'number') cam.bearing = S.rumoCam; // o mapa gira: a moto sempre aponta para cima
  try { S.mapa.easeTo(cam); } catch { /* noop */ }
}
function desligarSeguir() { if (!S.seguir) return; S.seguir = false; $('me-seg').hidden = false; }
function ligarSeguir() { S.seguir = true; $('me-seg').hidden = true; centralizar(true); }

// ---------------- semáforos (OpenStreetMap, guardados na API por região) ----------------
// V75.96: o semáforo no mapa também é ícone do Font Awesome (traffic-light, \uf637), desenhado num canvas porque o MapLibre pede imagem para símbolos.
let fontePromessa = null;
const fonteIconesPronta = () => fontePromessa || (fontePromessa = (document.fonts && document.fonts.load ? document.fonts.load('900 30px "Font Awesome 6 Free"').catch(() => []) : Promise.resolve([])));
function imagemSemaforo() {
  const t = 40, c = document.createElement('canvas'); c.width = t; c.height = t; const g = c.getContext('2d');
  g.font = '900 30px "Font Awesome 6 Free"'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.lineJoin = 'round'; g.lineWidth = 6; g.strokeStyle = '#ffffff'; g.strokeText('\uf637', t / 2, t / 2 + 1);
  g.fillStyle = '#1f2328'; g.fillText('\uf637', t / 2, t / 2 + 1);
  return g.getImageData(0, 0, t, t);
}
function desenharSemaforos() {
  if (!S || !S.mapa || !S.pronto) return;
  if (!S.semFonte) { // espera a fonte de ícones ficar pronta antes de desenhar a imagem do semáforo
    if (!S.semEsperando) { S.semEsperando = true; const s0 = S; fonteIconesPronta().then(() => { s0.semFonte = true; if (S === s0) desenharSemaforos(); }); }
    return;
  }
  const fc = { type: 'FeatureCollection', features: [...S.semPontos.values()].map((p) => ({ type: 'Feature', properties: {}, geometry: { type: 'Point', coordinates: [p.lon, p.lat] } })) };
  const src = S.mapa.getSource('semaforos');
  if (src) { src.setData(fc); return; }
  try { if (!S.mapa.hasImage || !S.mapa.hasImage('semaforo')) S.mapa.addImage('semaforo', imagemSemaforo()); } catch { /* noop */ }
  S.mapa.addSource('semaforos', { type: 'geojson', data: fc });
  S.mapa.addLayer({ id: 'semaforos', type: 'symbol', source: 'semaforos', minzoom: 14, layout: { 'icon-image': 'semaforo', 'icon-size': ['interpolate', ['linear'], ['zoom'], 14, 0.5, 18, 0.9], 'icon-allow-overlap': true, 'icon-ignore-placement': true } });
}
function ligarSemaforosARota() {
  if (!S.rota) return;
  S.rota.sem = semaforosNaRota(S.rota, [...S.semPontos.entries()].map(([id, p]) => ({ id, lat: p.lat, lon: p.lon })));
  atualizarNav();
}
/** Pedaços de no máximo 0,12° da caixa da rota (a API aceita áreas pequenas). */
function pedacosDaRota() {
  if (!S.rota) return [];
  let w = 180, s = 90, e = -180, n = -90;
  S.rota.coords.forEach((p) => { w = Math.min(w, p[0]); e = Math.max(e, p[0]); s = Math.min(s, p[1]); n = Math.max(n, p[1]); });
  const mg = 0.003, out = [], P = 0.12;
  for (let la = s - mg; la < n + mg && out.length < 6; la += P) for (let lo = w - mg; lo < e + mg && out.length < 6; lo += P) out.push({ s: la, w: lo, n: Math.min(la + P, n + mg), e: Math.min(lo + P, e + mg) });
  return out;
}
async function carregarSemaforos() {
  const sessao = S;
  for (const c of pedacosDaRota()) {
    const chave = [c.s, c.w, c.n, c.e].map((x) => x.toFixed(2)).join(',');
    if (sessao.semFeitos.has(chave)) continue;
    try {
      const r = await sessao.opts.chamar('/entregador/mapa/semaforos', { caixa: c });
      if (S !== sessao) return;
      (r.pontos || []).forEach((p) => sessao.semPontos.set(p[0], { lat: p[1], lon: p[2] }));
      if (!r.parcial) sessao.semFeitos.add(chave);
      desenharSemaforos(); ligarSemaforosARota();
    } catch { /* semáforo é só um extra: sem eles o mapa segue igual */ }
  }
}

// ---------------- voz ----------------
const vozesPt = () => { try { return (speechSynthesis.getVoices() || []).filter((v) => /^pt/i.test(v.lang)); } catch { return []; } };
function falar(txt) {
  if (!S.voz || !txt) return;
  const agora = Date.now();
  if (txt === S.ultimaFala && agora - S.ultimaFalaEm < 8000) return; // só barra eco do GPS
  S.ultimaFala = txt; S.ultimaFalaEm = agora;
  if (!('speechSynthesis' in window)) return;
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(txt); u.lang = 'pt-BR';
    const v = vozesPt().find((x) => /pt[-_]BR/i.test(x.lang)) || vozesPt()[0]; if (v) u.voice = v;
    speechSynthesis.speak(u);
  } catch { /* noop */ }
}
function aplicarVoz() {
  const b = $('me-voz'); b.innerHTML = IC(S.voz ? 'volume-high' : 'volume-xmark'); b.classList.toggle('off', !S.voz);
  guardar(CHAVE_VOZ, S.voz ? '1' : '0');
  if (!S.voz) { try { speechSynthesis.cancel(); } catch { /* noop */ } }
}

// ---------------- paradas e rota ----------------
const idsPendentes = () => S.ordem.filter((id) => !S.visitadas.has(id));
const numeroDaParada = (id) => S.ordem.indexOf(id) + 1;

function listarParadas() {
  const ol = $('me-lista'); limpar(ol);
  const pend = idsPendentes();
  S.ordem.forEach((id, i) => {
    const s = S.stops.get(id); if (!s) return;
    const feita = S.visitadas.has(id);
    const li = el('li', feita ? 'feita' : '');
    const info = el('div', 'me-par-info');
    { const st = el('strong', '', (i + 1) + '. Pedido #' + s.numero + (feita ? ' ' : '')); if (feita) st.appendChild(icone('circle-check')); info.appendChild(st); }
    info.appendChild(el('span', '', s.endereco));
    if (s.fraca && !feita) { const em = el('em', '', ''); em.appendChild(icone('triangle-exclamation')); em.appendChild(document.createTextNode(' endereço aproximado — confira com o cliente')); info.appendChild(em); }
    if (s.divergente && !feita) { const em = el('em', '', ''); em.appendChild(icone('location-dot')); em.appendChild(document.createTextNode(' o GPS do cliente estava longe do endereço digitado; a rota usa o endereço')); info.appendChild(em); }
    li.appendChild(info);
    const mv = el('div', 'me-par-mover');
    [['−1', 'arrow-up', 'Subir parada'], ['1', 'arrow-down', 'Descer parada']].forEach(([d, t, rot]) => {
      const b = el('button', 'me-btn me-icone', ''); b.appendChild(icone(t)); b.type = 'button'; b.setAttribute('aria-label', rot);
      const pos = pend.indexOf(id); const limite = d === '-1' ? pos <= 0 : pos >= pend.length - 1;
      b.disabled = feita || limite;
      b.addEventListener('click', () => moverNaOrdem(id, Number(d)));
      mv.appendChild(b);
    });
    li.appendChild(mv); ol.appendChild(li);
  });
  const sc = $('me-sem-coord');
  sc.hidden = !S.semCoord.length;
  sc.textContent = S.semCoord.length ? (S.semCoord.length === 1 ? '1 entrega sem localização no mapa (pedido #' + S.semCoord[0].numero + '): use o Google Maps para ela.' : S.semCoord.length + ' entregas sem localização no mapa: use o Google Maps para elas.') : '';
  const g = $('me-google'), r = urlRota(pend.map((id) => S.stops.get(id).endereco).concat(S.semCoord.map((x) => x.endereco)));
  g.hidden = !r; if (r) g.href = r.url;
}
function moverNaOrdem(id, delta) {
  const pend = idsPendentes(), novo = moverParada(pend, id, delta);
  S.ordem = S.ordem.filter((x) => S.visitadas.has(x)).concat(novo);
  S.opts.salvarOrdem && S.opts.salvarOrdem(S.ordem.slice());
  listarParadas(); desenharPinos();
  agendarRecalculo();
}
function ordemAutomatica() {
  const pend = idsPendentes(); if (pend.length < 3) { aviso('Com 2 paradas só há duas ordens possíveis. Use as setas.', 'aviso'); setTimeout(() => aviso(''), 3000); return; }
  const o = S.pos || S.origem; if (!o) return;
  const pts = pend.map((id) => ({ ...S.stops.get(id).coord }));
  const melhor = melhorOrdem(o, pts);
  if (!melhor) return;
  S.ordem = S.ordem.filter((x) => S.visitadas.has(x)).concat(melhor.map((i) => pend[i]));
  S.opts.salvarOrdem && S.opts.salvarOrdem(S.ordem.slice());
  listarParadas(); desenharPinos(); agendarRecalculo(0);
}
function agendarRecalculo(ms) { clearTimeout(S.timerOrdem); const sessao = S; S.timerOrdem = setTimeout(() => { if (S === sessao) calcularRota(); }, ms === undefined ? DEBOUNCE_ORDEM_MS : ms); }

/** Calcula a rota da posição atual (ou da partida) até as paradas que faltam, na ordem. */
async function calcularRota(tentativa = 0) {
  const sessao = S;
  const ids = idsPendentes();
  const origem = S.pos || S.origem;
  if (!ids.length) return;
  if (!origem) { hudTexto('Sem posição de partida', 'Ative a localização do aparelho.'); return; }
  if (S.calculando) { agendarRecalculo(1500); return; }
  S.calculando = true; aviso(tentativa ? 'Calculando de novo…' : 'Calculando a rota…');
  try {
    const usar = ids.slice(0, 6);
    const r = await S.opts.chamar('/entregador/mapa/rota', { origem: { lat: origem.lat, lng: origem.lng }, pedidoKeys: usar });
    if (S !== sessao) return;
    const rota = construirRota(r.rota);
    if (!rota) throw Object.assign(new Error('Não encontrei rota entre esses pontos.'), { status: 404 });
    rota.paradas = usar.map((id) => ({ id, endereco: S.stops.get(id).endereco }));
    rota.passos.forEach((p) => { if (/^destination/i.test(p.tipo)) p.rotuloParada = rotuloCurto(rota.paradas[p.perna] && rota.paradas[p.perna].endereco); });
    rota.concl = new Set(); rota.passou = new Set(); // passou = paradas em que o entregador já chegou perto (ver limitarAvanco)
    S.rota = rota; S.m = 0; S.desvioM = 0; S.desvios = 0; S.feitos = new Set(); S.aguardando = null; S.acaoFim = false; S.ultimoCalculo = Date.now();
    if (S.navegando) acoes([]); // a rota nova começa limpa; o botão volta sozinho se ainda estiver na parada
    aviso(S.opts.extrasRota ? S.opts.extrasRota(ids.length - usar.length) : (ids.length > usar.length ? 'O mapa leva ' + usar.length + ' paradas por rota; as ' + (ids.length - usar.length) + ' últimas ficam para depois.' : ''), ids.length > usar.length ? 'aviso' : '');
    desenharRota(); ligarSemaforosARota(); carregarSemaforos();
    if (!S.navegando) enquadrar();
    mostrarResumo(); atualizarNav();
  } catch (err) {
    if (S !== sessao) return;
    if (err.status === 429 && tentativa < 2 && !/limite di/i.test(err.message)) { S.calculando = false; setTimeout(() => { if (S === sessao) calcularRota(tentativa + 1); }, 3500); return; }
    aviso(err.message || 'Não consegui calcular a rota agora.', 'erro');
    if (!S.rota) { hudTexto('Sem rota', (err.message || 'Tente de novo em instantes.') + ' As paradas estão no mapa.'); acoes([[['rotate', 'Tentar de novo'], () => calcularRota(), 'principal']]); if (!S.navegando) enquadrar(); }
  } finally { if (S === sessao) S.calculando = false; }
}

const notaSemCoord = () => S.semCoord.length ? ' · ' + (S.semCoord.length === 1 ? 'A entrega #' + S.semCoord[0].numero + ' não foi achada no mapa e ficou fora da rota.' : S.semCoord.length + ' entregas não foram achadas no mapa e ficaram fora da rota.') : '';
function mostrarResumo() {
  if (!S.rota || S.navegando) return;
  const n = S.rota.paradasM.length;
  hudTexto(n + (n === 1 ? ' entrega' : ' entregas') + ' · ' + formatarDist(S.rota.apiDist || S.rota.total) + ' · ' + formatarTempo(S.rota.tempoS), 'Toque em Iniciar para navegar com voz.' + notaSemCoord());
  $('me-sinal').hidden = true;
  acoes([[['play', 'Iniciar'], iniciarNavegacao, 'principal'], [['list-ol', 'Ordem das paradas'], () => abrirFolha(true)]]);
}

// ---------------- navegação ----------------
function iniciarNavegacao() {
  if (!S.rota) return;
  S.navegando = true; S.seguir = true; $('me-seg').hidden = true; acoes([]);
  aviso('');
  pedirTela();
  if (!('geolocation' in navigator)) { hudTexto('Sem GPS', 'Este aparelho não liberou a localização.'); return; }
  S.gpsId = navigator.geolocation.watchPosition(
    (p) => aplicarPosicao(p.coords.longitude, p.coords.latitude, typeof p.coords.heading === 'number' && !isNaN(p.coords.heading) ? p.coords.heading : undefined, p.coords.accuracy),
    (e) => { if (e.code === 1) { aviso('Localização negada. Libere o GPS para navegar.', 'erro'); pararGps(); } else aviso('Sinal de GPS fraco. Continua tentando…', 'aviso'); }, // só a permissão negada encerra
    { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 });
  // V75.152: já começa virado para o lado da rota e com o mapa centralizado, sem esperar o aparelho andar (antes ficava norte para cima e a moto apontava errado)
  if (S.pos) {
    const r0 = rumoDaRotaEm(S.rota, projetar(S.rota, S.pos.lng, S.pos.lat, S.m || 0).m);
    if (typeof r0 === 'number') { S.rumoMoto = r0; S.rumoCam = r0; }
    centralizar(true);
  }
  falar('Navegação iniciada');
  atualizarNav();
}
function pararGps() { if (S.gpsId !== null) { try { navigator.geolocation.clearWatch(S.gpsId); } catch { /* noop */ } S.gpsId = null; } }
async function pedirTela() { try { if (navigator.wakeLock && !S.wake) { S.wake = await navigator.wakeLock.request('screen'); S.wake.addEventListener?.('release', () => { if (S) S.wake = null; }); } } catch { if (S) S.wake = null; } }
function soltarTela() { if (S && S.wake) { try { S.wake.release(); } catch { /* noop */ } S.wake = null; } }

function aplicarPosicao(lng, lat, rumoGps, precisao) {
  const navegando = !!(S.rota && S.navegando);
  const pj = navegando ? limitarAvanco(projetar(S.rota, lng, lat, S.m), lng, lat) : null;
  // V75.152: rumo do deslocamento medido desde o último ponto de referência (≥ 12 m), não de um segundo para o outro:
  // a pé ou a menos de ~40 km/h o GPS quase nunca passava de 8 m por leitura e o mapa nunca girava. Sinal fraco (>40 m) não conta.
  let deslocado = null;
  if (!S.ancora) S.ancora = { lng, lat };
  else if (haversine([S.ancora.lng, S.ancora.lat], [lng, lat]) >= 12 && !(typeof precisao === 'number' && precisao > 40)) {
    deslocado = rumoEntre([S.ancora.lng, S.ancora.lat], [lng, lat]); S.ancora = { lng, lat };
  }
  const rumo = escolherRumo({ gps: rumoGps, deslocado, rumoRota: pj ? rumoDaRotaEm(S.rota, pj.m) : null, desvioM: pj ? pj.desvioM : null });
  if (typeof rumo === 'number') { S.rumoMoto = rumo; S.rumoCam = suavizarAngulo(S.rumoCam, rumo, 0.35); }
  S.pos = { lng, lat }; desenharMoto();
  if (!pj) { if (S.navegando) centralizar(false); return; } // V75.153: recalculando a rota (sem rota por instantes), a câmera continua seguindo a moto
  S.m = pj.m; S.desvioM = pj.desvioM;
  verificarDesvio();
  atualizarNav(); anunciar(); centralizar(false);
}
/**
 * V75.101: o progresso na rota não pula uma parada. Rota curta que volta ao ponto de partida (paradas no mesmo endereço, retorno no quarteirão)
 * deixa o GPS perto do início E do fim ao mesmo tempo; sem este limite a moto "chegava ao destino" sem passar pela parada 1.
 * Regra: chegou a 40 m da parada → o avanço fica nela até o entregador tocar "Entreguei" ou se afastar 80 m; longe dela (>100 m) o avanço é livre.
 */
const DIST_CHEGOU = 40, DIST_FICA = 80, DIST_LONGE = 100;
function distanciaAParada(k, lng, lat) { const pt = posicaoAoLongo(S.rota, S.rota.paradasM[k]); return haversine([lng, lat], [pt.lng, pt.lat]); }
/** V75.101: chegada também por proximidade do GPS ao endereço (rota curta que volta ao ponto de partida deixa o "metro percorrido" enganoso). */
const pertoDaParada = (k, raio) => !!(S.pos && S.rota && distanciaAParada(k, S.pos.lng, S.pos.lat) <= raio);
function limitarAvanco(pj, lng, lat) {
  const R = S.rota, n = R.paradasM.length, k = paradaAlvo(R, S.m, R.concl);
  if (k >= n - 1 || R.concl.has(k) || pj.m <= R.paradasM[k]) return pj;
  const d = distanciaAParada(k, lng, lat);
  if (d <= DIST_CHEGOU) R.passou.add(k);
  const preso = R.passou.has(k) ? d <= DIST_FICA : d <= DIST_LONGE;
  return preso ? { m: R.paradasM[k], desvioM: pj.desvioM } : pj;
}
/** Fora da rota por algumas leituras seguidas: refaz a rota a partir de onde o entregador está. */
function verificarDesvio() {
  if (S.desvioM > DESVIO_M) S.desvios++; else S.desvios = 0;
  if (S.desvios >= DESVIO_FIXES && !S.calculando && Date.now() - S.ultimoCalculo > RECALC_MIN_MS) { S.desvios = 0; falar('Recalculando a rota'); calcularRota(); }
}
function anunciar() {
  const frases = anunciosPendentes(S.rota, S.m, S.feitos, 'api', true);
  const chegada = verificarParada();
  if (chegada) frases.push(chegada);
  if (frases.length) falar(juntarFalas(frases));
}
function paradaAtual() { const k = paradaAlvo(S.rota, S.m, S.rota.concl); return { k, id: S.rota.paradas[k] && S.rota.paradas[k].id }; }
function verificarParada() {
  const R = S.rota, n = R.paradasM.length, k = paradaAlvo(R, S.m, R.concl);
  if (k < n - 1 && !R.concl.has(k) && (R.paradasM[k] - S.m <= 25 || pertoDaParada(k, 25))) {
    if (S.aguardando !== k) {
      S.aguardando = k; mostrarChegada(k);
      const lugar = rotuloCurto(R.paradas[k].endereco);
      return 'Você chegou à parada ' + numeroDaParada(R.paradas[k].id) + (lugar ? ', ' + lugar : '');
    }
  } else if (S.aguardando !== null && (S.m - R.paradasM[S.aguardando] > 80 || (S.pos && distanciaAParada(S.aguardando, S.pos.lng, S.pos.lat) > DIST_LONGE))) { // seguiu viagem sem tocar no botão
    R.concl.add(S.aguardando); S.visitadas.add(R.paradas[S.aguardando].id); S.aguardando = null; acoes([]); listarParadas();
  }
  return null;
}
function mostrarChegada(k) {
  const id = S.rota.paradas[k].id;
  acoes([[['check', 'Entreguei — seguir para a próxima'], seguirParada, 'principal'], ['Informar o código', () => irParaCartao(id)]]);
}
function irParaCartao(id) { minimizar(); S.opts.irParaCartao && S.opts.irParaCartao(id); }
function seguirParada() {
  if (!S.rota || S.aguardando === null) return;
  const k = S.aguardando; S.rota.concl.add(k); S.visitadas.add(S.rota.paradas[k].id); S.aguardando = null; acoes([]);
  listarParadas(); desenharPinos(); atualizarNav();
  const fr = anunciosPendentes(S.rota, S.m, S.feitos, 'api', true); if (fr.length) falar(juntarFalas(fr));
}

function atualizarNav() {
  if (!S || !S.rota) return;
  const R = S.rota, m = Math.max(0, Math.min(R.total, S.m));
  if (!S.navegando) return;
  const falta = R.total - m, prox = proximaManobra(R, m), n = R.paradasM.length, k = paradaAlvo(R, m, R.concl);
  const faltaParada = Math.max(0, R.paradasM[k] - m), ini = k ? R.paradasM[k - 1] : 0, tam = Math.max(1, R.paradasM[k] - ini);
  const tempoPerna = (R.pernas[k] && R.pernas[k].tempo ? R.pernas[k].tempo : R.tempoS * (tam / R.total)) * (faltaParada / tam);
  const chegouFim = falta <= 15 || (k === n - 1 && pertoDaParada(k, 20)), chegouParada = !chegouFim && k < n - 1 && (faltaParada <= 15 || pertoDaParada(k, 20)) && !R.concl.has(k);
  const total = S.ordem.length, idk = R.paradas[k] && R.paradas[k].id, lbl = rotuloCurto(R.paradas[k] && R.paradas[k].endereco);
  const proxEhChegada = /^destination/i.test(prox.tipo);
  const titulo = chegouFim ? 'Chegou ao destino' : chegouParada ? 'Chegou à parada ' + numeroDaParada(idk) + (lbl ? ' — ' + lbl : '')
    : proxEhChegada ? 'Siga até ' + (k < n - 1 ? 'a parada ' + numeroDaParada(idk) : 'o destino') + (lbl ? ' — ' + lbl : '') : textoPasso(prox, 'api');
  const resto = n > 1 ? tempoPerna : R.tempoS * (falta / R.total);
  const sub = chegouFim ? '' : (total > 1 ? 'Parada ' + numeroDaParada(idk) + ' de ' + total + ' · ' : '') + 'Faltam ' + formatarDist(n > 1 ? faltaParada : falta) + ' · ' + formatarTempo(resto) + ' · chega às ' + horaChegada(resto) + (S.desvioM > DESVIO_M ? ' · FORA DA ROTA' : '');
  const sf = !chegouFim ? proximoSemaforo(R, m, 400) : null;
  hudTexto(titulo, sub, sf ? ['traffic-light', 'Semáforo em ' + formatarDist(sf.dist)] : '');
  const sinal = $('me-sinal'); sinal.hidden = false; limpar(sinal);
  sinal.innerHTML = iconeSinal(chegouFim || chegouParada ? 'chegada' : sinalDoPasso(prox.tipo)); // SVG fixo do motor
  if (!chegouFim && !chegouParada) sinal.appendChild(el('small', '', formatarDist(Math.max(0, prox.inicioM - m))));
  if (chegouFim && !S.acaoFim) { S.acaoFim = true; acoes([['Informar o código', () => irParaCartao(R.paradas[n - 1].id), 'principal'], ['Encerrar navegação', encerrar]]); }
}

// ---------------- folha de paradas, minimizar, encerrar ----------------
function abrirFolha(abrir) { $('me-folha').hidden = !abrir; if (abrir) listarParadas(); }
function minimizar() {
  if (!S) return;
  S.minimizado = true; $('me-raiz').classList.add('me-escondido');
  let volta = $('me-volta');
  if (!volta) { volta = el('button', 'me-volta', ''); volta.appendChild(icone('map-location-dot')); volta.appendChild(document.createTextNode(' Voltar ao mapa')); volta.id = 'me-volta'; volta.type = 'button'; volta.addEventListener('click', reabrir); document.body.appendChild(volta); }
  volta.hidden = false;
}
function reabrir() {
  if (!S) return;
  S.minimizado = false; $('me-raiz').classList.remove('me-escondido');
  const v = $('me-volta'); if (v) v.hidden = true;
  try { S.mapa && S.mapa.resize(); } catch { /* noop */ }
  if (S.pos && S.navegando) centralizar(true); else enquadrar();
}
export function encerrar() {
  if (!S) return;
  const sessao = S; S = sessao; clearTimeout(sessao.timerOrdem); clearTimeout(sessao.semTimer);
  pararGps(); soltarTela();
  try { speechSynthesis.cancel(); } catch { /* noop */ }
  try { sessao.mapa && sessao.mapa.remove(); } catch { /* noop */ }
  const r = $('me-raiz'); if (r) r.remove();
  const v = $('me-volta'); if (v) v.remove();
  sessao.encerrado = true; S = null;
  sessao.opts.aoFechar && sessao.opts.aoFechar();
}

// ---------------- abrir / atualizar ----------------
function montarParadas(prep, ativos) {
  const porId = new Map((prep.paradas || []).map((p) => [p.pedidoKey, p]));
  S.stops = new Map(); S.semCoord = [];
  ativos.forEach((a) => {
    const p = porId.get(a.id);
    if (p && p.coord) S.stops.set(a.id, { id: a.id, numero: a.numero, endereco: a.endereco, coord: p.coord, fraca: p.fraca === true, divergente: p.divergente === true });
    else S.semCoord.push({ id: a.id, numero: a.numero, endereco: a.endereco });
  });
}
function definirOrdem(ordemSalva) {
  const lista = [...S.stops.values()].map((s) => ({ id: s.id }));
  S.ordem = ordenarParadas(lista, ordemSalva || []).map((p) => p.id);
  if (!(ordemSalva && ordemSalva.length) && S.ordem.length >= 3 && S.origem) {
    const pts = S.ordem.map((id) => ({ ...S.stops.get(id).coord })), melhor = melhorOrdem(S.origem, pts);
    if (melhor) { S.ordem = melhor.map((i) => S.ordem[i]); S.opts.salvarOrdem && S.opts.salvarOrdem(S.ordem.slice()); }
  }
}

/**
 * opts: { chamar(rota, corpo), paradas: [{id, numero, endereco}], ordemSalva: [ids], salvarOrdem(ids), irParaCartao(id), aoFechar(), urlGoogle }
 * Devolve uma promessa que resolve quando o mapa já mostra a rota (ou falha com mensagem).
 */
export async function abrirMapa(opts) {
  if (S) { if (S.minimizado) reabrir(); return; }
  S = novaSessao(opts);
  const sessao = S;
  S.dom = montarDom();
  $('me-voltar').addEventListener('click', minimizar);
  $('me-voz').addEventListener('click', () => { S.voz = !S.voz; aplicarVoz(); });
  $('me-paradas').addEventListener('click', () => abrirFolha($('me-folha').hidden));
  $('me-folha-fechar').addEventListener('click', () => abrirFolha(false));
  $('me-seg').addEventListener('click', ligarSeguir);
  $('me-tudo').addEventListener('click', verTudo);
  $('me-auto').addEventListener('click', ordemAutomatica);
  $('me-atualizar').addEventListener('click', atualizarPeloServidor);
  $('me-encerrar').addEventListener('click', encerrar);
  aplicarVoz();
  try {
    const [prep, pos] = await Promise.all([opts.chamar('/entregador/mapa/preparar', {}), carregarLib().then(() => posicaoUnica(), (e) => { throw e; })]);
    if (S !== sessao) return;
    S.loja = prep.loja || null; S.estilo = prep.estilo || null;
    S.origem = pos ? { ...pos, fonte: 'gps' } : (S.loja && typeof S.loja.lat === 'number' ? { lat: S.loja.lat, lng: S.loja.lng, fonte: 'loja' } : null);
    if (pos) S.pos = { lat: pos.lat, lng: pos.lng };
    montarParadas(prep, opts.paradas || []);
    if (!S.stops.size) { hudTexto('Sem localização para o mapa', S.semCoord.length ? 'Não achei o endereço no mapa. Use o Google Maps.' : 'Nenhuma entrega com endereço.'); if (!S.semCoord.length) return; listarParadas(); abrirFolha(true); return; }
    definirOrdem(opts.ordemSalva);
    if (!S.origem) { hudTexto('Sem posição de partida', 'Libere a localização do aparelho.'); }
    criarMapa(); listarParadas();
    if (S.origem) await calcularRota();
  } catch (err) {
    if (S !== sessao) return;
    hudTexto('Não consegui abrir o mapa', err.message || 'Tente de novo.');
    aviso(err.message || 'Erro ao abrir o mapa.', 'erro');
    const g = opts.urlGoogle && opts.urlGoogle();
    acoes([...(g ? [['Abrir no Google Maps', () => abrirGoogleComAviso(g)]] : []), ['Fechar', encerrar]]);
  }
}
async function atualizarPeloServidor() {
  const sessao = S; aviso('Atualizando as entregas…');
  try {
    const ativos = S.opts.paradasAtuais ? S.opts.paradasAtuais() : S.opts.paradas;
    const prep = await S.opts.chamar('/entregador/mapa/preparar', {});
    if (S !== sessao) return;
    const antes = new Set(S.visitadas);
    montarParadas(prep, ativos);
    S.visitadas = new Set([...antes].filter((id) => S.stops.has(id)));
    definirOrdem(S.opts.ordemAtual ? S.opts.ordemAtual() : S.ordem);
    listarParadas(); desenharPinos(); aviso('');
    if (idsPendentes().length) await calcularRota(); else { aviso('Todas as entregas foram feitas.', 'ok'); }
  } catch (err) { aviso(err.message || 'Não consegui atualizar.', 'erro'); }
}

/** O app avisa quando a lista de entregas mudou (uma foi confirmada, outra chegou). */
export function atualizarEntregas(ativos, canceladas = []) {
  if (!S) return;
  const ids = new Set(ativos.map((a) => a.id));
  const sumiu = [...S.stops.keys()].filter((id) => !ids.has(id));
  const nova = ativos.filter((a) => !S.stops.has(a.id) && !S.semCoord.some((x) => x.id === a.id));
  S.opts.paradas = ativos;
  if (sumiu.length) {
    // V75.101: pedido cancelado a caminho sai da rota na hora, com aviso (e voz) — a rota é refeita sem ele
    const canc = sumiu.filter((id) => canceladas.includes(id)).map((id) => S.stops.get(id) && S.stops.get(id).numero).filter(Boolean);
    sumiu.forEach((id) => { S.stops.delete(id); S.visitadas.delete(id); });
    S.ordem = S.ordem.filter((id) => !sumiu.includes(id));
    S.semCoord = S.semCoord.filter((x) => ids.has(x.id));
    listarParadas(); desenharPinos();
    if (canc.length) { const t = canc.length === 1 ? 'O pedido #' + canc[0] + ' foi cancelado e saiu da rota.' : 'Os pedidos ' + canc.map((n) => '#' + n).join(', ') + ' foram cancelados e saíram da rota.'; S.avisoTemp = { t, ate: Date.now() + 10000 }; aviso(t, 'aviso'); falar(t.replace(/#/g, '')); }
    if (!S.stops.size || !idsPendentes().length) {
      if (canc.length) { hudTexto('Sem entregas na rota', canc.length === 1 ? 'O pedido foi cancelado.' : 'Os pedidos foram cancelados.'); } else { aviso('Todas as entregas foram feitas.', 'ok'); hudTexto('Entregas concluídas', 'Bom trabalho!'); }
      acoes([['Fechar o mapa', encerrar, 'principal']]); S.navegando = false; return;
    }
    if (S.rota) agendarRecalculo(500);
  }
  if (nova.length) aviso(nova.length === 1 ? 'Chegou uma entrega nova. Em Paradas, toque em “Atualizar entregas” para incluir.' : nova.length + ' entregas novas. Em Paradas, toque em “Atualizar entregas” para incluir.', 'aviso');
}
export const mapaAberto = () => !!S;
