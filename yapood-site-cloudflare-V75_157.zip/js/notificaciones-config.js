export const FCM_VAPID_KEY = 'BEN9d2ErSdokn3ZMDOI65sXdBcEhvf8alVzq5szSU6vC9-UTNiHkNW83vBsMNIeJ17rjZwFYpvpqm_zrqKvsduE';
export const NOTPUSH_API = 'https://api-notpush-delivery.onrender.com';
