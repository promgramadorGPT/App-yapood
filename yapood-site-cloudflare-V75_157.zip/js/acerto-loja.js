// V75.50 — painel da loja: comissão a pagar (saldo, como pagar, "Avisar que paguei", histórico).
import { db, auth, ref, onValue, push, set } from './firebase.js';
import { escapeHtml } from './utils.js';
import { situacaoAcerto, textoSaldoResumo, avisoParaLoja, ROTULO_ESTADO, dataBRms, formasDisponiveis, payloadPix, montarAviso, FORMAS, PRAZO_PADRAO_DIAS } from './acerto-comissao.js';
import { qrSvg } from './qr.js';

const $ = (id) => document.getElementById(id);
const reais = (v) => 'R$ ' + (Math.round(Number(v) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const dataHoraBR = (iso) => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', dateStyle: 'short', timeStyle: 'short' }); };

let lojaId = null, pedidos = [], acertos = {}, avisos = {}, cfg = {}, desligar = [], assinaturaPagar = '', ligado = false;

export function iniciarAcertoLoja(id) {
  desligar.forEach((f) => { try { f(); } catch { /* noop */ } }); desligar = [];
  lojaId = id ? String(id) : null; acertos = {}; avisos = {}; cfg = {}; assinaturaPagar = '';
  if (!lojaId) { desenhar(); return; }
  const ouvir = (caminho, aplicar) => desligar.push(onValue(ref(db, caminho), (snap) => { aplicar(snap.val() || {}); desenhar(); }, (e) => console.warn('[Acerto]', caminho, e?.code || e)));
  ouvir(`acertos_comissao/${lojaId}`, (v) => { acertos = v; });
  ouvir(`acerto_avisos/${lojaId}`, (v) => { avisos = v; });
  ouvir('config_plataforma/acerto', (v) => { cfg = v; });
  ligar();
}
export function atualizarAcertoPedidos(lista) { pedidos = Array.isArray(lista) ? lista : []; desenhar(); }

export const situacaoDaLoja = () => situacaoAcerto({ pedidos, acertos, prazoDias: cfg.prazoDias || PRAZO_PADRAO_DIAS });

function atualizarSaldoNoResumo(s) {
  const el = $('fin-comissao-saldo'); if (!el) return;
  el.textContent = textoSaldoResumo(s, !!lojaId);
}

function desenhar() {
  const card = $('acerto-card'); if (!card) return;
  const s = situacaoDaLoja();
  atualizarSaldoNoResumo(s);
  const temAlgo = s.totalDevido > 0 || s.totalPago > 0 || s.emAberto > 0 || Object.keys(avisos).length > 0;
  card.hidden = !lojaId || !temAlgo;
  const texto = avisoParaLoja(s), banner = $('acerto-banner');
  if (banner) { banner.hidden = !texto; if (texto) { $('acerto-banner-texto').textContent = texto; banner.classList.toggle('acerto-banner-vencido', s.estado === 'vencido'); } }
  if (card.hidden) return;
  $('acerto-regra').textContent = `Fechamos a conta toda segunda-feira. Você tem ${s.prazoDias} dias depois do fechamento para pagar, por Pix, transferência ou link.`;
  const chip = $('acerto-chip'); chip.textContent = ROTULO_ESTADO[s.estado]; chip.className = 'acerto-chip acerto-chip-' + s.estado;
  const av = $('acerto-aviso'); av.hidden = !texto; av.textContent = texto; av.classList.toggle('acerto-aviso-vencido', s.estado === 'vencido');
  const linha = (rot, val, cls = '') => `<div class="${cls}"><dt>${rot}</dt><dd>${reais(val)}</dd></div>`;
  $('acerto-resumo').innerHTML = linha('Vencido', s.saldoVencido, s.saldoVencido > 0 ? 'neg' : '') + linha('A vencer', s.saldoAVencer) + linha('Semana em andamento <small>(ainda não fechou)</small>', s.emAberto) + linha('Já pago', s.totalPago) + (s.credito > 0 ? linha('Crédito <small>(abate as próximas semanas)</small>', s.credito) : '');
  const corpo = $('acerto-semanas').querySelector('tbody');
  const semanas = [...s.semanas].reverse();
  corpo.innerHTML = semanas.length ? semanas.map((w) => `<tr class="${w.saldo > 0 ? (w.vence <= Date.now() ? 'acerto-venc' : 'acerto-abre') : 'acerto-ok'}"><td>${dataBRms(w.inicio)} a ${dataBRms(w.fecha - 1)}</td><td>${reais(w.devido)}</td><td>${reais(w.pago)}</td><td><strong>${reais(w.saldo)}</strong></td><td>${w.saldo > 0 ? dataBRms(w.vence) : 'Quitada'}</td></tr>`).join('') : '<tr><td colspan="5">Nenhuma semana fechada ainda.</td></tr>';
  desenharComoPagar(s);
  const form = $('acerto-form'); form.hidden = !(s.saldoFechado > 0 || Object.values(avisos).some((a) => a.status === 'pendente'));
  desenharHistorico();
}

function desenharComoPagar(s) {
  const box = $('acerto-pagar'); const saldo = s.saldoFechado;
  box.hidden = !(saldo > 0);
  if (saldo <= 0) { assinaturaPagar = ''; return; }
  const formas = formasDisponiveis(cfg), nenhuma = !formas.pix && !formas.transferencia && !formas.link;
  const assinatura = JSON.stringify([saldo, cfg.chavePix, cfg.beneficiario, cfg.cidade, cfg.dadosBancarios, cfg.linkPagamento]);
  $('acerto-valor-pagar').textContent = `Valor: ${reais(saldo)}`;
  if (assinatura === assinaturaPagar) return;                 // não redesenha à toa (preserva o botão "Copiado!")
  assinaturaPagar = assinatura;
  const alvo = $('acerto-formas');
  if (nenhuma) { alvo.innerHTML = '<p class="acerto-sem-dados">O YaPOOD ainda não cadastrou os dados de pagamento. Fale com o suporte para receber a chave Pix ou o link.</p>'; return; }
  let html = '';
  if (formas.pix) {
    let payload = '', qr = '';
    try { payload = payloadPix({ chave: cfg.chavePix, valor: saldo, beneficiario: cfg.beneficiario, cidade: cfg.cidade }); qr = qrSvg(payload, { rotulo: 'QR Code do Pix da comissão' }); } catch (e) { console.warn('[Acerto] Pix:', e); }
    html += `<section class="acerto-forma"><h5><i class="fa-solid fa-qrcode" aria-hidden="true"></i> Pix</h5>${qr ? `<div class="acerto-qr">${qr}</div>` : ''}<p class="section-help">Abra o app do seu banco, escolha Pix e leia o QR Code ou use o código “copia e cola”. Recebedor: <strong>${escapeHtml(cfg.beneficiario)}</strong>.</p>${payload ? `<div class="acerto-copia"><input type="text" readonly value="${escapeHtml(payload)}" aria-label="Pix copia e cola"><button type="button" class="btn-secondary" data-copiar="${escapeHtml(payload)}"><i class="fa-regular fa-copy" aria-hidden="true"></i> Copiar código</button></div>` : ''}<p class="section-help">Prefere digitar a chave? ${escapeHtml(rotuloChave(cfg.tipoChave))}: <strong>${escapeHtml(cfg.chavePix)}</strong> <button type="button" class="acerto-link-btn" data-copiar="${escapeHtml(cfg.chavePix)}">copiar chave</button></p></section>`;
  }
  if (formas.transferencia) html += `<section class="acerto-forma"><h5><i class="fa-solid fa-building-columns" aria-hidden="true"></i> Transferência</h5><p class="acerto-banco">${escapeHtml(cfg.dadosBancarios)}</p></section>`;
  if (formas.link) html += `<section class="acerto-forma"><h5><i class="fa-solid fa-link" aria-hidden="true"></i> Link de pagamento</h5><p class="section-help">Abre a página de pagamento do YaPOOD (cartão, Pix ou boleto, conforme o link).</p><a class="btn-primary acerto-abrir" href="${escapeHtml(cfg.linkPagamento)}" target="_blank" rel="noopener noreferrer"><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Abrir link para pagar</a></section>`;
  alvo.innerHTML = html;
}
const TIPOS = { cpf: 'CPF', cnpj: 'CNPJ', telefone: 'Telefone', email: 'E-mail', aleatoria: 'Chave aleatória' };
const rotuloChave = (t) => TIPOS[t] || 'Chave';

const ROTULO_AVISO = { pendente: 'Aguardando confirmação', confirmado: 'Confirmado', recusado: 'Não confirmado' };
function desenharHistorico() {
  const itens = [
    ...Object.entries(avisos).map(([id, a]) => ({ t: Date.parse(a.em) || 0, html: `<li class="acerto-h acerto-h-${escapeHtml(a.status)}"><span>${dataHoraBR(a.em)}</span><strong>${reais(a.valor)}</strong><em>${escapeHtml(FORMAS[a.forma] || a.forma)} · aviso: ${escapeHtml(ROTULO_AVISO[a.status] || a.status)}</em></li>` })),
    ...Object.entries(acertos).map(([id, a]) => ({ t: Date.parse(a.em) || 0, html: `<li class="acerto-h acerto-h-confirmado"><span>${dataHoraBR(a.em)}</span><strong>${reais(a.valor)}</strong><em>${escapeHtml(FORMAS[a.forma] || a.forma)} · pagamento registrado</em></li>` }))
  ].sort((a, b) => b.t - a.t).slice(0, 30);
  const box = $('acerto-historico'); box.hidden = !itens.length;
  $('acerto-historico-lista').innerHTML = itens.map((i) => i.html).join('');
}

function ligar() {
  if (ligado) return; ligado = true;
  const card = $('acerto-card'); if (!card) return;
  card.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-copiar]'); if (!b) return;
    const texto = b.getAttribute('data-copiar'), antes = b.innerHTML;
    try { await navigator.clipboard.writeText(texto); } catch {
      const t = document.createElement('textarea'); t.value = texto; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch { /* noop */ } t.remove();
    }
    b.textContent = 'Copiado!'; setTimeout(() => { b.innerHTML = antes; }, 1600);
  });
  $('acerto-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = $('acerto-msg'), btn = $('acerto-enviar');
    const dizer = (t, erro) => { msg.textContent = t; msg.classList.toggle('acerto-msg-erro', !!erro); };
    if (!lojaId || !auth.currentUser) { dizer('Entre novamente para avisar o pagamento.', true); return; }
    btn.disabled = true; dizer('Enviando…');
    try {
      let comprovante = '';
      const arquivo = $('acerto-aviso-comprovante').files?.[0];
      if (arquivo) {
        const fn = typeof window.uploadImagemCloudinaryPub === 'function' ? window.uploadImagemCloudinaryPub : window.uploadImagemCloudinary;
        if (typeof fn !== 'function') throw new Error('Não foi possível anexar o comprovante agora. Envie sem comprovante.');
        const r = await fn(arquivo); comprovante = r?.url || '';
      }
      const aviso = montarAviso({ valor: $('acerto-aviso-valor').value, forma: $('acerto-aviso-forma').value, obs: $('acerto-aviso-obs').value, comprovante });
      const novo = push(ref(db, `acerto_avisos/${lojaId}`));
      await set(novo, aviso);
      $('acerto-form').reset(); dizer('Aviso enviado! O YaPOOD vai conferir e confirmar o pagamento.');
    } catch (err) { dizer(err?.message || 'Não foi possível enviar o aviso.', true); }
    finally { btn.disabled = false; }
  });
}
