// js/perfil.js — V75.135: Perfil do cliente. Menu (Minha conta, Pedidos, App) e sub-telas por endereço (#dados, #enderecos, #pagamento, #sobre),
// para o botão voltar do celular fechar a sub-tela. Regras puras em perfil-dados.js, perfil-util.js e enderecos.js.
import { auth, googleProvider, signInWithPopup, onAuthStateChanged, signOut, db, ref, get, set, update, remove } from './firebase.js';
import { toast, confirmar } from './utils.js';
import { escapeHtml } from './regras.js';
import { nomeExibicao, primeiroNome, AVATAR_HTML, validarNome } from './perfil-util.js?v=75.107';
import { validarTelefone, validarEmail, idAoEditarEndereco, FORMAS, formaValida, nomeDaForma } from './perfil-dados.js?v=75.135';
import { ROTULOS, validarEndereco, resumoEndereco } from './enderecos.js?v=75.126';
import { buscarEnderecos } from './pedido-service.js';
import { formatarTelefone } from './checkout-ui.js?v=75.126';
import { configAnuncie, urlWhatsApp } from './anuncie.js';
import { abrirPolitica } from './reembolso-ui.js';
import { listaSaldos } from './saldo-loja.js?v=75.145';
import { buscarSaldos } from './saldo-api.js?v=75.145';
const moeda = (v) => (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
// Avisos: o módulo de notificações depende do Firebase Messaging (CDN). Carregado só ao mexer no interruptor, para o Perfil nunca quebrar por ele.
const CHAVE_AVISOS_OFF = 'yapood_avisos_off';
const avisosDesligados = () => { try { return localStorage.getItem(CHAVE_AVISOS_OFF) === '1'; } catch { return false; } };
const marcarAvisosDesligados = (off) => { try { if (off) localStorage.setItem(CHAVE_AVISOS_OFF, '1'); else localStorage.removeItem(CHAVE_AVISOS_OFF); } catch { /* sem armazenamento */ } };
const moduloAvisos = () => import('./notificaciones.js');

export const VERSAO_APP = 'V75.146';
const $ = (id) => document.getElementById(id);
const S = { user: null, dados: {}, enderecos: [], editando: null, suporte: '', saldos: [] };

// ---------- topo e menu ----------
function pintarTopo() {
  const u = S.user;
  $('profile-avatar').innerHTML = AVATAR_HTML;
  $('perfil-nome').textContent = `Olá, ${primeiroNome(u ? nomeExibicao(u, S.dados) : 'Cliente')}`;
  $('perfil-sub').textContent = u ? (S.dados.email || u.email || '') : 'Entre para salvar seus pedidos e endereços';
  document.querySelectorAll('[data-logado]').forEach((el) => { el.hidden = !u; });
  $('opcao-login').hidden = !!u;
  $('opcao-logout').hidden = !u;
  if (!u) return;
  const tel = S.dados.telefone ? formatarTelefone(S.dados.telefone) : '';
  $('resumo-dados').textContent = [nomeExibicao(u, S.dados), tel].filter(Boolean).join(' · ') || 'Nome, telefone e e-mail';
  const n = S.enderecos.length;
  $('resumo-enderecos').textContent = !n ? 'Nenhum endereço salvo' : n === 1 ? resumoEndereco(S.enderecos[0]) : `${n} endereços salvos`;
  $('resumo-pagamento').textContent = nomeDaForma(S.dados.pagamentoPreferido) || 'Escolha a preferida';
  const totSaldo = S.saldos.reduce((t, x) => t + x.valor, 0);
  $('resumo-saldos').textContent = S.saldos.length ? `${moeda(totSaldo)} em ${S.saldos.length === 1 ? S.saldos[0].lojaNome : `${S.saldos.length} lojas`}` : 'Nenhum saldo por enquanto';
  pintarAvisos();
}

async function carregar(user) {
  S.user = user; S.dados = {}; S.enderecos = []; S.saldos = [];
  pintarTopo();
  if (!user) { irPara(''); return; }
  try { S.dados = (await get(ref(db, `usuarios/${user.uid}`))).val() || {}; } catch { /* fica o da conta */ }
  try { S.enderecos = await buscarEnderecos(user.uid); } catch { S.enderecos = []; }
  S.saldos = listaSaldos(await buscarSaldos(user.uid));
  pintarTopo();
  carregarSuporte();
  mostrarTela();
}
onAuthStateChanged(auth, carregar);

$('opcao-login').addEventListener('click', async () => {
  try {
    const { user } = await signInWithPopup(auth, googleProvider);
    const uref = ref(db, `usuarios/${user.uid}`);
    if (!(await get(uref)).exists()) await set(uref, { nome: user.displayName || '', email: user.email || '', criadoEm: new Date().toISOString() });
  } catch (e) { if (e.code !== 'auth/popup-closed-by-user') toast('Não foi possível entrar.', 'error'); }
});
$('opcao-logout').addEventListener('click', async () => {
  const c = await confirmar({ titulo: 'Sair da conta?', texto: 'Seus pedidos e endereços continuam salvos. É só entrar de novo com o Google.', rotulo: 'Sair' });
  if (!c || c.ok === false) return;
  await signOut(auth); toast('Sessão encerrada.');
});
$('opcao-compartilhar').addEventListener('click', async () => {
  const url = location.origin + location.pathname.replace(/[^/]*$/, '');
  try {
    if (navigator.share) await navigator.share({ title: 'YaPOOD - Delivery', text: 'Peça os melhores pratos com entrega rápida!', url });
    else { await navigator.clipboard.writeText(url); toast('Link copiado.', 'success'); }
  } catch (e) { if (e.name !== 'AbortError') toast('Não foi possível compartilhar.', 'error'); }
});

// ---------- sub-telas (#dados, #enderecos, #pagamento, #sobre) ----------
const TELAS = { dados: 'tela-dados', enderecos: 'tela-enderecos', pagamento: 'tela-pagamento', saldos: 'tela-saldos', sobre: 'tela-sobre' };
const PRECISA_LOGIN = new Set(['dados', 'enderecos', 'pagamento', 'saldos']);
function irPara(nome) { if (location.hash.slice(1) !== nome) location.hash = nome; else mostrarTela(); }
function mostrarTela() {
  let nome = location.hash.slice(1);
  if (!TELAS[nome] || (PRECISA_LOGIN.has(nome) && !S.user)) nome = '';
  Object.entries(TELAS).forEach(([k, id]) => { $(id).hidden = k !== nome; });
  document.body.classList.toggle('pf-subtela', !!nome);
  if (nome === 'dados') abrirDados();
  if (nome === 'enderecos') { fecharFormEndereco(); pintarEnderecos(); }
  if (nome === 'pagamento') pintarFormas();
  if (nome === 'saldos') pintarSaldos();
  if (nome === 'sobre') abrirSobre();
  if (nome) $(TELAS[nome]).querySelector('.pf-voltar')?.focus();
  // V75.140: o sino da home abre o Perfil já no "Avisos no celular"
  if (location.hash === '#avisos') { const sw = $('avisos-switch')?.closest('.pf-item'); if (sw && !sw.hidden) { sw.scrollIntoView({ block: 'center' }); sw.classList.add('pf-destaque'); setTimeout(() => sw.classList.remove('pf-destaque'), 2200); } }
}
// Entrou pela lista (o app criou a entrada no histórico): voltar = history.back(). Aberto direto pelo link: só troca a tela.
let navegouAqui = false;
window.addEventListener('hashchange', () => { if (location.hash.length > 1) navegouAqui = true; mostrarTela(); });
function voltarAoMenu() {
  if (navegouAqui) { navegouAqui = false; history.back(); return; }
  history.replaceState(null, '', location.pathname + location.search); mostrarTela();
}
document.addEventListener('click', (e) => { if (e.target.closest('[data-voltar]')) voltarAoMenu(); });

// ---------- Meus dados ----------
function abrirDados() {
  const u = S.user; if (!u) return;
  $('dados-nome').value = nomeExibicao(u, S.dados) === 'Cliente' ? '' : nomeExibicao(u, S.dados);
  $('dados-telefone').value = S.dados.telefone ? formatarTelefone(S.dados.telefone) : '';
  $('dados-email').value = S.dados.email || u.email || '';
  $('dados-erro').textContent = '';
  ['dados-nome', 'dados-telefone', 'dados-email'].forEach((id) => $(id).removeAttribute('aria-invalid'));
}
$('form-dados').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const u = S.user; if (!u) return;
  const n = validarNome($('dados-nome').value), t = validarTelefone($('dados-telefone').value), m = validarEmail($('dados-email').value);
  const erro = !n.ok ? ['dados-nome', n.erro] : !t.ok ? ['dados-telefone', t.erro] : !m.ok ? ['dados-email', m.erro] : null;
  ['dados-nome', 'dados-telefone', 'dados-email'].forEach((id) => $(id).removeAttribute('aria-invalid'));
  if (erro) { $(erro[0]).setAttribute('aria-invalid', 'true'); $(erro[0]).focus(); $('dados-erro').textContent = erro[1]; return; }
  const btn = ev.target.querySelector('[type=submit]'); btn.disabled = true;
  try {
    const novo = { nome: n.nome, nomeEditado: true, telefone: t.telefone, email: m.email || null };
    await update(ref(db, `usuarios/${u.uid}`), novo);
    S.dados = { ...S.dados, ...novo, email: m.email || undefined };
    pintarTopo(); toast('Dados salvos.', 'success'); voltarAoMenu();
  } catch (e) { console.warn(e); $('dados-erro').textContent = 'Não foi possível salvar. Verifique a internet e tente de novo.'; }
  finally { btn.disabled = false; }
});

// ---------- Endereços ----------
function pintarEnderecos() {
  const box = $('lista-enderecos');
  if (!S.enderecos.length) { box.innerHTML = '<p class="pf-vazio">Você ainda não tem endereço salvo. Adicione um para pedir mais rápido.</p>'; return; }
  box.innerHTML = S.enderecos.map((e) => {
    const r = ROTULOS[e.rotulo] || ROTULOS.outro;
    return `<div class="pf-end"><span class="pf-ic"><i class="fa-solid ${r.icone}" aria-hidden="true"></i></span>
      <span class="pf-tx"><strong>${escapeHtml(r.nome)}</strong><small>${escapeHtml(e.rua)} · ${escapeHtml(e.bairro)}${e.referencia ? ` · ${escapeHtml(e.referencia)}` : ''}</small></span>
      <span class="pf-end-acoes"><button type="button" data-editar="${escapeHtml(e.id)}" aria-label="Editar ${escapeHtml(r.nome)}"><i class="fa-solid fa-pen" aria-hidden="true"></i></button>
      <button type="button" data-apagar="${escapeHtml(e.id)}" aria-label="Apagar ${escapeHtml(r.nome)}"><i class="fa-regular fa-trash-can" aria-hidden="true"></i></button></span></div>`;
  }).join('');
}
function abrirFormEndereco(e = null) {
  S.editando = e ? e.id : null;
  $('end-form-tit').textContent = e ? 'Editar endereço' : 'Novo endereço';
  const livre = ['casa', 'trabalho'].find((r) => !S.enderecos.some((x) => x.rotulo === r)) || 'outro';
  document.querySelector(`input[name="end-rotulo"][value="${e ? e.rotulo : livre}"]`).checked = true;
  $('end-rua').value = e?.rua || ''; $('end-bairro').value = e?.bairro || ''; $('end-ref').value = e?.referencia || '';
  $('end-erro').textContent = '';
  $('form-endereco').hidden = false; $('end-novo').hidden = true;
  $('end-rua').focus();
}
function fecharFormEndereco() { $('form-endereco').hidden = true; $('end-novo').hidden = false; S.editando = null; }
$('end-novo').addEventListener('click', () => abrirFormEndereco());
$('end-cancelar').addEventListener('click', fecharFormEndereco);
$('lista-enderecos').addEventListener('click', async (ev) => {
  const ed = ev.target.closest('[data-editar]'), ap = ev.target.closest('[data-apagar]');
  if (ed) return abrirFormEndereco(S.enderecos.find((x) => x.id === ed.dataset.editar));
  if (!ap || !S.user) return;
  const e = S.enderecos.find((x) => x.id === ap.dataset.apagar); if (!e) return;
  const c = await confirmar({ titulo: 'Apagar endereço?', texto: `${resumoEndereco(e)} será apagado.`, rotulo: 'Apagar', perigo: true });
  if (!c || c.ok === false) return;
  try {
    await remove(ref(db, `usuarios/${S.user.uid}/enderecos/${e.id}`));
    if (S.dados.ultimoEndereco === e.id) { await update(ref(db, `usuarios/${S.user.uid}`), { ultimoEndereco: null }); S.dados.ultimoEndereco = null; }
    S.enderecos = await buscarEnderecos(S.user.uid); pintarEnderecos(); pintarTopo(); toast('Endereço apagado.', 'success');
  } catch (err) { console.warn(err); toast('Não foi possível apagar.', 'error'); }
});
$('form-endereco').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  if (!S.user) return;
  const rotulo = document.querySelector('input[name="end-rotulo"]:checked')?.value || 'outro';
  const v = validarEndereco({ rotulo, rua: $('end-rua').value, bairro: $('end-bairro').value, referencia: $('end-ref').value });
  if (!v.ok) { $('end-erro').textContent = v.erro; (v.campo === 'bairro' ? $('end-bairro') : $('end-rua')).focus(); return; }
  const destino = idAoEditarEndereco(S.editando, rotulo, S.enderecos);
  if (destino.erro) { $('end-erro').textContent = destino.erro; return; }
  if (destino.substitui) {
    const atual = S.enderecos.find((x) => x.id === destino.substitui);
    const c = await confirmar({ titulo: `Trocar sua ${ROTULOS[rotulo].nome}?`, texto: `Você já tem ${ROTULOS[rotulo].nome}: ${atual ? resumoEndereco(atual) : ''}. Ele será substituído por este.`, rotulo: 'Substituir' });
    if (!c || c.ok === false) return;
  }
  const btn = ev.target.querySelector('[type=submit]'); btn.disabled = true;
  try {
    const antigo = S.enderecos.find((x) => x.id === (destino.substitui || destino.id));
    const agora = new Date().toISOString();
    await set(ref(db, `usuarios/${S.user.uid}/enderecos/${destino.id}`), { ...v.endereco, criadoEm: antigo?.criadoEm || agora, atualizadoEm: agora });
    if (destino.apagar) await remove(ref(db, `usuarios/${S.user.uid}/enderecos/${destino.apagar}`));
    S.enderecos = await buscarEnderecos(S.user.uid);
    fecharFormEndereco(); pintarEnderecos(); pintarTopo(); toast('Endereço salvo.', 'success');
  } catch (err) { console.warn(err); $('end-erro').textContent = 'Não foi possível salvar. Verifique a internet e tente de novo.'; }
  finally { btn.disabled = false; }
});

// ---------- Forma de pagamento preferida ----------
function pintarFormas() {
  const atual = formaValida(S.dados.pagamentoPreferido) ? S.dados.pagamentoPreferido : '';
  const op = (valor, nome, sub) => `<label><input type="radio" name="forma-pref" value="${escapeHtml(valor)}"${valor === atual ? ' checked' : ''}><span class="pf-tx"><strong>${escapeHtml(nome)}</strong>${sub ? `<small>${escapeHtml(sub)}</small>` : ''}</span><span class="pf-marca" aria-hidden="true"></span></label>`;
  const SUB = { PIX: 'Pague na hora pelo app', 'Mercado Pago': 'Crédito pelo Mercado Pago', 'Cartão / Débito (pagar ao entregador)': 'Crédito ou débito na maquininha', Dinheiro: 'Pague na entrega' };
  $('lista-formas').innerHTML = FORMAS.map((f) => op(f.valor, f.nome, SUB[f.valor])).join('') + op('', 'Escolher na hora', 'Nada vem marcado no carrinho');
}
$('lista-formas').addEventListener('change', async (ev) => {
  const r = ev.target.closest('input[name="forma-pref"]'); if (!r || !S.user) return;
  const valor = r.value || null;
  try {
    await update(ref(db, `usuarios/${S.user.uid}`), { pagamentoPreferido: valor });
    S.dados.pagamentoPreferido = valor; pintarTopo();
    toast(valor ? `Preferida: ${nomeDaForma(valor)}.` : 'Sem forma preferida.', 'success');
  } catch (err) { console.warn(err); toast('Não foi possível salvar.', 'error'); pintarFormas(); }
});

// ---------- Avisos no celular ----------
function pintarAvisos() {
  const sw = $('avisos-switch'), txt = $('resumo-avisos'); if (!sw) return;
  if (!('Notification' in window)) { sw.checked = false; sw.disabled = true; txt.textContent = 'Este aparelho não recebe avisos do app'; return; }
  const perm = Notification.permission;
  sw.disabled = perm === 'denied';
  sw.checked = perm === 'granted' && !avisosDesligados();
  txt.textContent = perm === 'denied' ? 'Bloqueados no navegador: libere nas configurações do celular' : sw.checked ? 'Ligados: status do pedido e promoções' : 'Desligados';
}
$('avisos-switch').addEventListener('change', async (ev) => {
  const sw = ev.target; sw.disabled = true;
  try {
    if (sw.checked) { marcarAvisosDesligados(false); await (await moduloAvisos()).ativarNotificacoes(); toast('Avisos ligados.', 'success'); }
    else { marcarAvisosDesligados(true); try { await (await moduloAvisos()).desativarNotificacoes(); } catch { /* sem o módulo: fica só a marca */ } toast('Avisos desligados.', 'success'); }
  } catch (e) { toast(e?.message || 'Não foi possível mudar os avisos.', 'error'); if (sw.checked) marcarAvisosDesligados(true); }
  finally { sw.disabled = false; pintarAvisos(); }
});

// ---------- Ajuda e Sobre ----------
async function carregarSuporte() {
  try {
    const cfg = configAnuncie((await get(ref(db, 'config_plataforma/anuncie'))).val());
    S.suporte = cfg?.suporte || '';
  } catch { S.suporte = ''; }
  $('opcao-ajuda').hidden = !S.suporte;
}
$('opcao-ajuda').addEventListener('click', () => {
  if (!S.suporte) return;
  const nome = S.user ? primeiroNome(nomeExibicao(S.user, S.dados)) : '';
  window.open(urlWhatsApp(S.suporte, `Olá! ${nome ? `Sou ${nome} e ` : ''}preciso de ajuda com o app YaPOOD.`), '_blank', 'noopener');
});
async function abrirSobre() {
  $('sobre-versao').textContent = `Versão ${VERSAO_APP}`;
  if (!S.user) return;
  try {
    const email = (await get(ref(db, 'config_plataforma/contato_dados'))).val()?.email;
    if (email) $('sobre-dados').textContent = `Usamos seu nome, telefone e endereço só para entregar os pedidos. Para ver, corrigir ou apagar seus dados: ${email}.`;
  } catch { /* fica o texto padrão */ }
}
$('sobre-politica').addEventListener('click', () => abrirPolitica());

// ---------- Meus saldos (V75.145) ----------
function pintarSaldos() {
  const box = $('lista-saldos'); if (!box) return;
  box.innerHTML = S.saldos.length ? S.saldos.map((x) => `<a class="pf-item pf-saldo" href="restaurante.html?id=${encodeURIComponent(x.lojaId)}">
      <span class="pf-ic"><i class="fa-solid fa-store" aria-hidden="true"></i></span>
      <span class="pf-tx"><strong>${escapeHtml(x.lojaNome)}</strong><small>Usado sozinho no próximo pedido · não vence</small></span>
      <span class="pf-saldo-valor">${moeda(x.valor)}</span></a>`).join('')
    : '<p class="pf-vazio">Você ainda não tem saldo em nenhuma loja.</p>';
}

mostrarTela();
