// V75.72 — O Master libera uma cidade pela API (ela grava a cidade como "aberta" e a isenção de comissão das lojas numa única vez).
import { auth } from './firebase.js';

const API = 'https://api-mp-yapoodbr.onrender.com';

export async function liberarCidade(cidadeId) {
  const token = await auth.currentUser.getIdToken();
  const r = await fetch(`${API}/master/cidade/liberar`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ cidadeId })
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'Não foi possível liberar a cidade agora.'), { status: r.status });
  return d; // { ok, cidadeId, lojas, meses, ate }
}
