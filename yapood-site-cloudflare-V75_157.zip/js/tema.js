// V75.41 — Cor principal do app: lê config_plataforma/tema (gravado só pelo Master) e aplica nas páginas.
// A cor em teste (só neste aparelho, escolhida no Master) tem prioridade e mostra uma faixa para voltar à oficial.
import { db, ref, get } from './firebase.js';
import { derivarTema, normalizarHex, normalizarSobre, COR_PADRAO, CHAVE_CACHE, CHAVE_TESTE, VARIAVEIS } from './tema-cores.js';

export function aplicarTema(t) {
  const st = document.documentElement.style;
  for (const [k, nome] of Object.entries(VARIAVEIS)) if (t?.[k]) st.setProperty(nome, t[k]);
  // V75.140: olhos/sorriso da logo, "comer?" e "Hoje eu quero…" — mesma regra do tema-boot.js (texto branco → mostarda; texto escuro → branco)
  if (t?.sobre) st.setProperty('--cor-acento-logo', /^#f{3,6}$/i.test(t.sobre) ? '#efb638' : '#ffffff');
  const meta = document.querySelector('meta[name="theme-color"][data-tema]');
  if (meta && t?.primaria) meta.setAttribute('content', t.primaria);
}

function temaEmTeste() {
  try {
    const t = JSON.parse(localStorage.getItem(CHAVE_TESTE) || 'null');
    const hex = normalizarHex(t?.primaria);
    return hex ? derivarTema(hex, normalizarSobre(t?.pref)) : null;   // sempre recalculado: nunca confia no que está guardado
  } catch { return null; }
}

function faixaDeTeste(t) {
  if (document.getElementById('tema-teste-faixa')) return;
  const f = document.createElement('div');
  f.id = 'tema-teste-faixa';
  f.setAttribute('role', 'status');
  f.style.cssText = 'position:fixed;left:50%;bottom:76px;transform:translateX(-50%);z-index:2147483000;display:flex;align-items:center;gap:10px;max-width:calc(100vw - 24px);padding:8px 8px 8px 14px;border-radius:999px;background:#14202b;color:#fff;font:600 .82rem/1.2 system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.3)';
  const txt = document.createElement('span');
  txt.textContent = `Cor em teste: ${t.primaria} (só neste aparelho)`;
  const bt = document.createElement('button');
  bt.type = 'button'; bt.textContent = 'Voltar à oficial';
  bt.style.cssText = 'border:0;border-radius:999px;padding:7px 12px;background:#fff;color:#14202b;font:700 .8rem system-ui,sans-serif;cursor:pointer';
  bt.addEventListener('click', () => { try { localStorage.removeItem(CHAVE_TESTE); } catch { /* sem armazenamento */ } location.reload(); });
  f.append(txt, bt);
  document.body.appendChild(f);
}

async function iniciar() {
  const teste = temaEmTeste();
  if (teste) {
    aplicarTema(teste);
    if (document.body) faixaDeTeste(teste); else document.addEventListener('DOMContentLoaded', () => faixaDeTeste(teste));
    return;
  }
  try {
    const v = (await get(ref(db, 'config_plataforma/tema'))).val();
    const hex = normalizarHex(v?.primaria);
    const t = derivarTema(hex || COR_PADRAO, hex ? v?.sobre : 'auto');
    aplicarTema(t);
    try { if (hex) localStorage.setItem(CHAVE_CACHE, JSON.stringify(t)); else localStorage.removeItem(CHAVE_CACHE); } catch { /* sem armazenamento */ }
  } catch (e) { console.warn('Tema: usando a cor guardada.', e?.message || e); }
}
iniciar();

// V75.131 — cores da barra do carrinho e da sacola (config_plataforma/sacola, gravado só pelo Master). Sem cadastro: padrão do CSS.
const HEX6 = /^#[0-9a-f]{6}$/i;
export function aplicarSacola(v) {
  const st = document.documentElement.style;
  if (v && HEX6.test(v.barra || '')) st.setProperty('--barra-carrinho', v.barra); else st.removeProperty('--barra-carrinho');
  if (v && HEX6.test(v.sacola || '')) st.setProperty('--sacola-cor', v.sacola); else st.removeProperty('--sacola-cor');
}
(async () => {
  try {
    const v = (await get(ref(db, 'config_plataforma/sacola'))).val();
    aplicarSacola(v);
    try { if (v) localStorage.setItem('yapood_sacola_v1', JSON.stringify({ barra: v.barra, sacola: v.sacola })); else localStorage.removeItem('yapood_sacola_v1'); } catch { /* sem armazenamento */ }
  } catch (e) { /* regra ainda não publicada ou sem rede: fica a cor guardada ou a padrão */ }
})();
