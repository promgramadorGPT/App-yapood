// js/aviso-abertura.js — V75.138: no painel da loja, 5 min antes de abrir, uma tela por cima de tudo com som em loop:
// "Estou pronto" / "Não estou pronto" (adiar 15/30/60 min ou não abrir hoje). Módulo isolado: se falhar, o painel segue normal.
// A resposta vai para restaurantes/{id}/abertura (todos os aparelhos da loja param juntos). Regras em abertura-loja.js.
import { db, ref, onValue, update } from './firebase.js';
import { avisoAbertura, opcoesAdiar, respostaAbertura, aberturaSegurada, hhmm } from './abertura-loja.js?v=75.138';

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SINO = '<svg viewBox="0 0 24 24" width="38" height="38" aria-hidden="true"><path fill="currentColor" d="M12 22a2.5 2.5 0 0 0 2.45-2h-4.9A2.5 2.5 0 0 0 12 22zm7-6V11a7 7 0 0 0-5.5-6.84V3.5a1.5 1.5 0 0 0-3 0v.66A7 7 0 0 0 5 11v5l-2 2v1h18v-1z"/></svg>';

let loja = null, lojaId = '', aviso = null, tela = null, passo = 'pergunta', escolha = 0, erro = '', gravando = false;

// ---------- Som (Web Audio; o navegador só deixa tocar depois de um toque na página) ----------
let ctx = null, somTimer = null, tituloTimer = null, tituloOriginal = document.title, notificou = '';
function contexto() {
  try {
    if (!ctx) { const A = window.AudioContext || window.webkitAudioContext; if (!A) return null; ctx = new A(); }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  } catch { return null; }
}
function bipe() {
  const c = contexto();
  if (!c || c.state !== 'running') { mostrarDicaSom(true); return; }
  mostrarDicaSom(false);
  const t = c.currentTime;
  [[0, 880], [0.32, 1175], [0.64, 880]].forEach(([d, f]) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.4, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.28);
    o.connect(g); g.connect(c.destination); o.start(t + d); o.stop(t + d + 0.3);
  });
  try { navigator.vibrate?.([300, 120, 300]); } catch { /* sem vibração */ }
}
function ligarSom() {
  if (somTimer) return;
  bipe(); somTimer = setInterval(bipe, 2500);
  let alt = false; tituloOriginal = document.title;
  tituloTimer = setInterval(() => { alt = !alt; document.title = alt ? '🔔 Sua loja vai abrir!' : tituloOriginal; }, 1200);
}
function desligarSom() { clearInterval(somTimer); somTimer = null; clearInterval(tituloTimer); tituloTimer = null; document.title = tituloOriginal; }
function mostrarDicaSom(sim) { const d = tela?.querySelector('.ab-dica-som'); if (d) d.hidden = !sim; }
// qualquer toque libera o áudio (exigência dos navegadores)
document.addEventListener('pointerdown', () => { if (ctx?.state === 'suspended') ctx.resume().catch(() => {}); }, { capture: true });

// aviso do sistema (computador com a aba em segundo plano), se o lojista já permitiu notificações
function notificarSistema(a) {
  if (notificou === a.chave || !('Notification' in window) || Notification.permission !== 'granted' || !document.hidden) return;
  notificou = a.chave;
  try { const n = new Notification('Sua loja vai abrir', { body: `Hoje às ${hhmm(a.abreEm)}. Está pronta para receber pedidos?`, tag: 'yapood-abertura', requireInteraction: true }); n.onclick = () => { window.focus(); n.close(); }; } catch { /* sem notificação */ }
}

// ---------- Tela ----------
function desenhar() {
  if (!aviso) { tela?.remove(); tela = null; desligarSom(); return; }
  if (!tela) { tela = document.createElement('div'); tela.className = 'ab-fundo'; tela.setAttribute('role', 'alertdialog'); tela.setAttribute('aria-modal', 'true'); tela.setAttribute('aria-labelledby', 'ab-titulo'); document.body.append(tela); }
  const nome = loja?.nombre || loja?.nome || '';
  const hora = hhmm(aviso.abreEm);
  if (passo === 'pergunta') {
    tela.innerHTML = `<div class="ab-caixa"><div class="ab-sino">${SINO}</div>
      <h2 id="ab-titulo">${aviso.jaPassou ? 'Sua loja já devia ter aberto' : `Sua loja abre em ${aviso.faltamMin || 1} min`}</h2>
      <p class="ab-hora">Hoje às <b>${esc(hora)}</b>${nome ? ` · ${esc(nome)}` : ''}</p>
      <p class="ab-sub">A loja já está pronta para receber pedidos?</p>
      <div class="ab-botoes"><button type="button" class="ab-nao" data-ab="nao">Não estou pronto</button><button type="button" class="ab-sim" data-ab="sim"${gravando ? ' disabled' : ''}>Estou pronto</button></div>
      ${erro ? `<p class="ab-erro" role="alert">${esc(erro)}</p>` : ''}
      <p class="ab-nota">🔔 O som toca até você responder</p><p class="ab-dica-som" hidden>Toque na tela para ligar o som.</p></div>`;
    ligarSom();
  } else {
    const ops = opcoesAdiar(aviso.abreEm, loja?.horarios, Date.now());
    if (escolha >= ops.length) escolha = 0;
    tela.innerHTML = `<div class="ab-caixa ab-esq"><h2 id="ab-titulo">Quando você quer abrir?</h2>
      <p class="ab-sub">Enquanto isso, a loja aparece fechada para os clientes.</p>
      <div class="ab-ops" role="radiogroup" aria-label="Novo horário">${ops.map((o, i) => `<button type="button" role="radio" aria-checked="${i === escolha}" class="ab-op${i === escolha ? ' sel' : ''}" data-ab-op="${i}">${esc(o.rotulo)}${o.extra ? ` <span>(${esc(o.extra)})</span>` : ''}</button>`).join('')}</div>
      <div class="ab-botoes"><button type="button" class="ab-nao" data-ab="voltar">Voltar</button><button type="button" class="ab-sim" data-ab="confirmar"${gravando ? ' disabled' : ''}>Confirmar</button></div>
      ${erro ? `<p class="ab-erro" role="alert">${esc(erro)}</p>` : ''}
      <p class="ab-nota">${ops[escolha].tipo === 'hoje-nao' ? 'A loja fica fechada até o fim do horário de hoje.' : 'No novo horário, o aviso volta 5 min antes.'}</p></div>`;
  }
}
async function responder(opcao) {
  if (gravando || !aviso || !lojaId) return;
  gravando = true; erro = ''; desenhar();
  try { await update(ref(db, `restaurantes/${lojaId}`), { abertura: respostaAbertura(aviso.chave, opcao, Date.now()) }); }
  catch (e) { console.warn('Aviso de abertura:', e); erro = 'Não foi possível salvar. Confira a internet e tente de novo.'; }
  gravando = false;
  if (!erro) { aviso = null; passo = 'pergunta'; escolha = 0; }
  desenhar();
}
document.addEventListener('click', (e) => {
  if (!tela || !tela.contains(e.target)) return;
  const op = e.target.closest('[data-ab-op]');
  if (op) { escolha = Number(op.dataset.abOp) || 0; desenhar(); return; }
  const b = e.target.closest('[data-ab]'); if (!b) return;
  const a = b.dataset.ab;
  if (a === 'sim') { desligarSom(); responder({ tipo: 'pronto' }); }
  else if (a === 'nao') { desligarSom(); passo = 'adiar'; escolha = 1; erro = ''; desenhar(); }
  else if (a === 'voltar') { passo = 'pergunta'; erro = ''; desenhar(); }
  else if (a === 'confirmar') { const ops = opcoesAdiar(aviso.abreEm, loja?.horarios, Date.now()); responder(ops[escolha] || ops[0]); }
});

// ---------- Faixa enquanto a abertura está adiada ("Abrir agora") ----------
function desenharFaixa() {
  const seg = aberturaSegurada(loja?.abertura, Date.now());
  let f = document.getElementById('ab-faixa');
  if (!seg || loja?.activo === false) { f?.remove(); return; }
  if (!f) { f = document.createElement('div'); f.id = 'ab-faixa'; f.className = 'ab-faixa'; (document.querySelector('.admin-main') || document.body).prepend(f); }
  const html = `<span>⏸ Loja fechada para os clientes · ${esc(seg.motivo)} (você adiou)</span><button type="button" data-ab-agora>Abrir agora</button>`;
  if (f.dataset.h !== html) { f.dataset.h = html; f.innerHTML = html; }
}
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-ab-agora]'); if (!b || !lojaId) return;
  b.disabled = true;
  try { await update(ref(db, `restaurantes/${lojaId}`), { abertura: respostaAbertura(String(loja?.abertura?.abreAs || Date.now()), { tipo: 'pronto' }, Date.now()) }); }
  catch (err) { console.warn('Abrir agora:', err); b.disabled = false; }
});

// ---------- Ciclo ----------
function avaliar() {
  const novo = avisoAbertura(loja, Date.now());
  if (!novo) { if (aviso) { aviso = null; passo = 'pergunta'; } }
  else { if (!aviso || aviso.chave !== novo.chave) { passo = 'pergunta'; escolha = 0; erro = ''; } aviso = novo; notificarSistema(novo); }
  if (!(tela && passo === 'adiar' && aviso)) desenhar(); // não redesenha a lista enquanto o lojista escolhe
  desenharFaixa();
}
function iniciar(id) {
  lojaId = id;
  onValue(ref(db, `restaurantes/${id}`), (s) => { loja = s.val(); avaliar(); }, (e) => console.warn('Aviso de abertura:', e));
  setInterval(avaliar, 15000);
}
(function esperarLoja(n = 0) {
  const id = window.__yapood?.lojaId;
  if (id) return iniciar(id);
  if (n < 240) setTimeout(() => esperarLoja(n + 1), 500); // até 2 min esperando o painel descobrir a loja
})();
