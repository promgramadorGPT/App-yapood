// V75.73 — Cidades na vitrine do cliente: escolha da cidade, banner "Chegando em…" com a barra de vagas e lista de interessados.
// As regras (qual cidade, quais lojas, validação do WhatsApp) estão em cidades.js (testadas). Aqui só tela e gravação.
import { db, auth, ref, set, get, onValue, onAuthStateChanged } from './firebase.js';
import { escapeHtml as esc } from './regras.js';
import { UFS, CHAVE_CIDADE, cidadeIdValido, rotuloCidade, listarCidades, resolverCidadeCliente, lojaVisivelNaCidade, progressoPublico, validarInteressado } from './cidades.js';
import { formatarWhatsApp } from './anuncie.js';
import { LOGO_YAPOOD } from './logo-yapood.js';
import { podeFurarCidade } from './cidades-bloqueio.js';

const $ = (id) => document.getElementById(id);
const lerLocal = (k) => { try { return localStorage.getItem(k) || ''; } catch { return ''; } };
const gravarLocal = (k, v) => { try { if (v) localStorage.setItem(k, v); else localStorage.removeItem(k); } catch { /* sem armazenamento: segue sem lembrar */ } };
const CHAVE_AVISO = (key) => `yapood_aviso_cidade_${key}`;

/**
 * ctx: { getLojas, aoMudar }
 * Devolve { setGps, visivel, atualizar, temBanner }.
 */
export function iniciarCidadesCliente({ getLojas, aoMudar }) {
  let cidades = {};
  let gps = null;
  // Link/QR da divulgação: index.html?cidade=uberlandia-mg abre já nessa cidade (vale se ela existir; senão ignora).
  const doLink = (() => { try { return (new URLSearchParams(location.search).get('cidade') || '').toLowerCase(); } catch { return ''; } })();
  let escolhidaId = lerLocal(CHAVE_CIDADE);
  let linkPendente = cidadeIdValido(doLink) ? doLink : '';
  let semLojas = false;
  let modo = 'lista'; // conteúdo do modal: 'lista' | 'avisar'
  let alvoAviso = null; // { cidadeId } ou null (cidade fora da lista)
  let carregou = false;
  let demoAtiva = false; // Master ligou a demonstração: qualquer pessoa vê o app aberto (só ver: pedido continua bloqueado)
  let demoTimer = null;
  let usuario = null; // conta logada (para o atalho de entrada dos testadores na tela de espera)
  let modoTeste = false; // Master ou conta em testadores: vê o app aberto mesmo com a cidade em espera (demonstração/testes)

  const banner = $('cidade-banner'), botao = $('btn-cidade'), modal = $('cidade-modal');
  // No modo teste, toda cidade vale como aberta para a vitrine; o aviso e a lista de cidades usam o estado real.
  const comoAbertas = () => Object.fromEntries(Object.entries(cidades).map(([id, c]) => [id, { ...c, status: 'aberta' }]));
  const resolucaoReal = () => resolverCidadeCliente({ cidades, escolhidaId, gps });
  const verTudo = () => modoTeste || demoAtiva;
  const resolucao = () => (verTudo() ? resolverCidadeCliente({ cidades: comoAbertas(), escolhidaId, gps }) : resolucaoReal());
  const jaPediu = (key) => lerLocal(CHAVE_AVISO(key)) === '1';

  function desenharBotao(res) {
    if (!botao) return;
    // Cidade já liberada e é a cidade onde o cliente está (GPS): o seletor some, o cliente vê só o app da cidade dele.
    // Em espera, o botão continua (é a saída da tela travada); quem escolheu outra cidade à mão também mantém o botão.
    const noGps = gps ? resolverCidadeCliente({ cidades, escolhidaId: '', gps }) : null;
    const daCidadeDele = res.tipo === 'aberta' && noGps?.cidade?.id === res.cidade.id;
    const mostrar = carregou && res.tipo !== 'sem-cidades' && (verTudo() || !daCidadeDele);
    botao.hidden = !mostrar;
    if (!mostrar) return;
    botao.querySelector('span').textContent = res.cidade ? rotuloCidade(res.cidade) : (res.tipo === 'desconhecida' ? res.texto : 'Escolher cidade');
  }

  function desenharBanner(resEf) {
    if (!banner) return;
    let html = '';
    const res = verTudo() ? resolucaoReal() : resEf;
    if (verTudo()) {
      // Faixa fina, sem travar: só lembra que os clientes ainda não veem o app aberto.
      const emEspera = res.tipo === 'espera';
      const txt = modoTeste ? `<b>Modo teste:</b> ${emEspera ? esc(res.cidade.nome) : 'esta cidade'} ainda está <b>em espera</b> para os clientes. Só você (Master/testador) vê o app aberto.` : `<b>Demonstração:</b> ${emEspera ? esc(res.cidade.nome) : 'a cidade'} ainda não abriu. Você está vendo o app como ele ficará; os pedidos continuam bloqueados.`;
      banner.hidden = !emEspera;
      banner.innerHTML = emEspera ? `<div class="cb-teste"><i class="fa-solid fa-flask" aria-hidden="true"></i> ${txt}</div>` : '';
      document.body.classList.remove('cidade-trava');
      return;
    }
    if (res.tipo === 'espera') {
      const p = progressoPublico(res.cidade, getLojas());
      const key = res.cidade.id;
      html = `<div class="cb-selo"><i class="fa-solid fa-hourglass-half" aria-hidden="true"></i> Em breve</div>
        <h3>Chegando em ${esc(res.cidade.nome)}</h3>
        <p>Estamos reunindo os primeiros restaurantes da cidade. Quando abrir, você pede por aqui, com entrega na sua porta.</p>
        <div class="cb-barra" role="progressbar" aria-valuemin="0" aria-valuemax="${p.meta}" aria-valuenow="${Math.min(p.vagas, p.meta)}" aria-label="Restaurantes cadastrados"><i style="width:${p.pct}%"></i></div>
        <p class="cb-contagem"><b>${p.vagas}</b> de ${p.meta} restaurantes já se cadastraram${p.metaBatida ? ' · abrindo em breve!' : ''}</p>
        <div class="cb-acoes">${jaPediu(key) ? '<span class="cb-ok"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> Você está na lista: avisaremos no WhatsApp</span>' : `<button type="button" class="cb-btn cb-principal" data-cb-avisar="${esc(key)}"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> Avise-me quando abrir</button>`}
        <button type="button" class="cb-btn" data-cb-trocar>Trocar cidade</button></div>`;
    } else if (res.tipo === 'desconhecida' && semLojas) {
      html = `<div class="cb-selo"><i class="fa-solid fa-map-location-dot" aria-hidden="true"></i> Ainda não chegamos</div>
        <h3>O YAPOOD ainda não chegou em ${esc(res.texto)}</h3>
        <p>Quer ser avisado quando abrirmos por aí? Deixe seu WhatsApp. Se a cidade estiver errada, escolha outra.</p>
        <div class="cb-acoes"><button type="button" class="cb-btn cb-principal" data-cb-avisar=""><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> Avise-me quando abrir</button><button type="button" class="cb-btn" data-cb-trocar>Escolher outra cidade</button></div>`;
    } else if (res.tipo === 'nao-definida' && semLojas) {
      html = `<div class="cb-selo"><i class="fa-solid fa-location-dot" aria-hidden="true"></i> Sua cidade</div>
        <h3>Em qual cidade você está?</h3><p>Escolha para ver os restaurantes que entregam aí.</p>
        <div class="cb-acoes"><button type="button" class="cb-btn cb-principal" data-cb-trocar>Escolher cidade</button></div>`;
    }
    banner.hidden = !html;
    // Sem o menu inferior, o testador precisa de um caminho para entrar com a conta Google (a tela de login fica em Perfil).
    const entrar = usuario?.email
      ? `<a class="cb-entrar" href="perfil.html">Conectado como ${esc(usuario.email)} · Trocar conta</a>`
      : '<a class="cb-entrar" href="perfil.html"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> Sou testador · Entrar</a>';
    banner.innerHTML = html ? `<div class="cb-logo">${LOGO_YAPOOD}</div>${html}${entrar}` : '';
    // V75.73: com o aviso na tela, o app fica travado (só a cidade, o aviso e o menu): a vitrine só abre depois do lançamento.
    document.body.classList.toggle('cidade-trava', !!html);
  }

  function atualizar(opts = {}) {
    if ('semLojas' in opts) semLojas = !!opts.semLojas;
    const res = resolucao();
    desenharBotao(res);
    desenharBanner(res);
    return res;
  }

  // ----- modal -----
  function abrirModal(m, alvo = null) {
    if (!modal) return;
    modo = m; alvoAviso = alvo;
    desenharModal();
    modal.hidden = false;
    document.body.classList.add('cb-aberto');
    modal.querySelector('button, input, select')?.focus();
  }
  function fecharModal() { if (modal) modal.hidden = true; document.body.classList.remove('cb-aberto'); }

  function desenharModal() {
    const corpo = $('cidade-modal-corpo'); if (!corpo) return;
    const lista = listarCidades(cidades);
    if (modo === 'lista') {
      $('cidade-modal-titulo').textContent = 'Escolha sua cidade';
      corpo.innerHTML = `<div class="cb-lista">${lista.map((c) => `<button type="button" class="cb-item${c.id === resolucao().cidade?.id ? ' ativa' : ''}" data-cb-escolher="${esc(c.id)}"><span>${esc(rotuloCidade(c))}</span>${c.status === 'aberta' ? '' : '<small>Em breve</small>'}</button>`).join('')}</div>
        <button type="button" class="cb-link" data-cb-outra>Minha cidade não está na lista</button>`;
      return;
    }
    const c = alvoAviso?.cidadeId ? cidades[alvoAviso.cidadeId] : null;
    const gpsNome = !c && gps?.cidade ? gps.cidade : '';
    $('cidade-modal-titulo').textContent = 'Avise-me quando abrir';
    corpo.innerHTML = `<form id="cb-form" class="cb-form" novalidate>
      ${c ? `<p class="cb-texto">Vamos avisar no WhatsApp quando o YAPOOD abrir em <b>${esc(rotuloCidade(c))}</b>.</p>`
        : `<label>Sua cidade<input id="cb-nome" type="text" maxlength="80" autocomplete="address-level2" placeholder="Ex.: Patos de Minas" value="${esc(gpsNome)}"></label>
           <label>Estado<select id="cb-uf"><option value="">UF</option>${UFS.map((u) => `<option value="${u}"${gps?.uf === u ? ' selected' : ''}>${u}</option>`).join('')}</select></label>`}
      <label>Seu WhatsApp<input id="cb-zap" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="(34) 99999-9999"></label>
      <p id="cb-erro" class="cb-erro" role="alert" hidden></p>
      <button type="submit" class="cb-btn cb-principal" id="cb-enviar"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> Quero ser avisado</button>
      <p class="cb-pequeno">Usamos seu número só para avisar da abertura nesta cidade.</p></form>`;
  }

  async function enviarAviso(ev) {
    ev.preventDefault();
    const erro = $('cb-erro'), btn = $('cb-enviar');
    const v = validarInteressado({ cidadeId: alvoAviso?.cidadeId || '', nome: $('cb-nome')?.value, uf: $('cb-uf')?.value, whatsapp: $('cb-zap').value, cidades, uid: auth.currentUser?.uid || '' });
    if (!v.ok) { erro.hidden = false; erro.textContent = v.erro; return; }
    erro.hidden = true; btn.disabled = true;
    try {
      await set(ref(db, `lista_espera/${v.id}`), v.dados);
      gravarLocal(CHAVE_AVISO(v.dados.cidadeKey), '1');
      $('cidade-modal-corpo').innerHTML = `<div class="cb-sucesso"><i class="fa-solid fa-circle-check" aria-hidden="true"></i><h3>Pronto!</h3><p>Avisaremos no WhatsApp <b>${esc(formatarWhatsApp(v.dados.whatsapp))}</b> assim que o YAPOOD abrir em ${esc(v.dados.cidade)}.</p><button type="button" class="cb-btn cb-principal" data-cb-fechar>Fechar</button></div>`;
      atualizar();
    } catch (e) {
      console.warn('Lista de espera:', e);
      // Pedir de novo com o mesmo número é recusado pelo banco (não regrava): para o cliente, já está na lista.
      gravarLocal(CHAVE_AVISO(v.dados.cidadeKey), '1');
      erro.hidden = false; erro.textContent = 'Não foi possível registrar agora. Se você já pediu aviso para esta cidade com este número, ele já está na lista.';
      btn.disabled = false;
    }
  }

  document.addEventListener('click', (e) => {
    const t = e.target;
    if (t.closest('#btn-cidade')) return abrirModal('lista');
    const av = t.closest('[data-cb-avisar]');
    if (av) return abrirModal('avisar', av.dataset.cbAvisar ? { cidadeId: av.dataset.cbAvisar } : null);
    if (t.closest('[data-cb-trocar]')) return abrirModal('lista');
    if (t.closest('[data-cb-outra]')) { modo = 'avisar'; alvoAviso = null; return desenharModal(); }
    const esc_ = t.closest('[data-cb-escolher]');
    if (esc_) { escolhidaId = esc_.dataset.cbEscolher; gravarLocal(CHAVE_CIDADE, escolhidaId); fecharModal(); atualizar(); aoMudar?.(); return; }
    if (t.closest('[data-cb-fechar]') || t.closest('#cidade-modal-fechar') || t === modal) fecharModal();
  });
  document.addEventListener('submit', (e) => { if (e.target?.id === 'cb-form') enviarAviso(e); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal && !modal.hidden) fecharModal(); });

  // Quem é Master ou testador entra em modo teste. Falha de leitura = cliente comum (não abre nada por engano).
  onAuthStateChanged(auth, async (u) => {
    usuario = u || null;
    const ok = await podeFurarCidade(u);
    if (ok !== modoTeste) { modoTeste = ok; atualizar(); aoMudar?.(); } else atualizar();
  });

  // Demonstração ligada pelo Master (config_plataforma/demo_cidades {ativo, ate}): vale até a hora marcada e se desliga sozinha.
  const aplicarDemo = (v) => {
    clearTimeout(demoTimer);
    const ate = Number(v?.ate);
    const ativa = v?.ativo === true && Number.isFinite(ate) && ate > Date.now();
    if (ativa) demoTimer = setTimeout(() => aplicarDemo(v), Math.min(ate - Date.now() + 500, 2147000000));
    if (ativa !== demoAtiva) { demoAtiva = ativa; atualizar(); aoMudar?.(); }
  };
  onValue(ref(db, 'config_plataforma/demo_cidades'), (snap) => aplicarDemo(snap.val()), () => aplicarDemo(null)); // sem permissão de leitura: sem demonstração

  onValue(ref(db, 'cidades'), (snap) => {
    cidades = snap.val() || {};
    carregou = true;
    if (linkPendente) { // veio do QR/link de uma cidade: vale uma vez e fica lembrada
      if (cidades[linkPendente]) { escolhidaId = linkPendente; gravarLocal(CHAVE_CIDADE, escolhidaId); }
      linkPendente = '';
    }
    // Escolha antiga de uma cidade que não existe mais: esquece.
    if (escolhidaId && !cidades[escolhidaId]) { escolhidaId = ''; gravarLocal(CHAVE_CIDADE, ''); }
    atualizar();
    aoMudar?.();
  }, () => { cidades = {}; carregou = true; atualizar(); aoMudar?.(); }); // sem permissão de leitura: o app funciona como antes

  return {
    setGps(info) { gps = info && info.cidade ? { cidade: info.cidade, uf: info.uf || '' } : null; atualizar(); aoMudar?.(); },
    visivel: (loja) => lojaVisivelNaCidade(loja, resolucao(), verTudo() ? comoAbertas() : cidades),
    atualizar,
    temBanner: () => !!banner && !banner.hidden
  };
}
