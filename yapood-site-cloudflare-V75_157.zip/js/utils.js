// js/utils.js — utilitários de UI/armazenamento compartilhados (browser).
import { escapeHtml } from './regras.js';
export { escapeHtml };

export const IMG_LOJA_PADRAO = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="150" height="150"><rect width="150" height="150" fill="#eceff2"/><text x="75" y="88" font-family="Arial" font-size="42" font-weight="700" fill="#8a929a" text-anchor="middle">Loja</text></svg>'
);

// Versão Brasil: moeda única BRL.
export const MOEDAS_SUPORTADAS = Object.freeze({
  BRL: { codigo: 'BRL', nome: 'Real brasileiro', simbolo: 'R$', locale: 'pt-BR' }
});

const CHAVE_MOEDA = 'moeda_delivery';
export function normalizarMoeda(codigo) { return 'BRL'; }
export function obterMoedaAtual() { return 'BRL'; }
export function definirMoedaAtual(codigo) { try { localStorage.setItem(CHAVE_MOEDA, 'BRL'); } catch {} return 'BRL'; }

export function formatarMoeda(v, codigo = obterMoedaAtual()) {
  const c = normalizarMoeda(codigo);
  const cfg = MOEDAS_SUPORTADAS[c];
  return new Intl.NumberFormat(cfg.locale, { style: 'currency', currency: cfg.codigo, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(v) || 0);
}

export function debounce(fn, ms = 200) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// URL só é aceita se for http(s) ou data:image — evita javascript: em campos livres (logo, imagem).
/** V75.151: foto do Cloudinary no tamanho que a tela precisa (formato e compressão automáticos, nunca aumenta).
 *  Antes o app baixava o arquivo original (até 5 MB por foto). Só mexe em imagem enviada ao Cloudinary e sem ajuste prévio;
 *  GIF, SVG, vídeo e qualquer outro endereço voltam como vieram. Passe a largura já pensando em tela retina (2×). */
export function imgOtimizada(url, largura = 640) {
  const s = String(url || '').trim();
  const m = s.match(/^(https:\/\/res\.cloudinary\.com\/[^/]+\/image\/upload\/)(v\d+\/.+)$/i);
  if (!m || /\.(gif|svg)(\?|#|$)/i.test(m[2])) return s;
  const w = Math.max(48, Math.min(2000, Math.round(Number(largura)) || 640));
  return `${m[1]}f_auto,q_auto,c_limit,w_${w}/${m[2]}`;
}

export function urlSegura(u, fallback = '') {
  const s = String(u || '').trim();
  return /^(https?:\/\/|data:image\/)/i.test(s) ? s : fallback;
}

// ---------- Toast e confirmação personalizados (V75.26: no lugar de alert()/confirm() nativos) ----------
export { toast, confirmar } from './ui-mensagens.js';

// ---------- Armazenamento tolerante a falhas (modo privado / JSON corrompido) ----------
export function lerJSON(chave, padrao) {
  try { const v = JSON.parse(localStorage.getItem(chave)); return v ?? padrao; } catch { return padrao; }
}
export function gravarJSON(chave, valor) {
  try { localStorage.setItem(chave, JSON.stringify(valor)); } catch { /* quota/privado */ }
}
export const remover = (chave) => { try { localStorage.removeItem(chave); } catch { /* noop */ } };

export const CHAVE_CARRINHO = 'carrinho_delivery';
export const CHAVE_CUPOM = 'cupomCodigo';
export const obterCarrinho = () => {
  const c = lerJSON(CHAVE_CARRINHO, null);
  return c && Array.isArray(c.itens) ? c : { lojaId: null, itens: [] };
};
export const salvarCarrinho = (c) => gravarJSON(CHAVE_CARRINHO, c);

// Botão "carregando" para evitar clique duplo (pedidos duplicados).
export async function comTrava(btn, fn) {
  if (!btn || btn.disabled) return;
  const html = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processando…';
  try { return await fn(); } finally { btn.disabled = false; btn.innerHTML = html; }
}
