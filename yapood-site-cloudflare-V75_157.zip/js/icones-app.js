/**
 * V75.68 — troca o ícone dentro do app (aba do navegador, "adicionar à tela" do iPhone e aviso com o app aberto)
 * quando o Master configurou uma imagem para a data. Falha em silêncio: sem permissão, sem rede ou sem
 * campanha, nada muda e o ícone padrão continua valendo.
 */
import { db, ref, get } from './firebase.js';
import { appDaPagina, campanhaAtiva, infoDoApp } from './icones-campanha.js';

export const appAtual = appDaPagina(typeof location !== 'undefined' ? location.pathname : '');
let urlDaData = '';

function ligar(rel, href) {
  let l = document.querySelector(`link[rel="${rel}"]`);
  if (!l) { l = document.createElement('link'); l.rel = rel; document.head.appendChild(l); }
  l.href = href;
}

/** Ícone do aviso mostrado com o app aberto: o da data, ou o padrão do app. */
export function iconeDoAviso() { return urlDaData || `/${infoDoApp(appAtual).padrao}`; }
export function silhuetaDoAviso() { return `/${infoDoApp(appAtual).badge}`; }

export async function aplicarIconeDaData() {
  try {
    const c = (await get(ref(db, `config_icones/${appAtual}`))).val();
    if (!campanhaAtiva(c)) return '';
    urlDaData = c.url;
    ligar('apple-touch-icon', c.url);
    ligar('icon', c.url);
    return c.url;
  } catch { return ''; }
}

if (typeof document !== 'undefined') aplicarIconeDaData();
