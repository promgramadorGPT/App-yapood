// V75.40 — Financeiro: separa o que é VENDA DA LOJA, o que é COMISSÃO DO YAPOOD e o que é PUBLICIDADE.
// Regras puras (sem DOM/Firebase), usadas pelo painel da loja e pelo Master.
//   Venda da loja  = produtos + entrega − descontos (o desconto é custo da loja) − reembolsos
//   Comissão       = % da plataforma sobre os produtos; vira receita do YAPOOD (já separada no Mercado Pago ou "a acertar")
//   Publicidade    = anúncios vendidos pelo YAPOOD (registrados pelo Master); nunca entra em vendas nem em comissão
import { comissaoDoPedido } from './comissao.js';
import { normalizarStatus, STATUS } from './regras.js';

const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;
const num = (n) => Number(n) || 0;

export const PUB = { PENDENTE: 'pendente', PAGO: 'pago', CANCELADO: 'cancelado' };
export const ROTULO_PUB = { pendente: 'A receber', pago: 'Pago', cancelado: 'Cancelado' };

const online = (p) => { const f = String(p?.formaPagamento || '').toLowerCase(); return f.includes('mercado') || f.includes('pix'); };

function devolvido(p) {
  const r = p?.reembolso, total = num(p?.total);
  return r?.status === 'aprovado' ? Math.min(num(r.valor), total) : 0;
}
function produtosDe(p) {
  const sub = Number(p?.subtotal);
  if (Number.isFinite(sub) && sub >= 0) return sub;
  return (Array.isArray(p?.itens) ? p.itens : []).reduce((s, i) => s + num(i.precio) * num(i.qtd), 0);
}

/**
 * Contas de uma lista de pedidos (o chamador já tirou os cancelados / sem pagamento confirmado, mas cancelados são ignorados aqui também).
 * Tudo em reais, arredondado.
 */
export function resumoDinheiro(pedidos) {
  const r = {
    pedidos: 0, produtos: 0, entrega: 0, descontos: 0, reembolsos: 0, cobrado: 0,
    comissaoSplit: 0, comissaoAcertar: 0, comissao: 0,
    cobradoOnline: 0, cobradoNaEntrega: 0
  };
  for (const p of pedidos || []) {
    if (!p || normalizarStatus(p.status) === STATUS.CANCELADO) continue;
    const dev = devolvido(p), liquidoPedido = Math.max(0, num(p.total) - dev);
    r.pedidos++;
    r.produtos += produtosDe(p);
    r.entrega += num(p.precioEnvio);
    r.descontos += num(p.desconto);
    r.reembolsos += dev;
    r.cobrado += liquidoPedido;
    if (online(p)) r.cobradoOnline += liquidoPedido; else r.cobradoNaEntrega += liquidoPedido;
    const c = comissaoDoPedido(p);
    if (c.modo === 'split') r.comissaoSplit += c.valor; else if (c.modo === 'a_acertar') r.comissaoAcertar += c.valor;
  }
  for (const k of Object.keys(r)) if (k !== 'pedidos') r[k] = arred(r[k]);
  r.comissao = arred(r.comissaoSplit + r.comissaoAcertar);
  // O que sobra para a loja depois da comissão, e por onde cada parte chega até ela.
  r.liquidoLoja = arred(r.cobrado - r.comissao);
  r.noMercadoPago = arred(Math.max(0, r.cobradoOnline - r.comissaoSplit));   // PIX/cartão online: cai na conta do Mercado Pago já sem a comissão separada
  r.emMaos = r.cobradoNaEntrega;                                               // dinheiro/maquininha: a loja recebe do cliente
  r.devidoAoYapood = r.comissaoAcertar;                                        // comissão que a loja ainda precisa acertar
  return r;
}

// ---------- Publicidade ----------
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const limpar = (s, max) => String(s ?? '').trim().replace(/\s+/g, ' ').slice(0, max);

/** Valida o formulário do Master e devolve o registro pronto para gravar (sem criadoEm/criadoPor, que o chamador põe). */
export function montarPublicidade({ anunciante, lojaId = '', descricao = '', valor, status = PUB.PENDENTE, data, inicioEm = '', fimEm = '' }) {
  const nome = limpar(anunciante, 80);
  if (nome.length < 2) throw new Error('Informe quem está anunciando.');
  const v = arred(typeof valor === 'string' ? valor.replace(/\./g, '').replace(',', '.') : valor);
  if (!(v > 0) || v > 1000000) throw new Error('Informe o valor do anúncio (maior que zero).');
  if (!Object.values(PUB).includes(status)) throw new Error('Situação inválida.');
  if (!ISO.test(String(data || ''))) throw new Error('Informe a data da venda do anúncio.');
  const ini = inicioEm ? String(inicioEm) : '', fim = fimEm ? String(fimEm) : '';
  if ((ini && !ISO.test(ini)) || (fim && !ISO.test(fim))) throw new Error('Datas do período inválidas.');
  if (ini && fim && fim < ini) throw new Error('O fim do anúncio não pode ser antes do início.');
  const id = limpar(lojaId, 64);
  const desc = limpar(descricao, 120);
  return { anunciante: nome, ...(id ? { lojaId: id } : {}), ...(desc ? { descricao: desc } : {}), valor: v, status, data, ...(ini ? { inicioEm: ini } : {}), ...(fim ? { fimEm: fim } : {}) };
}

/** Soma da publicidade por situação. `lojaId` filtra uma loja; `desde`/`ate` (AAAA-MM-DD, inclusivos) filtram pela data da venda. */
export function resumoPublicidade(registros, { lojaId = null, desde = '', ate = '' } = {}) {
  const r = { pago: 0, pendente: 0, cancelado: 0, qtd: 0 };
  for (const x of registros || []) {
    if (!x) continue;
    if (lojaId && x.lojaId !== lojaId) continue;
    const d = String(x.data || '');
    if (desde && d < desde) continue;
    if (ate && d > ate) continue;
    const v = num(x.valor);
    if (x.status === PUB.PAGO) r.pago += v; else if (x.status === PUB.CANCELADO) r.cancelado += v; else r.pendente += v;
    if (x.status !== PUB.CANCELADO) r.qtd++;
  }
  r.pago = arred(r.pago); r.pendente = arred(r.pendente); r.cancelado = arred(r.cancelado);
  return r;
}

/** Receita do YAPOOD: só comissão + publicidade. As vendas das lojas NÃO entram aqui. */
export function receitaYapood({ comissao, publicidadePaga }) {
  const c = arred(comissao), p = arred(publicidadePaga);
  return { comissao: c, publicidade: p, total: arred(c + p) };
}

export function registrosDePublicidade(obj) {
  return Object.entries(obj || {}).map(([id, v]) => ({ id, ...(v || {}) })).sort((a, b) => String(b.data || '').localeCompare(String(a.data || '')) || String(b.criadoEm || '').localeCompare(String(a.criadoEm || '')));
}
