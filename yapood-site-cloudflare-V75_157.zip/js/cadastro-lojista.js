// js/cadastro-lojista.js — V75.47: cadastro do lojista (CPF/CNPJ + maioridade) analisado pelo Master antes de criar a loja.
// Funções puras (sem Firebase): validação de documento, idade, montagem do registro e textos de aviso. Testadas em tests/cadastro-lojista.test.mjs.
//
// Fluxo: Google → cadastro (status "pendente") → Master aprova ("aprovado") ou recusa ("recusado" + motivo) → lojista cria a loja.
// Dados: lojistas_cadastro/{uid} (dados e status) e lojistas_documentos/{uid} (foto do documento, só o Master lê).
// ATENÇÃO: validar o dígito verificador só pega erro de digitação. Quem confere se o documento é da pessoa é o Master, olhando a foto.

export const CADASTRO = Object.freeze({ PENDENTE: 'pendente', APROVADO: 'aprovado', RECUSADO: 'recusado' });
export const IDADE_MINIMA = 18;
export const TERMOS_VERSAO = 'provisorio-2026-10b'; // V75.116: item de dados virou aviso (LGPD)
export const LIMITE_FOTO_CHARS = 700000;           // ≈ 500 KB de imagem; igual ao limite das regras do Firebase
export const PREFIXO_FOTO = 'data:image/jpeg;base64,';

export const somenteDigitos = (v) => String(v ?? '').replace(/\D/g, '');
const todosIguais = (d) => /^(\d)\1+$/.test(d);

export function cpfValido(valor) {
  const d = somenteDigitos(valor);
  if (d.length !== 11 || todosIguais(d)) return false;
  for (const n of [9, 10]) {
    let soma = 0;
    for (let i = 0; i < n; i++) soma += Number(d[i]) * (n + 1 - i);
    const dv = ((soma * 10) % 11) % 10;
    if (dv !== Number(d[n])) return false;
  }
  return true;
}

export function cnpjValido(valor) {
  const d = somenteDigitos(valor);
  if (d.length !== 14 || todosIguais(d)) return false;
  for (const n of [12, 13]) {
    const pesos = n === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    let soma = 0;
    for (let i = 0; i < n; i++) soma += Number(d[i]) * pesos[i];
    const r = soma % 11;
    const dv = r < 2 ? 0 : 11 - r;
    if (dv !== Number(d[n])) return false;
  }
  return true;
}

/** 'cpf' | 'cnpj' | null — pelo tamanho; a validade é conferida à parte. */
export function tipoDoDocumento(valor) {
  const n = somenteDigitos(valor).length;
  return n === 11 ? 'cpf' : n === 14 ? 'cnpj' : null;
}

export function documentoValido(valor) {
  const t = tipoDoDocumento(valor);
  return t === 'cpf' ? cpfValido(valor) : t === 'cnpj' ? cnpjValido(valor) : false;
}

export function formatarDocumento(valor) {
  const d = somenteDigitos(valor);
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  return d;
}

/** Para listas: esconde parte do número (o número inteiro só aparece no detalhe, para o Master). */
export function mascararDocumento(valor) {
  const d = somenteDigitos(valor);
  if (d.length === 11) return `***.${d.slice(3, 6)}.${d.slice(6, 9)}-**`;
  if (d.length === 14) return `**.${d.slice(2, 5)}.${d.slice(5, 8)}/****-**`;
  return '—';
}

/** 'AAAA-MM-DD' real (rejeita 31/02) → milissegundos UTC à meia-noite, ou null. */
export function nascimentoParaMs(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso ?? ''));
  if (!m) return null;
  const [, a, me, di] = m.map(Number);
  const t = Date.UTC(a, me - 1, di);
  const d = new Date(t);
  return d.getUTCFullYear() === a && d.getUTCMonth() === me - 1 && d.getUTCDate() === di ? t : null;
}

/** Idade completa em anos na data `hoje` (Date). null se a data for inválida ou futura. */
export function idadeEm(iso, hoje = new Date()) {
  const ms = nascimentoParaMs(iso);
  if (ms === null) return null;
  const n = new Date(ms);
  const h = new Date(Date.UTC(hoje.getUTCFullYear(), hoje.getUTCMonth(), hoje.getUTCDate()));
  if (n > h) return null;
  let idade = h.getUTCFullYear() - n.getUTCFullYear();
  const antes = h.getUTCMonth() < n.getUTCMonth() || (h.getUTCMonth() === n.getUTCMonth() && h.getUTCDate() < n.getUTCDate());
  if (antes) idade--;
  return idade;
}

export const maiorDeIdade = (iso, hoje = new Date()) => {
  const i = idadeEm(iso, hoje);
  return i !== null && i >= IDADE_MINIMA && i <= 120;
};

/** WhatsApp/celular brasileiro → só dígitos com 55 (ex.: 5511987654321), ou ''. */
export function normalizarTelefone(raw) {
  let d = somenteDigitos(raw);
  if (!d) return '';
  if (d.length === 10 || d.length === 11) d = `55${d}`;
  if (!/^55\d{10,11}$/.test(d)) return '';
  const ddd = Number(d.slice(2, 4));
  if (ddd < 11 || ddd > 99) return '';
  if (d.length === 13 && d[4] !== '9') return '';
  return d;
}

const limpar = (v, max) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);

/** Máscara enquanto digita a data: dd/mm/aaaa. */
export function formatarNascimentoParcial(v) {
  const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v ?? '').trim());      // preenchimento automático do navegador
  const d = iso ? `${iso[3]}${iso[2]}${iso[1]}` : somenteDigitos(v).slice(0, 8);
  return d.length <= 2 ? d : d.length <= 4 ? `${d.slice(0, 2)}/${d.slice(2)}` : `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`;
}
/** '25/03/1990' ou '1990-03-25' → '1990-03-25' (data real) — ou '' se não for uma data válida. */
export function normalizarNascimento(v) {
  const s = String(v ?? '').trim();
  const br = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s);
  const iso = br ? `${br[3]}-${br[2]}-${br[1]}` : s;
  return nascimentoParaMs(iso) === null ? '' : iso;
}
/** '1990-03-25' → '25/03/1990' (para mostrar no campo). */
export function nascimentoParaBR(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso ?? ''));
  return m ? `${m[3]}/${m[2]}/${m[1]}` : '';
}

/**
 * Valida o formulário. Devolve { ok, erros: {campo: mensagem}, dados } — `dados` só vale quando ok.
 * `form`: { nomeCompleto, documento, nascimento, whatsapp, nomeLoja, aceitou, temFoto }
 */
export function validarCadastro(form, hoje = new Date()) {
  const erros = {};
  const nomeCompleto = limpar(form?.nomeCompleto, 120);
  if (nomeCompleto.length < 5 || !nomeCompleto.includes(' ')) erros.nomeCompleto = 'Digite seu nome completo.';

  const doc = somenteDigitos(form?.documento);
  const docTipo = tipoDoDocumento(doc);
  if (!docTipo) erros.documento = 'Digite um CPF (11 números) ou CNPJ (14 números).';
  else if (!documentoValido(doc)) erros.documento = `Este ${docTipo.toUpperCase()} não é válido. Confira os números.`;

  const nascBruto = String(form?.nascimento ?? '').trim();
  const nascimento = normalizarNascimento(nascBruto);            // aceita 25/03/1990 (digitado) ou 1990-03-25
  const nascimentoMs = nascimentoParaMs(nascimento);
  if (!nascBruto) erros.nascimento = 'Informe sua data de nascimento.';
  else if (nascimentoMs === null) erros.nascimento = 'Data inválida. Digite dia/mês/ano, por exemplo 25/03/1990.';
  else if (!maiorDeIdade(nascimento, hoje)) erros.nascimento = `É preciso ter ${IDADE_MINIMA} anos ou mais.`;

  const whatsapp = normalizarTelefone(form?.whatsapp);
  if (!whatsapp) erros.whatsapp = 'Informe um WhatsApp com DDD, por exemplo (11) 91234-5678.';

  const nomeLoja = limpar(form?.nomeLoja, 80);
  if (nomeLoja.length < 2) erros.nomeLoja = 'Digite o nome da loja.';

  if (!form?.temFoto) erros.foto = 'Envie uma foto do documento (RG ou CNH).';
  if (form?.aceitou !== true) erros.aceite = 'Para continuar, aceite os termos.';

  const ok = Object.keys(erros).length === 0;
  return {
    ok, erros,
    dados: ok ? { nomeCompleto, docTipo, doc, nascimento, nascimentoMs, whatsapp, nomeLoja } : null
  };
}

/** Registro gravado em lojistas_cadastro/{uid}. O status nasce sempre "pendente". */
export function montarCadastro(dados, { email = '', agora = new Date() } = {}) {
  const iso = agora.toISOString();
  return {
    status: CADASTRO.PENDENTE,
    nomeCompleto: dados.nomeCompleto, docTipo: dados.docTipo, doc: dados.doc,
    nascimento: dados.nascimento, nascimentoMs: dados.nascimentoMs,
    whatsapp: dados.whatsapp, email: limpar(email, 120), nomeLoja: dados.nomeLoja,
    aceite: { versao: TERMOS_VERSAO, em: iso },
    enviadoEm: iso, atualizadoEm: iso
  };
}

/** Só quem tem cadastro aprovado cria loja. */
export const podeCriarLoja = (cadastro) => cadastro?.status === CADASTRO.APROVADO;

export const rotuloCadastro = (c) => ({ [CADASTRO.PENDENTE]: 'Em análise', [CADASTRO.APROVADO]: 'Aprovado', [CADASTRO.RECUSADO]: 'Recusado' }[c?.status] || '—');

/** Alterações que o Master grava ao decidir. */
export function decisaoDoMaster(status, { motivo = '', uid = '', agora = new Date() } = {}) {
  if (status !== CADASTRO.APROVADO && status !== CADASTRO.RECUSADO) throw new Error('Decisão inválida.');
  const m = limpar(motivo, 300);
  if (status === CADASTRO.RECUSADO && m.length < 5) throw new Error('Explique o motivo da recusa (mín. 5 letras).');
  const iso = agora.toISOString();
  return { status, analisadoEm: iso, analisadoPor: uid, atualizadoEm: iso, motivoRecusa: status === CADASTRO.RECUSADO ? m : null };
}

/** Mensagem pronta para o Master mandar pelo WhatsApp. */
export function mensagemWhatsApp(cadastro, { url = '' } = {}) {
  const primeiro = limpar(cadastro?.nomeCompleto, 60).split(' ')[0] || 'tudo bem';
  if (cadastro?.status === CADASTRO.APROVADO) {
    return `Olá, ${primeiro}! Seu cadastro no YaPOOD foi aprovado. 🎉 Já pode entrar e criar a sua loja${url ? `: ${url}` : '.'}`;
  }
  return `Olá, ${primeiro}! Analisamos o seu cadastro no YaPOOD e ainda não foi possível aprovar. Motivo: ${limpar(cadastro?.motivoRecusa, 300) || 'veja no aplicativo'}. Você pode corrigir os dados e enviar de novo${url ? `: ${url}` : '.'}`;
}

export function linkWhatsApp(telefone, texto) {
  const t = normalizarTelefone(telefone);
  return t ? `https://wa.me/${t}?text=${encodeURIComponent(texto)}` : '';
}

/** Máscara enquanto a pessoa digita: CPF até 11 números, CNPJ depois disso. */
export function formatarDocumentoParcial(valor) {
  const d = somenteDigitos(valor).slice(0, 14);
  if (d.length <= 11) {
    return d.replace(/^(\d{3})(\d)/, '$1.$2').replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3').replace(/^(\d{3})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3-$4');
  }
  return d.replace(/^(\d{2})(\d)/, '$1.$2').replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3').replace(/^(\d{2})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3/$4').replace(/^(\d{2})\.(\d{3})\.(\d{3})\/(\d{4})(\d)/, '$1.$2.$3/$4-$5');
}

/** Máscara de telefone enquanto digita: (11) 91234-5678 ou (11) 3456-7890. */
export function formatarTelefoneParcial(valor) {
  let d = somenteDigitos(valor);
  if (d.startsWith('55') && d.length > 11) d = d.slice(2);
  d = d.slice(0, 11);
  if (d.length <= 2) return d ? `(${d}` : '';
  const meio = d.length > 10 ? 7 : 6;
  if (d.length <= meio) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, meio)}-${d.slice(meio)}`;
}

/** Último dia em que alguém nascido nele já tem 18 anos hoje (valor do atributo `max` do campo de data). */
export function maxNascimento(hoje = new Date()) {
  const d = new Date(Date.UTC(hoje.getUTCFullYear() - IDADE_MINIMA, hoje.getUTCMonth(), hoje.getUTCDate()));
  return d.toISOString().slice(0, 10);
}

/** Reduz a imagem para caber no limite. Devolve {largura, altura} mantendo a proporção. */
export function dimensoesReduzidas(w, h, maxLado = 1400) {
  const maior = Math.max(w, h);
  if (!(maior > 0)) return { largura: 0, altura: 0 };
  const f = maior > maxLado ? maxLado / maior : 1;
  return { largura: Math.max(1, Math.round(w * f)), altura: Math.max(1, Math.round(h * f)) };
}

export const fotoValida = (s) => typeof s === 'string' && s.startsWith(PREFIXO_FOTO) && s.length > PREFIXO_FOTO.length + 200 && s.length <= LIMITE_FOTO_CHARS;
