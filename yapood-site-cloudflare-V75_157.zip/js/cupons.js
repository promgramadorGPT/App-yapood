import './icones-app.js';
// js/cupons.js — página "Cupons".
// Antes: três cupons fixos no front (qualquer pessoa editava o localStorage e ganhava desconto em qualquer loja).
// Agora: os cupons pertencem à LOJA (restaurantes/{id}/cupones, cadastrados no painel admin) e são validados no carrinho.
// Aqui o cliente só vê/aplica cupons da loja do seu carrinho atual; guardamos apenas o CÓDIGO.
import { auth, onAuthStateChanged } from './firebase.js';
import { buscarLoja, cuponsDaLoja, buscarUsoCupons } from './pedido-service.js';
import { calcularTotais, resolverCupom, escapeHtml, estadoValidadeCupom, produtosDoCupom, dataBR } from './regras.js';
import { obterCarrinho, gravarJSON, toast, CHAVE_CUPOM } from './utils.js';

const $ = (id) => document.getElementById(id);
const container = $('lista-cupons-container');
let cupons = [], carrinho = obterCarrinho(), loja = null, uso = null;

function descricao(c) {
  const alvo = c.tipo === 'porcentagem' ? `${c.valor}% de desconto` : c.tipo === 'fixo' ? `R$ ${Number(c.valor).toFixed(2).replace('.', ',')} de desconto` : 'Entrega grátis';
  const ids = produtosDoCupom(c);
  const nomes = ids.map((id) => loja?.menu?.[id]?.nombre).filter(Boolean);
  const min = c.minimo ? ` · ${ids.length ? 'mínimo em produtos participantes' : 'pedido mínimo'} R$ ${Number(c.minimo).toFixed(2).replace('.', ',')}` : '';
  const prod = ids.length ? ` · vale para: ${nomes.length ? nomes.slice(0, 3).join(', ') + (nomes.length > 3 ? ` e mais ${nomes.length - 3}` : '') : 'produtos selecionados'}` : '';
  const val = estadoValidadeCupom(c) === 'agendado' ? ` · começa em ${dataBR(c.inicioEm)}` : c.fimEm ? ` · válido até ${dataBR(c.fimEm)}` : '';
  return `${alvo}${min}${prod}${val}`;
}

async function iniciar() {
  if (!carrinho.lojaId || !carrinho.itens.length) {
    container.innerHTML = '<div class="msg-vazio"><p>Os cupons dependem do restaurante.<br>Adicione produtos ao seu carrinho e veja aqui os cupons disponíveis.</p><a class="btn-link" href="index.html">Ver restaurantes</a></div>';
    return;
  }
  try {
    loja = await buscarLoja(carrinho.lojaId);
    cupons = cuponsDaLoja(loja).filter((c) => c.ativo !== false && estadoValidadeCupom(c) !== 'expirado'); // vencidos saem da lista
  } catch { container.innerHTML = '<p class="msg-vazio">Não foi possível carregar os cupons.</p>'; return; }

  desenhar();
  // O limite de usos depende de quem está logado: confere assim que o login for conhecido.
  onAuthStateChanged(auth, async (user) => {
    uso = user ? await buscarUsoCupons(carrinho.lojaId, user.uid, cupons) : null;
    if (uso) desenhar();
  });
}

// Estado do botão: "Usar", "Em breve", "Esgotado" ou "Já usado" (limite por cliente).
function acao(c) {
  if (estadoValidadeCupom(c) === 'agendado') return '<span class="cupom-futuro">Em breve</span>';
  const r = resolverCupom(c.codigo, [c], 0, 0, null, new Date(), uso);
  if (r.erro && /esgotou/.test(r.erro)) return '<span class="cupom-futuro off">Esgotado</span>';
  if (r.erro && /já usou/.test(r.erro)) return '<span class="cupom-futuro off">Já usado</span>';
  return `<button class="btn-aplicar-cupom" data-cod="${escapeHtml(c.codigo)}">Usar</button>`;
}

function desenhar() {
  container.innerHTML = cupons.length
    ? `<p class="cupom-contexto">Cupons de <strong>${escapeHtml(loja.nombre || 'seu restaurante')}</strong></p>` + cupons.map((c) => `
      <div class="cupom-card"><div class="cupom-info"><h4>${escapeHtml(c.codigo)}</h4><p>${escapeHtml(c.titulo || '')}</p><small>${escapeHtml(descricao(c))}</small></div>
      ${acao(c)}</div>`).join('')
    : '<p class="msg-vazio">Este restaurante não possui cupons ativos no momento.</p>';
}


function aplicar(codigo) {
  const cod = String(codigo || '').trim().toUpperCase(); if (!cod) return;
  const t = calcularTotais(carrinho.itens, loja?.precioEnvio || 0, cupons, cod, new Date(), uso);
  if (!t.cupom) return toast(t.erroCupom || 'Cupom inválido ou expirado.', 'error');
  gravarJSON(CHAVE_CUPOM, cod);
  toast(`Cupom ${cod} aplicado. Ahorras R$ ${t.desconto.toFixed(2).replace('.', ',')}.`, 'success');
  setTimeout(() => { location.href = 'cart.html'; }, 900);
}

container.addEventListener('click', (e) => { const b = e.target.closest('[data-cod]'); if (b) aplicar(b.dataset.cod); });
$('btn-validar-cupom')?.addEventListener('click', () => {
  if (!loja) return toast('Primeiro adicione produtos ao seu carrinho.', 'error');
  aplicar($('input-codigo-cupom').value);
});
iniciar();
