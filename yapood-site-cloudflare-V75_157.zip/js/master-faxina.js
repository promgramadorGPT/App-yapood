// js/master-faxina.js — V75.117: "Faxina de imagens" do Cloudinary (Master → Configuração).
// Quem lista, confere e apaga é a API 2.21 (só ela tem a API Secret). Aqui: prévia, escolha das pastas, confirmação e resultado.
// A API confere tudo de novo na hora de apagar: se uma imagem voltou a ser usada, ela não é apagada.

const API = 'https://api-mp-yapoodbr.onrender.com';
const MAX_MINIATURAS = 120;

export const tamanho = (b) => {
  const n = Number(b) || 0;
  if (n >= 1024 * 1024 * 1024) return `${(n / 1024 / 1024 / 1024).toFixed(2).replace('.', ',')} GB`;
  if (n >= 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1).replace('.', ',')} MB`;
  return `${Math.max(0, Math.round(n / 1024))} KB`;
};
export const nomePasta = (p) => (p ? p : '(sem pasta)');
export const imagens = (n) => `${n} ${n === 1 ? 'imagem' : 'imagens'}`;
/** Pasta do YAPOOD no Cloudinary (V75.118: todo envio novo vai para ela). */
export const PASTA_YAPOOD = 'yapood';
/** Pastas que começam marcadas: só a do YAPOOD, quando tem o que apagar. V75.120: nenhuma outra começa marcada,
 *  nem se for a única (a conta do Cloudinary tem imagens de outros projetos, inclusive em "(sem pasta)"). */
export function pastasIniciais(pastas) {
  return new Set((pastas || []).some((p) => p.pasta === PASTA_YAPOOD && p.semUso > 0) ? [PASTA_YAPOOD] : []);
}
/** V75.120: texto de uma pasta. Pasta sem nada para apagar também aparece, dizendo por quê (a API 2.21.4 manda emUso/recentes/liberaEm). */
export function resumoPasta(p, idadeMinDias = 7) {
  const nome = nomePasta(p.pasta);
  if (p.semUso > 0) return `${nome} · ${p.semUso} de ${p.total} imagens para apagar (${tamanho(p.bytesSemUso)})`;
  if (typeof p.emUso !== 'number') return `${nome} · ${imagens(p.total)} · nada para apagar agora (estão em uso ou foram enviadas há menos de ${idadeMinDias} dias)`;
  const partes = [p.emUso ? `${p.emUso} em uso` : '', p.recentes ? `${p.recentes} ${p.recentes === 1 ? 'nova' : 'novas'} sem uso, protegida${p.recentes === 1 ? '' : 's'} até ${idadeMinDias} dias${p.liberaEm ? ` (a primeira pode sair a partir de ${new Date(p.liberaEm).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })})` : ''}` : ''].filter(Boolean);
  return `${nome} · ${imagens(p.total)} · nada para apagar agora${partes.length ? `: ${partes.join(', ')}` : ''}`;
}
/** Ordem das pastas na tela: a do YAPOOD primeiro, depois as que têm o que apagar, depois o resto. */
export function ordenarPastas(pastas) {
  const peso = (p) => (p.pasta === PASTA_YAPOOD ? 0 : p.semUso > 0 ? 1 : 2);
  return [...(pastas || [])].sort((a, b) => peso(a) - peso(b) || b.total - a.total);
}
/** O que vai ser apagado com as pastas escolhidas. */
export function selecionadas(previa, pastas) {
  const todas = [...(previa?.semUso || []), ...(previa?.expiradas || [])];
  const itens = todas.filter((x) => pastas.has(x.pasta));
  return { itens, bytes: itens.reduce((s, x) => s + (Number(x.bytes) || 0), 0), semUso: itens.filter((x) => x.motivo === 'sem_uso').length, vencidas: itens.filter((x) => x.motivo !== 'sem_uso').length };
}

const ESTILO = `
#faxina-raiz .fx-resumo{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:12px 0}
#faxina-raiz .fx-num{border:1px solid var(--m-linha);border-radius:12px;padding:10px 12px}
#faxina-raiz .fx-num b{display:block;font-size:1.25rem}
#faxina-raiz .fx-num span{font-size:.82rem;color:var(--m-suave)}
#faxina-raiz .fx-pastas{display:grid;gap:6px;margin:10px 0}
#faxina-raiz label.fx-pasta{flex-direction:row;align-items:center;gap:10px;font-weight:600}
#faxina-raiz .fx-pasta-vazia{margin:0;display:flex;gap:10px;align-items:baseline;color:var(--m-suave);font-weight:600;padding-left:2px}
#faxina-raiz label.fx-pasta input{width:20px;height:20px;flex:none;accent-color:var(--m-marca)}
#faxina-raiz .fx-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(76px,1fr));gap:6px;margin:10px 0}
#faxina-raiz .fx-grade figure{margin:0;position:relative}
#faxina-raiz .fx-grade img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;background:#eef1f4;border:1px solid var(--m-linha)}
#faxina-raiz .fx-grade figcaption{font-size:.7rem;color:var(--m-suave);text-align:center}
#faxina-raiz .fx-tag{position:absolute;top:4px;left:4px;background:rgba(0,0,0,.65);color:#fff;font-size:.65rem;padding:1px 6px;border-radius:999px}
#faxina-raiz .fx-acoes{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:12px}
`;

/** ctx: { $, esc, aviso, executar, confirmar, logar, auth }. Desenha dentro de <div id="faxina-raiz">. */
export function iniciarFaxinaMaster(ctx) {
  const { $, esc, aviso, executar, confirmar, logar, auth } = ctx;
  const raiz = $('faxina-raiz');
  if (!raiz) return { render() {} };
  if (!document.getElementById('faxina-estilo')) { const st = document.createElement('style'); st.id = 'faxina-estilo'; st.textContent = ESTILO; document.head.appendChild(st); }
  let previa = null, pastas = new Set(), carregando = false, apagando = false, erro = '', semChaves = false;

  async function api(rota, corpo) {
    const token = await auth?.currentUser?.getIdToken();
    if (!token) throw new Error('Sessão Master não encontrada. Entre novamente.');
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 120000); // a primeira chamada pode acordar a API e a lista pode ser longa
    try {
      const r = await fetch(API + rota, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(corpo || {}), signal: ctl.signal });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || d.error) {
        if (r.status === 404 && !d.error) throw new Error('A API ainda não tem a faxina. Atualize a API no Render para a 2.21.0.');
        throw Object.assign(new Error(d.error || 'Não foi possível concluir.'), { semChaves: !!d.semChaves });
      }
      return d;
    } catch (e) {
      if (e.name === 'AbortError') throw new Error('O servidor demorou para responder. Tente de novo em instantes.');
      if (e instanceof TypeError) throw new Error('Sem conexão com o servidor. Confira a internet e tente de novo.');
      throw e;
    } finally { clearTimeout(t); }
  }

  function desenhar() {
    const sel = previa ? selecionadas(previa, pastas) : null;
    const num = (v, t) => `<div class="fx-num"><b>${v}</b><span>${esc(t)}</span></div>`;
    let corpo = '';
    if (semChaves) corpo = `<p class="m-faixa m-faixa-aviso"><b>Faltam as chaves do Cloudinary no Render.</b> No painel do Cloudinary, abra Settings → API Keys e copie a API Key e a API Secret. No Render, em api-mp-yapoodbr → Environment, crie <b>CLOUDINARY_API_KEY</b> e <b>CLOUDINARY_API_SECRET</b> com esses valores e salve (a API reinicia sozinha). Depois toque de novo em "Ver o que pode ser apagado".</p>`;
    else if (erro) corpo = `<p class="m-faixa m-faixa-erro">${esc(erro)}</p>`;
    if (previa) {
      const ps = previa.pastas.filter((p) => p.semUso > 0);
      const todas = ordenarPastas(previa.pastas);
      const linhaPasta = (p) => p.semUso > 0
        ? `<label class="fx-pasta"><input type="checkbox" data-fx-pasta="${esc(p.pasta)}" ${pastas.has(p.pasta) ? 'checked' : ''} ${apagando ? 'disabled' : ''}><span>${esc(resumoPasta(p, previa.idadeMinDias))}</span></label>`
        : `<p class="fx-pasta-vazia"><i class="fa-regular fa-folder" aria-hidden="true"></i> <span>${esc(resumoPasta(p, previa.idadeMinDias))}</span></p>`;
      corpo += `<div class="fx-resumo">${num(previa.total, 'imagens na conta')}${num(tamanho(previa.bytesTotal), 'ocupadas no total')}${num(previa.emUso, 'em uso no app')}${num(previa.recentes, `enviadas há menos de ${previa.idadeMinDias} dias (protegidas)`)}${num(previa.qtdSemUso, 'sem uso')}${num(previa.qtdExpiradas, `fotos de relato e comprovantes com mais de ${previa.guardaDias} dias`)}</div>`;
      if (!previa.completo) corpo += '<p class="m-faixa m-faixa-aviso">A conta tem imagens demais para listar de uma vez. A prévia mostra só uma parte e a faxina fica bloqueada.</p>';
      if (!ps.length) corpo += `<p class="m-nota">Nada para apagar agora. 🎉</p><div class="fx-pastas">${todas.map(linhaPasta).join('')}</div>`;
      else {
        corpo += `<p class="m-nota"><b>Escolha as pastas.</b> A pasta <b>yapood</b> é só do YAPOOD (todo envio novo vai para ela). ${ps.length > 1 ? 'As outras podem ser de outros projetos que usam a mesma conta do Cloudinary: só marque se tiver certeza.' : ''}</p>
          <div class="fx-pastas">${todas.map(linhaPasta).join('')}</div>`;
        const mostrar = sel.itens.slice(0, MAX_MINIATURAS);
        corpo += mostrar.length ? `<div class="fx-grade" id="fx-grade">${mostrar.map((x) => `<figure><img loading="lazy" src="${esc(x.miniatura)}" alt="Imagem ${esc(x.public_id)}">${x.motivo !== 'sem_uso' ? `<span class="fx-tag">${x.motivo === 'relato' ? 'relato' : 'comprovante'}</span>` : ''}<figcaption>${new Date(x.criadaEm).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })}</figcaption></figure>`).join('')}</div>${sel.itens.length > mostrar.length ? `<p class="m-nota">… e mais ${sel.itens.length - mostrar.length}.</p>` : ''}` : '<p class="m-nota">Marque uma pasta para ver as imagens.</p>';
      }
    }
    raiz.innerHTML = `${corpo}<div class="fx-acoes">
      <button type="button" class="m-btn m-btn-leve" id="fx-previa" ${carregando || apagando ? 'disabled' : ''}><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i> ${carregando ? 'Conferindo… pode levar até 2 minutos' : previa ? 'Conferir de novo' : 'Ver o que pode ser apagado'}</button>
      ${previa && sel?.itens.length ? `<button type="button" class="m-btn m-btn-perigo-cheio" id="fx-apagar" ${apagando || !previa.completo ? 'disabled' : ''}><i class="fa-solid fa-broom" aria-hidden="true"></i> ${apagando ? 'Apagando…' : `Apagar ${imagens(sel.itens.length)} (${tamanho(sel.bytes)})`}</button>` : ''}
    </div>`;
  }

  async function verPrevia() {
    if (carregando) return;
    carregando = true; erro = ''; semChaves = false; desenhar();
    try { previa = await api('/imagens/faxina/previa'); pastas = pastasIniciais(previa.pastas); }
    catch (e) { previa = null; semChaves = !!e.semChaves; erro = semChaves ? '' : e.message; }
    carregando = false; desenhar();
  }

  async function apagar() {
    const sel = selecionadas(previa, pastas); if (!sel.itens.length || apagando) return;
    const partes = [sel.semUso ? `${sel.semUso} sem uso` : '', sel.vencidas ? `${sel.vencidas} foto(s) de relato/comprovante com mais de ${previa.guardaDias} dias (o link também sai do pedido ou do acerto)` : ''].filter(Boolean).join(' e ');
    const c = await confirmar({ titulo: `Apagar ${imagens(sel.itens.length)} do Cloudinary?`, texto: `${partes}. Libera ${tamanho(sel.bytes)}. Pastas: ${[...pastas].map(nomePasta).join(', ')}.`, aviso: 'Não dá para desfazer. O servidor confere de novo antes de apagar: o que voltou a ser usado fica.', rotulo: 'Apagar', perigo: true });
    if (!c.ok) return;
    apagando = true; desenhar();
    const r = await executar(() => api('/imagens/faxina/apagar', { publicIds: sel.itens.map((x) => x.public_id), pastas: [...pastas] }));
    apagando = false;
    if (r && r.ok) {
      aviso(`${r.apagadas} imagem(ns) apagada(s), ${tamanho(r.bytes)} liberados.${r.falharam ? ` ${r.falharam} falharam (tente de novo).` : ''}${r.ignoradas ? ` ${r.ignoradas} ficaram (voltaram a ser usadas).` : ''}`, r.falharam ? 'erro' : 'ok');
      await logar('imagens.faxina', `${r.apagadas} apagadas`, `${tamanho(r.bytes)} · pastas: ${[...pastas].map(nomePasta).join(', ')}${r.falharam ? ` · ${r.falharam} falharam` : ''}`);
      await verPrevia();
    } else desenhar();
  }

  raiz.addEventListener('click', (e) => {
    if (e.target.closest('#fx-previa')) verPrevia();
    else if (e.target.closest('#fx-apagar')) apagar();
  });
  raiz.addEventListener('change', (e) => {
    const p = e.target.dataset?.fxPasta; if (p === undefined) return;
    if (e.target.checked) pastas.add(p); else pastas.delete(p);
    desenhar();
  });
  desenhar();
  return { render() {} };
}
