// js/checkout-ui.js — V75.126: partes puras do carrinho (sem DOM, sem banco). Testadas em tests/checkout-ui.test.mjs.

const limpo = (v) => String(v ?? '').replace(/\s+/g, ' ').trim();

/** Dados do cliente bastam para mostrar só o cartão (nome com 2+ letras e telefone com DDD). */
export function dadosCompletos({ nome, telefone } = {}) {
  return limpo(nome).length >= 2 && String(telefone ?? '').replace(/\D/g, '').length >= 10;
}

/** "34988887777" → "(34) 98888-7777"; "3432221111" → "(34) 3222-1111"; outro formato volta como veio. */
export function formatarTelefone(v) {
  const d = String(v ?? '').replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return limpo(v);
}

// Valores do <select id="forma-pago"> (não mudam: o pedido e o painel da loja usam esses textos).
const CARTAO_ENTREGA = 'Cartão / Débito (pagar ao entregador)';
const ORDEM = ['PIX', 'Mercado Pago', CARTAO_ENTREGA, 'Dinheiro'];

/**
 * Lista de formas para desenhar, na ordem Pix, cartão online, cartão na entrega, dinheiro.
 * `disponiveis`: valores das opções visíveis do select. Valor desconhecido vai no fim com o próprio texto.
 */
export function formasDePagamento(disponiveis, retirada = false) {
  const info = {
    PIX: { nome: 'Pix', sub: 'Pague agora, aprovação na hora', icone: 'fa-brands fa-pix' },
    'Mercado Pago': { nome: 'Cartão de crédito online', sub: 'Pague agora pelo Mercado Pago', icone: 'fa-regular fa-credit-card' },
    [CARTAO_ENTREGA]: { nome: retirada ? 'Cartão na loja' : 'Cartão na entrega', sub: 'Crédito ou débito na maquininha', icone: 'fa-solid fa-credit-card' },
    Dinheiro: { nome: 'Dinheiro', sub: retirada ? 'Pague na loja' : 'Pague na entrega', icone: 'fa-solid fa-money-bill-wave' }
  };
  const lista = [...new Set((disponiveis || []).map(String))];
  const pos = (v) => { const i = ORDEM.indexOf(v); return i < 0 ? 99 : i; };
  return lista.sort((a, b) => pos(a) - pos(b)).map((valor) => ({ valor, ...(info[valor] || { nome: valor, sub: '', icone: 'fa-solid fa-wallet' }) }));
}
