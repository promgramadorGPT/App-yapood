import { avaliarLocalizacaoCliente, textoErroLocalizacao, coordParaPedido } from './rastreio.js';
import { auth, googleProvider, signInWithPopup, onAuthStateChanged, db, ref, get, set } from './firebase.js';
import { bloqueioDaLojaAgora } from './cidades-bloqueio.js';
import { calcularTotais, reconciliarItensComMenu, lojaAberta, escapeHtml, PAGO } from './regras.js';
import {
  formatarMoeda, obterCarrinho, salvarCarrinho, lerJSON, gravarJSON, remover, toast, confirmar, comTrava, urlSegura, imgOtimizada, CHAVE_CARRINHO, CHAVE_CUPOM
} from './utils.js';
import {
  buscarLoja, cuponsDaLoja, buscarUsoCupons, registrarPedido, buscarPedidosDoCliente, cancelarPedidoCliente, salvarPerfilCliente,
  montarMensagemWhatsApp, urlWhatsApp, telefoneLoja, buscarEnderecos, salvarEndereco, removerEndereco, lembrarUltimoEndereco, sugerirBairro, comLimite
} from './pedido-service.js';
import { resolverBairro, textoBairro, listarBairros, configBairros } from './bairros.js';
import { distanciaParaEndereco } from './distancia.js';
import { pedidosEmAndamentoNaLoja, textoPedidoAberto } from './pedido-aberto.js';
import { validarTroco } from './troco.js';
import { ROTULOS, montarEndereco, mesmoEndereco, modoEndereco, enderecoPadrao } from './enderecos.js?v=75.126';
import { dadosCompletos, formatarTelefone, formasDePagamento } from './checkout-ui.js?v=75.126';
import { formaValida } from './perfil-dados.js?v=75.135';
import { detalhesDaLinha } from './combo.js?v=75.128';
import { configFidelidade, progressoFidelidade, descontoPremio, calcularTotaisComPremio, presentesParaCliente, textoProgressoSurpresa } from './fidelidade.js';
import { lerReveladas, marcarReveladas, mostrarPresente, consumirUsoNoCarrinho } from './fidelidade-presente.js';
import { montarCartao, desmontarCartao, cobrarNoBackend } from './checkout-cartao.js';
import { nomeExibicao } from './perfil-util.js?v=75.106';
import { previsaoUso, valorSaldo } from './saldo-loja.js?v=75.145';
import { aplicarSaldo, devolverSaldoDoPedido, buscarSaldo } from './saldo-api.js?v=75.145';

const IMG_PRATO_PADRAO = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300';
const MP_BACKEND = 'https://api-mp-yapoodbr.onrender.com';
let pixTimer = null;
let pixPagamentoId = null;

const $ = (id) => document.getElementById(id);
const modalAuth = $('modal-auth');

// Estado único da tela: tudo (UI, cartão, pedido) deriva daqui.
const S = { loja: null, lojaId: null, itens: [], cupons: [], codigoCupom: '', totais: null, status: { aberta: true }, pedidoPendente: null, tipoEntrega: 'delivery', premioCfg: null, progresso: null, presentes: { novos: 0, visiveis: 0 }, uso: null, usarPremio: false, enderecos: [], enderecoSel: null, endNovo: false, dadosEditando: false, entregaCoord: null, saldo: 0, usarSaldo: true };

// ---------- Auth ----------
onAuthStateChanged(auth, async (user) => {
  if (!user) { S.saldo = 0; S.progresso = null; S.uso = null; S.presentes = { novos: 0, visiveis: 0 }; S.usarPremio = false; S.enderecos = []; S.enderecoSel = null; S.endNovo = false; S.dadosEditando = false; fecharSheetEnderecos(); renderEnderecos(); renderDados(); if (S.itens.length) recalcular(); return; }
  atualizarPremio();
  atualizarUsoCupons();
  atualizarSaldo();
  try {
    const dados = (await get(ref(db, `usuarios/${user.uid}`))).val() || {};
    const preencher = (id, v) => { const e = $(id); if (e && !e.value) e.value = v || ''; };
    preencher('cliente-nombre', nomeExibicao(user, dados));
    preencher('cliente-email', dados.email || user.email); // V75.135: o e-mail do Perfil vale antes do da conta Google
    preencher('cliente-telefono', dados.telefone);
    S.formaPreferida = formaValida(dados.pagamentoPreferido) ? dados.pagamentoPreferido : null; aplicarFormaPreferida();
    try { S.enderecos = await buscarEnderecos(user.uid); } catch (e) { console.warn('Endereços não carregados:', e); S.enderecos = []; }
    S.ultimoEnd = dados.ultimoEndereco || null;
    const padrao = enderecoPadrao(S.enderecos, S.ultimoEnd);
    if (padrao && !$('cliente-direccion').value) selecionarEndereco(padrao.id);
    else if (!S.enderecos.length) preencher('cliente-direccion', dados.direccion);
    if (!S.enderecoSel) preencher('cliente-referencia', dados.referencia); // V75.125: no cartão, a referência é a do endereço salvo
    renderEnderecos();
    preencher('cliente-observacion', dados.observacion);
  } catch (e) { console.warn('Perfil no cargado:', e); }
  renderDados();
  modalAuth.style.display = 'none';
});

$('btn-login-google')?.addEventListener('click', async () => {
  try {
    const { user } = await signInWithPopup(auth, googleProvider);
    const uref = ref(db, `usuarios/${user.uid}`);
    if (!(await get(uref)).exists()) {
      await set(uref, { nome: user.displayName || '', email: user.email || '', criadoEm: new Date().toISOString() });
    }
    modalAuth.style.display = 'none';
    toast('Sessão iniciada. Agora você pode confirmar seu pedido.', 'success');
  } catch (e) {
    console.error(e);
    if (e.code !== 'auth/popup-closed-by-user') toast('Não foi possível entrar com Google.', 'error');
  }
});
$('btn-fechar-auth')?.addEventListener('click', () => { modalAuth.style.display = 'none'; });

// ---------- Carregamento e reconciliação ----------
async function carregar() {
  const c = obterCarrinho();
  if (!c.lojaId || !c.itens.length) { S.itens = []; return renderVazio(); }

  if (S.lojaId !== c.lojaId) {
    S.loja = await buscarLoja(c.lojaId);
    S.lojaId = c.lojaId;
    if (!S.loja) { salvarCarrinho({ lojaId: null, itens: [] }); toast('Este restaurante não existe mais.', 'error'); return renderVazio(); }
    S.cupons = cuponsDaLoja(S.loja);
    S.usarPremio = false; S.progresso = null; S.uso = null; S.presentes = { novos: 0, visiveis: 0 }; S.saldo = 0; S.usarSaldo = true;
    if (auth.currentUser) atualizarSaldo();
  }
  S.premioCfg = configFidelidade(S.loja.fidelidade);
  if (S.premioCfg && auth.currentUser && !S.progresso) atualizarPremio();
  if (auth.currentUser && !S.uso) atualizarUsoCupons();

  // O carrinho vive no localStorage (o usuário pode editá-lo). Preços/disponibilidade são revalidados contra o cardápio.
  const { itens, avisos } = reconciliarItensComMenu(c.itens, S.loja.menu);
  if (avisos.length) { avisos.forEach((a) => toast(a, 'error', 5000)); salvarCarrinho({ lojaId: c.lojaId, itens }); }
  if (!itens.length) { salvarCarrinho({ lojaId: null, itens: [] }); return renderVazio(); }
  S.itens = itens;
  S.status = lojaAberta(S.loja);
  const bloqueioCidade = await bloqueioDaLojaAgora(S.loja); // V75.73: cidade ainda em espera
  if (bloqueioCidade.bloqueada) S.status = { aberta: false, motivo: bloqueioCidade.motivo };
  const retiradaPermitida = S.loja.aceitaRetirada !== false;
  const opcaoRetirada = $('opcao-retirada');
  const radioRetirada = document.querySelector('input[name=tipo-entrega][value=retirada]');
  if (opcaoRetirada) {
    opcaoRetirada.hidden = false;
    opcaoRetirada.classList.toggle('indisponible', !retiradaPermitida);
    opcaoRetirada.setAttribute('aria-disabled', String(!retiradaPermitida));
    const small = opcaoRetirada.querySelector('small');
    if (small) small.textContent = retiradaPermitida ? 'Retirar diretamente no local' : 'Não disponible en este momento';
  }
  if (radioRetirada) radioRetirada.disabled = false;
  if (!retiradaPermitida && S.tipoEntrega === 'retirada') S.tipoEntrega = 'delivery';
  document.querySelectorAll('input[name=tipo-entrega]').forEach(r => r.checked = r.value === S.tipoEntrega);
  atualizarModalidadeUI();
  S.codigoCupom = lerJSON(CHAVE_CUPOM, '') || '';
  atualizarBairroUI();
  recalcular();
}

// V75.38 — cupons com limite de usos: quantas vezes o cliente já usou e se o cupom esgotou.
async function atualizarUsoCupons() {
  try {
    if (!auth.currentUser || !S.lojaId) return;
    S.uso = await buscarUsoCupons(S.lojaId, auth.currentUser.uid, S.cupons);
    if (S.itens.length && S.uso) recalcular();
  } catch (e) { console.warn('Uso de cupons:', e); }
}

// V75.145 — saldo do cliente nesta loja (reembolso em saldo). Falha na leitura = sem saldo; nunca bloqueia o pedido.
async function atualizarSaldo() {
  if (!auth.currentUser || !S.lojaId) return;
  const lojaId = S.lojaId;
  const reg = await buscarSaldo(auth.currentUser.uid, lojaId);
  if (lojaId !== S.lojaId) return;
  S.saldo = valorSaldo(reg);
  if (S.itens.length && S.totais) render();
}
/** Prévia do saldo neste pedido: { usado, aPagar, cobreTudo }. */
const usoSaldo = () => previsaoUso(S.totais?.total || 0, S.saldo, S.usarSaldo);
/** Cancela o pedido pendente (pagamento desistido/total mudou) e devolve o saldo que ele usou. */
function cancelarPendente(p) {
  if (!p) return;
  cancelarPedidoCliente(p.key).then(() => (p.saldoUsado > 0 ? devolverSaldoDoPedido(p.key) : null)).catch((e) => console.warn('Cancelar pendente:', e));
}
/** Depois de criar o pedido: usa o saldo (se marcado). → { usado, aPagar, pago } | null (sem saldo). Erro = o pedido é cancelado. */
async function usarSaldoNoPedido(key) {
  const prev = usoSaldo();
  if (!(prev.usado > 0)) return null;
  try { return await aplicarSaldo(key); }
  catch (err) {
    cancelarPedidoCliente(key).catch(() => {});
    throw new Error(`Não foi possível usar o seu saldo agora (${err.message}). Tente de novo ou desmarque "Usar saldo".`);
  }
}
function renderSaldo() {
  const box = $('secao-saldo'); if (!box) return;
  const tem = S.saldo > 0 && !!auth.currentUser;
  box.hidden = !tem;
  if (!tem) return;
  const u = usoSaldo();
  box.innerHTML = `<label class="saldo-op"><input type="checkbox" id="usar-saldo"${S.usarSaldo ? ' checked' : ''}>
    <span class="saldo-op-txt"><strong><i class="fa-solid fa-wallet" aria-hidden="true"></i> Usar meu saldo nesta loja</strong>
    <small>Você tem ${formatarMoeda(S.saldo)}${S.usarSaldo && u.usado > 0 ? ` · usa ${formatarMoeda(u.usado)} neste pedido` : ''}</small></span></label>
    ${S.usarSaldo && u.cobreTudo ? '<p class="saldo-nota"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> O saldo paga o pedido todo. Não precisa escolher forma de pagamento.</p>' : ''}`;
}
$('secao-saldo')?.addEventListener('change', (e) => {
  if (e.target.id !== 'usar-saldo') return;
  S.usarSaldo = e.target.checked; invalidarCartao(); render();
});

// ---------- Presente fidelidade ----------
async function atualizarPremio() {
  try {
    if (!auth.currentUser || !S.lojaId || !S.premioCfg) return;
    const pedidos = await buscarPedidosDoCliente(auth.currentUser.uid);
    S.progresso = progressoFidelidade(pedidos, auth.currentUser.uid, S.lojaId, S.premioCfg);
    // V75.36: o presente só vale (e só mostra o prêmio) depois que o cliente abriu a caixa.
    S.presentes = presentesParaCliente(S.progresso, lerReveladas(auth.currentUser.uid)[S.lojaId]);
    // "Usar" na tela de Cupons deixa um recado: aplica sozinho se for desta loja.
    if (consumirUsoNoCarrinho() === S.lojaId && S.presentes.visiveis > 0) S.usarPremio = true;
    if (S.itens.length) recalcular();
  } catch (e) { console.warn('Presente fidelidade:', e); }
}
const premioAtivo = () => (S.usarPremio && S.premioCfg && S.presentes?.visiveis > 0 ? S.premioCfg : null);
const valorBairro = () => ($('cliente-bairro')?.value || '').trim();
const envioAtual = () => (S.tipoEntrega === 'retirada' ? 0 : resolverBairro(S.loja, valorBairro()).taxa);

function renderPremio() {
  const box = $('secao-premio'); if (!box) return;
  const cfg = S.premioCfg, pr = S.progresso;
  if (!cfg || !pr || !S.totais) { box.style.display = 'none'; return; }
  box.style.display = 'block';
  const casas = Array.from({ length: cfg.meta }, (_, i) => `<i class="fid-casa${i < pr.posicao ? ' on' : ''}"></i>`).join('<b class="fid-liga"></b>');
  const { novos, visiveis } = S.presentes || { novos: 0, visiveis: 0 };
  const barra = `<div class="fid-barra" aria-hidden="true">${casas}<b class="fid-liga"></b><i class="fa-solid fa-gift fid-presente${novos + visiveis > 0 ? ' on' : ''}"></i></div>`;
  if (visiveis > 0) {
    const d = descontoPremio(cfg, S.totais.subtotal, S.totais.envio);
    const ativo = !!premioAtivo();
    box.innerHTML = `<div class="fid-cab"><strong><i class="fa-solid fa-gift fid-cab-icone" aria-hidden="true"></i>Presente fidelidade disponível</strong></div>${barra}
      <p class="fid-txt">${escapeHtml(cfg.titulo)}${d > 0 ? ` · economiza ${formatarMoeda(d)} neste pedido` : ''}. Não soma com cupom.</p>
      ${ativo ? '<button type="button" class="fid-btn sec" data-premio-remover>Não usar agora</button>'
        : (d > 0 ? '<button type="button" class="fid-btn" data-premio-usar>Usar presente neste pedido</button>'
          : '<p class="fid-txt aviso">Este presente não gera desconto neste pedido (ex.: entrega grátis em retirada).</p>')}`;
  } else if (novos > 0) {
    box.innerHTML = `<div class="fid-cab"><strong><i class="fa-solid fa-gift fid-cab-icone" aria-hidden="true"></i>Seu presente chegou!</strong></div>${barra}
      <p class="fid-txt">Abra para ver o que você ganhou.</p>
      <button type="button" class="fid-btn" data-premio-abrir>Abrir presente</button>`;
  } else {
    box.innerHTML = `<div class="fid-cab"><strong><i class="fa-solid fa-gift fid-cab-icone" aria-hidden="true"></i>Presente fidelidade</strong></div>${barra}
      <p class="fid-txt">${escapeHtml(textoProgressoSurpresa(pr, cfg))}</p>`;
  }
}

function recalcular() {
  if (S.usarPremio && !(S.presentes?.visiveis > 0 && descontoPremio(S.premioCfg, S.itens.reduce((s, i) => s + i.precio * i.qtd, 0), envioAtual()) > 0)) S.usarPremio = false;
  if (premioAtivo()) {
    S.totais = calcularTotaisComPremio(S.itens, envioAtual(), S.cupons, '', S.premioCfg);
    render();
    return;
  }
  S.totais = calcularTotais(S.itens, envioAtual(), S.cupons, S.codigoCupom, new Date(), S.uso);
  if (S.codigoCupom && !S.totais.cupom) { // cupom inválido p/ esta loja/valor: descarta
    if (S.totais.erroCupom) toast(S.totais.erroCupom, 'error');
    remover(CHAVE_CUPOM); S.codigoCupom = '';
    S.totais = calcularTotais(S.itens, envioAtual(), S.cupons, '');
  }
  render();
}

// ---------- Render ----------
function renderVazio() {
  $('lista-itens-carrinho').innerHTML = '<p class="msg-vazio">Seu carrinho está vazio.<br><a href="index.html" class="btn-link">Ver restaurantes</a></p>';
  ['subtotal-valor', 'envio-valor', 'total-final', 'btn-total'].forEach((id) => { const el = $(id); if (el) el.textContent = formatarMoeda(0); });
  $('box-desconto').style.display = 'none';
  $('btn-confirmar-pedido').disabled = true;
  $('secao-cupom').style.display = 'none';
  if ($('secao-premio')) $('secao-premio').style.display = 'none';
}

function render() {
  queueMicrotask(atualizarCampoTroco);
  const t = S.totais;
  $('lista-itens-carrinho').innerHTML = S.itens.map((i, idx) => `
    <div class="item-carrinho">
      <img class="foto-item-carrinho" src="${escapeHtml(imgOtimizada(urlSegura(S.loja?.menu?.[i.id]?.imagen || S.loja?.menu?.[i.id]?.imagem, IMG_PRATO_PADRAO), 200))}" alt="" loading="lazy">
      <div class="info-item-carrinho"><h4>${escapeHtml(i.nombre)}</h4>${detalhesDaLinha(i).length ? `<small class="extras-item">${escapeHtml(detalhesDaLinha(i).join(' · '))}</small>` : ''}<span>${formatarMoeda(i.precio * i.qtd)}</span></div>
      <div class="controles-qtd">
        <button type="button" class="btn-qtd" data-qtd="${idx}" data-delta="-1" aria-label="Quitar uno"><i class="fa-solid fa-minus"></i></button>
        <span>${i.qtd}</span>
        <button type="button" class="btn-qtd" data-qtd="${idx}" data-delta="1" aria-label="Adicionar uno"><i class="fa-solid fa-plus"></i></button>
      </div>
    </div>`).join('');

  $('subtotal-valor').textContent = formatarMoeda(t.subtotal);
  $('envio-valor').textContent = S.tipoEntrega === 'retirada' ? 'Retirada na loja · Grátis' : (t.envio === 0 ? 'Grátis' : formatarMoeda(t.envio));
  $('box-desconto').style.display = t.desconto > 0 ? 'flex' : 'none';
  $('desconto-valor').textContent = `-${formatarMoeda(t.desconto)}`;
  $('total-final').textContent = formatarMoeda(t.total);
  const u = usoSaldo(); // V75.145: saldo da loja
  if ($('box-saldo')) { $('box-saldo').style.display = u.usado > 0 ? 'flex' : 'none'; $('saldo-valor').textContent = `-${formatarMoeda(u.usado)}`; }
  if ($('box-apagar')) { $('box-apagar').style.display = u.usado > 0 ? 'flex' : 'none'; $('apagar-valor').textContent = formatarMoeda(u.aPagar); }
  if ($('btn-total')) $('btn-total').textContent = formatarMoeda(u.aPagar); // V75.137: o total também no botão (V75.145: o que falta pagar)
  const pagSaldo = u.cobreTudo; // o saldo paga tudo: some a escolha da forma de pagamento
  document.querySelector('.titulo-pago')?.toggleAttribute('hidden', pagSaldo);
  $('formas-pagamento')?.toggleAttribute('hidden', pagSaldo);
  renderSaldo();

  const aviso = $('aviso-loja');
  aviso.hidden = S.status.aberta;
  aviso.innerHTML = S.status.aberta ? '' : `<i class="fa-solid fa-clock"></i> ${escapeHtml(S.status.motivo)}. Não se pueden confirmar pedidos ahora.`;
  $('btn-confirmar-pedido').disabled = !S.status.aberta;
  renderPremio();
  renderCupons();
}

function renderCupons() {
  const box = $('secao-cupom'), lista = $('lista-cupons-carrinho'), badge = $('qtd-cupons-badge');
  const aplicavel = S.cupons.filter((c) => c.ativo !== false && (!c.minimo || S.totais.subtotal >= c.minimo));
  box.style.display = (S.cupons.length || S.codigoCupom) ? 'block' : 'none';
  badge.textContent = aplicavel.length; badge.style.display = aplicavel.length && !S.totais.cupom ? 'inline-block' : 'none';

  if (S.totais.cupom) {
    lista.innerHTML = `<div class="cupom-linha aplicado"><div><strong><i class="fa-solid fa-circle-check"></i> Cupom "${escapeHtml(S.totais.cupom.codigo)}" aplicado</strong>
      <span>${escapeHtml(S.totais.cupom.titulo || 'Desconto aplicado')}</span></div><button type="button" data-remover-cupom>Quitar</button></div>`;
    return;
  }
  lista.innerHTML = aplicavel.length
    ? aplicavel.map((c) => `<div class="cupom-linha"><div><strong>${escapeHtml(c.codigo)}</strong><span>${escapeHtml(c.titulo || 'Desconto especial')}</span></div>
        <button type="button" data-usar-cupom="${escapeHtml(c.codigo)}">Usar</button></div>`).join('')
    : '<small>Não há cupons disponíveis para este valor.</small>';
}

function atualizarModalidadeUI() {
  const retirada = S.tipoEntrega === 'retirada';
  const campoEndereco = $('cliente-direccion')?.closest('.campo');
  const labelEndereco = document.querySelector('label[for="cliente-direccion"]');
  if (campoEndereco) campoEndereco.hidden = retirada;
  if ($('campo-bairro')) $('campo-bairro').hidden = retirada;
  if (retirada) limparLocalizacao();
  if ($('cliente-bairro')) $('cliente-bairro').required = !retirada;
  const campoReferencia = $('cliente-referencia')?.closest('.campo');
  if (campoReferencia) campoReferencia.hidden = retirada;
  if (labelEndereco) labelEndereco.textContent = retirada ? 'Endereço' : 'Endereço completo *';
  if ($('cliente-direccion')) $('cliente-direccion').required = !retirada;
  const pago = $('forma-pago');
  if (pago) {
    const valorAtual = pago.value;
    pago.innerHTML = retirada
      ? '<option value="Dinheiro">Dinheiro na loja</option><option value="Cartão / Débito (pagar ao entregador)">Cartão / Débito na loja</option><option value="Mercado Pago">Mercado Pago (cartão online)</option><option value="PIX">PIX</option>'
      : '<option value="Dinheiro">Dinheiro na entrega</option><option value="Cartão / Débito (pagar ao entregador)">Cartão / Débito (pagar ao entregador)</option><option value="Mercado Pago">Mercado Pago (cartão online)</option><option value="PIX">PIX</option>';
    const optCartao=[...pago.options].find(o=>o.value==='Mercado Pago'); if(optCartao)optCartao.hidden=S.loja?.aceitaCartaoOnline===false||!S.loja?.mp_public_key; if(optCartao?.hidden&&pago.value==='Mercado Pago')pago.value='Dinheiro'; if ([...pago.options].some(o => o.value === valorAtual && !o.hidden)) pago.value = valorAtual;
  }
  renderFormasPagamento();
  aplicarFormaPreferida();
  const titulo = document.querySelector('#etapa-dados-loja .titulo-pago');
  if (titulo) titulo.innerHTML = '<i class="fa-solid fa-wallet"></i> Forma de Pagamento';
  atualizarBairroUI();
  ultimaTaxaBairro = envioAtual();
  recalcular();
}

document.querySelectorAll('input[name="tipo-entrega"]').forEach(r => r.addEventListener('change', () => {
  if (r.value === 'retirada' && S.loja?.aceitaRetirada === false) {
    r.checked = false;
    document.querySelector('input[name="tipo-entrega"][value="delivery"]')?.click();
    toast('Esta loja não oferece retirada na loja no momento.', 'error', 4500);
    return;
  }
  S.tipoEntrega = r.value;
  invalidarCartao();
  atualizarModalidadeUI();
}));

$('opcao-retirada')?.addEventListener('click', (e) => {
  if (S.loja?.aceitaRetirada !== false) return;
  e.preventDefault();
  const radio = $('opcao-retirada').querySelector('input');
  if (radio) radio.checked = false;
  toast('Esta loja não oferece retirada na loja no momento.', 'error', 4500);
});

// ---------- Eventos (delegação) ----------
$('lista-itens-carrinho').addEventListener('click', (e) => {
  const b = e.target.closest('[data-qtd]'); if (!b) return;
  const c = obterCarrinho(); const it = c.itens[Number(b.dataset.qtd)]; if (!it) return;
  it.qtd = Math.min(99, it.qtd + Number(b.dataset.delta));
  if (it.qtd <= 0) c.itens.splice(Number(b.dataset.qtd), 1);
  if (!c.itens.length) c.lojaId = null;
  salvarCarrinho(c);
  invalidarCartao();
  carregar();
});

$('secao-cupom').addEventListener('click', (e) => {
  const usar = e.target.closest('[data-usar-cupom]');
  if (usar) aplicarCupom(usar.dataset.usarCupom);
  if (e.target.closest('[data-remover-cupom]')) { remover(CHAVE_CUPOM); S.codigoCupom = ''; invalidarCartao(); recalcular(); }
  if (e.target.closest('#btn-cupom-manual')) aplicarCupom($('input-cupom-manual').value);
});
$('secao-premio')?.addEventListener('click', (e) => {
  if (e.target.closest('[data-premio-usar]')) { S.usarPremio = true; invalidarCartao(); recalcular(); toast('Presente aplicado. Ele substitui o cupom neste pedido.', 'success'); }
  if (e.target.closest('[data-premio-remover]')) { S.usarPremio = false; invalidarCartao(); recalcular(); }
  if (e.target.closest('[data-premio-abrir]') && auth.currentUser) {
    const uid = auth.currentUser.uid, lojaId = S.lojaId, ganhos = S.progresso?.ganhos || 0;
    mostrarPresente({ lojaNome: S.loja?.nombre || '', titulo: S.premioCfg.titulo, quantidade: S.presentes.novos,
      aoPegar: () => { marcarReveladas(uid, lojaId, ganhos); location.href = 'cupons.html#presentes'; } });
  }
});

function aplicarCupom(codigo) {
  const cod = String(codigo || '').trim().toUpperCase();
  if (!cod) return;
  const t = calcularTotais(S.itens, envioAtual(), S.cupons, cod, new Date(), S.uso);
  if (!t.cupom) return toast(t.erroCupom || 'Cupom no válido.', 'error');
  gravarJSON(CHAVE_CUPOM, cod); S.codigoCupom = cod; S.usarPremio = false;
  $('input-cupom-manual').value = '';
  invalidarCartao(); recalcular();
  toast(`Cupom ${cod} aplicado.`, 'success');
}

// ---------- Formulário ----------
function lerFormulario() {
  const v = (id) => ($(id)?.value || '').trim();
  const cliente = { nombre: v('cliente-nombre'), email: v('cliente-email') || auth.currentUser?.email || '',
    telefono: v('cliente-telefono'), direccion: S.tipoEntrega === 'delivery' ? montarEndereco(v('cliente-direccion'), v('cliente-bairro')) : v('cliente-direccion'), referencia: v('cliente-referencia'), observacion: v('cliente-observacion') };
  const erros = [];
  if (cliente.nombre.length < 2) erros.push(['cliente-nombre', 'Digite seu nome.']);
  if (cliente.telefono.replace(/\D/g, '').length < 10) erros.push(['cliente-telefono', 'Telefone inválido (mínimo 10 dígitos com DDD).']);
  if (S.tipoEntrega === 'delivery' && v('cliente-direccion').length < 5) erros.push(['cliente-direccion', 'Informe um endereço completo (rua e número).']);
  if (S.tipoEntrega === 'delivery' && v('cliente-bairro').length < 2) erros.push(['cliente-bairro', 'Informe o bairro.']);
  else if (S.tipoEntrega === 'delivery') { const rb = resolverBairro(S.loja, v('cliente-bairro')); if (!rb.permitido) erros.push(['cliente-bairro', textoBairro(rb)]); }
  document.querySelectorAll('.campo input').forEach((i) => i.classList.remove('invalido'));
  if (erros.length) {
    const [id, msg] = erros[0];
    // V75.125: no modo cartão os campos de endereço ficam escondidos: marca o cartão (o aviso do bairro aparece logo abaixo dele)
    if ((id === 'cliente-direccion' || id === 'cliente-bairro') && $('form-checkout')?.classList.contains('end-modo-card')) {
      $('end-card').classList.add('invalido'); $('end-card').scrollIntoView({ block: 'center', behavior: 'smooth' }); $('end-card-acao')?.focus();
    } else { if (IDS_DADOS.includes(id)) mostrarCamposDados(); $(id).classList.add('invalido'); $(id).focus(); }
    toast(msg, 'error'); return null;
  }
  return cliente;
}

// ---------- Taxa por bairro (V75.22) ----------
let ultimaTaxaBairro = null;
function atualizarBairroUI() {
  const info = $('bairro-info'), btn = $('btn-avisar-bairro'), lista = $('lista-bairros');
  if (!info || !S.loja) return;
  const cfg = configBairros(S.loja);
  if (lista) lista.innerHTML = cfg.ativo ? listarBairros(S.loja).filter((b) => b.ativo).map((b) => `<option value="${escapeHtml(b.nome)}"></option>`).join('') : '';
  const entrega = S.tipoEntrega === 'delivery';
  const r = resolverBairro(S.loja, valorBairro());
  const texto = entrega && cfg.ativo ? textoBairro(r, formatarMoeda) : '';
  info.hidden = !texto; info.textContent = texto;
  info.className = 'bairro-info' + (r.permitido ? '' : ' erro');
  if (btn) btn.hidden = !(entrega && r.estado === 'bloqueado');
  return r;
}
function aoMudarBairro() {
  if (!S.loja || !S.itens.length) return;
  const r = atualizarBairroUI();
  preCalcularDistancia();
  const taxa = S.tipoEntrega === 'retirada' ? 0 : r.taxa;
  if (taxa !== ultimaTaxaBairro) { ultimaTaxaBairro = taxa; invalidarCartao(); recalcular(); }
}
// V75.42: enquanto o cliente digita um bairro novo, já calcula a distância até a loja (pronta quando ele enviar o pedido).
let timerDist = null;
function preCalcularDistancia() {
  clearTimeout(timerDist);
  timerDist = setTimeout(() => {
    if (!S.loja || S.tipoEntrega !== 'delivery') return;
    const r = resolverBairro(S.loja, valorBairro());
    if (r.estado === 'novo' || r.estado === 'bloqueado') distanciaParaEndereco({ lojaId: S.lojaId, loja: S.loja, direccion: $('cliente-direccion')?.value || '', bairro: valorBairro() });
  }, 1500);
}
$('cliente-direccion')?.addEventListener('input', preCalcularDistancia);
$('cliente-bairro')?.addEventListener('input', aoMudarBairro);
$('cliente-bairro')?.addEventListener('change', aoMudarBairro);
$('btn-avisar-bairro')?.addEventListener('click', async () => {
  if (!auth.currentUser) { modalAuth.style.display = 'flex'; return; }
  const dist = await comLimite(distanciaParaEndereco({ lojaId: S.lojaId, loja: S.loja, direccion: $('cliente-direccion')?.value || '', bairro: valorBairro() }));
  const ok = await sugerirBairro(S.lojaId, S.loja, valorBairro(), auth.currentUser.uid, dist);
  toast(ok ? 'Pronto! A loja foi avisada sobre o seu bairro.' : 'A loja já foi avisada sobre este bairro.', 'success', 5000);
});

// ---------- Endereços salvos (V75.21) ----------
const lerEnderecoForm = () => ({
  rua: ($('cliente-direccion')?.value || '').trim(),
  bairro: ($('cliente-bairro')?.value || '').trim(),
  referencia: ($('cliente-referencia')?.value || '').trim()
});

// V75.125 — com endereço salvo escolhido, o carrinho mostra só o cartão (os campos continuam no form, preenchidos e escondidos).
// "Trocar" só aparece com mais de um endereço; com um só, o botão é "Adicionar". Dentro do Trocar dá para adicionar um novo.
function renderEnderecos() {
  const modo = modoEndereco({ enderecos: S.enderecos, selecionado: S.enderecoSel, novo: S.endNovo });
  $('form-checkout')?.classList.toggle('end-modo-card', modo === 'card');
  const card = $('end-card');
  if (card) {
    card.hidden = modo !== 'card';
    card.classList.remove('invalido');
    const e = S.enderecos.find((x) => x.id === S.enderecoSel);
    if (modo === 'card' && e) {
      const r = ROTULOS[e.rotulo] || ROTULOS.outro;
      $('end-card-rua').textContent = e.rua;
      $('end-card-sub').textContent = e.rotulo === 'outro' ? `Bairro ${e.bairro}` : `${r.nome} · Bairro ${e.bairro}`;
      $('end-card-ref').textContent = e.referencia ? `Ref.: ${e.referencia}` : '';
      $('end-card-ref').hidden = !e.referencia;
    }
  }
  const voltar = $('end-voltar-salvos'); if (voltar) voltar.hidden = !(modo === 'form' && S.enderecos.length > 0);
  if (!$('sheet-enderecos')?.hidden) renderSheetEnderecos();
}

function renderSheetEnderecos() {
  const box = $('end-sheet-lista'); if (!box) return;
  box.innerHTML = S.enderecos.map((e) => {
    const r = ROTULOS[e.rotulo] || ROTULOS.outro, sel = S.enderecoSel === e.id && !S.endNovo;
    return `<div class="end-op${sel ? ' ativo' : ''}">
      <button type="button" class="end-op-escolher" role="radio" aria-checked="${sel}" data-end="${escapeHtml(e.id)}">
        <span class="end-op-ic" aria-hidden="true"><i class="fa-solid ${r.icone}"></i></span>
        <span class="end-op-txt"><strong>${escapeHtml(r.nome)}</strong><span>${escapeHtml(e.rua)}</span><small>${escapeHtml(e.bairro)}${e.referencia ? ` · ${escapeHtml(e.referencia)}` : ''}</small></span>
        <span class="end-op-marca" aria-hidden="true"><i class="fa-solid fa-check"></i></span>
      </button>
      <button type="button" class="end-op-remover" data-end-remover="${escapeHtml(e.id)}" aria-label="Remover endereço ${escapeHtml(r.nome)}: ${escapeHtml(e.rua)}"><i class="fa-regular fa-trash-can" aria-hidden="true"></i></button>
    </div>`;
  }).join('');
}

let focoAntesSheet = null;
function abrirSheetEnderecos() {
  const sh = $('sheet-enderecos'); if (!sh) return;
  focoAntesSheet = document.activeElement;
  renderSheetEnderecos();
  sh.hidden = false; document.body.classList.add('modal-aberto');
  (sh.querySelector('.end-op.ativo .end-op-escolher') || sh.querySelector('.end-op-escolher') || $('end-sheet-novo'))?.focus();
}
function fecharSheetEnderecos(devolverFoco = true) {
  const sh = $('sheet-enderecos'); if (!sh || sh.hidden) return;
  sh.hidden = true; document.body.classList.remove('modal-aberto');
  if (devolverFoco && focoAntesSheet?.isConnected) focoAntesSheet.focus();
  focoAntesSheet = null;
}
function novoEndereco() {
  fecharSheetEnderecos(false);
  S.enderecoSel = null; S.endNovo = true;
  limparLocalizacao();
  ['cliente-direccion', 'cliente-bairro', 'cliente-referencia'].forEach((id) => { if ($(id)) $(id).value = ''; });
  renderEnderecos(); aoMudarBairro();
  $('cliente-direccion')?.focus();
}

// V75.86 — localização opcional: o cliente marca onde está e, quando o pedido sair, vê a distância do entregador. Nunca bloqueia o pedido.
function limparLocalizacao() {
  S.entregaCoord = null;
  const info = $('localizacao-info'); if (info) { info.hidden = true; info.textContent = ''; info.className = 'localizacao-info'; }
  const b = $('btn-minha-localizacao'); if (b && !b.disabled) b.innerHTML = '<i class="fa-solid fa-location-crosshairs" aria-hidden="true"></i> Ative para acompanhar a entrega em tempo real';
}
function avisoLocalizacao(texto, tipo) { const info = $('localizacao-info'); if (!info) return; info.textContent = texto; info.className = `localizacao-info ${tipo}`; info.hidden = false; }
function marcarLocalizacao() {
  const btn = $('btn-minha-localizacao'); if (!btn || btn.disabled) return;
  if (!navigator.geolocation) { avisoLocalizacao('Este aparelho não permite marcar a localização. Digite o endereço normalmente.', 'erro'); return; }
  btn.disabled = true; btn.textContent = 'Buscando o GPS…';
  navigator.geolocation.getCurrentPosition((pos) => {
    btn.disabled = false;
    const r = avaliarLocalizacaoCliente(pos);
    if (!r.ok) { limparLocalizacao(); avisoLocalizacao(r.texto, 'erro'); return; }
    S.entregaCoord = r.coord;
    btn.innerHTML = '<i class="fa-solid fa-location-crosshairs" aria-hidden="true"></i> Atualizar minha localização';
    avisoLocalizacao('Acompanhamento ativado. Quando o entregador sair, a distância aparece na tela do pedido. Use só se você está no local da entrega; se digitar outro endereço, ele é desativado.', 'ok');
  }, (err) => {
    btn.disabled = false; limparLocalizacao();
    avisoLocalizacao(textoErroLocalizacao(err?.code), 'erro');
  }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}
$('btn-minha-localizacao')?.addEventListener('click', marcarLocalizacao);
$('cliente-direccion')?.addEventListener('input', () => { if (S.entregaCoord) limparLocalizacao(); });

function selecionarEndereco(id) {
  const e = S.enderecos.find((x) => x.id === id); if (!e) return;
  S.enderecoSel = e.id; S.endNovo = false;
  limparLocalizacao(); // a localização marcada era de outro endereço
  $('cliente-direccion').value = e.rua;
  $('cliente-bairro').value = e.bairro;
  $('cliente-referencia').value = e.referencia || '';
  renderEnderecos();
  aoMudarBairro();
}

// Se o cliente editar o texto, o cartão deixa de ficar marcado (a menos que o texto ainda coincida com um salvo).
function sincronizarSelecaoEndereco() {
  const f = lerEnderecoForm();
  const igual = S.enderecos.find((x) => mesmoEndereco(x, f));
  const novoId = igual ? igual.id : null;
  if (novoId !== S.enderecoSel) { S.enderecoSel = novoId; renderEnderecos(); }
}
// V75.125: digitar nos campos é sempre "endereço novo" (os campos só aparecem no modo formulário): não pula para o cartão no meio da digitação.
['cliente-direccion', 'cliente-bairro'].forEach((id) => $(id)?.addEventListener('input', () => { if (S.enderecos.length) S.endNovo = true; sincronizarSelecaoEndereco(); }));

// V75.126: "Alterar" sempre abre a lista: escolher outro, remover ou adicionar um novo.
$('end-card-acao')?.addEventListener('click', abrirSheetEnderecos);

// ---------- V75.126: seus dados em cartão ----------
const IDS_DADOS = ['cliente-nombre', 'cliente-telefono', 'cliente-email'];
function renderDados() {
  const card = $('dados-card'), campos = $('dados-campos'); if (!card || !campos) return;
  const v = (id) => ($(id)?.value || '').trim();
  const mostrar = !!auth.currentUser && !S.dadosEditando && dadosCompletos({ nome: v('cliente-nombre'), telefone: v('cliente-telefono') });
  // V75.135: dados completos não aparecem no carrinho (editar fica no Perfil → Meus dados). Falta algo: os campos aparecem aqui mesmo.
  card.hidden = true; campos.hidden = mostrar;
  const tit = $('dados-titulo'); if (tit) tit.hidden = mostrar;
  if (mostrar) {
    $('dados-card-nome').textContent = v('cliente-nombre');
    $('dados-card-tel').textContent = formatarTelefone(v('cliente-telefono'));
    $('dados-card-email').textContent = v('cliente-email');
    $('dados-card-email').hidden = !v('cliente-email');
  }
}
function mostrarCamposDados() { if (!S.dadosEditando) { S.dadosEditando = true; renderDados(); } }
function focarDados(id) { mostrarCamposDados(); $(id)?.focus(); }
$('dados-card-alterar')?.addEventListener('click', () => focarDados('cliente-nombre'));
$('end-voltar-salvos')?.addEventListener('click', () => {
  const e = enderecoPadrao(S.enderecos, S.ultimoEnd); if (e) { selecionarEndereco(e.id); $('end-card-acao')?.focus(); }
});
$('end-sheet-novo')?.addEventListener('click', novoEndereco);
$('end-sheet-fechar')?.addEventListener('click', () => fecharSheetEnderecos());
$('sheet-enderecos')?.addEventListener('click', async (e) => {
  if (e.target === e.currentTarget) return fecharSheetEnderecos();
  const rem = e.target.closest('[data-end-remover]');
  if (rem) {
    if (!auth.currentUser || !await confirmar({ titulo: 'Remover endereço?', texto: 'Este endereço salvo será apagado.', rotulo: 'Remover', perigo: true })) return;
    try {
      const id = rem.dataset.endRemover, eraOEscolhido = S.enderecoSel === id;
      await removerEndereco(auth.currentUser.uid, id);
      S.enderecos = await buscarEnderecos(auth.currentUser.uid);
      if (eraOEscolhido) {
        const prox = enderecoPadrao(S.enderecos, null);
        if (prox) selecionarEndereco(prox.id); else novoEndereco();
      }
      if (S.enderecos.length < 2) fecharSheetEnderecos();
      renderEnderecos();
      toast('Endereço removido.', 'success');
    } catch (err) { console.warn(err); toast('Não foi possível remover o endereço.', 'error'); }
    return;
  }
  const op = e.target.closest('[data-end]');
  if (op) { selecionarEndereco(op.dataset.end); fecharSheetEnderecos(); }
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('sheet-enderecos')?.hidden) fecharSheetEnderecos(); });

// Imagem quebrada no resumo → imagem padrão (sem onerror inline).
$('lista-itens-carrinho').addEventListener('error', (e) => {
  const img = e.target;
  if (img?.classList?.contains('foto-item-carrinho') && img.src !== IMG_PRATO_PADRAO) img.src = IMG_PRATO_PADRAO;
}, true);

// Pergunta "este é o endereço certo?" antes de criar o pedido. Resolve true = seguir; false = voltar e corrigir.
let confirmandoEndereco = false;
// V75.60 — Troco: o campo só aparece quando a forma é "Dinheiro".
const pagaEmDinheiro = () => $('forma-pago')?.value === 'Dinheiro';
function atualizarCampoTroco() {
  const campo = $('campo-troco'); if (!campo) return;
  const dinheiro = pagaEmDinheiro() && !(S.totais && usoSaldo().cobreTudo);
  campo.hidden = !dinheiro;
  const sim = document.querySelector('input[name="troco-precisa"][value="sim"]')?.checked;
  $('troco-valor-box').hidden = !(dinheiro && sim);
  const u = S.totais ? usoSaldo() : null;
  const aj = $('troco-ajuda'); if (aj && S.totais) aj.textContent = `${u.usado > 0 ? 'A pagar na entrega' : 'Total do pedido'}: ${formatarMoeda(u.aPagar)}. Informe a nota que você vai entregar (ex.: 100).`;
}
function lerTroco() {
  if (!pagaEmDinheiro() || usoSaldo().cobreTudo) return { ok: true, troco: null };
  const marcado = document.querySelector('input[name="troco-precisa"]:checked')?.value;
  const r = validarTroco({ precisa: marcado === 'sim' ? true : marcado === 'nao' ? false : null, texto: $('troco-valor')?.value }, usoSaldo().aPagar);
  if (!r.ok) { $((marcado === 'sim') ? 'troco-valor' : 'campo-troco')?.classList.add('invalido'); (marcado === 'sim' ? $('troco-valor') : document.querySelector('input[name="troco-precisa"]'))?.focus(); toast(r.erro, 'error'); }
  return r;
}
document.querySelectorAll('input[name="troco-precisa"]').forEach((i) => i.addEventListener('change', () => { $('troco-valor')?.classList.remove('invalido'); atualizarCampoTroco(); if (i.value === 'sim') $('troco-valor')?.focus(); }));
$('troco-valor')?.addEventListener('input', () => $('troco-valor').classList.remove('invalido'));
$('forma-pago')?.addEventListener('change', atualizarCampoTroco);

// V75.56 — Já existe pedido em andamento nesta loja? Pergunta uma vez por visita ao carrinho; erro na consulta nunca bloqueia.
async function confirmarOutroPedido() {
  if (S.outroPedidoOk) return true;
  try {
    const todos = await buscarPedidosDoCliente(auth.currentUser.uid);
    const abertos = pedidosEmAndamentoNaLoja(todos, S.lojaId, { ignorar: S.pedidoPendente ? [S.pedidoPendente.key] : [] });
    if (!abertos.length) return true;
    const ok = await confirmar({ ...textoPedidoAberto(abertos), cancelar: 'Voltar' });
    if (ok) S.outroPedidoOk = true;
    return !!ok;
  } catch (err) { console.warn('Pedido em andamento: consulta falhou, seguindo normalmente.', err); return true; }
}

function confirmarEndereco() {
  if (S.tipoEntrega !== 'delivery') return Promise.resolve(true);
  if (confirmandoEndereco) return Promise.resolve(false);
  const f = lerEnderecoForm();
  const salvo = S.enderecos.find((x) => mesmoEndereco(x, f));
  const editando = S.enderecos.find((x) => x.id === S.enderecoSel);
  const livres = ['casa', 'trabalho'].filter((r) => !S.enderecos.some((x) => x.rotulo === r));
  let rotulo = editando?.rotulo || livres[0] || 'outro';
  const modal = $('modal-endereco');
  if (!modal) return Promise.resolve(true);
  confirmandoEndereco = true;

  $('end-conf-texto').textContent = montarEndereco(f.rua, f.bairro);
  const taxaEl = $('end-conf-taxa');
  if (taxaEl) { const tx = envioAtual(); taxaEl.hidden = false; taxaEl.textContent = `Taxa de entrega: ${tx > 0 ? formatarMoeda(tx) : 'grátis'}`; }
  const refEl = $('end-conf-ref'); refEl.hidden = !f.referencia; refEl.textContent = f.referencia ? `Referência: ${f.referencia}` : '';
  const areaSalvar = $('end-conf-salvar'); areaSalvar.hidden = !!salvo || !auth.currentUser;
  const check = $('end-conf-check'); check.checked = true;
  const boxRot = $('end-conf-rotulos');
  const desenharRotulos = () => {
    boxRot.innerHTML = Object.entries(ROTULOS).map(([k, r]) => `<button type="button" class="end-rot${k === rotulo ? ' ativo' : ''}" data-rot="${k}" aria-pressed="${k === rotulo}"><i class="fa-solid ${r.icone}"></i> ${r.nome}</button>`).join('');
  };
  desenharRotulos();
  modal.style.display = 'flex';
  document.body.classList.add('modal-aberto');

  return new Promise((resolve) => {
    const ok = $('end-conf-ok'), corrigir = $('end-conf-corrigir');
    const fechar = (resposta) => {
      modal.style.display = 'none'; document.body.classList.remove('modal-aberto');
      ok.removeEventListener('click', aoConfirmar); corrigir.removeEventListener('click', aoCorrigir);
      modal.removeEventListener('click', aoFundo); boxRot.removeEventListener('click', aoRotulo); document.removeEventListener('keydown', aoTecla);
      confirmandoEndereco = false;
      if (!resposta) $('cliente-direccion')?.focus();
      resolve(resposta);
    };
    const aoRotulo = (e) => { const b = e.target.closest('[data-rot]'); if (b) { rotulo = b.dataset.rot; desenharRotulos(); } };
    const aoConfirmar = async () => {
      ok.disabled = true;
      try {
        const uid = auth.currentUser?.uid;
        if (uid && salvo) lembrarUltimoEndereco(uid, salvo.id).catch(() => {});
        else if (uid && check.checked) {
          // Falha ao salvar nunca bloqueia o pedido.
          try {
            const r = await salvarEndereco(uid, { rotulo, ...f });
            S.enderecos = await buscarEnderecos(uid); S.enderecoSel = r.id; S.endNovo = false; renderEnderecos();
            lembrarUltimoEndereco(uid, r.id).catch(() => {});
          } catch (err) { console.warn('Endereço não salvo:', err); }
        }
      } finally { ok.disabled = false; }
      fechar(true);
    };
    const aoCorrigir = () => fechar(false);
    const aoFundo = (e) => { if (e.target === modal) fechar(false); };
    const aoTecla = (e) => { if (e.key === 'Escape') fechar(false); };
    ok.addEventListener('click', aoConfirmar); corrigir.addEventListener('click', aoCorrigir);
    modal.addEventListener('click', aoFundo); boxRot.addEventListener('click', aoRotulo); document.addEventListener('keydown', aoTecla);
    ok.focus();
  });
}

// ---------- Pedido convencional (dinheiro / cartão na entrega) ----------
$('form-checkout').addEventListener('submit', async (e) => {
  e.preventDefault();
  const pagaComSaldo = !!S.totais && usoSaldo().cobreTudo; // V75.145: o saldo da loja paga o pedido todo
  const forma = pagaComSaldo ? 'Saldo na loja' : $('forma-pago').value;
  // pagamentos online usam seus próprios fluxos. V75.135: com Pix/cartão online já marcado (ex.: forma preferida), "Confirmar pedido" inicia o pagamento
  if (forma === 'Mercado Pago' || forma === 'PIX') { $('forma-pago').dispatchEvent(new Event('change')); return; }

  if (!auth.currentUser) { modalAuth.style.display = 'flex'; return; }
  if (!S.status.aberta) return toast(S.status.motivo, 'error');
  const cliente = lerFormulario(); if (!cliente) return;
  const rTroco = lerTroco(); if (!rTroco.ok) return;   // troco primeiro: o cliente corrige antes de confirmar o endereço
  if (!(await confirmarEndereco())) return;
  if (!(await confirmarOutroPedido())) return;

  comTrava($('btn-confirmar-pedido'), async () => {
    try {
      // Revalida contra o cardápio no último instante (preço mudou / item pausado enquanto o cliente preenchia).
      S.loja = await buscarLoja(S.lojaId); S.cupons = cuponsDaLoja(S.loja);
      const { itens, avisos } = reconciliarItensComMenu(S.itens, S.loja.menu);
      if (avisos.length) { avisos.forEach((a) => toast(a, 'error', 5000)); salvarCarrinho({ lojaId: S.lojaId, itens }); await carregar(); return; }
      if (!lojaAberta(S.loja).aberta || (await bloqueioDaLojaAgora(S.loja)).bloqueada) { await carregar(); return; }

      salvarPerfilCliente(auth.currentUser.uid, cliente).catch((err) => console.warn('Perfil no guardado:', err));
      const r = await registrarPedido({ user: auth.currentUser, lojaId: S.lojaId, loja: S.loja, itens, cliente, formaPagamento: forma, codigoCupom: S.codigoCupom, tipoEntrega: S.tipoEntrega, usarPremio: !!premioAtivo(), bairro: valorBairro(), troco: rTroco.troco, entregaCoord: S.entregaCoord, abaterTroco: usoSaldo().usado });
      // V75.145: usa o saldo da loja (se falhar, o pedido é cancelado e o cliente tenta de novo)
      let rs = null;
      try { rs = await usarSaldoNoPedido(r.key); } catch (err) { toast(err.message, 'error', 8000); atualizarSaldo(); return; }
      if (pagaComSaldo && !rs?.pago) { cancelarPendente({ key: r.key, saldoUsado: rs?.usado || 0 }); atualizarSaldo(); toast('Seu saldo mudou e não cobre mais o pedido todo. Confira o total e escolha a forma de pagamento.', 'error', 8000); return; }

      // Link do WhatsApp fica na página de status (window.open após await é bloqueado como pop-up no iOS/Safari).
      const link = urlWhatsApp(telefoneLoja(S.loja), montarMensagemWhatsApp(r.pedido, `${location.origin}${location.pathname.replace(/[^/]*$/, '')}status.html?num=${r.codigo}`));
      try { sessionStorage.setItem(`wa_${r.codigo}`, link); } catch { /* noop */ }
      remover(CHAVE_CARRINHO); remover(CHAVE_CUPOM);
      location.href = `status.html?num=${r.codigo}`;
    } catch (err) {
      console.error('Erro ao registrar pedido:', err);
      toast(/troco|valor precisa/i.test(err?.message || '') ? err.message : 'Não foi possível registrar o pedido. Tente novamente.', 'error');
    }
  });
});

// ---------- Pagamento com PIX ----------
function limparPixUI() {
  if (pixTimer) { clearInterval(pixTimer); pixTimer = null; }
  pixPagamentoId = null;
  const qr = $('pix-qr'); if (qr) { qr.hidden = true; qr.removeAttribute('src'); }
  const cp = $('pix-copia-cola'); if (cp) cp.value = '';
  const link = $('pix-link'); if (link) { link.hidden = true; link.removeAttribute('href'); }
}

async function criarPix(pedido, cliente) {
  const idToken = await auth.currentUser?.getIdToken(true);
  if (!idToken) throw new Error('Sessão expirada. Entre novamente.');
  const resp = await fetch(`${MP_BACKEND}/criar-pix-loja`, {
    method:'POST',
    headers:{'Content-Type':'application/json','Authorization':`Bearer ${idToken}`},
    body:JSON.stringify({
      pedidoId: pedido.codigo, pedidoKey: pedido.key, codigo: pedido.codigo,
      lojaId: S.lojaId, email: cliente.email, payer: { email: cliente.email }
    })
  });
  const dados = await resp.json().catch(()=>({}));
  if (!resp.ok || dados.error) throw new Error(dados.error || dados.statusDetail || 'Não foi possível gerar o PIX.');
  return dados;
}

function extrairPix(dados) {
  const qrBase64 = dados.qr_code_base64 || dados.qr_code_based64 || dados.qrCodeBase64 || dados.point_of_interaction?.transaction_data?.qr_code_base64 || dados.payment?.point_of_interaction?.transaction_data?.qr_code_base64 || '';
  const copia = dados.qr_code || dados.qrCode || dados.pix_copia_cola || dados.copia_e_cola || dados.point_of_interaction?.transaction_data?.qr_code || dados.payment?.point_of_interaction?.transaction_data?.qr_code || '';
  const ticket = dados.ticket_url || dados.ticketUrl || dados.pix_url || dados.point_of_interaction?.transaction_data?.ticket_url || dados.payment?.point_of_interaction?.transaction_data?.ticket_url || '';
  const id = dados.id || dados.paymentId || dados.payment_id || dados.payment?.id || '';
  return { qrBase64, copia, ticket, id: String(id || '') };
}

function mostrarPix(dados) {
  const x = extrairPix(dados);
  pixPagamentoId = x.id;
  const qr = $('pix-qr');
  if (qr && x.qrBase64) { qr.src = `data:image/png;base64,${x.qrBase64}`; qr.hidden = false; }
  const cp = $('pix-copia-cola'); if (cp) cp.value = x.copia || '';
  const link = $('pix-link'); if (link && x.ticket) { link.href=x.ticket; link.hidden=false; }
  const txt = $('pix-status-text'); if (txt) txt.textContent = x.qrBase64 || x.copia ? 'Escaneie o QR Code ou copie o código para pagar. Estamos aguardando a confirmação.' : 'PIX gerado. Abra o link de pagamento para continuar.';
  if (x.id) iniciarConsultaPix(x.id);
  return x;
}

async function consultarPix(id) {
  const idToken = await auth.currentUser?.getIdToken(true);
  if (!idToken) return;
  const r = await fetch(`${MP_BACKEND}/status-loja/${encodeURIComponent(S.lojaId)}/${encodeURIComponent(id)}`, {headers:{Authorization:`Bearer ${idToken}`} });
  const d = await r.json().catch(()=>({}));
  if (!r.ok) return;
  const status = String(d.status || d.payment?.status || '').toLowerCase();
  if (status === 'approved') {
    if (pixTimer) clearInterval(pixTimer); pixTimer=null;
    const txt=$('pix-status-text'); if(txt) txt.textContent='PIX pago! 🎉';
    remover(CHAVE_CARRINHO); remover(CHAVE_CUPOM);
    const codigo=S.pedidoPendente?.codigo;
    if(codigo) setTimeout(()=>location.replace(`status.html?num=${codigo}`),700);
  } else if (status === 'rejected' || status === 'cancelled' || status === 'expired') {
    if (pixTimer) clearInterval(pixTimer); pixTimer=null;
    // V75.113: antes o erro só ia para o console e a tela ficava "aguardando" para sempre
    const txt=$('pix-status-text'); if(txt) txt.textContent = status === 'expired' ? 'Este PIX expirou e não foi pago. Toque em Cancelar e gere um novo, ou escolha outra forma de pagamento.' : 'O PIX não foi aprovado. Toque em Cancelar e tente de novo, ou escolha outra forma de pagamento.';
    toast(status === 'expired' ? 'O PIX expirou.' : 'O PIX não foi aprovado.', 'error', 8000);
    throw new Error(d.statusDetail || 'O PIX não foi aprovado.');
  }
}

function iniciarConsultaPix(id) {
  if (pixTimer) clearInterval(pixTimer);
  pixTimer=setInterval(()=>consultarPix(id).catch(e=>console.warn('PIX status:',e)),5000);
}

async function pagarComPix(cliente) {
  let p=S.pedidoPendente;
  if(!p || p.total!==S.totais.total || p.premio!==!!premioAtivo() || p.usarSaldo!==(usoSaldo().usado>0)){
    if(p) cancelarPendente(p);
    S.pedidoPendente=null;
    const r=await registrarPedido({user:auth.currentUser,lojaId:S.lojaId,loja:S.loja,itens:S.itens,cliente,formaPagamento:'PIX',codigoCupom:S.codigoCupom,tipoEntrega:S.tipoEntrega,usarPremio:!!premioAtivo(),pagoStatus:PAGO.PENDENTE,bairro:valorBairro(),entregaCoord:S.entregaCoord});
    const rs=await usarSaldoNoPedido(r.key); // V75.145
    p=S.pedidoPendente={key:r.key,codigo:r.codigo,total:r.totais.total,premio:!!r.pedido.premioFidelidade,usarSaldo:!!rs,saldoUsado:rs?.usado||0,aPagar:rs?rs.aPagar:r.totais.total};
    salvarPerfilCliente(auth.currentUser.uid,cliente).catch(()=>{});
    if(rs?.pago){ remover(CHAVE_CARRINHO); remover(CHAVE_CUPOM); location.replace(`status.html?num=${r.codigo}`); return; }
  }
  const dados=await criarPix(p,cliente);
  $('btn-confirmar-pedido').style.display='none';
  $('etapa-cartao-loja').style.display='none';
  $('etapa-pix-loja').style.display='block';
  mostrarPix(dados);
}

$('btn-pix-copiar')?.addEventListener('click', async()=>{
  const v=$('pix-copia-cola')?.value||'';
  if(!v) return toast('O código PIX ainda não está disponível.','error');
  try { await navigator.clipboard.writeText(v); toast('Código PIX copiado.','success'); }
  catch { $('pix-copia-cola').focus(); $('pix-copia-cola').select(); toast('Selecione e copie o código PIX.','error'); }
});

$('btn-cancelar-pix')?.addEventListener('click',()=>{
  limparPixUI(); $('etapa-pix-loja').style.display='none'; $('btn-confirmar-pedido').style.display='block'; $('forma-pago').value='Dinheiro';
  if(S.pedidoPendente){ cancelarPendente(S.pedidoPendente); S.pedidoPendente=null; }
});

// ---------- Pagamento com cartão ----------
let cartaoAberto = false;      // V72: o modal só é "invalidado" se estiver realmente aberto
let cartaoAbertoEm = 0;        // V72: protege contra o clique-fantasma do seletor nativo (toque no fundo fecha o modal)
function invalidarCartao() {
  if ($('etapa-pix-loja')?.style.display !== 'none') { limparPixUI(); $('etapa-pix-loja').style.display='none'; }
  if (!cartaoAberto) return;
  cancelarCartao(); toast('O total mudou. Escolha a forma de pagamento novamente.');
}

function abrirModalCartao(){
  cartaoAberto=true; cartaoAbertoEm=Date.now();
  console.info('[Cartão] abrindo modal');
  const m=$('modal-cartao-loja');
  if(m)m.style.display='flex';
  document.body.classList.add('modal-aberto');
}
function fecharModalCartao(){
  const m=$('modal-cartao-loja');
  if(m)m.style.display='none';
  document.body.classList.remove('modal-aberto');
}
function cancelarCartao() {
  cartaoAberto=false;
  desmontarCartao();
  fecharModalCartao();
  $('etapa-cartao-loja').style.display = 'none';
  $('btn-confirmar-pedido').style.display = 'block';
  $('forma-pago').value = 'Dinheiro';
}
$('btn-cancelar-cartao').addEventListener('click', cancelarCartao);
$('btn-fechar-modal-cartao')?.addEventListener('click', cancelarCartao);
$('modal-cartao-loja')?.addEventListener('click',e=>{if(e.target.id==='modal-cartao-loja'&&Date.now()-cartaoAbertoEm>700)cancelarCartao();});

$('forma-pago').addEventListener('change', async (e) => {
  if (e.target.value === 'PIX') {
    desmontarCartao(); fecharModalCartao(); limparPixUI(); $('etapa-cartao-loja').style.display='none';
    if (!auth.currentUser) { e.target.value='Dinheiro'; modalAuth.style.display='flex'; return; }
    if (!S.status.aberta) { e.target.value='Dinheiro'; return toast(S.status.motivo,'error'); }
    const cliente=lerFormulario();
    if (!cliente) { e.target.value='Dinheiro'; return; }
    if (!cliente.email.includes('@')) { e.target.value='Dinheiro'; focarDados('cliente-email'); return toast('Para pagar online, você precisa de um e-mail válido.','error'); }
    if (!(await confirmarEndereco())) { e.target.value='Dinheiro'; return; }
    if (!(await confirmarOutroPedido())) { e.target.value='Dinheiro'; return; }
    $('btn-confirmar-pedido').style.display='none'; $('etapa-pix-loja').style.display='block'; $('pix-status-text').textContent='Gerando seu PIX com segurança…';
    try { await pagarComPix(cliente); } catch(err) { console.error('PIX:',err); limparPixUI(); $('etapa-pix-loja').style.display='none'; $('btn-confirmar-pedido').style.display='block'; e.target.value='Dinheiro'; toast(err.message,'error'); }
    return;
  }
  if ((e.target.value === 'PIX' || e.target.value === 'Mercado Pago') && S.totais && usoSaldo().cobreTudo) { e.target.value = 'Dinheiro'; return toast('O seu saldo já paga o pedido todo. Toque em Confirmar pedido.'); }
  if (e.target.value === 'Mercado Pago' && (S.loja?.aceitaCartaoOnline === false || !S.loja?.mp_public_key)) { e.target.value='Dinheiro'; return toast('Esta loja não aceita cartão online no momento.','error'); }
  if (e.target.value !== 'Mercado Pago') { limparPixUI(); desmontarCartao(); fecharModalCartao(); $('etapa-cartao-loja').style.display = 'none'; $('etapa-pix-loja').style.display='none'; $('btn-confirmar-pedido').style.display = 'block'; return; }
  if (!auth.currentUser) { e.target.value = 'Dinheiro'; modalAuth.style.display = 'flex'; return; }
  if (!S.status.aberta) { e.target.value = 'Dinheiro'; return toast(S.status.motivo, 'error'); }
  const cliente = lerFormulario();
  if (!cliente) { e.target.value = 'Dinheiro'; return; }
  if (!cliente.email.includes('@')) { e.target.value = 'Dinheiro'; focarDados('cliente-email'); return toast('Para pagar online, você precisa de um e-mail válido.', 'error'); }
  if (!(await confirmarEndereco())) { e.target.value = 'Dinheiro'; return; }
  if (!(await confirmarOutroPedido())) { e.target.value = 'Dinheiro'; return; }

  $('btn-confirmar-pedido').style.display = 'none';
  $('etapa-cartao-loja').style.display = 'block';
  try {
    window.__YAPOOD_PAYER_EMAIL = cliente.email;
    abrirModalCartao();
    await montarCartao({
      containerId: 'form-checkout-cartao', valor: usoSaldo().aPagar, publicKey: S.loja.mp_public_key,
      aoSubmeter: (formData) => pagarComCartao(formData, cliente)
    });
  } catch (err) {
    console.error('[MP] Falha ao abrir cartão:', err);
    const box = $('form-checkout-cartao');
    if (box) box.innerHTML = `<div class="msg-pagamento-erro">${escapeHtml(err?.message || 'Não foi possível carregar o formulário de cartão.')}</div>`;
    toast(err?.message || 'Não foi possível abrir o pagamento com cartão.', 'error', 6000);
  }
});

async function pagarComCartao(formData, cliente) {
  // 1) Cria (ou reaproveita, em nova tentativa) o pedido ANTES de cobrar — assim todo pagamento aprovado tem um pedido associado.
  let p = S.pedidoPendente;
  if (!p || p.total !== S.totais.total || p.premio !== !!premioAtivo() || p.usarSaldo !== (usoSaldo().usado > 0)) {
    if (p) cancelarPendente(p);
    S.pedidoPendente = null;
    const r = await registrarPedido({ user: auth.currentUser, lojaId: S.lojaId, loja: S.loja, itens: S.itens, cliente,
      formaPagamento: 'Mercado Pago', codigoCupom: S.codigoCupom, tipoEntrega: S.tipoEntrega, usarPremio: !!premioAtivo(), pagoStatus: PAGO.PENDENTE, bairro: valorBairro(), entregaCoord: S.entregaCoord });
    const rs = await usarSaldoNoPedido(r.key); // V75.145
    p = S.pedidoPendente = { key: r.key, codigo: r.codigo, total: r.totais.total, premio: !!r.pedido.premioFidelidade, usarSaldo: !!rs, saldoUsado: rs?.usado || 0, aPagar: rs ? rs.aPagar : r.totais.total };
    salvarPerfilCliente(auth.currentUser.uid, cliente).catch(() => {});
    if (rs?.pago) { await desmontarCartao(); remover(CHAVE_CARRINHO); remover(CHAVE_CUPOM); location.replace(`status.html?num=${r.codigo}`); return; }
  }
  // 2) Cobra
  const dados = await cobrarNoBackend({ formData, valor: p.aPagar ?? p.total, pedidoKey: p.key, codigo: p.codigo, lojaId: S.lojaId, email: cliente.email });
  if (dados.status === 'rejected') {
    cancelarPendente(p); S.pedidoPendente = null;
    throw new Error(dados.statusDetail || 'Pagamento recusado. Verifique os dados do cartão.');
  }
  // approved | in_process | pending → o status de pagamento é atualizado pelo backend; a página de status acompanha em tempo real.
  await desmontarCartao();
  remover(CHAVE_CARRINHO); remover(CHAVE_CUPOM);
  toast(dados.status === 'approved' ? 'Pagamento aprovado! 🎉' : 'Pagamento em análise.', 'success');
  location.replace(`status.html?num=${p.codigo}`);
}

carregar().catch((e) => { console.error(e); $('lista-itens-carrinho').innerHTML = '<p class="msg-vazio">Não foi possível carregar o carrinho. Verifique sua conexão.</p>'; });

// ---------- V75.126: formas de pagamento em lista ----------
// O <select id="forma-pago"> continua sendo a fonte (todo o fluxo de Pix/cartão lê e muda ele). A lista só desenha e repassa o toque.
function renderFormasPagamento() {
  const box = $('formas-pagamento'), sel = $('forma-pago'); if (!box || !sel) return;
  const disp = [...sel.options].filter((o) => !o.hidden && !o.disabled).map((o) => o.value);
  const atual = sel.value;
  box.innerHTML = formasDePagamento(disp, S.tipoEntrega === 'retirada').map((f) => `<label class="forma-op${f.valor === atual ? ' ativo' : ''}">
      <input type="radio" name="forma-pag-ui" value="${escapeHtml(f.valor)}"${f.valor === atual ? ' checked' : ''}>
      <span class="forma-op-ic" aria-hidden="true"><i class="${escapeHtml(f.icone)}"></i></span>
      <span class="forma-op-txt"><strong>${escapeHtml(f.nome)}</strong>${f.sub ? `<small>${escapeHtml(f.sub)}</small>` : ''}</span>
      <span class="forma-op-marca" aria-hidden="true"></span></label>`).join('');
}
(() => {
  const sel = $('forma-pago'); if (!sel) return;
  // Os fluxos de pagamento voltam o select para "Dinheiro" por código (sem evento): a lista e a pergunta do troco acompanham.
  const d = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
  if (d?.set) Object.defineProperty(sel, 'value', { configurable: true, get() { return d.get.call(this); }, set(v) { d.set.call(this, v); renderFormasPagamento(); atualizarCampoTroco(); } });
  sel.addEventListener('change', renderFormasPagamento);
  $('formas-pagamento')?.addEventListener('change', (e) => {
    const r = e.target.closest('input[name="forma-pag-ui"]'); if (!r || r.value === sel.value) return;
    sel.value = r.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
  });
  renderFormasPagamento();
})();

// V75.135 — forma de pagamento preferida (Perfil): vem marcada uma vez, se a loja aceitar. Marcar não inicia pagamento nenhum.
function aplicarFormaPreferida() {
  const pref = S.formaPreferida, sel = $('forma-pago');
  if (!pref || S.prefAplicada || !sel || !S.loja) return;
  const op = [...sel.options].find((o) => o.value === pref && !o.hidden && !o.disabled);
  if (!op) return;
  S.prefAplicada = true;
  sel.value = pref;
}
