// js/produto-opcoes.js — V75.127: opções (escolha única), adicionais (− 0 +) e sugestões de um produto. Funções puras: sem DOM, sem banco.
// A API (precos.js, 2.24) usa uma cópia desta mesma conta para conferir o preço antes de cobrar online.
//
// No cardápio (restaurantes/{loja}/menu/{id}):
//   info: 'Serve 1 pessoa · 350 g'                                   (informações adicionais, opcional)
//   sugerir: true                                                    (o lojista marca bebidas e sobremesas para sugerir)
//   opcoes:     { g_x: { nome: 'Ponto da carne', obrigatorio: true, ordem: 0, itens: { o_x: { nome: 'Ao ponto', preco: 0, ordem: 0 } } } }
//   adicionais: { a_x: { nome: 'Queijo', preco: 3, max: 5, ordem: 0 } }
// No carrinho e no pedido, cada linha guarda o que foi escolhido (nome e preço do momento) e o preço unitário já somado:
//   { id, nombre, precio, qtd, opcoes: [{ grupo, grupoNome, id, nome, preco }], adicionais: [{ id, nome, preco, qtd }], obs }

export const LIMITES = Object.freeze({ grupos: 8, opcoesPorGrupo: 20, adicionais: 30, maxPorAdicional: 20, maxPadrao: 5, obs: 140, info: 160, nome: 50, sugestoes: 4 });

const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;
const texto = (v, max) => String(v ?? '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, max);
const precoValido = (v) => { const n = Number(v); return Number.isFinite(n) && n >= 0 && n <= 10000 ? arred(n) : 0; };
const ordenados = (obj) => Object.entries(obj && typeof obj === 'object' ? obj : {})
  .filter(([, v]) => v && typeof v === 'object')
  .sort((a, b) => (Number(a[1].ordem) || 0) - (Number(b[1].ordem) || 0) || a[0].localeCompare(b[0]));

/** Opções e adicionais válidos e disponíveis do produto, na ordem do lojista. */
export function configDoProduto(item) {
  const grupos = ordenados(item?.opcoes).slice(0, LIMITES.grupos).map(([id, g]) => ({
    id,
    nome: texto(g.nome, LIMITES.nome) || 'Escolha uma opção',
    obrigatorio: g.obrigatorio !== false,
    itens: ordenados(g.itens).filter(([, o]) => o.disponivel !== false)
      .map(([oid, o]) => ({ id: oid, nome: texto(o.nome, LIMITES.nome), preco: precoValido(o.preco) }))
      .filter((o) => o.nome).slice(0, LIMITES.opcoesPorGrupo)
  })).filter((g) => g.itens.length);
  const adicionais = ordenados(item?.adicionais).filter(([, a]) => a.disponivel !== false)
    .map(([id, a]) => ({ id, nome: texto(a.nome, LIMITES.nome), preco: precoValido(a.preco), max: Math.min(LIMITES.maxPorAdicional, Math.max(1, parseInt(a.max, 10) || LIMITES.maxPadrao)) }))
    .filter((a) => a.nome).slice(0, LIMITES.adicionais);
  return { grupos, adicionais, info: texto(item?.info, LIMITES.info) };
}

/** O produto pede escolha antes de ir para o carrinho? (grupo obrigatório) */
export const temEscolhaObrigatoria = (item) => configDoProduto(item).grupos.some((g) => g.obrigatorio);

/**
 * Confere a escolha do cliente contra o cardápio ATUAL e soma o preço unitário.
 * escolha = { opcoes: { grupoId: opcaoId }, adicionais: { adicionalId: qtd } }
 * → { ok: true, precio, opcoes, adicionais } ou { ok: false, erro: 'obrigatorio'|'opcao'|'adicional'|'maximo', grupo?, grupoNome?, adicional? }
 */
export function montarEscolha(item, escolha = {}) {
  const cfg = configDoProduto(item);
  const escOp = escolha?.opcoes && typeof escolha.opcoes === 'object' ? escolha.opcoes : {};
  const escAd = escolha?.adicionais && typeof escolha.adicionais === 'object' ? escolha.adicionais : {};
  for (const gid of Object.keys(escOp)) if (escOp[gid] != null && !cfg.grupos.some((g) => g.id === gid)) return { ok: false, erro: 'opcao', grupo: gid };
  const opcoes = [];
  for (const g of cfg.grupos) {
    const esc = escOp[g.id];
    const o = esc != null ? g.itens.find((x) => x.id === esc) : null;
    if (esc != null && !o) return { ok: false, erro: 'opcao', grupo: g.id, grupoNome: g.nome };
    if (!o) { if (g.obrigatorio) return { ok: false, erro: 'obrigatorio', grupo: g.id, grupoNome: g.nome }; continue; }
    opcoes.push({ grupo: g.id, grupoNome: g.nome, id: o.id, nome: o.nome, preco: o.preco });
  }
  const adicionais = [];
  for (const [aid, q0] of Object.entries(escAd)) {
    const q = parseInt(q0, 10) || 0;
    if (q <= 0) continue;
    const a = cfg.adicionais.find((x) => x.id === aid);
    if (!a) return { ok: false, erro: 'adicional', adicional: aid };
    if (q > a.max) return { ok: false, erro: 'maximo', adicional: aid };
    adicionais.push({ id: a.id, nome: a.nome, preco: a.preco, qtd: q });
  }
  const pos = (id) => cfg.adicionais.findIndex((a) => a.id === id);
  adicionais.sort((a, b) => pos(a.id) - pos(b.id));
  const precio = arred(precoValido(item?.precio) + opcoes.reduce((s, o) => s + o.preco, 0) + adicionais.reduce((s, a) => s + a.preco * a.qtd, 0));
  return { ok: true, precio, opcoes, adicionais };
}

/** A escolha guardada numa linha do carrinho/pedido, no formato de montarEscolha. */
export function escolhaDaLinha(linha) {
  const opcoes = {}, adicionais = {};
  for (const o of Array.isArray(linha?.opcoes) ? linha.opcoes : []) if (o && o.grupo) opcoes[o.grupo] = o.id;
  for (const a of Array.isArray(linha?.adicionais) ? linha.adicionais : []) if (a && a.id) adicionais[a.id] = a.qtd;
  return { opcoes, adicionais };
}

export const limparObs = (v) => texto(v, LIMITES.obs);

/** Mesma escolha = mesma linha no carrinho (soma a quantidade); escolha diferente = outra linha. */
export function chaveLinha(linha) {
  const op = (linha?.opcoes || []).map((o) => `${o.grupo}:${o.id}`).sort().join(',');
  const ad = (linha?.adicionais || []).map((a) => `${a.id}x${a.qtd}`).sort().join(',');
  return `${linha?.id}|${op}|${ad}|${limparObs(linha?.obs).toLowerCase()}`;
}

/** Linha pronta para o carrinho (só leva os campos que existem). */
export function linhaDoCarrinho(id, item, r, qtd = 1, obs = '') {
  const o = limparObs(obs);
  return {
    id, nombre: texto(item?.nombre, 80) || 'Produto', precio: r.precio, qtd: Math.min(99, Math.max(1, parseInt(qtd, 10) || 1)),
    ...(r.opcoes?.length ? { opcoes: r.opcoes } : {}),
    ...(r.adicionais?.length ? { adicionais: r.adicionais } : {}),
    ...(o ? { obs: o } : {})
  };
}

/** Partes curtas para mostrar abaixo do nome: ['Ao ponto', '2x Queijo', 'Obs.: sem cebola']. */
export function resumoLinha(linha) {
  const partes = [];
  for (const o of Array.isArray(linha?.opcoes) ? linha.opcoes : []) if (o?.nome) partes.push(texto(o.nome, LIMITES.nome));
  for (const a of Array.isArray(linha?.adicionais) ? linha.adicionais : []) if (a?.nome && Number(a.qtd) > 0) partes.push(`${Number(a.qtd)}x ${texto(a.nome, LIMITES.nome)}`);
  const obs = limparObs(linha?.obs);
  if (obs) partes.push(`Obs.: ${obs}`);
  return partes;
}

// ---------- Sugestões (bebida ou sobremesa) ----------
const RE_BEBIDA = /bebida|drink|refri|suco|[aá]gua|cerveja|chopp?|vinho|caf[eé]|milk ?shake|soda|ch[aá]s?\b/i;
const RE_SOBREMESA = /sobremesa|doce|sorvete|a[cç]a[ií]|pudim|bolo|mousse|brownie|gelato|confeit|petit/i;

/** 'bebida' | 'sobremesa' | null, pela categoria do produto. */
export function tipoSugestao(item) {
  const c = String(item?.categoria || '');
  if (RE_BEBIDA.test(c)) return 'bebida';
  if (RE_SOBREMESA.test(c)) return 'sobremesa';
  return null;
}

const disponivelAgora = (i) => i && i.disponible !== false && !(i.controlaEstoque === true && (Number(i.estoque) || 0) <= 0);

/**
 * Até 4 sugestões para a tela do produto `atualId`: só o que está disponível agora e pode ir direto para o carrinho
 * (sem escolha obrigatória). Se o lojista marcou produtos ("sugerir"), usa esses; senão, bebidas e sobremesas pela categoria.
 * Nunca sugere o mesmo tipo do produto aberto (abriu um suco: não sugere outro suco). Mais vendidos primeiro.
 */
export function sugestoesDoProduto(menu, atualId) {
  const atual = menu?.[atualId];
  const tipoAtual = tipoSugestao(atual);
  const candidatos = Object.entries(menu || {}).filter(([id, i]) => id !== atualId && disponivelAgora(i) && !temEscolhaObrigatoria(i)
    && !(tipoAtual && tipoSugestao(i) === tipoAtual));
  const marcados = candidatos.filter(([, i]) => i.sugerir === true);
  const lista = marcados.length ? marcados : candidatos.filter(([, i]) => tipoSugestao(i));
  return lista.sort((a, b) => (Number(b[1].vendas) || 0) - (Number(a[1].vendas) || 0) || String(a[1].nombre || '').localeCompare(String(b[1].nombre || ''), 'pt-BR'))
    .slice(0, LIMITES.sugestoes).map(([id, item]) => ({ id, item }));
}
