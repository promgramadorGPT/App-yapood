// V75.73 — Aviso na tela da loja e no carrinho quando a loja está numa cidade ainda em espera.
// O bloqueio de verdade é do servidor (pagamento online) e das regras do Firebase; isto só avisa o cliente antes dele tentar.
// Master e contas em testadores/{uid} passam, para testar o fluxo inteiro antes de liberar a cidade.
import { db, auth, ref, get } from './firebase.js';
import { bloqueioDaCidade, chaveEmailTestador } from './cidades.js';

/** Master, conta em testadores/{uid} ou e-mail cadastrado pelo Master em testadores_email. Falha de leitura = cliente comum. */
export async function podeFurarCidade(user) {
  const uid = user?.uid;
  if (!uid) return false;
  const ler = async (caminho) => { try { return (await get(ref(db, caminho))).val(); } catch { return null; } };
  const chave = user.emailVerified !== false && user.email ? chaveEmailTestador(user.email) : '';
  const [papel, testador, porEmail] = await Promise.all([ler(`admins/${uid}/role`), ler(`testadores/${uid}`), chave ? ler(`testadores_email/${chave}`) : null]);
  return papel === 'master' || testador === true || (!!porEmail && typeof porEmail === 'object');
}

export async function bloqueioDaLojaAgora(loja) {
  try {
    if (!loja?.cidadeId) return { bloqueada: false };
    const cidade = (await get(ref(db, `cidades/${loja.cidadeId}`))).val();
    if (!cidade || cidade.status !== 'espera') return { bloqueada: false };
    try { await auth.authStateReady?.(); } catch { /* sem suporte: segue */ }
    const podeFurar = await podeFurarCidade(auth.currentUser);
    return bloqueioDaCidade(loja, cidade, podeFurar);
  } catch (err) {
    console.warn('Cidade da loja não verificada:', err);
    return { bloqueada: false }; // falha de leitura não impede (o servidor decide)
  }
}
