// V75.16 — Modal da política de cancelamento e reembolso (usado em Status e em Meus pedidos).
import { POLITICA } from './reembolso.js';

const lis = (arr) => arr.map((t) => `<li>${t}</li>`).join('');

export function abrirPolitica() {
  if (document.getElementById('modal-politica')) return;
  const el = document.createElement('div');
  el.id = 'modal-politica';
  el.className = 'rb-overlay';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-modal', 'true');
  el.innerHTML = `<div class="rb-modal">
    <div class="rb-head"><h3>Política de cancelamento e reclamações</h3><button type="button" class="rb-fechar" data-fechar aria-label="Fechar">&times;</button></div>
    <h4>Cancelamento e reembolso</h4><ul>${lis(POLITICA.cancelamento)}</ul>
    <h4>Reclamações</h4><ul>${lis(POLITICA.reclamacoes)}</ul>
    <button type="button" class="rb-btn rb-btn-sec" data-fechar>Entendi</button></div>`;
  el.addEventListener('click', (e) => { if (e.target === el || e.target.closest('[data-fechar]')) el.remove(); });
  document.body.appendChild(el);
}
