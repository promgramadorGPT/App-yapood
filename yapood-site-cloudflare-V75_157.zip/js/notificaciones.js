import { app, auth, onAuthStateChanged } from './firebase.js';
import './ui-mensagens.js';
import { iconeDoAviso, silhuetaDoAviso } from './icones-app.js';
import { FCM_VAPID_KEY, NOTPUSH_API } from './notificaciones-config.js';
// V75.151: o SDK de mensagens (push) só é baixado quando precisa (ativar avisos / escutar com o app aberto), depois que a tela já abriu.
const FCM_SDK = 'https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging.js';
const carregarFcm = () => import(FCM_SDK);

const urlHttps = (u) => (typeof u === 'string' && u.startsWith('https://') && u.length <= 400 ? u : '');
let tokenAtual = null;
let inicializado = false;

function avisar(msg) {
  console.warn('[NotPush]', msg);
}

async function registrarToken(token) {
  const user = auth.currentUser;
  if (!user || !token) return false;
  const idToken = await user.getIdToken(true);
  const r = await fetch(`${NOTPUSH_API}/registrar-token`, {
    method: 'POST',
    headers: {'Content-Type':'application/json','Authorization':`Bearer ${idToken}`},
    body: JSON.stringify({ token, plataforma:'web' })
  });
  const data = await r.json().catch(()=>({}));
  if (!r.ok || !data.ok) throw new Error(data.error || `HTTP ${r.status}`);
  tokenAtual = token;
  return true;
}

export async function ativarNotificacoes() {
  if (!('Notification' in window)) throw new Error('Este navegador não oferece suporte a notificações.');
  if (!FCM_VAPID_KEY || FCM_VAPID_KEY.includes('COLE_AQUI')) throw new Error('A chave VAPID ainda não foi configurada.');
  if (!auth.currentUser) throw new Error('Entre primeiro.');

  const permissao = await Notification.requestPermission();
  if (permissao !== 'granted') throw new Error('Permissão de notificações não concedida.');

  const { getMessaging, getToken, isSupported } = await carregarFcm();
  const soportado = await isSupported().catch(() => false);
  if (!soportado) throw new Error('O FCM Web Push não é compatível com este navegador/dispositivo.');
  const messaging = getMessaging(app);
  let registration = await navigator.serviceWorker.getRegistration('./');
  if (!registration) registration = await navigator.serviceWorker.register('./sw.js', { scope: './' });
  await registration.update().catch(() => {});
  await navigator.serviceWorker.ready;
  const token = await getToken(messaging, {
    vapidKey: FCM_VAPID_KEY,
    serviceWorkerRegistration: registration
  });
  if (!token) throw new Error('Não foi possível obter o token FCM.');
  await registrarToken(token);
  return true;
}

export async function desativarNotificacoes() {
  if (!tokenAtual || !auth.currentUser) return;
  try {
    const idToken = await auth.currentUser.getIdToken(true);
    await fetch(`${NOTPUSH_API}/remover-token`, {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${idToken}`},
      body:JSON.stringify({token:tokenAtual})
    });
  } finally { tokenAtual=null; }
}

// V75.135 — o cliente pode desligar os avisos no Perfil: o app para de pedir e de registrar o aparelho.
export const CHAVE_AVISOS_OFF = 'yapood_avisos_off';
export const avisosDesligados = () => { try { return localStorage.getItem(CHAVE_AVISOS_OFF) === '1'; } catch { return false; } };
export function marcarAvisosDesligados(off) { try { if (off) localStorage.setItem(CHAVE_AVISOS_OFF, '1'); else localStorage.removeItem(CHAVE_AVISOS_OFF); } catch { /* sem armazenamento */ } }
export const avisosRegistrados = () => !!tokenAtual;

// Páginas que cuidam dos próprios avisos (o app do entregador mostra a situação e o botão) não usam o pedido automático nem o botão flutuante.
const cuidaSozinha = () => document.body?.dataset?.notpushProprio === '1';

async function iniciar(user) {
  if (inicializado || !user || cuidaSozinha() || avisosDesligados()) return;
  inicializado = true;
  if (!('Notification' in window)) return;

  try {
    // Se já autorizou anteriormente, registra/atualiza o token sem pedir nada.
    if (Notification.permission === 'granted') {
      await ativarNotificacoes();
      return;
    }

    // Primeira entrada: tenta pedir permissão. Se o navegador exigir gesto,
    // o botão de fallback criado abaixo permite ativar manualmente.
    if (Notification.permission === 'default') {
      try { await ativarNotificacoes(); } catch (e) { avisar(e.message); }
    }
  } catch (e) { avisar(e.message); }
}

function criarFallback() {
  if (cuidaSozinha() || avisosDesligados() || document.getElementById('notpush-fallback')) return;
  if (!('Notification' in window)) return;
  if (Notification.permission !== 'default') return;
  const box=document.createElement('div');
  box.id='notpush-fallback';
  box.style.cssText='position:fixed;left:12px;right:12px;bottom:82px;z-index:99999;background:#fff;padding:14px;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.18);font:600 14px Arial';
  const texto=document.body?.dataset?.notpushTexto||'Ative as notificações para receber atualizações dos seus pedidos.';
  box.innerHTML='<div style="margin-bottom:10px"><i class="fa-solid fa-bell" aria-hidden="true"></i> '+texto.replace(/[<>&]/g,'')+'</div><button id="notpush-ativar" type="button" style="border:0;border-radius:10px;padding:10px 14px;background:var(--cor-primaria,#efb638);color:var(--cor-sobre-primaria,#1b1b1b);font-weight:700">Ativar notificações</button>';
  document.body.appendChild(box);
  box.querySelector('#notpush-ativar').onclick=async()=>{
    const btn=box.querySelector('#notpush-ativar'); btn.disabled=true;
    try { await ativarNotificacoes(); box.remove(); }
    catch(e){ avisar(e.message); alert(e.message); btn.disabled=false; }
  };
}

onAuthStateChanged(auth, user => {
  if (user) {
    setTimeout(()=>{ iniciar(user); setTimeout(criarFallback,1200); }, 500);
  } else {
    inicializado=false; tokenAtual=null;
  }
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.addEventListener('message', e => {
    if (e.data?.type === 'NOTPUSH_READY') console.log('[NotPush] Service Worker pronto.');
  });
}

async function escutarComAppAberto() {
  try {
  const { getMessaging, onMessage } = await carregarFcm();
  const messaging = getMessaging(app);
  onMessage(messaging, payload => {
    // V75.49: com o app aberto o FCM não mostra o aviso sozinho. `new Notification()` é proibido no Chrome do Android
    // (lança "Illegal constructor"), por isso o aviso é mostrado pelo service worker; o construtor fica só como reserva.
    const n=payload?.notification, d=payload?.data || {};
    if (n && Notification.permission === 'granted') {
      const opcoes={body:n.body || '', icon:urlHttps(d.icon) || iconeDoAviso(), badge:urlHttps(d.badge) || silhuetaDoAviso(), ...(d.tag ? {tag:d.tag} : {}), data:d};
      const titulo=n.title || 'YAPOOD';
      const reserva=()=>{ try { new Notification(titulo, opcoes); } catch {} };
      if ('serviceWorker' in navigator) navigator.serviceWorker.getRegistration().then(reg => reg ? reg.showNotification(titulo, opcoes) : reserva()).catch(reserva);
      else reserva();
    }
  });
} catch (e) { avisar('FCM foreground: '+e.message); }
}
// Espera a página terminar de abrir (e um respiro) antes de baixar o SDK de mensagens.
const agendarEscuta = () => setTimeout(escutarComAppAberto, 2500);
if (document.readyState === 'complete') agendarEscuta(); else window.addEventListener('load', agendarEscuta, { once: true });
