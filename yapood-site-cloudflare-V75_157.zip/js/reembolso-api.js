// V75.20 — Devolução do dinheiro pelo Mercado Pago (API). A loja decide no painel; a API executa com o token da própria loja.
import { auth } from './firebase.js';
import { aguardandoEscolha, fimEscolha, devolveSoEmSaldo } from './saldo-loja.js?v=75.145';

const API = 'https://api-mp-yapoodbr.onrender.com';

export async function devolverPeloMercadoPago(pedidoKey) {
  const token = await auth.currentUser.getIdToken();
  const r = await fetch(`${API}/reembolso/executar`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ pedidoKey })
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'Não foi possível devolver o valor agora.'), { status: r.status });
  return d;
}

// Só pedidos pagos online (têm paymentIdMP) podem ser devolvidos pela API. V75.145: e os pagos só com saldo da loja (voltam como saldo).
// Com `loja` (ADM da loja): some enquanto o cliente ainda pode escolher entre dinheiro e saldo (48 h), e depois que ele escolheu saldo.
export const devolucaoPossivel = (p, loja = null) => (!!p?.paymentIdMP || devolveSoEmSaldo(p)) && p.reembolso?.status === 'aprovado'
  && p.reembolso.execucao?.status !== 'concluido' && p.reembolso.execucao?.status !== 'processando'
  && p.reembolso.escolha?.tipo !== 'saldo' && !(loja && aguardandoEscolha(p, loja));

const rs = (n) => (Number(n) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dataHora = (ms) => new Date(ms).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export function textoDevolucao(p, loja = null) {
  const r = p?.reembolso; if (!r || r.status !== 'aprovado') return '';
  const ex = r.execucao?.status;
  // V75.145 — saldo na loja
  if (r.escolha?.tipo === 'saldo') return ` · o cliente escolheu receber em saldo na sua loja (${rs(r.escolha.valor)}${r.escolha.bonus > 0 ? `, com ${rs(r.escolha.bonus)} de bônus` : ''})`;
  if (ex === 'concluido' && r.execucao.tipo === 'saldo') return ' · valor devolvido como saldo na loja';
  if (ex === 'concluido' && r.execucao.valorSaldo > 0) return ` · ${rs(r.execucao.valorMP)} devolvidos pelo Mercado Pago e ${rs(r.execucao.valorSaldo)} como saldo na loja`;
  if (loja && aguardandoEscolha(p, loja)) return ` · aguardando o cliente escolher: dinheiro de volta ou saldo na loja (até ${dataHora(fimEscolha(p))})`;
  if (devolveSoEmSaldo(p) && !ex) return ' · pago com saldo da loja: toque em "Devolver em saldo"';
  if (ex === 'concluido') return ' · valor devolvido pelo Mercado Pago';
  if (ex === 'processando') return ' · devolvendo pelo Mercado Pago…';
  if (r.devolucaoDireta) return r.devolvidoDiretoEm ? ' · devolvido direto ao cliente' : ' · pago na entrega: devolva o valor direto ao cliente e marque como devolvido';
  if (!p.paymentIdMP) return ' · pagamento fora do app: devolva direto ao cliente';
  if (ex === 'falhou') return ` · a devolução falhou (${String(r.execucao.erro || 'erro')}). Use "Devolver pelo Mercado Pago"`;
  return ' · devolução pendente';
}
