// js/destino-loja.js — V75.138: no Master (Marketing), escolher uma LOJA como destino de banner, aviso principal ou push.
// O link da página da loja é montado sozinho (restaurante.html?id=…), sem copiar e colar.
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sem = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const ID_OK = /^[A-Za-z0-9_-]{1,64}$/;

/** Link da página da loja. `absoluto` (push): com o endereço do site na frente. */
export function linkDaLoja(id, absoluto = '') {
  if (!ID_OK.test(String(id || ''))) return '';
  const rel = `restaurante.html?id=${encodeURIComponent(id)}`;
  return absoluto ? `${String(absoluto).replace(/\/+$/, '')}/${rel}` : rel;
}
/** Id da loja num link "restaurante.html?id=…" (relativo ou absoluto); '' se não for link de loja. */
export function lojaDoLink(link) {
  const m = /(?:^|\/)restaurante\.html\?(?:[^#]*&)?id=([A-Za-z0-9_-]{1,64})(?:[&#]|$)/.exec(String(link || '').trim());
  return m ? m[1] : '';
}
const nomeDe = (l, id) => String(l?.nombre || l?.nome || id || '').trim();
/** Lojas que combinam com o termo (nome ou cidade, sem acento), em ordem alfabética; no máximo `max`. */
export function filtrarLojas(lojas, termo = '', max = 8) {
  const t = sem(termo).trim();
  return Object.entries(lojas || {})
    .filter(([id, l]) => l && ID_OK.test(id))
    .map(([id, l]) => ({ id, nome: nomeDe(l, id), cidade: String(l.cidade || l.ciudad || '').trim(), logo: l.logo || l.logoUrl || '', ativa: l.activo !== false }))
    .filter((x) => !t || sem(x.nome).includes(t) || sem(x.cidade).includes(t))
    .sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'))
    .slice(0, max);
}

/**
 * Desenha o seletor dentro de `host`. opts: { lojas: () => objeto de lojas, aoMudar(id), dica(nome) => texto }.
 * Devolve { valor(), definir(id) }.
 */
export function seletorLoja(host, { lojas, aoMudar = () => {}, dica = (n) => `Ao tocar, o cliente abre a página da ${n}.` } = {}) {
  let escolhida = '';
  host.classList.add('dl');
  host.innerHTML = `<label>Loja<input type="search" class="dl-busca" placeholder="Digite o nome da loja" autocomplete="off"></label>
    <div class="dl-lista" role="listbox" aria-label="Lojas"></div><div class="dl-escolhida" hidden></div>`;
  const busca = host.querySelector('.dl-busca'), lista = host.querySelector('.dl-lista'), card = host.querySelector('.dl-escolhida');
  const item = (x, sel = false) => `<button type="button" class="dl-op${sel ? ' sel' : ''}" data-dl="${esc(x.id)}" role="option" aria-selected="${sel}">
      ${x.logo ? `<img src="${esc(x.logo)}" alt="" loading="lazy">` : `<span class="dl-ini">${esc(x.nome.charAt(0).toUpperCase())}</span>`}
      <span><b>${esc(x.nome)}</b><small>${esc([x.cidade, x.ativa ? '' : 'fechada no momento'].filter(Boolean).join(' · ') || 'Loja do YaPOOD')}</small></span></button>`;
  const pintar = () => {
    const todas = lojas?.() || {};
    if (escolhida && todas[escolhida]) {
      const x = filtrarLojas({ [escolhida]: todas[escolhida] })[0];
      lista.innerHTML = ''; lista.hidden = true; busca.closest('label').hidden = true;
      card.hidden = false;
      card.innerHTML = `${item(x, true)}<p class="dl-dica">${esc(dica(x.nome))} O link é preenchido sozinho.</p><button type="button" class="dl-trocar">Trocar loja</button>`;
      return;
    }
    busca.closest('label').hidden = false; card.hidden = true; lista.hidden = false;
    const r = filtrarLojas(todas, busca.value);
    lista.innerHTML = r.length ? r.map((x) => item(x)).join('') : '<p class="dl-vazio">Nenhuma loja com esse nome.</p>';
  };
  host.addEventListener('input', (e) => { if (e.target === busca) pintar(); });
  host.addEventListener('focusin', (e) => { if (e.target === busca) pintar(); }); // as lojas podem ter chegado depois
  host.addEventListener('click', (e) => {
    const op = e.target.closest('[data-dl]');
    if (op && !op.classList.contains('sel')) { escolhida = op.dataset.dl; pintar(); aoMudar(escolhida); return; }
    if (e.target.closest('.dl-trocar')) { escolhida = ''; busca.value = ''; pintar(); aoMudar(''); busca.focus(); }
  });
  pintar();
  return { valor: () => escolhida, definir: (id) => { escolhida = id && (lojas?.() || {})[id] ? id : ''; busca.value = ''; pintar(); }, atualizar: pintar };
}
