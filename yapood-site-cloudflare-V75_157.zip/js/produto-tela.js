// js/produto-tela.js — V75.127: tela do produto dentro da loja. V75.128: cartão da loja sobre a foto, combos,
// rodapé "− 1 + · valor · Adicionar" e passo que mostra só o "+" enquanto está em zero.
// Abre ao tocar no produto ou no "+": foto no cabeçalho, descrição e informações; opções (escolha uma);
// sugestão de bebida ou sobremesa disponível agora; adicionais com "− 0 +"; observação; quantidade e "Adicionar R$ X".
// A conta do preço é a de produto-opcoes.js (a mesma que o carrinho, o pedido e a API conferem).
import { escapeHtml } from './regras.js';
import { formatarMoeda, urlSegura, imgOtimizada, toast } from './utils.js';
import { configDoProduto, montarEscolha, linhaDoCarrinho, sugestoesDoProduto, LIMITES } from './produto-opcoes.js?v=75.127';
import { ehCombo, resumoCombo, comboParaLinha } from './combo.js?v=75.128';

const IMG_PADRAO = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600';
let raiz = null, S = null, focoAntes = null, comHistorico = false;
const $q = (sel) => raiz.querySelector(sel);
const maisPreco = (v) => (v > 0 ? `+ ${formatarMoeda(v)}` : '');
const esgotado = (i) => i?.controlaEstoque === true && (Number(i.estoque) || 0) <= 0;
const limiteQtd = (i) => (i?.controlaEstoque === true ? Math.max(1, Math.min(99, Math.floor(Number(i.estoque) || 0))) : 99);

function criar() {
  if (raiz) return;
  raiz = document.createElement('div');
  raiz.id = 'produto-tela';
  raiz.className = 'pt-fundo';
  raiz.hidden = true;
  raiz.innerHTML = `<div class="pt-caixa" role="dialog" aria-modal="true" aria-labelledby="pt-nome">
    <div class="pt-rolagem" id="pt-rolagem"></div>
    <div class="pt-rodape">
      <div class="pt-step pt-qtd" role="group" aria-label="Quantidade">
        <button type="button" data-qtd="-1" aria-label="Diminuir quantidade"><span class="pt-sinal" aria-hidden="true">−</span></button>
        <span id="pt-qtd" aria-live="polite">1</span>
        <button type="button" data-qtd="1" aria-label="Aumentar quantidade"><span class="pt-sinal" aria-hidden="true">+</span></button>
      </div>
      <button type="button" class="pt-adicionar" id="pt-adicionar"><strong id="pt-total"></strong><span id="pt-adicionar-txt">Adicionar</span></button>
    </div>
  </div>`;
  document.body.appendChild(raiz);
  raiz.addEventListener('click', aoClicar);
  raiz.addEventListener('change', aoMudar);
  raiz.addEventListener('input', (e) => { if (e.target.id === 'pt-obs') { S.obs = e.target.value; const c = $q('#pt-obs-cont'); if (c) c.textContent = `${e.target.value.length}/${LIMITES.obs}`; } });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && raiz && !raiz.hidden) fechar(); });
  window.addEventListener('popstate', () => { if (raiz && !raiz.hidden && comHistorico) { comHistorico = false; fechar(true); } });
}

/**
 * opts: { menu, itemId, aberta, motivo, loja: { nome, logo, nota, total, tempo, taxa, gratis, km, selo }, aoAdicionar(linhas) → Promise<boolean> }
 */
export function abrirProdutoTela(opts) {
  const item = opts?.menu?.[opts.itemId];
  if (!item || item.disponible === false) { toast('Produto indisponível.', 'error'); return; }
  criar();
  S = { ...opts, item, cfg: configDoProduto(item), op: {}, ad: {}, qtd: 1, obs: '', sug: {}, sugestoes: sugestoesDoProduto(opts.menu, opts.itemId), combo: ehCombo(item) ? resumoCombo(item, opts.menu) : null };
  desenhar();
  focoAntes = document.activeElement;
  raiz.hidden = false;
  document.body.classList.add('pt-aberta');
  try { history.pushState({ produtoTela: opts.itemId }, ''); comHistorico = true; } catch { comHistorico = false; }
  $q('.pt-fechar')?.focus();
}

export function fechar(veioDoVoltar = false) {
  if (!raiz || raiz.hidden) return;
  raiz.hidden = true;
  document.body.classList.remove('pt-aberta');
  if (!veioDoVoltar && comHistorico) { comHistorico = false; try { history.back(); } catch { /* sem histórico */ } }
  if (focoAntes?.isConnected) focoAntes.focus();
  focoAntes = null;
}

function desenhar() {
  const { item, cfg } = S;
  const sugs = S.sugestoes;
  const grupos = cfg.grupos.map((g) => `<section class="pt-secao pt-grupo" data-grupo="${escapeHtml(g.id)}">
      <div class="pt-secao-cab"><div><h3>${escapeHtml(g.nome)}</h3><small>Escolha 1</small></div><span class="pt-selo${g.obrigatorio ? ' obrig' : ''}" data-selo="${escapeHtml(g.id)}">${g.obrigatorio ? 'Obrigatório' : 'Opcional'}</span></div>
      <div class="pt-ops" role="radiogroup" aria-label="${escapeHtml(g.nome)}">${g.itens.map((o) => `<label class="pt-op">
        <span class="pt-op-txt"><span>${escapeHtml(o.nome)}</span>${o.preco > 0 ? `<small>${maisPreco(o.preco)}</small>` : ''}</span>
        <input type="radio" name="pt-g-${escapeHtml(g.id)}" value="${escapeHtml(o.id)}" data-g="${escapeHtml(g.id)}"><span class="pt-radio" aria-hidden="true"></span></label>`).join('')}</div>
    </section>`).join('');
  const sugestao = sugs.length ? `<section class="pt-secao pt-sug">
      <div class="pt-secao-cab"><div><h3>Que tal uma bebida ou sobremesa?</h3><small>Disponível agora</small></div></div>
      <div class="pt-sug-lista">${sugs.map(({ id, item: s }) => `<div class="pt-sug-card">
        <img src="${escapeHtml(imgOtimizada(urlSegura(s.imagen || s.imagem, IMG_PADRAO), 200))}" alt="" loading="lazy">
        <strong>${escapeHtml(s.nombre || 'Produto')}</strong><span>${formatarMoeda(Number(s.precio) || 0)}</span>
        ${passo('sug', id, s.nombre, 0)}</div>`).join('')}</div>
    </section>` : '';
  const adicionais = cfg.adicionais.length ? `<section class="pt-secao pt-adicionais">
      <div class="pt-secao-cab"><div><h3>Adicionais</h3><small>Escolha quantos quiser</small></div></div>
      ${cfg.adicionais.map((a) => `<div class="pt-ad"><div class="pt-ad-txt"><strong>${escapeHtml(a.nome)}</strong><small>${a.preco > 0 ? maisPreco(a.preco) : 'Grátis'}</small></div>${passo('ad', a.id, a.nome, 0)}</div>`).join('')}
    </section>` : '';
  const c = S.combo;
  const preco = c && c.economia > 0
    ? `<strong class="pt-preco">${formatarMoeda(Number(item.precio) || 0)} <s>${formatarMoeda(c.de)}</s></strong><span class="pt-economia">Economize ${formatarMoeda(c.economia)} no combo</span>`
    : `<strong class="pt-preco">${formatarMoeda(Number(item.precio) || 0)}</strong>`;
  const blocoCombo = c ? `<section class="pt-secao pt-combo">
      <div class="pt-secao-cab"><div><h3>Neste combo</h3><small>${c.itens.reduce((n, i) => n + i.qtd, 0)} itens</small></div>${c.disponivel ? '' : '<span class="pt-selo obrig">Indisponível agora</span>'}</div>
      ${c.itens.map((i) => `<div class="pt-combo-item${i.disponivel ? '' : ' falta'}"><img src="${escapeHtml(imgOtimizada(urlSegura(i.imagem, IMG_PADRAO), 200))}" alt="" loading="lazy"><span><strong>${i.qtd}x ${escapeHtml(i.nome)}</strong>${i.disponivel ? '' : '<small>Em falta agora</small>'}</span></div>`).join('')}
    </section>` : '';
  $q('#pt-rolagem').innerHTML = `<div class="pt-foto"><img src="${escapeHtml(imgOtimizada(urlSegura(item.imagen || item.imagem, IMG_PADRAO), 900))}" alt="">
      <button type="button" class="pt-fechar" aria-label="Fechar"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></button>
      ${cartaoLoja(S.loja)}</div>
    <div class="pt-corpo">
      <h2 id="pt-nome">${escapeHtml(item.nombre || 'Produto')}</h2>
      ${item.descripcion ? `<p class="pt-desc">${escapeHtml(item.descripcion)}</p>` : ''}
      ${cfg.info ? `<p class="pt-info"><i class="fa-solid fa-circle-info" aria-hidden="true"></i> ${escapeHtml(cfg.info)}</p>` : ''}
      ${preco}
      ${blocoCombo}${grupos}${sugestao}${adicionais}
      <section class="pt-secao pt-obs">
        <div class="pt-secao-cab"><div><h3><label for="pt-obs">Alguma observação?</label></h3><small>Ex.: sem cebola, molho à parte</small></div><small id="pt-obs-cont">0/${LIMITES.obs}</small></div>
        <textarea id="pt-obs" maxlength="${LIMITES.obs}" rows="2" placeholder="Escreva aqui"></textarea>
      </section>
    </div>`;
  atualizar();
}

// Cartão da loja sobre a foto: logo, nome, selo, ★ nota (avaliações) · tempo · taxa · km.
function cartaoLoja(l) {
  if (!l || !l.nome) return '';
  const partes = [];
  partes.push(l.nota != null && l.total > 0 ? `<span class="pt-nota"><i class="fa-solid fa-star" aria-hidden="true"></i> ${l.nota.toFixed(1).replace('.', ',')} <em>(${l.total})</em></span>` : '<span class="pt-nota">Novo</span>');
  if (l.tempo) partes.push(`<span>${escapeHtml(l.tempo)}</span>`);
  if (l.taxa) partes.push(`<span class="${l.gratis ? 'pt-gratis' : ''}">${escapeHtml(l.taxa)}</span>`);
  if (Number.isFinite(l.km)) partes.push(`<span>${String(l.km).replace('.', ',')} km</span>`);
  return `<div class="pt-loja"><img src="${escapeHtml(l.logo || '')}" alt=""><div><strong>${escapeHtml(l.nome)}${l.selo ? ' <i class="fa-solid fa-circle-check pt-selo-loja" aria-label="Loja Super"></i>' : ''}</strong>
    <small>${partes.join('<b aria-hidden="true">•</b>')}</small></div></div>`;
}

function passo(tipo, id, nome, q) {
  return `<div class="pt-step${q <= 0 ? ' zero' : ''}" role="group" aria-label="${escapeHtml(nome || '')}">
    <button type="button" data-${tipo}="${escapeHtml(id)}" data-delta="-1" aria-label="Tirar ${escapeHtml(nome || '')}"${q <= 0 ? ' disabled' : ''}><span class="pt-sinal" aria-hidden="true">−</span></button>
    <span data-${tipo}-qtd="${escapeHtml(id)}">${q}</span>
    <button type="button" data-${tipo}="${escapeHtml(id)}" data-delta="1" aria-label="Mais ${escapeHtml(nome || '')}"><span class="pt-sinal" aria-hidden="true">+</span></button></div>`;
}

// Preço enquanto o cliente ainda não terminou de escolher (soma o que já está marcado).
function precoParcial() {
  let v = Number(S.item.precio) || 0;
  for (const g of S.cfg.grupos) v += g.itens.find((o) => o.id === S.op[g.id])?.preco || 0;
  for (const a of S.cfg.adicionais) v += a.preco * (S.ad[a.id] || 0);
  return v;
}
function totalAtual() {
  const r = montarEscolha(S.item, { opcoes: S.op, adicionais: S.ad });
  const unit = r.ok ? r.precio : precoParcial();
  const sug = S.sugestoes.reduce((s, { id, item }) => s + (Number(item.precio) || 0) * (S.sug[id] || 0), 0);
  return { r, total: Math.round((unit * S.qtd + sug) * 100) / 100 };
}

function atualizar() {
  const { total, r: escolha } = totalAtual();
  $q('#pt-qtd').textContent = S.qtd;
  $q('[data-qtd="-1"]').disabled = S.qtd <= 1;
  $q('[data-qtd="1"]').disabled = S.qtd >= limiteQtd(S.item);
  for (const a of S.cfg.adicionais) {
    const q = S.ad[a.id] || 0;
    const n = raiz.querySelector(`[data-ad-qtd="${CSS.escape(a.id)}"]`); if (n) n.textContent = q;
    const menos = raiz.querySelector(`[data-ad="${CSS.escape(a.id)}"][data-delta="-1"]`), mais = raiz.querySelector(`[data-ad="${CSS.escape(a.id)}"][data-delta="1"]`);
    if (menos) menos.disabled = q <= 0; if (mais) mais.disabled = q >= a.max;
    n?.closest('.pt-ad')?.classList.toggle('ativo', q > 0); n?.closest('.pt-step')?.classList.toggle('zero', q <= 0);
  }
  for (const { id, item } of S.sugestoes) {
    const q = S.sug[id] || 0;
    const n = raiz.querySelector(`[data-sug-qtd="${CSS.escape(id)}"]`); if (n) n.textContent = q;
    const menos = raiz.querySelector(`[data-sug="${CSS.escape(id)}"][data-delta="-1"]`), mais = raiz.querySelector(`[data-sug="${CSS.escape(id)}"][data-delta="1"]`);
    if (menos) menos.disabled = q <= 0; if (mais) mais.disabled = q >= limiteQtd(item);
    n?.closest('.pt-sug-card')?.classList.toggle('ativo', q > 0); n?.closest('.pt-step')?.classList.toggle('zero', q <= 0);
  }
  for (const g of S.cfg.grupos) {
    const selo = raiz.querySelector(`[data-selo="${CSS.escape(g.id)}"]`); if (!selo) continue;
    const ok = !!S.op[g.id];
    selo.classList.toggle('feito', ok);
    selo.innerHTML = ok ? '<i class="fa-solid fa-check" aria-hidden="true"></i> Escolhido' : (g.obrigatorio ? 'Obrigatório' : 'Opcional');
  }
  const btn = $q('#pt-adicionar');
  const fechada = S.aberta === false, semEstoque = esgotado(S.item), comboFalta = S.combo && !S.combo.disponivel;
  btn.disabled = fechada || semEstoque || comboFalta;
  // V75.148: faltando escolha obrigatória o botão fica cinza mas continua clicável: o toque faz o celular vibrar e mostra o que falta.
  const incompleto = !btn.disabled && !escolha.ok;
  btn.classList.toggle('pt-incompleto', incompleto);
  if (incompleto) btn.setAttribute('aria-disabled', 'true'); else btn.removeAttribute('aria-disabled');
  $q('#pt-adicionar-txt').textContent = semEstoque ? 'Esgotado' : comboFalta ? 'Indisponível agora' : fechada ? (S.motivo || 'Loja fechada') : 'Adicionar';
  $q('#pt-total').textContent = fechada || semEstoque || comboFalta ? '' : formatarMoeda(total);
}

function aoMudar(e) {
  const r = e.target.closest('input[type="radio"][data-g]'); if (!r) return;
  S.op[r.dataset.g] = r.value;
  r.closest('.pt-grupo')?.classList.remove('pt-falta', 'pt-treme');
  atualizar();
}

async function aoClicar(e) {
  if (e.target === raiz || e.target.closest('.pt-fechar')) return fechar();
  // opção opcional: tocar de novo na escolhida desmarca
  const lab = e.target.closest('.pt-op');
  if (lab) {
    const r = lab.querySelector('input'); const g = S.cfg.grupos.find((x) => x.id === r?.dataset.g);
    if (g && !g.obrigatorio && r.checked && S.op[g.id] === r.value && e.target === r) { r.checked = false; delete S.op[g.id]; atualizar(); }
    return;
  }
  const b = e.target.closest('button'); if (!b || b.disabled) return;
  const d = Number(b.dataset.delta) || 0;
  if (b.dataset.qtd) { S.qtd = Math.min(limiteQtd(S.item), Math.max(1, S.qtd + Number(b.dataset.qtd))); return atualizar(); }
  if (b.dataset.ad) { const a = S.cfg.adicionais.find((x) => x.id === b.dataset.ad); if (a) { S.ad[a.id] = Math.min(a.max, Math.max(0, (S.ad[a.id] || 0) + d)); if (!S.ad[a.id]) delete S.ad[a.id]; } return atualizar(); }
  if (b.dataset.sug) { const s = S.sugestoes.find((x) => x.id === b.dataset.sug); if (s) { S.sug[s.id] = Math.min(limiteQtd(s.item), Math.max(0, (S.sug[s.id] || 0) + d)); if (!S.sug[s.id]) delete S.sug[s.id]; } return atualizar(); }
  if (b.id === 'pt-adicionar') return adicionar(b);
}

async function adicionar(btn) {
  const { r } = totalAtual();
  if (!r.ok) {
    try { navigator.vibrate?.([70, 40, 70]); } catch { /* aparelho sem vibração */ }
    if (r.erro === 'obrigatorio') {
      const faltam = S.cfg.grupos.filter((x) => x.obrigatorio && !S.op[x.id])
        .map((x) => raiz.querySelector(`.pt-grupo[data-grupo="${CSS.escape(x.id)}"]`)).filter(Boolean);
      for (const g of faltam) { // tira e põe a classe para a animação recomeçar a cada clique
        g.classList.remove('pt-falta', 'pt-treme'); void g.offsetWidth; g.classList.add('pt-falta', 'pt-treme');
      }
      const primeiro = faltam[0] || raiz.querySelector(`.pt-grupo[data-grupo="${CSS.escape(r.grupo || '')}"]`);
      if (primeiro) { primeiro.scrollIntoView({ behavior: 'smooth', block: 'center' }); primeiro.querySelector('input')?.focus({ preventScroll: true }); }
      return;
    }
    toast('Revise as opções deste produto.', 'error');
    return;
  }
  const principal = linhaDoCarrinho(S.itemId, S.item, r, S.qtd, S.obs);
  const linhas = [S.combo ? { ...principal, combo: comboParaLinha(S.item, S.menu) } : principal];
  for (const { id, item } of S.sugestoes) if (S.sug[id] > 0) linhas.push(linhaDoCarrinho(id, item, montarEscolha(item, {}), S.sug[id]));
  btn.disabled = true;
  try { if (await S.aoAdicionar(linhas)) fechar(); }
  finally { if (raiz && !raiz.hidden) atualizar(); }
}
