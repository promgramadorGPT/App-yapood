// js/notpush-evento.js — pede ao NotPush para avisar alguém (novo entregador, entrega concluída, bairro novo).
// Nunca atrapalha o fluxo: qualquer falha vira só um aviso no console. Quem pode disparar cada evento é conferido no servidor.
import { auth } from './firebase.js';
import { NOTPUSH_API } from './notificaciones-config.js';

export async function avisarEvento(corpo) {
  try {
    const user = auth?.currentUser;
    if (!user || typeof user.getIdToken !== 'function') return false;
    const idToken = await user.getIdToken();
    const r = await fetch(`${NOTPUSH_API}/notificar-pedido`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` },
      body: JSON.stringify(corpo),
      keepalive: true
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok) { console.warn('[NotPush]', corpo?.evento, d.error || `HTTP ${r.status}`); return false; }
    return true;
  } catch (e) { console.warn('[NotPush] não foi possível avisar:', e); return false; }
}
