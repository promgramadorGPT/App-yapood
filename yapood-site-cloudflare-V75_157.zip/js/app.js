import { db, ref, onValue, auth, onAuthStateChanged } from './firebase.js';
import { nomeDoCliente } from './perfil-nome.js?v=75.106';
import { calcularDistanciaKm, obterLocalizacao, obterEnderecoPorCoordenadas } from './geo.js';
import { escapeHtml, normalizarTexto, lojaAberta, avaliarSuper, textoTempo } from './regras.js';
import { atualizarSacola } from './sacola.js?v=75.131';
import { cuponsVigentes, etiquetaCupom } from './cupom-etiqueta.js?v=75.134';
import { resumoTaxaLoja } from './bairros.js';
import { iniciarCidadesCliente } from './cidades-cliente.js';
import { splashConfigurar, splashExigir, splashPronto, splashAguardar } from './splash.js';
import { formatarMoeda, debounce, urlSegura, imgOtimizada, IMG_LOJA_PADRAO, obterCarrinho } from './utils.js';
import { irParaCard, esquerdaDoCard } from './carrossel-util.js';
import { tagMidia } from './midia.js';

const $ = (id) => document.getElementById(id);
const carrosselCategorias = $('carrossel-categorias');
const carrosselLojas = $('carrossel-lojas');
const carrosselBanners = $('carrossel-banners');
const listaContainer = $('lista-restaurantes');
const inputBusca = $('input-busca');
const enderecoAtualElem = $('endereco-atual');
// V75.146: "Bairro, Cidade" em duas partes; com o botão da cidade à mostra, o CSS esconde a cidade (já está no botão)
function mostrarEndereco(t) {
  if (!enderecoAtualElem) return;
  const i = String(t).indexOf(', ');
  if (i < 1) { enderecoAtualElem.textContent = t; return; }
  const b = document.createElement('span'), c = document.createElement('span');
  b.className = 'end-bairro'; b.textContent = t.slice(0, i); c.className = 'end-cidade'; c.textContent = t.slice(i);
  enderecoAtualElem.replaceChildren(b, c);
}
const btnLupa = $('btn-lupa');

const categoriasFallback = [
  { id: 'hamburguesas', nombre: 'Hamburguesas', img: '' },
  { id: 'pizzería', nombre: 'Pizzería', img: '' },
  { id: 'comida-japonesa', nombre: 'Comida japonesa', img: '' },
  { id: 'salados-empanadas', nombre: 'Salados / Empanadas', img: '' },
  { id: 'comida-mexicana', nombre: 'Comida mexicana', img: '' },
  { id: 'dulces-postres', nombre: 'Dulces y postres', img: '' },
  { id: 'bebidas', nombre: 'Bebidas', img: '' },
  { id: 'crepes', nombre: 'Crepes', img: '' }
];

let painelCidades = null; // V75.73: cidade do cliente (banner, escolha e filtro das lojas)
const estado = { lojas: {}, notas: {}, pedidos: {}, categorias: [], banners: {}, aviso: {}, pos: null, filtro: 'todos', categoria: '', categoriaId: '', pronta: false };
function renderizarAvisoApp(){
  const sec=$('aviso-app'), card=$('aviso-app-card'), content=$('aviso-popup-content');
  if(!sec||!card||!content)return;
  const a=estado.aviso||{};
  if(a.ativo!==true||!a.img){sec.hidden=true;content.innerHTML='';return;}
  const avisoId=String(a.updatedAt||a.img||a.titulo||'aviso-app');
  let fechado=false;
  try{ fechado=sessionStorage.getItem(`yapood_aviso_feito_${avisoId}`)==='1'; }catch{}
  if(fechado){sec.hidden=true;content.innerHTML='';return;}
  const titulo=escapeHtml(a.titulo||'');
  const desc=a.descripcion?`<div class="aviso-popup-text">${escapeHtml(a.descripcion)}</div>`:'';
  // V75.150: título é opcional; sem título nem texto o popup mostra só a imagem, inteira
  const temTexto=!!(String(a.titulo||'').trim()||String(a.descripcion||'').trim());
  const info=temTexto?`<div class="aviso-popup-info">${titulo?`<h3 id="aviso-popup-title">${titulo}</h3>`:''}${desc}</div>`:'';
  card.classList.toggle('so-midia',!temTexto);
  if(titulo){card.setAttribute('aria-labelledby','aviso-popup-title');card.removeAttribute('aria-label');}
  else{card.removeAttribute('aria-labelledby');card.setAttribute('aria-label','Aviso promocional');}
  const inner=`${tagMidia(a.img,{alt:a.titulo||'Aviso promocional',onerror:"this.closest('#aviso-app').hidden=true"})}${info}`;
  const link=linkBannerSeguro(a.link);
  content.innerHTML=link?`<a href="${escapeHtml(link)}" class="aviso-popup-link">${inner}</a>`:inner;
  sec.hidden=false;
}

const RAIO_PERTO_KM = 5;
const MAX_ENTREGA_RAPIDA_MIN = 30;

const precoEnvioHtml = (l) => {
  const r = resumoTaxaLoja(l);
  if (r.gratis) return '<span class="envio-gratis">Entrega grátis</span>';
  if (r.variavel) return r.algumGratis ? `<span class="envio-gratis">Grátis</span> a ${formatarMoeda(r.max, l.moeda)}` : `A partir de ${formatarMoeda(r.min, l.moeda)}`;
  return formatarMoeda(r.min, l.moeda);
};
// V75.142: com `item`, a página da loja já abre rolada até o prato buscado
const irParaLoja = (id, item = '') => { window.location.href = `restaurante.html?id=${encodeURIComponent(id)}${item ? `&item=${encodeURIComponent(item)}` : ''}`; };


function atualizarCarrinhoGlobal() {
  const barra = $('barra-carrinho-global');
  if (!barra) return;
  const c = obterCarrinho();
  const itens = Array.isArray(c.itens) ? c.itens : [];
  const qtd = itens.reduce((s,i) => s + Math.max(0, Number(i.qtd)||0), 0);
  const total = itens.reduce((s,i) => s + (Number(i.precio)||0) * (Number(i.qtd)||0), 0);
  barra.hidden = qtd === 0;
  $('qtd-carrinho-global').textContent = String(qtd);
  $('total-carrinho-global').textContent = formatarMoeda(total);
  atualizarSacola(barra, qtd);
}

function prepararNavegacaoBusca() {
  const nav = $('nav-buscar');
  if (!nav) return;
  nav.addEventListener('click', (e) => {
    e.preventDefault();
    history.replaceState(null, '', 'index.html#buscar');
    inputBusca?.scrollIntoView({ block:'center', behavior:'smooth' });
    setTimeout(() => inputBusca?.focus({ preventScroll:true }), 120);
  });
}

// ---------- Categorias ----------
function categoriaFallbackImg(nome='Categoria') {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="150" height="150"><rect width="150" height="150" rx="24" fill="#eee"/><text x="75" y="82" font-family="Arial" font-size="16" text-anchor="middle" fill="#555">${nome.slice(0,18)}</text></svg>`)}`;
}

function normalizarCategoriaNome(v) {
  return String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
}

function categoriaParaLoja(loja) {
  if (!loja) return null;
  if (loja.categoriaId && estado.categorias.length) {
    const encontrada = estado.categorias.find(c => c.id === loja.categoriaId);
    if (encontrada) return encontrada;
  }
  const nome = normalizarCategoriaNome(loja.categoria);
  return estado.categorias.find(c => normalizarCategoriaNome(c.nombre) === nome) || null;
}

function renderizarCategorias() {
  if (!carrosselCategorias) return;
  const categorias = estado.categorias.length ? estado.categorias.filter(c => c.activa !== false) : categoriasFallback;
  carrosselCategorias.innerHTML = categorias.sort((a,b)=>(Number(a.orden)||0)-(Number(b.orden)||0)).map((c) => {
    const img = c.img || categoriaFallbackImg(c.nombre);
    // V75.140: moldura de pincel (filtro #pincel no index.html) atrás da foto
    return `<button type="button" class="item-circulo-cat" data-cat-id="${escapeHtml(c.id)}" data-cat="${escapeHtml(c.nombre)}" aria-pressed="false"><span class="cat-pincel"><svg viewBox="0 0 100 84" preserveAspectRatio="none" aria-hidden="true"><rect x="6" y="6" width="88" height="72" rx="16" filter="url(#pincel)"/></svg><img src="${escapeHtml(img)}" alt="" loading="lazy" onerror="this.onerror=null;this.src='${categoriaFallbackImg(c.nombre)}'"></span><span>${escapeHtml(c.nombre)}</span></button>`;
  }).join('');
  mostrarVerTodas();
}

// ---------- V75.142: "Ver todas" (categorias e destaques) numa folha que sobe de baixo ----------
const folha = $('folha-ver'), folhaCorpo = $('folha-corpo');
let folhaVoltarFoco = null;
function abrirFolha(tipo, botao) {
  if (!folha || !folhaCorpo) return;
  const cats = tipo === 'cats';
  $('folha-titulo').textContent = cats ? 'Categorias' : 'Destaques';
  folhaCorpo.className = 'folha-corpo ' + (cats ? 'folha-cats' : 'folha-lojas');
  folhaCorpo.innerHTML = (cats ? carrosselCategorias : carrosselLojas)?.innerHTML || '';
  folha.hidden = false; document.documentElement.classList.add('folha-aberta');
  folhaVoltarFoco = botao || null;
  requestAnimationFrame(() => folha.classList.add('aberta'));
  folha.querySelector('.folha-x')?.focus({ preventScroll: true });
}
function fecharFolha() {
  if (!folha || folha.hidden) return;
  folha.classList.remove('aberta'); document.documentElement.classList.remove('folha-aberta');
  setTimeout(() => { folha.hidden = true; folhaCorpo.innerHTML = ''; }, 220);
  folhaVoltarFoco?.focus({ preventScroll: true });
}
document.addEventListener('click', (e) => {
  const v = e.target.closest('[data-ver]'); if (v) { abrirFolha(v.dataset.ver, v); return; }
  if (e.target.closest('[data-fechar-folha]')) { fecharFolha(); return; }
  if (!folha || folha.hidden || !folha.contains(e.target)) return;
  const cat = e.target.closest('[data-cat-id]');
  if (cat) {
    fecharFolha();
    const alvo = carrosselCategorias?.querySelector(`[data-cat-id="${CSS.escape(cat.dataset.catId)}"]`);
    // V75.146: escolhida fora das 8 da grade → vai para a 1ª posição, já marcada
    if (alvo && [...carrosselCategorias.children].indexOf(alvo) >= MAX_CATS_HOME) carrosselCategorias.prepend(alvo);
    alvo?.click(); return;
  }
  const loja = e.target.closest('[data-id]');
  if (loja) irParaLoja(loja.dataset.id);
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fecharFolha(); });
const MAX_CATS_HOME = 8;
function mostrarVerTodas() {
  const vc = document.querySelector('[data-ver="cats"]'), vd = document.querySelector('[data-ver="destaques"]');
  if (vc) vc.hidden = (carrosselCategorias?.children.length || 0) <= MAX_CATS_HOME; // V75.146: grade 4 x 2
  if (vd) vd.hidden = (carrosselLojas?.children.length || 0) <= 1;
}

carrosselCategorias?.addEventListener('click', (e) => {
  const b = e.target.closest('[data-cat-id]'); if (!b) return;
  const novoId = estado.categoriaId === b.dataset.catId ? '' : b.dataset.catId;
  estado.categoriaId = novoId;
  estado.categoria = novoId ? b.dataset.cat : '';
  carrosselCategorias.querySelectorAll('[data-cat-id]').forEach((x) => {
    const on = x.dataset.catId === estado.categoriaId;
    x.classList.toggle('ativa', on); x.setAttribute('aria-pressed', on);
  });
  aplicar();
  irParaLista(); // V75.132: mostra o resultado com os filtros parados no topo
});

function iniciarCategorias() {
  onValue(ref(db, 'categorias_loja'), (snap) => {
    const raw = snap.val() || {};
    estado.categorias = Object.entries(raw).map(([id, c]) => ({ id, ...(c || {}) }))
      .filter(c => c.nombre && c.activa !== false)
      .sort((a,b)=>(Number(a.orden)||0)-(Number(b.orden)||0));
    renderizarCategorias();
    aplicar();
    splashPronto('categorias');
  }, () => {
    estado.categorias = [];
    renderizarCategorias();
    splashPronto('categorias');
  });
}

// ---------- Dados ----------
// 2 listeners (lojas + agregado de notas) em vez de 1 + N consultas de avaliações como antes.
function iniciarDados() {
  onValue(ref(db, 'restaurantes'), (snap) => {
    estado.lojas = snap.val() || {};
    aplicar();
    try { renderizarBanners(); } catch (e) { console.warn('Banners:', e); } // V75.154: a logo do banner depende das lojas
    splashPronto('lojas');
  }, () => {
    definirHtml(listaContainer, '<p class="msg-vazio">Não foi possível carregar os restaurantes. Verifique sua conexão.</p>');
    splashPronto('lojas');
  });
  onValue(ref(db, 'lojas'), (snap) => { estado.notas = snap.val() || {}; aplicar(); splashPronto('notas'); }, () => { splashPronto('notas'); });
  // V75.157: a home NÃO lê mais o nó `pedidos`. As regras só permitem ler pedidos com filtro (cliente, dono da loja ou número),
  // então essa leitura sem filtro era sempre negada (milhares de negações por mês) e `estado.pedidos` ficava vazio.
  // O selo YaSUPER depende de contadores por loja (entregues/cancelados) — etapa futura; até lá segue inativo, como já estava.
  onValue(ref(db, 'aviso_app'), (snap) => { estado.aviso = snap.val() || {}; renderizarAvisoApp(); splashPronto('aviso'); }, () => { estado.aviso = {}; renderizarAvisoApp(); splashPronto('aviso'); });
onValue(ref(db, 'banners'), (snap) => { estado.banners = snap.val() || {}; renderizarBanners(); splashPronto('banners'); }, () => { estado.banners = {}; renderizarBanners(); splashPronto('banners'); });
}


function bannerAtivo(b){const agora=Date.now();const inicio=b?.inicio?Date.parse(b.inicio):NaN;const fim=b?.fim?Date.parse(b.fim):NaN;return b?.activo!==false&&(!Number.isFinite(inicio)||agora>=inicio)&&(!Number.isFinite(fim)||agora<=fim)&&!!b?.img;}
function linkBannerSeguro(v){const s=String(v||'').trim();if(!s)return '';if(/^https:\/\//i.test(s))return s;if(/^[a-z0-9_./-]+(?:\?[^ ]*)?$/i.test(s))return s;return ''; }
let bannerSliderTimer=null;
let bannerSliderPaused=false;
let bannerSliderIndex=0;
let ultimoHtmlBanners=null;
function pararSliderBanners(){if(bannerSliderTimer){clearInterval(bannerSliderTimer);bannerSliderTimer=null;}}
function iniciarSliderBanners(){
  pararSliderBanners();
  bannerSliderIndex=0;
  if(!carrosselBanners || carrosselBanners.children.length<=1) return;
  const avancar=()=>{
    if(bannerSliderPaused) return;
    const cards=[...carrosselBanners.querySelectorAll('.banner-card')];
    if(cards.length<=1) return;
    // Parte do banner que está de fato à vista (o cliente também desliza com o dedo) e só anda se o carrossel aparece na tela.
    const pos=cards.map(c=>Math.abs(esquerdaDoCard(carrosselBanners,c)-carrosselBanners.scrollLeft));
    bannerSliderIndex=(pos.indexOf(Math.min(...pos))+1)%cards.length;
    irParaCard(carrosselBanners,cards[bannerSliderIndex]); // só o carrossel anda; a página não rola
  };
  bannerSliderTimer=setInterval(avancar,4500);
}
function renderizarBanners(){
  const sec=$('secao-banners');
  if(!sec||!carrosselBanners)return;
  const rows=Object.entries(estado.banners||{}).map(([id,b])=>({id,...(b||{})})).filter(b=>bannerAtivo(b)).sort((a,b)=>(Number(a.orden)||0)-(Number(b.orden)||0));
  sec.hidden=!rows.length;
  const html=rows.map(b=>{
    // V75.140: chamada "Ver oferta" só quando o banner leva a algum lugar (loja, link ou categoria)
    const acao=(b.targetType==='categoria'&&b.targetCategoryId)||!!linkBannerSeguro(b.link);
    // V75.148: título e descrição são opcionais. Banner só de imagem não leva camada escura, texto nem chamada (o card inteiro continua clicável).
    const temTexto=!!(String(b.titulo||'').trim()||String(b.descripcion||'').trim());
    // V75.154: banner de loja mostra a logo da loja ao lado de um título opcional, SEM fundo; sem loja ou sem logo, tudo igual a antes.
    const lojaB=(()=>{let id=b.lojaId||(b.targetType==='loja'?(String(b.link||'').match(/[?&]id=([^&#]+)/)||[])[1]:'');if(!id)return null;try{id=decodeURIComponent(id);}catch(e){}return estado.lojas?.[id]||null;})();
    const logoB=lojaB&&lojaB.logo?escapeHtml(imgOtimizada(urlSegura(lojaB.logo,IMG_LOJA_PADRAO),120)):'';
    const faixaLoja=logoB?`<div class="banner-loja"><img class="banner-loja-logo" src="${logoB}" alt="${escapeHtml(lojaB.nombre||lojaB.nome||'Loja')}" loading="lazy" onerror="this.remove()"><div class="banner-loja-texto">${b.titulo?`<strong>${escapeHtml(b.titulo)}</strong>`:''}${b.descripcion?`<span>${escapeHtml(b.descripcion)}</span>`:''}${acao&&temTexto?'<span class="banner-cta">Ver oferta →</span>':''}</div></div>`:''; // V75.155: sem título nem descrição, não aparece "Ver oferta"
    const overlay=temTexto?`<div class="banner-overlay">${b.titulo?`<strong>${escapeHtml(b.titulo)}</strong>`:''}${b.descripcion?`<span>${escapeHtml(b.descripcion)}</span>`:''}${acao?'<span class="banner-cta">Ver oferta →</span>':''}</div>`:'';
    const inner=`${tagMidia(b.img,{alt:b.titulo||'Banner promocional',onerror:"this.closest('.banner-card')?.remove()"})}${faixaLoja||overlay}`; // V75.148: imagem, GIF ou vídeo curto
    if(b.targetType==='categoria' && b.targetCategoryId) return `<button type="button" class="banner-card banner-card-action" data-banner-category="${escapeHtml(b.targetCategoryId)}">${inner}</button>`;
    const link=linkBannerSeguro(b.link);
    return link?`<a class="banner-card" href="${escapeHtml(link)}">${inner}</a>`:`<div class="banner-card">${inner}</div>`;
  }).join('');
  if(html===ultimoHtmlBanners) return; // nada mudou (o app redesenha a cada atualização do banco): o carrossel não pode voltar ao início
  ultimoHtmlBanners=html;
  pararSliderBanners();
  carrosselBanners.innerHTML=html;
  carrosselBanners.scrollLeft=0;
  const pontos=$('banner-pontos'); if(pontos) pontos.innerHTML=rows.length>1?rows.map((_,i)=>`<i${i===0?' class="on"':''}></i>`).join(''):'';
  if(rows.length>=2) iniciarSliderBanners();
}
const avisoClose=$('aviso-app-close'); if(avisoClose) avisoClose.addEventListener('click',()=>{const sec=$('aviso-app'); if(sec) sec.hidden=true; const a=estado.aviso||{}; const avisoId=String(a.updatedAt||a.img||a.titulo||'aviso-app'); try{sessionStorage.setItem(`yapood_aviso_feito_${avisoId}`,'1');}catch{}});

if(carrosselBanners){
  carrosselBanners.addEventListener('pointerdown',()=>{bannerSliderPaused=true;});
  carrosselBanners.addEventListener('pointerup',()=>{setTimeout(()=>bannerSliderPaused=false,1200);});
  carrosselBanners.addEventListener('pointercancel',()=>{bannerSliderPaused=false;});
  carrosselBanners.addEventListener('mouseenter',()=>{bannerSliderPaused=true;});
  carrosselBanners.addEventListener('mouseleave',()=>{bannerSliderPaused=false;});
  carrosselBanners.addEventListener('click',(e)=>{
    const target=e.target.closest('[data-banner-category]');
    if(!target) return;
    e.preventDefault();
    const id=target.dataset.bannerCategory||'';
    const cat=estado.categorias.find(c=>c.id===id);
    if(!cat) return;
    estado.categoriaId=id;
    estado.categoria=cat.nombre||'';
    carrosselCategorias?.querySelectorAll('[data-cat-id]').forEach(x=>{
      const on=x.dataset.catId===id; x.classList.toggle('ativa',on); x.setAttribute('aria-pressed',on);
    });
    aplicar();
    irParaLista();
  });
}


function montarLista() {
  renderizarBanners();
  const { pos } = estado;
  const out = [];
  for (const [id, l] of Object.entries(estado.lojas)) {
    if (!l || l.activo === false) continue;
    if (painelCidades && !painelCidades.visivel(l)) continue; // cidade em espera / de outra cidade
    let distancia = null;
    if (pos && l.lat != null && l.lng != null) {
      distancia = calcularDistanciaKm(pos.lat, pos.lng, l.lat, l.lng);
      if (distancia > (l.radioMaximoKm || 50)) continue; // fora da área de entrega
    }
    const agg = estado.notas[id];
    const total = Number(agg?.totalAvaliacoes) || 0;
    const nota = total > 0 ? Number(agg.avaliacaoMedia) : null;
    out.push({ id, ...l, distancia, nota, totalAval: total, status: lojaAberta(l) });
  }
  // Abertas primeiro, depois melhor nota, depois mais perto.
  return out.sort((a, b) =>
    (b.status.aberta - a.status.aberta) || ((b.nota ?? -1) - (a.nota ?? -1)) || ((a.distancia ?? 1e9) - (b.distancia ?? 1e9)));
}

let achadosPorLoja = new Map();
function pratosAchados(l, termo) {
  return Object.entries(l.menu || {})
    .filter(([, i]) => i && i.disponible !== false && normalizarTexto(i.nombre).includes(termo))
    .map(([id, i]) => ({ id, nome: String(i.nombre || ''), preco: Number(i.precio) || 0, img: i.imagen || i.imagem || '' }));
}
function achadosHtml(l) {
  const a = achadosPorLoja.get(l.id) || [];
  if (!a.length) return '';
  const p = a[0];
  const img = p.img ? `<img src="${escapeHtml(imgOtimizada(urlSegura(p.img, ''), 300))}" alt="" loading="lazy">` : '<i class="fa-solid fa-utensils" aria-hidden="true"></i>';
  return `<span class="lc-achou">${img}<span class="lc-achou-txt"><b>${escapeHtml(p.nome)}</b>${p.preco ? ` · ${formatarMoeda(p.preco, l.moeda)}` : ''}</span>${a.length > 1 ? `<span class="lc-achou-mais">+${a.length - 1}</span>` : ''}<span class="lc-achou-ir" aria-hidden="true">›</span></span>`;
}

function aplicar() {
  if (!listaContainer || !estado.pronta) return; // espera a localização para não renderizar duas vezes
  const termo = normalizarTexto(inputBusca?.value || '');
  const base = montarLista();
  painelCidades?.atualizar({ semLojas: base.length === 0 });
  let lojas = base.filter((l) => {
    const cat = categoriaParaLoja(l);
    const passaCategoria = !estado.categoriaId || (cat && cat.id === estado.categoriaId);
    const passaBusca = !termo || normalizarTexto(l.nombre).includes(termo) || normalizarTexto(l.categoria).includes(termo) ||
      Object.values(l.menu || {}).some((i) => normalizarTexto(i.nombre).includes(termo));
    return passaCategoria && passaBusca;
  });
  // V75.142: na busca, cada loja traz os pratos que combinam (aparecem no cartão) e quem tem o nome buscado vem primeiro
  achadosPorLoja = new Map();
  if (termo) {
    lojas.forEach((l) => achadosPorLoja.set(l.id, pratosAchados(l, termo)));
    const peso = (l) => (normalizarTexto(l.nombre).includes(termo) ? 0 : achadosPorLoja.get(l.id).length ? 1 : 2);
    lojas = lojas.map((l, i) => [l, i]).sort((a, b) => peso(a[0]) - peso(b[0]) || a[1] - b[1]).map(([l]) => l);
  }
  if (estado.filtro === 'gratis') lojas = lojas.filter((l) => resumoTaxaLoja(l).algumGratis);
  if (estado.filtro === 'top') lojas = lojas.filter((l) => l.nota !== null && l.nota >= 4.5);
  if (estado.filtro === 'cupones') lojas = lojas.filter((l) => cuponsVigentes(l).length > 0); // V75.133: só cupom valendo hoje
  if (estado.filtro === 'super') lojas = lojas.filter((l) => avaliarSuper(l, pedidosDaLoja(l.id)).elegivel);
  if (estado.filtro === 'perto') lojas = lojas.filter((l) => l.distancia !== null && l.distancia <= RAIO_PERTO_KM);
  if (estado.filtro === 'rapida') lojas = lojas.filter((l) => entregaRapida(l.tiempoEntrega || l.tempoEntrega));
  document.body.classList.toggle('buscando', !!termo);
  renderizar(lojas, base, termo);
}

// V75.132 — o filtro, a categoria e a busca mudam SÓ a lista de baixo; o título diz o que está valendo.
const ROTULO_FILTRO = { gratis: 'Entrega grátis', top: 'Nota 4.5+', cupones: 'Lojas com cupons', super: 'YaSUPER', perto: 'Perto de mim', rapida: 'Entrega rápida' };
function rotuloDaLista(termo) {
  const partes = [];
  if (estado.categoria) partes.push(estado.categoria);
  if (ROTULO_FILTRO[estado.filtro]) partes.push(ROTULO_FILTRO[estado.filtro]);
  if (termo) partes.push(`“${(inputBusca?.value || '').trim().slice(0, 30)}”`);
  return partes.join(' · ');
}
const textoQtd = (n) => `${n} ${n === 1 ? 'restaurante' : 'restaurantes'}`;
function limparFiltros() {
  estado.filtro = 'todos'; estado.categoria = ''; estado.categoriaId = '';
  if (inputBusca) inputBusca.value = '';
  btnLupa?.classList.remove('active');
  document.querySelectorAll('#filtros-chips .chip').forEach((x) => x.classList.toggle('active', x.dataset.filtro === 'todos'));
  carrosselCategorias?.querySelectorAll('[data-cat-id]').forEach((x) => { x.classList.remove('ativa'); x.setAttribute('aria-pressed', 'false'); });
  aplicar();
}
// Botões de filtro grudados embaixo do topo; ao filtrar, a tela vai para o começo da lista com os botões parados lá em cima.
// V75.140: o topo novo não gruda (é alto); os filtros grudam no alto da tela
const topoVitrina = document.querySelector('.header-vitrina:not(.hero-vitrina)');
const chipsEl = document.getElementById('filtros-chips');
function medirTopo() { document.documentElement.style.setProperty('--topo-vitrina', `${topoVitrina ? topoVitrina.offsetHeight : 0}px`); }
medirTopo();
if (topoVitrina && 'ResizeObserver' in window) new ResizeObserver(medirTopo).observe(topoVitrina);
window.addEventListener('scroll', () => {
  if (!chipsEl) return;
  const topo = topoVitrina ? topoVitrina.offsetHeight : 0;
  chipsEl.classList.toggle('grudado', chipsEl.getBoundingClientRect().top <= topo + 1);
}, { passive: true });
function irParaLista() {
  const sec = document.getElementById('secao-lista'); if (!sec) return;
  const topo = (topoVitrina ? topoVitrina.offsetHeight : 0) + (chipsEl ? chipsEl.offsetHeight : 0);
  const y = window.scrollY + sec.getBoundingClientRect().top - topo - 6;
  const reduzir = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  window.scrollTo({ top: Math.max(0, y), behavior: reduzir ? 'auto' : 'smooth' });
}
listaContainer?.addEventListener('click', (e) => { if (e.target.closest('[data-limpar-filtros]')) { limparFiltros(); irParaLista(); } });


function pedidosDaLoja(id) {
  return Object.values(estado.pedidos || {}).filter(p => p && String(p.lojaId || '') === String(id));
}
function entregaRapida(v) {
  const nums = String(v || '').match(/\d+/g)?.map(Number).filter(Number.isFinite) || [];
  if (!nums.length) return false;
  const max = Math.max(...nums);
  return max <= MAX_ENTREGA_RAPIDA_MIN;
}

// V75.133 — cupom discreto no cartão: ticket fininho + valor na cor do app, sem fundo ("10% off", "R$ 10 off")
const TICKET_SVG = '<svg class="ticket-ic" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M3 8a2 2 0 0 0 2-2h14a2 2 0 0 0 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 0-2 2H5a2 2 0 0 0-2-2v-2a2 2 0 0 0 0-4z"/><path d="M14 6v12" stroke-dasharray="2 2"/></svg>';
function etiquetaHtml(l) {
  const e = etiquetaCupom(l);
  if (!e) return '';
  // V75.141 (modelo C): etiqueta branca em cima da foto da loja
  return `<span class="linha-cupom">${TICKET_SVG}<span>${escapeHtml(e.texto)}</span></span>`;
}
/**
 * Troca o conteúdo só se mudou. O banco avisa a cada pedido da plataforma inteira e a vitrine era redesenhada toda vez:
 * o carrossel de destaques voltava para a primeira loja e a página pulava. Quando muda de verdade, mantém a posição do carrossel.
 */
const ultimoHtml = new WeakMap();
function definirHtml(el, html) {
  if (ultimoHtml.get(el) === html) return false;
  ultimoHtml.set(el, html);
  const x = el.scrollLeft;
  el.innerHTML = html;
  if (x) el.scrollLeft = x;
  return true;
}

// V75.141 — cartões do modelo C: foto de capa grande (sem capa: a logo no meio, com fundo borrado da própria logo),
// cupom em etiqueta na foto, nome + selo YaSUPER e "★ nota · tempo · taxa".
function fotoLojaHtml(l) {
  const capa = l.capa ? imgOtimizada(urlSegura(l.capa, ''), 800) : '';  // V75.151: foto no tamanho do cartão
  const logo = escapeHtml(imgOtimizada(urlSegura(l.logo, IMG_LOJA_PADRAO), 200));
  const fechada = l.status.aberta ? '' : `<span class="badge-fechada">${escapeHtml(l.status.motivo)}</span>`;
  // V75.142: com capa, a logo fica num quadradinho por cima da borda da foto (capa + logo, como o cliente reconhece a loja)
  if (capa) return `<span class="lc-foto"><img src="${escapeHtml(capa)}" class="lc-capa" alt="" loading="lazy">${fechada}${etiquetaHtml(l)}</span><img src="${logo}" class="lc-logo" alt="" loading="lazy">`;
  return `<span class="lc-foto sem-capa"><img src="${logo}" class="lc-borrado" alt="" loading="lazy" aria-hidden="true"><img src="${logo}" class="logo-loja-card" alt="" loading="lazy">${fechada}${etiquetaHtml(l)}</span>`;
}
const temCapa = (l) => !!(l.capa && urlSegura(l.capa, ''));
const seloSuperHtml = (l) => (avaliarSuper(l, pedidosDaLoja(l.id)).elegivel ? '<span class="lc-super">YaSUPER</span>' : '');
const notaCurta = (l) => (l.nota !== null
  ? `<span class="star"><i class="fa-solid fa-star"></i> ${l.nota.toFixed(1)}</span>`
  : '<span class="star"><i class="fa-solid fa-star"></i> Novo</span>');
function linhaLojaHtml(l, comKm) {
  const partes = [notaCurta(l), `<span>${escapeHtml(textoTempo(l.tiempoEntrega || l.tempoEntrega))}</span>`, `<span>${precoEnvioHtml(l)}</span>`];
  if (comKm && l.distancia !== null) partes.push(`<span>${l.distancia} km</span>`);
  return partes.join('<span class="dot">·</span>');
}

function renderizar(lojas, base = lojas, termo = '') {

  // V75.132: destaques vêm da lista COMPLETA da cidade (o filtro não faz a seção sumir e a tela não pula)
  const destaques = base.filter((l) => l.nota !== null && l.nota >= 4.0 && l.status.aberta);
  const rotulo = rotuloDaLista(termo);
  const titulo = $('titulo-lista');
  if (titulo) titulo.textContent = rotulo ? `${rotulo} · ${textoQtd(lojas.length)}` : 'Restaurantes disponíveis';
  const sec = $('secao-destaques');
  if (sec) sec.style.display = destaques.length ? 'block' : 'none';
  if (carrosselLojas) {
    definirHtml(carrosselLojas, destaques.map((l) => `
      <button type="button" class="item-loja-destaque lc${temCapa(l) ? ' com-logo' : ''}" data-id="${escapeHtml(l.id)}">
        ${fotoLojaHtml(l)}
        <span class="lc-info"><strong>${escapeHtml(l.nombre)}</strong>${seloSuperHtml(l)}</span>
        <small class="lc-linha">${linhaLojaHtml(l, false)}</small>
      </button>`).join(''));
    mostrarVerTodas();
  }

  if (!lojas.length) {
    definirHtml(listaContainer, painelCidades?.temBanner() ? '' // o aviso de cidade em espera já explica
      : Object.keys(estado.lojas).length
        ? `<div class="msg-vazio lista-vazia"><p>${rotulo ? `Nenhum restaurante em <b>${escapeHtml(rotulo)}</b> por aqui ainda.` : 'Nenhum restaurante corresponde à sua busca.'}</p><button type="button" class="btn-ver-todos" data-limpar-filtros>Ver todos os restaurantes</button></div>`
        : '<p class="msg-vazio">Ainda não há restaurantes disponíveis na sua região.</p>');
    return;
  }

  definirHtml(listaContainer, lojas.map((l) => `
    <button type="button" class="loja-cartao lc${temCapa(l) ? ' com-logo' : ''} ${l.status.aberta ? '' : 'loja-fechada'}" data-id="${escapeHtml(l.id)}"${(achadosPorLoja.get(l.id) || []).length ? ` data-item="${escapeHtml(achadosPorLoja.get(l.id)[0].id)}"` : ''}>
      ${fotoLojaHtml(l)}
      <span class="info-loja-card">
        <span class="linha-titulo"><h4>${escapeHtml(l.nombre)}</h4>${seloSuperHtml(l)}</span>
        <span class="linha-detalhes lc-linha">${linhaLojaHtml(l, true)}</span>
        ${achadosHtml(l)}
      </span>
    </button>`).join(''));
}

// Delegação de eventos: um listener por lista (antes: onclick em cada card).
[listaContainer, carrosselLojas].forEach((el) => el?.addEventListener('click', (e) => {
  const c = e.target.closest('[data-id]'); if (c) irParaLoja(c.dataset.id, c.dataset.item || '');
}));

// ---------- Busca / filtros ----------
inputBusca?.addEventListener('input', debounce(() => {
  estado.categoria = '';
  estado.categoriaId = '';
  carrosselCategorias?.querySelectorAll('.ativa').forEach((x) => x.classList.remove('ativa'));
  btnLupa?.classList.toggle('active', inputBusca.value.trim() !== '');
  const antes = document.body.classList.contains('buscando');
  aplicar();
  // V75.142: buscando, a busca sobe para o alto da tela e os resultados ficam logo abaixo (categorias, banner e destaques somem)
  if (document.body.classList.contains('buscando')) subirParaBusca();
  else if (antes) window.scrollTo({ top: 0, behavior: 'auto' });
}, 180));
function subirParaBusca() {
  const barra = inputBusca?.closest('.search-bar-container'); if (!barra) return;
  const y = Math.max(0, window.scrollY + barra.getBoundingClientRect().top - 10);
  if (Math.abs(window.scrollY - y) < 4) return;
  const reduzir = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  window.scrollTo({ top: y, behavior: reduzir ? 'auto' : 'smooth' });
}
// "Ir" do teclado: fecha o teclado para ver os resultados
inputBusca?.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); inputBusca.blur(); } });
btnLupa?.addEventListener('click', () => { inputBusca?.focus(); aplicar(); });

document.querySelector('.filtros-chips')?.addEventListener('click', (e) => {
  const b = e.target.closest('[data-filtro]'); if (!b) return;
  estado.filtro = b.dataset.filtro;
  document.querySelectorAll('#filtros-chips .chip').forEach((x) => x.classList.toggle('active', x === b));
  aplicar();
  // a fileira não volta ao começo: só garante o botão tocado à vista (sem rolar a página na vertical)
  const c = b.parentElement, esq = b.offsetLeft - c.offsetLeft, dir = esq + b.offsetWidth;
  if (esq < c.scrollLeft) c.scrollTo({ left: esq - 8, behavior: 'smooth' });
  else if (dir > c.scrollLeft + c.clientWidth) c.scrollTo({ left: dir - c.clientWidth + 8, behavior: 'smooth' });
  irParaLista();
});

// ---------- Navegação inferior ----------
// A barra permanece visível para evitar que os botões desapareçam durante a navegação.
// Também permite focar a busca quando o usuário chega de outra página via #input-busca.
if (location.hash === '#input-busca') {
  setTimeout(() => inputBusca?.focus({ preventScroll: true }), 80);
}

// ---------- Boot ----------
prepararNavegacaoBusca();
window.addEventListener('storage', atualizarCarrinhoGlobal);
window.addEventListener('pageshow', atualizarCarrinhoGlobal);
// Tela de carregamento: aguarda os dados da vitrine (a localização tem limite próprio, pois depende de permissão).
splashConfigurar({ imagens: '.header-vitrina img, .container-vitrina img' });
['lojas', 'notas', 'categorias', 'banners', 'aviso'].forEach((n) => splashExigir(n));
splashExigir('local', 4000);
painelCidades = iniciarCidadesCliente({ getLojas: () => estado.lojas, aoMudar: () => aplicar() });
renderizarCategorias();
iniciarCategorias();
if (listaContainer) definirHtml(listaContainer, '<p class="loading"><i class="fa-solid fa-spinner fa-spin"></i> Buscando restaurantes cercanos...</p>');
obterLocalizacao((lat, lng, info) => {
  estado.pos = info.estimada ? null : { lat, lng };
  estado.pronta = true;
  splashPronto('local');
  if (enderecoAtualElem) enderecoAtualElem.textContent = info.estimada ? 'Ative sua localização' : '…';
  if (!info.estimada) obterEnderecoPorCoordenadas(lat, lng, (t, cid) => { mostrarEndereco(t); if (cid?.cidade) painelCidades?.setGps(cid); });
  aplicar();
  atualizarCarrinhoGlobal();
});
iniciarDados();
atualizarCarrinhoGlobal();
splashAguardar();

// V75.140 — topo novo: logo na cor do tema, saudação com o primeiro nome e pontinhos do banner acompanhando o carrossel
onAuthStateChanged(auth, async (user) => {
  const sub = $('hv-sub'); if (!sub) return;
  if (!user) { sub.textContent = 'O que combina com você hoje?'; return; }
  try { const nome = String(await nomeDoCliente(user) || '').trim().split(/\s+/)[0]; sub.textContent = nome ? `O que combina com você hoje, ${nome}?` : 'O que combina com você hoje?'; }
  catch { sub.textContent = 'O que combina com você hoje?'; }
});
carrosselBanners?.addEventListener('scroll', debounce(() => {
  const cards = [...carrosselBanners.querySelectorAll('.banner-card')], pontos = $('banner-pontos');
  if (!pontos || cards.length < 2) return;
  const pos = cards.map((c) => Math.abs(esquerdaDoCard(carrosselBanners, c) - carrosselBanners.scrollLeft));
  const i = pos.indexOf(Math.min(...pos));
  [...pontos.children].forEach((p, k) => p.classList.toggle('on', k === i));
}, 80), { passive: true });
