// V75.99 — aviso antes de o entregador sair do YAPOOD para o Google Maps.
// No Google Maps o YAPOOD deixa de guiar (voz, semáforos, paradas); por isso pedimos uma confirmação curta.
// Qualquer link com data-google passa por aqui; o aviso aparece por cima do mapa e do painel.
const TEXTO = {
  titulo: 'Você está saindo da rota rastreada',
  corpo: 'No Google Maps o YAPOOD deixa de guiar você: a navegação por voz, os semáforos e a ordem das paradas não acompanham. Depois de entregar, volte ao app para informar o código do cliente.',
  sair: 'Abrir Google Maps',
  ficar: 'Continuar no YAPOOD'
};
let aberto = null;

/** Mostra o aviso e devolve uma promessa: true = quer abrir o Google Maps, false = ficou no app. */
export function perguntarSaidaGoogle() {
  if (aberto) return aberto;
  aberto = new Promise((resolve) => {
    const fundo = document.createElement('div'); fundo.className = 'ag-fundo'; fundo.setAttribute('role', 'alertdialog'); fundo.setAttribute('aria-modal', 'true'); fundo.setAttribute('aria-labelledby', 'ag-titulo');
    fundo.innerHTML = '<div class="ag-caixa"><i class="fa-solid fa-triangle-exclamation ag-icone" aria-hidden="true"></i><h3 id="ag-titulo"></h3><p></p><div class="ag-acoes"><button type="button" class="ag-ficar"></button><button type="button" class="ag-sair"></button></div></div>';
    fundo.querySelector('h3').textContent = TEXTO.titulo;
    fundo.querySelector('p').textContent = TEXTO.corpo;
    const ficar = fundo.querySelector('.ag-ficar'), sair = fundo.querySelector('.ag-sair');
    ficar.textContent = TEXTO.ficar; sair.innerHTML = '<i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> ';
    sair.appendChild(document.createTextNode(TEXTO.sair));
    const fechar = (v) => { document.removeEventListener('keydown', tecla); fundo.remove(); aberto = null; resolve(v); };
    const tecla = (e) => { if (e.key === 'Escape') fechar(false); };
    ficar.addEventListener('click', () => fechar(false));
    sair.addEventListener('click', () => fechar(true));
    fundo.addEventListener('click', (e) => { if (e.target === fundo) fechar(false); });
    document.addEventListener('keydown', tecla);
    document.body.appendChild(fundo);
    try { ficar.focus(); } catch { /* noop */ }
  });
  return aberto;
}

/** Pergunta e, se o entregador confirmar, abre o link numa aba nova. */
export async function abrirGoogleComAviso(url) {
  if (!url) return false;
  if (!(await perguntarSaidaGoogle())) return false;
  window.open(url, '_blank', 'noopener');
  return true;
}

// Links <a data-google href="..."> em qualquer tela: interceptados no clique.
document.addEventListener('click', (ev) => {
  const a = ev.target && ev.target.closest && ev.target.closest('a[data-google]');
  if (!a) return;
  ev.preventDefault();
  abrirGoogleComAviso(a.getAttribute('href'));
}, true);
