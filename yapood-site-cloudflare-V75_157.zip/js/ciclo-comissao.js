// V75.60 — Ciclo de 30 dias corridos (a partir do cadastro da loja) para os números de Finanças. Regra pura, sem DOM.
// Dia = calendário de Brasília (UTC-3, sem horário de verão).
const DIA = 86400000, BR = 3 * 3600000;
export const DIAS_CICLO = 30;

export const inicioDoDiaBR = (ms) => Math.floor((ms - BR) / DIA) * DIA + BR;

/** Ciclo que contém `agoraMs`. Ciclo 1 começa no dia do cadastro; cada ciclo tem 30 dias; o seguinte começa no dia 31. */
export function cicloAtual(inicioMs, agoraMs = Date.now(), dias = DIAS_CICLO) {
  const base = Number.isFinite(inicioMs) && inicioMs > 0 && inicioMs <= agoraMs ? inicioMs : agoraMs;
  const a = inicioDoDiaBR(base);
  const n = Math.max(0, Math.floor((inicioDoDiaBR(agoraMs) - a) / DIA / dias));
  const inicio = a + n * dias * DIA, fim = inicio + dias * DIA;
  return { numero: n + 1, inicio, fim, diasRestantes: Math.max(0, Math.ceil((fim - agoraMs) / DIA)) };
}

export const noCiclo = (ms, ciclo) => Number.isFinite(ms) && ms >= ciclo.inicio && ms < ciclo.fim;

const dm = (ms) => new Date(ms - BR).toISOString().slice(0, 10).split('-').reverse().slice(0, 2).join('/');
/** "01/10 a 30/10" */
export const rotuloCiclo = (c) => `${dm(c.inicio)} a ${dm(c.fim - 1)}`;
