// V75.83 — Textos do kit de divulgação por cidade (funções puras, sem DOM). O desenho das imagens está em kit-cidade.js.

const meses = (n) => `${n} ${n === 1 ? 'mês' : 'meses'}`;
const numero = (v, padrao, min, max) => { const n = Number(v); return Number.isInteger(n) && n >= min && n <= max ? n : padrao; };

/** Endereços que os QR Codes e os textos usam. `origem` = endereço do app (ex.: https://yapoodbr.vercel.app). */
export function linksDaCidade(origem, cidadeId) {
  const base = String(origem || '').replace(/\/+$/, '');
  const q = cidadeId ? `?cidade=${encodeURIComponent(cidadeId)}` : '';
  return { cliente: `${base}/index.html${q}`, lojista: `${base}/admin-loja.html${q}` };
}

/**
 * Textos de uma cidade. cidade: { nome, uf, isencaoMeses, meta }; vagas = lojas já cadastradas nela.
 * Devolve { lojista, cliente } — cada um com selo, titulo, sub, bullets, contagem, pct, cta e o texto pronto para WhatsApp.
 */
export function textosDivulgacao({ cidade = {}, vagas = 0, links = {} } = {}) {
  const nome = String(cidade.nome || 'sua cidade').trim();
  const uf = String(cidade.uf || '').trim();
  const rotulo = uf ? `${nome} - ${uf}` : nome;
  const m = numero(cidade.isencaoMeses, 6, 1, 24);
  const meta = numero(cidade.meta, 30, 1, 1000);
  const v = Math.max(0, Math.floor(Number(vagas) || 0));
  const faltam = Math.max(0, meta - v);
  const pct = Math.min(100, Math.round((v / meta) * 100));

  const lojista = {
    selo: 'Lojas fundadoras',
    titulo: `Seja uma loja fundadora em ${nome}`,
    sub: `Cadastre sua loja antes da abertura e fique ${meses(m)} sem comissão.`,
    bullets: [
      `${meses(m)} sem comissão`,
      'Vale para quem cadastra até a abertura',
      'Pix e cartão na sua conta Mercado Pago'
    ],
    contagem: faltam > 0 ? `${v} de ${meta} vagas preenchidas · restam ${faltam}` : `${v} lojas cadastradas · meta batida`,
    pct,
    cta: 'Aponte a câmera e cadastre sua loja',
    link: links.lojista || ''
  };
  lojista.whatsapp = [
    `🍽️ *YAPOOD chegando em ${rotulo}!*`,
    '',
    `Estamos reunindo as primeiras lojas da cidade. Quem se cadastrar antes da abertura fica *${meses(m)} sem comissão*. Quem entrar depois paga a comissão normal.`,
    faltam > 0 ? `Já são ${v} de ${meta} vagas preenchidas.` : `Já são ${v} lojas cadastradas.`,
    '',
    lojista.link ? `Cadastre sua loja: ${lojista.link}` : ''
  ].filter((l, i, a) => l !== '' || (a[i - 1] !== '' && i < a.length - 1)).join('\n').trim();

  const cliente = {
    selo: 'Em breve',
    titulo: `YAPOOD está chegando em ${nome}`,
    sub: 'Restaurantes da sua cidade, com entrega na sua porta.',
    bullets: [],
    chamada: 'Deixe seu WhatsApp e avisamos assim que o YAPOOD abrir.',
    contagem: v === 1 ? '1 restaurante já se cadastrou' : `${v} restaurantes já se cadastraram`,
    pct,
    cta: 'Aponte a câmera e peça para ser avisado',
    link: links.cliente || ''
  };
  cliente.whatsapp = [
    `🛵 *YAPOOD está chegando em ${rotulo}!*`,
    '',
    'Restaurantes da sua cidade, com entrega na sua porta. Deixe seu WhatsApp e avisamos assim que abrir.',
    '',
    cliente.link ? `Quero ser avisado: ${cliente.link}` : ''
  ].join('\n').trim();

  return { rotulo, lojista, cliente };
}

/** Quebra o texto em linhas que cabem em `largura`, usando `medir(texto)` (largura em px). Palavra maior que a linha fica sozinha. */
export function quebrarLinhas(medir, texto, largura) {
  const palavras = String(texto ?? '').split(/[ \t\r\n]+/).filter(Boolean); // só espaço comum quebra: o espaço sem quebra (nbsp) segura "6 meses"
  const linhas = [];
  let atual = '';
  for (const p of palavras) {
    const tenta = atual ? `${atual} ${p}` : p;
    if (!atual || medir(tenta) <= largura) atual = tenta;
    else { linhas.push(atual); atual = p; }
  }
  if (atual) linhas.push(atual);
  return linhas;
}

/** Mantém número e unidade na mesma linha ("6 meses", "12 vagas"), trocando o espaço por espaço sem quebra. */
export const juntarNumeros = (txt) => String(txt ?? '').replace(/(\d) (m[eê]s(?:es)?|vagas?|lojas?|restaurantes?)/g, '$1\u00a0$2');

/** Quebra em linhas mais equilibradas: mesmo número de linhas de `quebrarLinhas`, mas sem deixar uma palavra sozinha na última. */
export function quebrarEquilibrado(medir, texto, largura) {
  const base = quebrarLinhas(medir, texto, largura);
  if (base.length < 2) return base;
  let lo = largura * 0.45, hi = largura, melhor = base;
  for (let i = 0; i < 14; i++) {
    const meio = (lo + hi) / 2, l = quebrarLinhas(medir, texto, meio);
    if (l.length <= base.length) { melhor = l; hi = meio; } else lo = meio;
  }
  return melhor.length === base.length ? melhor : base;
}

/** "Uberlândia" -> "uberlandia" (para hashtags). */
export const semAcento = (t) => String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');

/**
 * Carrossel "Como funciona" (5 telas por público) + legenda pronta para o post.
 * Cada tela: { tipo: 'capa' | 'passo' | 'fim', ... }. O desenho está em kit-cidade.js.
 */
export function textosCarrossel({ cidade = {}, vagas = 0, links = {} } = {}) {
  const base = textosDivulgacao({ cidade, vagas, links });
  const nome = String(cidade.nome || 'sua cidade').trim();
  const m = numero(cidade.isencaoMeses, 6, 1, 24);
  const tag = semAcento(nome);
  const tags = (...extra) => ['#yapood', tag ? `#${tag}` : '', ...extra].filter(Boolean).join(' ');

  const lojista = {
    legenda: [
      `Como funciona o YAPOOD para a sua loja em ${nome} 👇`,
      '',
      '1️⃣ Você cadastra a loja pelo celular',
      '2️⃣ Recebe os pedidos e aceita Pix e cartão',
      '3️⃣ Acompanha cada entrega pelo painel',
      '',
      `Quem se cadastra antes da abertura fica ${meses(m)} sem comissão. ${base.lojista.contagem}.`,
      base.lojista.link ? `Cadastre sua loja: ${base.lojista.link}` : 'Link do cadastro na bio.',
      '',
      tags('#delivery', '#restaurantes', '#empreendedorismo')
    ].join('\n'),
    telas: [
      { tipo: 'capa', selo: 'Como funciona', titulo: 'Sua loja no YAPOOD em 3 passos', sub: `Para lojistas de ${nome}. Deslize e veja como é simples.` },
      { tipo: 'passo', n: 1, icone: 'loja', titulo: 'Cadastre sua loja', sub: 'Pelo celular, em poucos minutos: nome, fotos, cardápio e horários.' },
      { tipo: 'passo', n: 2, icone: 'celular', titulo: 'Receba os pedidos', sub: 'Você é avisado na hora. Pix e cartão caem na sua conta Mercado Pago.' },
      { tipo: 'passo', n: 3, icone: 'pino', titulo: 'Entregue e acompanhe', sub: 'Veja cada pedido e cada entrega pelo painel da loja.' },
      { tipo: 'fim', selo: 'Lojas fundadoras', titulo: `${meses(m)} sem comissão`, sub: 'Para quem cadastrar a loja antes da abertura.', contagem: base.lojista.contagem, pct: base.lojista.pct, cta: base.lojista.cta, link: base.lojista.link }
    ]
  };
  const cliente = {
    legenda: [
      `Como vai ser pedir no YAPOOD em ${nome} 👇`,
      '',
      '1️⃣ Escolha o restaurante',
      '2️⃣ Peça e pague do seu jeito',
      '3️⃣ Acompanhe até chegar na sua porta',
      '',
      'Quer ser avisado quando abrir? Deixe seu WhatsApp pelo link.',
      base.cliente.link ? base.cliente.link : 'Link na bio.',
      '',
      tags('#delivery', '#comida', '#pedirnoapp')
    ].join('\n'),
    telas: [
      { tipo: 'capa', selo: 'Em breve', titulo: `Pedir no YAPOOD em ${nome} é simples`, sub: 'São só 3 passos. Deslize e veja.' },
      { tipo: 'passo', n: 1, icone: 'loja', titulo: 'Escolha o restaurante', sub: 'Veja os restaurantes da sua cidade e o cardápio completo.' },
      { tipo: 'passo', n: 2, icone: 'moeda', titulo: 'Peça e pague', sub: 'Pix, cartão ou dinheiro: você escolhe como pagar.' },
      { tipo: 'passo', n: 3, icone: 'pino', titulo: 'Receba em casa', sub: 'Acompanhe o pedido pelo app até chegar na sua porta.' },
      { tipo: 'fim', selo: 'Em breve', titulo: `Avisamos quando abrir em ${nome}`, sub: base.cliente.chamada, contagem: base.cliente.contagem, pct: base.cliente.pct, cta: base.cliente.cta, link: base.cliente.link }
    ]
  };
  return { lojista, cliente };
}
