// V75.18 — Rota única no Google Maps para entregador com mais de uma entrega (front, sem backend).
// O Maps traça do ponto onde o entregador está até a última parada, passando pelas anteriores, na ordem da lista.
export const MAX_PARADAS = 10; // limite do link do Google Maps: 9 paradas intermediárias + destino

const limpo = (s) => String(s ?? '').replace(/\s+/g, ' ').trim();

// Mantém a ordem salva pelo entregador; paradas novas entram no fim, na ordem original (ordem de atribuição).
export function ordenarParadas(paradas, ordemSalva = []) {
  const porId = new Map(paradas.map((p) => [p.id, p]));
  const conhecidas = (Array.isArray(ordemSalva) ? ordemSalva : []).filter((id) => porId.has(id));
  const resto = paradas.filter((p) => !conhecidas.includes(p.id));
  return [...conhecidas.map((id) => porId.get(id)), ...resto];
}

export function moverParada(ids, id, delta) {
  const i = ids.indexOf(id), j = i + delta;
  if (i < 0 || j < 0 || j >= ids.length) return ids.slice();
  const novo = ids.slice();
  [novo[i], novo[j]] = [novo[j], novo[i]];
  return novo;
}

// enderecos já na ordem de visita. Devolve null se não houver endereço utilizável.
export function urlRota(enderecos) {
  const lista = (enderecos || []).map(limpo).filter(Boolean);
  if (!lista.length) return null;
  const usadas = lista.slice(0, MAX_PARADAS);
  const destino = usadas[usadas.length - 1];
  const meio = usadas.slice(0, -1);
  let url = 'https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=' + encodeURIComponent(destino);
  if (meio.length) url += '&waypoints=' + meio.map(encodeURIComponent).join('%7C');
  return { url, usadas: usadas.length, ignoradas: lista.length - usadas.length };
}
