// js/master-limites.js — V75.151: "Limites e planos" (Master). Semáforo de uso dos planos grátis e "em quantas lojas migrar".
// O navegador NÃO consegue ler o consumo real do Firebase/Vercel/Render (só o painel de cada um mostra). Por isso:
//  • o que dá para MEDIR aqui (tamanho dos dados, pedidos, fotos do Cloudinary pela API) é medido;
//  • o resto é ESTIMADO a partir disso, e cada medidor tem um campo para o Master digitar o número real do painel do serviço.
// Cálculos puros ficam nas funções exportadas (testadas em tests/master-limites.test.mjs); a tela vem no fim do arquivo.
import { tamanho } from './master-faxina.js?v=75.120';

export const CONFERIDO_EM = '16/10/2026';           // data em que os limites abaixo foram conferidos nos sites oficiais
export const LIMITE = { fbArmazMB: 1024, fbBaixadoGB: 10, fbConexoes: 100, clCreditos: 25, vcGB: 100, vcRequisicoes: 1_000_000, rdHoras: 750 };
export const FAIXAS = { amarelo: 0.6, vermelho: 0.85 }; // até 60% verde · 60–85% amarelo · 85% ou mais vermelho
export const ABERTURAS_POR_PEDIDO = 10;   // estimativa: quantas aberturas do app existem para cada pedido feito (troque pelo número real)
export const REQUISICOES_POR_ABERTURA = 45; // arquivos que a tela inicial pede (31 módulos + CSS + HTML + ícones)
export const KB_POR_ABERTURA = 150;        // tráfego médio do site por abertura (a maioria volta do cache do aparelho)
export const MESES_HISTORICO = 12;         // quantos meses de pedidos o banco guarda, para calcular o espaço
export const COLCHAO = 0.8;                // migrar ao chegar em 80% da capacidade estimada, nunca em cima do limite
export const PARTE_CLOUDINARY_FOTOS = 0.5; // metade dos créditos para guardar fotos; a outra metade fica para banda/transformações

export const PRECOS = [
  { id: 'firebase', nome: 'Firebase (banco de dados)', gratis: '1 GB guardado · 10 GB baixados por mês · 100 conexões ao mesmo tempo', pago: 'Plano Blaze: mantém o grátis e cobra só o que passar (US$ 5 por GB guardado, US$ 1 por GB baixado; até 200 mil conexões).', onde: 'https://console.firebase.google.com/project/yapoodbr-delivery/usage' },
  { id: 'cloudinary', nome: 'Cloudinary (fotos)', gratis: '25 créditos por mês (1 crédito = 1 GB guardado, ou 1 GB de banda, ou mil transformações)', pago: 'Plano Plus, a partir de cerca de US$ 89 por mês (225 créditos). No grátis o Cloudinary avisa e pede upgrade ao passar.', onde: 'https://console.cloudinary.com/' },
  { id: 'vercel', nome: 'Vercel (hospedagem do app)', gratis: 'Hobby: 100 GB de tráfego e 1 milhão de requisições por mês. Uso COMERCIAL não é permitido no Hobby.', pago: 'Plano Pro: US$ 20 por usuário por mês (1 TB de tráfego, uso comercial liberado).', onde: 'https://vercel.com/dashboard' },
  { id: 'render', nome: 'Render (APIs de pagamento e de avisos)', gratis: '750 horas por mês somando todos os serviços grátis; o serviço dorme após 15 min parado e leva cerca de 30 a 50 s para acordar.', pago: 'A partir de cerca de US$ 7 por mês por serviço (fica sempre ligado, sem demora para acordar).', onde: 'https://dashboard.render.com/' }
];

// ---------- cálculos puros ----------
export const corDoUso = (pct) => (pct == null || !Number.isFinite(pct) ? 'cinza' : pct >= FAIXAS.vermelho ? 'vermelho' : pct >= FAIXAS.amarelo ? 'amarelo' : 'verde');
export const ROTULO_COR = { verde: 'Verde · tranquilo', amarelo: 'Amarelo · atenção', vermelho: 'Vermelho · perto do limite', cinza: 'Sem dado ainda' };
const GRAVIDADE = { cinza: 0, verde: 1, amarelo: 2, vermelho: 3 };
export const piorCor = (cores) => (cores || []).reduce((p, c) => (GRAVIDADE[c] > GRAVIDADE[p] ? c : p), 'cinza');
const bytes = (v) => new TextEncoder().encode(JSON.stringify(v ?? null)).length;
const num = (v) => (v === '' || v == null ? null : Number.isFinite(Number(v)) && Number(v) >= 0 ? Number(v) : null);
const tempo = (v) => (typeof v === 'number' ? v : Date.parse(String(v || '')));

/** Mede o que o Master já tem carregado: lojas, produtos, pedidos (os mais recentes) e usuários. */
export function medir({ lojas = {}, pedidos = [], usuarios = {}, usuariosOk = true } = {}) {
  const lista = Object.values(lojas || {});
  const nLojas = lista.length;
  const nProdutos = lista.reduce((s, l) => s + Object.keys((l && l.menu) || {}).length, 0);
  const bytesLojas = bytes(lojas);
  const nPedidos = pedidos.length;
  const bytesPedido = nPedidos ? Math.round(bytes(pedidos) / nPedidos) : 0;
  const ts = pedidos.map((p) => tempo(p?.criadoEm ?? p?.dataCriacao ?? p?.createdAt)).filter(Number.isFinite);
  const dias = ts.length > 1 ? Math.max(1, (Math.max(...ts) - Math.min(...ts)) / 864e5) : 1;
  const pedidosDia = nPedidos ? nPedidos / dias : 0;
  return { nLojas, nProdutos, bytesLojas, bytesPorLoja: nLojas ? Math.round(bytesLojas / nLojas) : 0, bytesUsuarios: usuariosOk ? bytes(usuarios) : 0, nPedidos, bytesPedido, pedidosDia, pedidosMes: Math.round(pedidosDia * 30) };
}

export function aberturasDoMes(m, prem = {}) {
  const digitado = num(prem.aberturasMes);
  return digitado != null ? { valor: digitado, origem: 'digitado' } : { valor: Math.round(m.pedidosMes * ABERTURAS_POR_PEDIDO), origem: 'estimado' };
}

const GB = 1024 ** 3, MB = 1024 ** 2;
function medidor(def, prem, estimativa) {
  const digitado = num(prem[def.campo]);
  const usado = digitado != null ? digitado : estimativa?.valor ?? null;
  const origem = digitado != null ? 'digitado' : estimativa ? estimativa.origem : 'sem dado';
  const pct = usado != null ? usado / def.limite : null;
  return { ...def, usado, origem, pct, cor: corDoUso(pct), texto: estimativa?.texto || '' };
}

/** Os 7 medidores do semáforo. `prem` = números digitados/medidos pelo Master (config_plataforma/limites). */
export function medidores(m, prem = {}) {
  const ab = aberturasDoMes(m, prem);
  const clGB = num(prem.clGB);
  const armazMB = (m.bytesLojas + m.bytesUsuarios + m.bytesPedido * m.nPedidos) / MB;
  const baixGB = (ab.valor * m.bytesLojas) / GB;
  const M = (def, est) => medidor(def, prem, est);
  return [
    M({ id: 'fbArmaz', campo: 'fbArmazMB', grupo: 'Firebase', titulo: 'Banco de dados · espaço guardado', unidade: 'MB', limite: LIMITE.fbArmazMB, onde: 'Firebase → Realtime Database → Uso' },
      { valor: Math.round(armazMB * 100) / 100, origem: 'estimado', texto: 'Soma de lojas + usuários + pedidos recentes. Avaliações, cupons e pedidos antigos não entram: confira no Console.' }),
    M({ id: 'fbBaixado', campo: 'fbBaixadoGB', grupo: 'Firebase', titulo: 'Banco de dados · baixado no mês', unidade: 'GB', limite: LIMITE.fbBaixadoGB, onde: 'Firebase → Realtime Database → Uso → Downloads' },
      { valor: Math.round(baixGB * 100) / 100, origem: ab.origem, texto: 'Cada abertura do app baixa a lista completa de lojas e cardápios.' }),
    M({ id: 'fbConexoes', campo: 'fbConexoes', grupo: 'Firebase', titulo: 'Banco de dados · conexões ao mesmo tempo', unidade: '', limite: LIMITE.fbConexoes, onde: 'Firebase → Realtime Database → Uso → Conexões (pico)' }, null),
    M({ id: 'clCreditos', campo: 'clCreditos', grupo: 'Cloudinary', titulo: 'Fotos · créditos do mês', unidade: 'créditos', limite: LIMITE.clCreditos, onde: 'Cloudinary → Dashboard → Usage' },
      clGB != null ? { valor: Math.round(clGB * 100) / 100, origem: 'medido', texto: 'Só o espaço guardado (1 GB = 1 crédito). Some a banda e as transformações do painel do Cloudinary.' } : null),
    M({ id: 'vcGB', campo: 'vcGB', grupo: 'Vercel', titulo: 'Hospedagem · tráfego do mês', unidade: 'GB', limite: LIMITE.vcGB, onde: 'Vercel → Usage → Fast Data Transfer' },
      { valor: Math.round(((ab.valor * KB_POR_ABERTURA * 1024) / GB) * 100) / 100, origem: ab.origem, texto: `Estimado em ${KB_POR_ABERTURA} KB por abertura.` }),
    M({ id: 'vcReq', campo: 'vcRequisicoes', grupo: 'Vercel', titulo: 'Hospedagem · requisições do mês', unidade: '', limite: LIMITE.vcRequisicoes, onde: 'Vercel → Usage → Edge Requests' },
      { valor: ab.valor * REQUISICOES_POR_ABERTURA, origem: ab.origem, texto: `Estimado em ${REQUISICOES_POR_ABERTURA} arquivos por abertura.` }),
    M({ id: 'rdHoras', campo: 'rdHoras', grupo: 'Render', titulo: 'APIs · horas ligadas no mês', unidade: 'horas', limite: LIMITE.rdHoras, onde: 'Render → Billing → Free instance hours' }, null)
  ];
}

/** Em quantas lojas cada recurso acaba. Cada pessoa que abre o app baixa TODAS as lojas, então o download cresce com o QUADRADO das lojas. */
export function capacidade(m, prem = {}) {
  const n = m.nLojas, ab = aberturasDoMes(m, prem).valor;
  const porLoja = n && ab ? ab / n : 0;
  const itens = [];
  const add = (id, titulo, lojas, como) => itens.push({ id, titulo, lojas: Number.isFinite(lojas) && lojas > 0 ? Math.floor(lojas) : null, como });
  if (porLoja && m.bytesPorLoja) add('fbBaixado', 'Firebase · download (10 GB/mês)', Math.sqrt((LIMITE.fbBaixadoGB * GB) / (porLoja * m.bytesPorLoja)), 'cada visita baixa todas as lojas: mais lojas = mais gente × mais dados por pessoa');
  if (n && m.bytesPorLoja) {
    const porLojaAno = m.bytesPorLoja + m.bytesUsuarios / n + (m.pedidosMes / n) * MESES_HISTORICO * m.bytesPedido;
    add('fbArmaz', `Firebase · espaço (1 GB, ${MESES_HISTORICO} meses de pedidos)`, (LIMITE.fbArmazMB * MB) / porLojaAno, 'lojas, usuários e pedidos acumulados');
  }
  if (porLoja) {
    add('vcReq', 'Vercel · requisições (1 milhão/mês)', LIMITE.vcRequisicoes / (porLoja * REQUISICOES_POR_ABERTURA), 'cresce em linha reta com as aberturas');
    add('vcGB', 'Vercel · tráfego (100 GB/mês)', (LIMITE.vcGB * GB) / (porLoja * KB_POR_ABERTURA * 1024), 'cresce em linha reta com as aberturas');
  }
  const clGB = num(prem.clGB);
  if (n && clGB) add('clCreditos', 'Cloudinary · fotos (metade dos 25 créditos)', (LIMITE.clCreditos * PARTE_CLOUDINARY_FOTOS) / (clGB / n), 'espaço por loja; a outra metade fica para banda');
  const validos = itens.filter((i) => i.lojas);
  const aperta = validos.reduce((p, i) => (!p || i.lojas < p.lojas ? i : p), null);
  return { itens, limitante: aperta, migrarEm: aperta ? Math.max(1, Math.floor(aperta.lojas * COLCHAO)) : null };
}

/** Avisos que valem sempre, independente de número. */
export function avisosFixos() {
  return [
    { cor: 'vermelho', titulo: 'Vercel Hobby não permite uso comercial', texto: 'O plano grátis da Vercel é só para uso pessoal. Um app que vende e cobra entra como comercial: o plano Pro (US$ 20/mês) é o correto assim que o YAPOOD operar de verdade.' },
    { cor: 'amarelo', titulo: 'As APIs no Render grátis dormem', texto: 'Após 15 minutos sem uso a API dorme e a primeira chamada demora de 30 a 50 s (pagamento e avisos). Deixar as duas ligadas o mês todo gasta cerca de 1.488 horas, acima das 750 grátis: o Render suspende os serviços. Para pagamento real, use o plano pago (cerca de US$ 7/mês por API).' },
    { cor: 'amarelo', titulo: 'Mapas e endereços usam serviços públicos', texto: 'O app usa serviços abertos gratuitos (Nominatim/OpenStreetMap, Photon, OpenFreeMap, BrasilAPI) que não têm garantia e pedem uso leve. Com muito movimento, troque por um serviço de mapas com plano pago.' }
  ];
}

export function resumoGeral(medidos, cap) {
  const cor = piorCor(medidos.map((x) => x.cor));
  return { cor, migrarEm: cap.migrarEm, limitante: cap.limitante };
}

// ---------- tela ----------
const ESTILO = `
.lim-topo{display:flex;gap:14px;align-items:center;padding:14px;border-radius:14px;border:1px solid var(--m-borda,#e5e5e5);margin-bottom:14px}
.lim-topo>div>b{display:block;font-size:1.05rem}.lim-topo small{color:#666;display:block;line-height:1.4}
.lim-bola{width:42px;height:42px;border-radius:50%;flex:none;display:grid;place-items:center;color:#fff;font-size:1.1rem}
.lim-verde{background:#1f9d55}.lim-amarelo{background:#e0a100}.lim-vermelho{background:#d64545}.lim-cinza{background:#8a8a8a}
.lim-grupo{margin:16px 0 6px;font-weight:700;font-size:.8rem;letter-spacing:.06em;text-transform:uppercase;color:#777}
.lim-card{border:1px solid var(--m-borda,#e5e5e5);border-radius:12px;padding:12px;margin-bottom:8px}
.lim-linha{display:flex;justify-content:space-between;gap:8px;align-items:baseline;flex-wrap:wrap}
.lim-linha strong{font-size:.95rem}.lim-num{font-variant-numeric:tabular-nums;font-size:.9rem}
.lim-barra{height:10px;border-radius:99px;background:#eee;overflow:hidden;margin:8px 0 6px}
.lim-barra i{display:block;height:100%;border-radius:99px;min-width:3px}
.lim-meta{font-size:.78rem;color:#666;line-height:1.35}
.lim-tag{display:inline-block;font-size:.68rem;padding:1px 7px;border-radius:99px;background:#f0f0f0;color:#555;margin-left:6px}
.lim-aviso{border-left:5px solid;border-radius:10px;padding:10px 12px;margin-bottom:8px;background:#fafafa;font-size:.88rem;line-height:1.4}
.lim-aviso.lim-b-vermelho{border-color:#d64545}.lim-aviso.lim-b-amarelo{border-color:#e0a100}
.lim-aviso b{display:block;margin-bottom:2px}
.lim-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;margin:10px 0}
.lim-form label{font-size:.82rem;display:grid;gap:3px}.lim-form small{color:#777;font-size:.72rem}
.lim-form input{padding:9px;border:1px solid #ccc;border-radius:8px;font:inherit;width:100%;box-sizing:border-box}
.lim-acoes{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
.lim-tab{width:100%;border-collapse:collapse;font-size:.85rem}.lim-tab td{padding:7px 4px;border-top:1px solid #eee;vertical-align:top}.lim-tab td:last-child{text-align:right;white-space:nowrap}
.lim-preco{font-size:.85rem;line-height:1.4;margin-bottom:10px}.lim-preco b{display:block}
`;
const CAMPOS = [
  ['aberturasMes', 'Aberturas do app por mês (todas as pessoas)', 'Se deixar vazio, estimo pelos pedidos (10 aberturas por pedido).'],
  ['fbArmazMB', 'Firebase · espaço usado (MB)', 'Console → Realtime Database → Uso'],
  ['fbBaixadoGB', 'Firebase · baixado no mês (GB)', 'Console → Realtime Database → Uso'],
  ['fbConexoes', 'Firebase · pico de conexões', 'Console → Realtime Database → Uso'],
  ['clCreditos', 'Cloudinary · créditos usados no mês', 'Cloudinary → Dashboard → Usage'],
  ['vcGB', 'Vercel · tráfego no mês (GB)', 'Vercel → Usage → Fast Data Transfer'],
  ['vcRequisicoes', 'Vercel · requisições no mês', 'Vercel → Usage → Edge Requests'],
  ['rdHoras', 'Render · horas grátis usadas', 'Render → Billing']
];
const ICONE = { verde: 'fa-circle-check', amarelo: 'fa-triangle-exclamation', vermelho: 'fa-circle-exclamation', cinza: 'fa-circle-question' };
const COR_HEX = { verde: '#1f9d55', amarelo: '#e0a100', vermelho: '#d64545', cinza: '#8a8a8a' };
const API = 'https://api-mp-yapoodbr.onrender.com';
const fmt = (n, d = 0) => (n == null ? '—' : Number(n).toLocaleString('pt-BR', { maximumFractionDigits: d }));

export function iniciarLimitesMaster(ctx) {
  const { $, esc, aviso, executar, logar, auth, dados, salvar } = ctx;
  const raiz = $('limites-raiz');
  if (!raiz) return { render() {} };
  if (!document.getElementById('limites-estilo')) { const st = document.createElement('style'); st.id = 'limites-estilo'; st.textContent = ESTILO; document.head.appendChild(st); }
  let medindoFotos = false;

  const cartao = (x) => {
    const pct = x.pct == null ? 0 : Math.min(100, x.pct * 100);
    const usado = x.usado == null ? 'sem dado' : `${fmt(x.usado, x.usado < 10 ? 2 : 0)} de ${fmt(x.limite)} ${x.unidade}`.trim();
    return `<div class="lim-card"><div class="lim-linha"><strong>${esc(x.titulo)}<span class="lim-tag">${esc(x.origem)}</span></strong><span class="lim-num"><i class="fa-solid ${ICONE[x.cor]}" style="color:${COR_HEX[x.cor]}" aria-hidden="true"></i> ${esc(ROTULO_COR[x.cor].split(' · ')[0])}${x.pct != null ? ` · ${fmt(x.pct * 100)}%` : ''}</span></div>
      <div class="lim-barra" role="img" aria-label="${esc(x.titulo)}: ${fmt(pct)}% do limite"><i class="lim-${x.cor}" style="width:${pct}%"></i></div>
      <div class="lim-meta">${esc(usado)}${x.texto ? ` · ${esc(x.texto)}` : ''}<br>Onde ver o número real: ${esc(x.onde)}</div></div>`;
  };

  // Dados novos chegam o tempo todo (pedidos, lojas…): não redesenha enquanto o Master digita num campo.
  function render() { if (raiz.contains(document.activeElement) && document.activeElement.matches('input')) return; desenhar(); }

  function desenhar() {
    const d = dados();
    const m = medir(d.base), prem = d.prem || {};
    const med = medidores(m, prem), cap = capacidade(m, prem), geral = resumoGeral(med, cap);
    const grupos = [...new Set(med.map((x) => x.grupo))];
    const quem = `${fmt(m.nLojas)} ${m.nLojas === 1 ? 'loja' : 'lojas'}`;
    const topoTxt = !cap.migrarEm ? `Hoje: <b>${quem}</b>. Faltam pedidos ou lojas para estimar; digite os números abaixo.`
      : m.nLojas >= cap.limitante.lojas ? `Hoje: <b>${quem}</b>. Pelos seus números, <b>${esc(cap.limitante.titulo)}</b> já passou do limite (acabaria com ~${fmt(cap.limitante.lojas)} lojas). Hora de contratar o plano pago.`
      : m.nLojas >= cap.migrarEm ? `Hoje: <b>${quem}</b>. Está perto: <b>${esc(cap.limitante.titulo)}</b> acaba com ~${fmt(cap.limitante.lojas)} lojas. Hora de planejar o plano pago.`
      : `Hoje: <b>${quem}</b>. Planeje o plano pago ao chegar perto de <b>${fmt(cap.migrarEm)} lojas</b> (o que aperta primeiro: ${esc(cap.limitante.titulo)}).`;
    const peso = m.bytesLojas;
    raiz.innerHTML = `
      <div class="lim-topo"><span class="lim-bola lim-${geral.cor}"><i class="fa-solid ${ICONE[geral.cor]}" aria-hidden="true"></i></span><div><b>${esc(ROTULO_COR[geral.cor])}</b><small>${topoTxt}</small></div></div>
      ${med.length ? grupos.map((g) => `<div class="lim-grupo">${esc(g)}</div>${med.filter((x) => x.grupo === g).map(cartao).join('')}`).join('') : ''}
      <div class="lim-grupo">Atenção permanente</div>
      ${avisosFixos().map((a) => `<div class="lim-aviso lim-b-${a.cor}"><b>${esc(a.titulo)}</b>${esc(a.texto)}</div>`).join('')}
      <div class="lim-grupo">Em quantas lojas cada limite acaba</div>
      <div class="lim-card">${cap.itens.length ? `<table class="lim-tab"><tbody>${cap.itens.map((i) => `<tr><td>${esc(i.titulo)}<br><span class="lim-meta">${esc(i.como)}</span></td><td>${i.lojas ? `~${fmt(i.lojas)} lojas` : '—'}</td></tr>`).join('')}</tbody></table><p class="lim-meta">Conta com a média de hoje (${fmt(m.nLojas)} lojas, ${fmt(m.pedidosMes)} pedidos/mês). Migrar ao chegar em ${Math.round(COLCHAO * 100)}% do que aperta primeiro. É estimativa: refaça quando os números mudarem.</p>` : '<p class="lim-meta">Sem lojas ou aberturas suficientes para calcular.</p>'}</div>
      <div class="lim-grupo">Peso da tela inicial</div>
      <div class="lim-card"><div class="lim-linha"><strong>Lista de lojas baixada a cada abertura do app</strong><span class="lim-num">${esc(tamanho(peso))}</span></div><div class="lim-meta">${fmt(m.nLojas)} lojas e ${fmt(m.nProdutos)} produtos, sem compressão. Quanto maior, mais lenta é a abertura no celular e mais cota do Firebase se gasta.</div></div>
      <div class="lim-grupo">Seus números (do painel de cada serviço)</div>
      <div class="lim-form">${CAMPOS.map(([k, rot, dica]) => `<label>${esc(rot)}<input type="number" min="0" step="any" inputmode="decimal" data-lim="${k}" value="${prem[k] != null ? esc(String(prem[k])) : ''}"><small>${esc(dica)}</small></label>`).join('')}</div>
      <div class="lim-acoes"><button type="button" class="m-btn m-btn-principal" id="lim-salvar"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar números</button>
      <button type="button" class="m-btn m-btn-leve" id="lim-fotos" ${medindoFotos ? 'disabled' : ''}><i class="fa-solid fa-cloud" aria-hidden="true"></i> ${medindoFotos ? 'Medindo…' : 'Medir fotos no Cloudinary'}</button></div>
      <p class="lim-meta">${prem.clGB != null ? `Fotos no Cloudinary: ${esc(fmt(prem.clGB, 2))} GB${prem.clMedidoEm ? ` (medido em ${esc(new Date(prem.clMedidoEm).toLocaleDateString('pt-BR'))})` : ''}, incluindo imagens de outros projetos da mesma conta.` : 'Medir fotos usa a API do Render e pode demorar se ela estiver dormindo.'}</p>
      <div class="lim-grupo">Quando pagar (conferido em ${CONFERIDO_EM})</div>
      ${PRECOS.map((p) => `<div class="lim-preco"><b>${esc(p.nome)}</b>Grátis: ${esc(p.gratis)}<br>Pago: ${esc(p.pago)}<br><a href="${esc(p.onde)}" target="_blank" rel="noopener noreferrer">Abrir painel de uso</a></div>`).join('')}
      <p class="lim-meta">Preços e limites mudam: confira nos sites antes de contratar.</p>`;
  }

  const lerCampos = () => {
    const out = {};
    raiz.querySelectorAll('[data-lim]').forEach((i) => { const v = num(i.value); if (v != null) out[i.dataset.lim] = v; });
    return out;
  };
  raiz.addEventListener('click', async (e) => {
    if (e.target.closest('#lim-salvar')) {
      const atual = dados().prem || {};
      const novo = { ...lerCampos() };
      if (atual.clGB != null) { novo.clGB = atual.clGB; if (atual.clMedidoEm) novo.clMedidoEm = atual.clMedidoEm; }
      const ok = await executar(() => salvar(novo), 'Números salvos.');
      if (ok) { await logar('limites.salvar', 'Limites e planos', Object.keys(novo).join(', ')); desenhar(); }
    }
    if (e.target.closest('#lim-fotos') && !medindoFotos) {
      medindoFotos = true; desenhar();
      const ok = await executar(async () => {
        const token = await auth?.currentUser?.getIdToken();
        if (!token) throw new Error('Sessão Master não encontrada. Entre novamente.');
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 120000);
        try {
          const r = await fetch(`${API}/imagens/faxina/previa`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: '{}', signal: ctl.signal });
          const j = await r.json().catch(() => ({}));
          if (!r.ok || !Number.isFinite(Number(j.bytesTotal))) throw new Error(j.erro || j.error || 'A API não devolveu o tamanho das fotos.');
          await salvar({ ...(dados().prem || {}), ...lerCampos(), clGB: Math.round((Number(j.bytesTotal) / GB) * 100) / 100, clMedidoEm: Date.now() });
        } finally { clearTimeout(t); }
      }, 'Fotos medidas.');
      medindoFotos = false;
      if (ok) await logar('limites.medir-fotos', 'Cloudinary', '');
      desenhar();
    }
  });
  return { render };
}
