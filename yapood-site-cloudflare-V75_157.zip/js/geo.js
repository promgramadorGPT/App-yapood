// js/geo.js
export function calcularDistanciaKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return parseFloat((R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(1));
}

const CHAVE_POS = 'pos_cache_v1';

// callback(lat, lng, { estimada }) — `estimada: true` quando NÃO há localização real.
// Antes, o fallback era Santiago/Chile, o que escondia todas as lojas (que ficam no Brasil) de quem negava o GPS.
// Agora o fallback não filtra por raio: o app mostra tudo e avisa o usuário.
export function obterLocalizacao(callback) {
  let respondeu = false;
  const responder = (lat, lng, extra) => { if (!respondeu) { respondeu = true; callback(lat, lng, extra); } };

  try {
    const c = JSON.parse(sessionStorage.getItem(CHAVE_POS) || 'null');
    if (c && Date.now() - c.t < 5 * 60 * 1000) return responder(c.lat, c.lng, { estimada: false });
  } catch { /* ignora cache inválido */ }

  if (!('geolocation' in navigator)) return responder(null, null, { estimada: true });
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const { latitude: lat, longitude: lng } = pos.coords;
      try { sessionStorage.setItem(CHAVE_POS, JSON.stringify({ lat, lng, t: Date.now() })); } catch { /* noop */ }
      responder(lat, lng, { estimada: false });
    },
    () => responder(null, null, { estimada: true }),
    { enableHighAccuracy: false, timeout: 8000, maximumAge: 5 * 60 * 1000 }
  );
}

// Geocodificação reversa (Nominatim) com cache local — a política do OSM pede para não repetir chamadas.
// callback(texto, { cidade, uf }): o segundo argumento (V75.73) diz em que cidade o cliente está (para o filtro por cidade).
export function obterEnderecoPorCoordenadas(lat, lng, callback) {
  if (lat == null) return callback('Ative sua localização', null);
  const chave = `end2_${lat.toFixed(2)}_${lng.toFixed(2)}`;
  try { const c = JSON.parse(localStorage.getItem(chave) || 'null'); if (c?.txt) return callback(c.txt, { cidade: c.cidade || '', uf: c.uf || '' }); } catch { /* noop */ }

  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 6000);
  fetch(`https://nominatim.openstreetmap.org/reverse?format=json&zoom=16&lat=${lat}&lon=${lng}`, { signal: ctrl.signal })
    .then((r) => r.json())
    .then((data) => {
      const a = data?.address || {};
      const bairro = a.suburb || a.neighbourhood || a.residential || '';
      const cidade = a.city || a.town || a.village || a.municipality || '';
      const uf = /^BR-[A-Z]{2}$/.test(a['ISO3166-2-lvl4'] || '') ? a['ISO3166-2-lvl4'].slice(3) : '';
      const nomeTexto = cidade || a.state || '';
      const txt = bairro && nomeTexto ? `${bairro}, ${nomeTexto}` : (nomeTexto || 'Localização atual');
      try { localStorage.setItem(chave, JSON.stringify({ txt, cidade, uf })); } catch { /* noop */ }
      callback(txt, { cidade, uf });
    })
    .catch(() => callback('Localização atual', null))
    .finally(() => clearTimeout(t));
}
