// V75.20 — Comissão da plataforma no front (espelha comissao.js da API, só para exibir; a cobrança real é feita na API).
const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;

// V75.32 — Base = valor dos PRODUTOS antes de qualquer desconto, sem a entrega.
// Cupom e presente são custo da loja: a comissão da plataforma não diminui por causa deles.
export function baseComissao(p) {
  const itens = Array.isArray(p?.itens) ? p.itens : [];
  const somaItens = itens.reduce((s, i) => s + (Number(i.precio) || 0) * (Number(i.qtd) || 0), 0);
  const sub = Number(p?.subtotal);
  const subtotal = Number.isFinite(sub) && sub >= 0 ? sub : somaItens;
  return arred(Math.max(0, subtotal));
}

// modo: 'split' (já separada pelo Mercado Pago), 'a_acertar' (a loja deve à plataforma) ou 'nenhum'.
// Reembolso aprovado reduz a comissão na mesma proporção do valor devolvido.
export function comissaoDoPedido(p) {
  if (!p) return { valor: 0, modo: 'nenhum' };
  const total = Number(p.total) || 0;
  let valor = 0, modo = 'nenhum';
  const reg = p.comissaoPlataforma;
  if (reg && Number.isFinite(Number(reg.valor))) {
    valor = arred(reg.valor); modo = reg.modo === 'split' ? 'split' : (reg.modo === 'a_acertar' ? 'a_acertar' : 'nenhum');
  } else {
    const perc = Number(p.comissaoPercentual);
    if (perc > 0) { valor = Math.min(arred((baseComissao(p) * perc) / 100), Math.max(0, arred(total - 0.01))); modo = 'a_acertar'; }
  }
  if (!(valor > 0)) return { valor: 0, modo: 'nenhum' };
  const r = p.reembolso;
  if (r?.status === 'aprovado' && total > 0) valor = arred(valor * Math.max(0, 1 - Math.min(Number(r.valor) || 0, total) / total));
  return { valor, modo: valor > 0 ? modo : 'nenhum' };
}

export function resumoComissao(lista) {
  return (lista || []).reduce((s, p) => {
    const c = comissaoDoPedido(p);
    if (c.modo === 'split') s.split += c.valor; else if (c.modo === 'a_acertar') s.aAcertar += c.valor;
    return s;
  }, { split: 0, aAcertar: 0 });
}
