// V75.35 — Relato de problema depois da entrega (regras puras, sem Firebase/DOM).
// Fluxo: o cliente relata em até 24 h após a entrega -> a loja responde (resolve, recusa ou reembolsa)
// -> o cliente pode contestar uma vez -> o Master decide quando a loja não responde ou o cliente contesta.
import { normalizarStatus, STATUS } from './regras.js';

export const RELATO = { ABERTO: 'aberto', RESOLVIDO: 'resolvido', REEMBOLSADO: 'reembolsado', RECUSADO: 'recusado' };

export const PRAZO_RELATO_HORAS = 24;      // quanto tempo o cliente tem para relatar, contado da entrega
export const PRAZO_LOJA_HORAS = 24;        // quanto tempo a loja tem para responder antes de subir para o Master
const HORA = 3600000;

export const MOTIVOS_RELATO = [
  { id: 'faltou', texto: 'Faltou item no pedido' },
  { id: 'errado', texto: 'Veio item errado' },
  { id: 'qualidade', texto: 'Problema de qualidade (frio, estragado ou mal preparado)' },
  { id: 'avaria', texto: 'Embalagem violada ou comida derramada' },
  { id: 'nao_recebi', texto: 'O pedido consta como entregue, mas não recebi' },
  { id: 'cobranca', texto: 'O valor cobrado está diferente do pedido' },
  { id: 'outro', texto: 'Outro problema' }
];

// Só fotos enviadas ao Cloudinary do app (as regras do banco repetem esta conferência).
export const FOTO_RELATO_RE = /^https:\/\/res\.cloudinary\.com\/dkbhdasfh\/[A-Za-z0-9_\-./%]+$/;

const ms = (iso) => { const t = Date.parse(iso); return Number.isFinite(t) ? t : null; };

// Momento em que o pedido foi entregue (a API grava entregaConfirmadaEm; a loja grava atualizadoEm).
export function momentoEntrega(p) {
  return ms(p?.entregaConfirmadaEm) ?? ms(p?.atualizadoEm) ?? null;
}

export function prazoRelato(p, agora = Date.now()) {
  const t = momentoEntrega(p);
  if (t == null) return { aberto: true, expiraEm: null, restanteMs: null };
  const expiraEm = t + PRAZO_RELATO_HORAS * HORA;
  return { aberto: agora <= expiraEm, expiraEm, restanteMs: Math.max(0, expiraEm - agora) };
}

export function podeRelatar(p, uid, agora = Date.now()) {
  if (!p || !uid || p.clienteUid !== uid) return false;
  if (p.relato) return false;
  if (normalizarStatus(p.status) !== STATUS.ENTREGUE) return false;
  return prazoRelato(p, agora).aberto;
}

export function textoPrazo(restanteMs) {
  if (restanteMs == null) return '';
  const min = Math.ceil(restanteMs / 60000);
  if (min >= 120) return `${Math.floor(min / 60)} h`;
  if (min >= 60) return '1 h';
  return `${Math.max(1, min)} min`;
}

// abertoEmMs: o app passa serverTimestamp() (as regras exigem que seja o horário do servidor).
export function montarRelato(p, { motivoId, comentario, foto }, abertoEmMs, agora = new Date()) {
  const m = MOTIVOS_RELATO.find((x) => x.id === motivoId);
  if (!m) throw new Error('Escolha o que aconteceu.');
  const c = String(comentario || '').trim().slice(0, 300);
  if (c.length < 10) throw new Error('Conte o que aconteceu (mínimo de 10 caracteres).');
  const f = String(foto || '').trim();
  if (f && !FOTO_RELATO_RE.test(f)) throw new Error('A foto não foi enviada corretamente. Tente de novo.');
  return {
    status: RELATO.ABERTO, motivoId: m.id, motivo: m.texto, comentario: c, ...(f ? { foto: f } : {}),
    valorPedido: Number(p?.total) || 0, abertoEm: agora.toISOString(), abertoEmMs
  };
}

const textoResposta = (r) => String(r || '').trim().slice(0, 300);

// Resposta sem dinheiro: "resolvido" (loja corrigiu/combinou algo) ou "recusado" (não procede). A mensagem é obrigatória.
export function montarRespostaRelato(relato, { decisao, resposta, por, porTipo }, agora = new Date()) {
  if (!relato) throw new Error('Relato não encontrado.');
  if (decisao !== RELATO.RESOLVIDO && decisao !== RELATO.RECUSADO) throw new Error('Decisão inválida.');
  const t = textoResposta(resposta);
  if (t.length < 5) throw new Error('Escreva uma mensagem para o cliente (mínimo de 5 caracteres).');
  if (porTipo !== 'loja' && porTipo !== 'master') throw new Error('Quem está decidindo?');
  return { status: decisao, resposta: t, respondidoEm: agora.toISOString(), respondidoPor: por || '', respondidoPorTipo: porTipo };
}

// Reembolso decidido a partir do relato (o dinheiro sai pelo fluxo de reembolso que já existe).
export function montarReembolsoDoRelato({ valor, resposta, por, porTipo }, agora = new Date()) {
  if (porTipo !== 'loja' && porTipo !== 'master') throw new Error('Quem está decidindo?');
  const v = Math.round((Number(valor) || 0) * 100) / 100;
  if (!(v > 0)) throw new Error('Informe o valor a devolver.');
  const t = textoResposta(resposta);
  return {
    status: RELATO.REEMBOLSADO, valorReembolso: v, ...(t ? { resposta: t } : {}),
    respondidoEm: agora.toISOString(), respondidoPor: por || '', respondidoPorTipo: porTipo
  };
}

export function podeContestar(relato) {
  return !!relato && relato.status !== RELATO.ABERTO && !relato.contestacao && relato.respondidoPorTipo !== 'master';
}

export function montarContestacao(relato, comentario, agora = new Date()) {
  if (!podeContestar(relato)) throw new Error('Este relato não pode mais ser contestado.');
  const c = String(comentario || '').trim().slice(0, 300);
  if (c.length < 10) throw new Error('Explique por que você não concorda (mínimo de 10 caracteres).');
  return { em: agora.toISOString(), comentario: c };
}

// A loja deve responder (ainda não respondeu e não passou pelo Master).
export const lojaDeveResponder = (p) => p?.relato?.status === RELATO.ABERTO;

// O Master entra quando a loja não respondeu no prazo ou o cliente contestou e o Master ainda não decidiu.
export function precisaDoMaster(p, agora = Date.now()) {
  const r = p?.relato;
  if (!r || r.respondidoPorTipo === 'master') return false;
  if (r.contestacao) return true;
  if (r.status === RELATO.ABERTO) { const t = ms(r.abertoEm); return t != null && agora - t >= PRAZO_LOJA_HORAS * HORA; }
  return false;
}

export function motivoMasterAlerta(p, agora = Date.now()) {
  if (!precisaDoMaster(p, agora)) return '';
  return p.relato.contestacao ? 'Cliente contestou a resposta da loja' : 'A loja não respondeu em 24 h';
}

export function rotuloRelato(r) {
  if (!r) return '';
  return { aberto: 'Em análise', resolvido: 'Resolvido', reembolsado: 'Reembolsado', recusado: 'Recusado' }[r.status] || 'Em análise';
}

export function textoRelatoCliente(r) {
  if (!r) return '';
  const quem = r.respondidoPorTipo === 'master' ? 'O YAPOOD' : 'A loja';
  if (r.status === RELATO.ABERTO) return 'Relato enviado. A loja vai responder aqui em até 24 h. Se ela não responder, o YAPOOD assume o caso.';
  if (r.status === RELATO.REEMBOLSADO) return `${quem} aprovou o reembolso. O valor volta para a forma de pagamento usada; o prazo depende do Mercado Pago e do seu banco. Pedidos pagos na entrega são devolvidos direto pela loja.`;
  if (r.status === RELATO.RESOLVIDO) return `${quem} deu o caso como resolvido.`;
  return `${quem} analisou o relato e não aprovou.`;
}
