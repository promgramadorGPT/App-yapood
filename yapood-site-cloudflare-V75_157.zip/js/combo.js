// js/combo.js — V75.128: combos (um produto que junta outros produtos do cardápio por um preço só). Funções puras.
// No cardápio: menu/{id}.combo = { itens: { <idDoProduto>: <qtd> } }. O preço é o do próprio combo (precio);
// o "de" riscado é a soma dos produtos incluídos. Opções e adicionais do combo funcionam como em qualquer produto
// (ex.: grupo "Escolha a bebida"). Na linha do pedido vai a lista do que o combo inclui: combo: [{ id, nome, qtd }].
import { resumoLinha } from './produto-opcoes.js';

export const COMBO = Object.freeze({ maxItens: 10, maxQtd: 10 });
const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;
const texto = (v, max = 60) => String(v ?? '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, max);
const disponivelAgora = (i, qtd = 1) => !!i && i.disponible !== false && !(i.controlaEstoque === true && (Number(i.estoque) || 0) < qtd);

/** O produto é um combo (tem pelo menos um item)? */
export const ehCombo = (item) => !!item?.combo && typeof item.combo.itens === 'object' && item.combo.itens !== null && Object.keys(item.combo.itens).length > 0;

/** Itens do combo com nome, preço e se estão disponíveis agora. Produto apagado do cardápio aparece como indisponível. */
export function itensDoCombo(item, menu) {
  if (!ehCombo(item)) return [];
  return Object.entries(item.combo.itens).slice(0, COMBO.maxItens).map(([id, q]) => {
    const p = menu?.[id];
    const qtd = Math.min(COMBO.maxQtd, Math.max(1, parseInt(q, 10) || 1));
    return { id, qtd, nome: texto(p?.nombre) || 'Produto removido', preco: arred(p?.precio), imagem: p?.imagen || p?.imagem || '', disponivel: disponivelAgora(p, qtd) };
  });
}

/** { itens, de, por, economia, disponivel, falta } — "de" = soma dos itens; economia só quando o combo sai mais barato. */
export function resumoCombo(item, menu) {
  const itens = itensDoCombo(item, menu);
  const de = arred(itens.reduce((s, i) => s + i.preco * i.qtd, 0));
  const por = arred(item?.precio);
  const falta = itens.filter((i) => !i.disponivel).map((i) => i.nome);
  return { itens, de, por, economia: de > por ? arred(de - por) : 0, disponivel: itens.length > 0 && !falta.length, falta };
}

/** O que vai gravado na linha do carrinho/pedido. */
export const comboParaLinha = (item, menu) => itensDoCombo(item, menu).map(({ id, nome, qtd }) => ({ id, nome, qtd }));

/** "Inclui: 1x X-Burguer, 1x Batata, 1x Refri". */
export function textoCombo(linha) {
  const l = Array.isArray(linha?.combo) ? linha.combo.filter((c) => c && c.nome) : [];
  return l.length ? `Inclui: ${l.map((c) => `${Math.max(1, parseInt(c.qtd, 10) || 1)}x ${texto(c.nome)}`).join(', ')}` : '';
}

/** Tudo o que aparece abaixo do nome do item (combo, opções, adicionais, observação). */
export const detalhesDaLinha = (linha) => [textoCombo(linha), ...resumoLinha(linha)].filter(Boolean);

/**
 * Painel: linhas do editor [{ id, qtd }] → { ok, combo: { itens } | null } ou { ok:false, erro }.
 * Junta o mesmo produto repetido, não deixa o combo conter ele mesmo nem outro combo.
 */
export function comboParaBanco(linhas, menu, proprioId = null) {
  const itens = {};
  for (const l of linhas || []) {
    if (!l || !l.id) continue;
    const p = menu?.[l.id];
    if (!p) return { ok: false, erro: 'Um produto do combo não existe mais no cardápio.' };
    if (l.id === proprioId) return { ok: false, erro: 'O combo não pode conter ele mesmo.' };
    if (ehCombo(p)) return { ok: false, erro: `"${texto(p.nombre)}" já é um combo. Escolha produtos simples.` };
    const q = String(l.qtd ?? '').trim() === '' ? 1 : parseInt(l.qtd, 10);
    if (!Number.isInteger(q) || q < 1 || q > COMBO.maxQtd) return { ok: false, erro: `A quantidade de "${texto(p.nombre)}" deve ser de 1 a ${COMBO.maxQtd}.` };
    itens[l.id] = Math.min(COMBO.maxQtd, (itens[l.id] || 0) + q);
  }
  const n = Object.keys(itens).length;
  if (!n) return { ok: false, erro: 'Escolha os produtos que fazem parte do combo.' };
  if (n > COMBO.maxItens) return { ok: false, erro: `No máximo ${COMBO.maxItens} produtos por combo.` };
  return { ok: true, combo: { itens } };
}
