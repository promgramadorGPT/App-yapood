// js/perfil-nome.js — nome do cliente guardado em usuarios/{uid}/nome (editável no Perfil). Qualquer falha cai no nome da conta Google.
import { db, ref, get, update } from './firebase.js';
import { nomeExibicao, validarNome } from './perfil-util.js';

export async function nomeDoCliente(user) {
  if (!user) return 'Cliente';
  try { return nomeExibicao(user, (await get(ref(db, `usuarios/${user.uid}`))).val() || {}); }
  catch { return nomeExibicao(user, null); }
}

export async function salvarNomeCliente(user, texto) {
  const v = validarNome(texto);
  if (!v.ok) throw new Error(v.erro);
  await update(ref(db, `usuarios/${user.uid}`), { nome: v.nome, nomeEditado: true });
  return v.nome;
}
