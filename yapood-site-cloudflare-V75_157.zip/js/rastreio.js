// V75.86 — Rastreio da entrega por distância (sem mapa). Funções puras, sem DOM nem Firebase; as telas estão em status.js, cart.js e entregador.js.
// Fluxo: o app do entregador manda a posição à API; a API grava só a distância arredondada em rastreio/{pedido};
// o cliente lê essa distância. A posição do entregador nunca chega ao aparelho do cliente.

export const PRECISAO_CHECKOUT_MAX_M = 200;  // localização do cliente no checkout: pior que isso pede para tentar de novo
export const PRECISAO_ENTREGADOR_MAX_M = 300; // igual ao limite da API
export const INTERVALO_ENVIO_MS = 10000;      // o entregador manda a posição a cada 10 s (a API só grava se mudou ou a cada 30 s)
export const BATIMENTO_MS = 25000;            // parado no sinal, o navegador pode não avisar posição nova: depois de 25 s sem envio, pede uma leitura
export const FRESCO_MS = 90000;               // registro com até 90 s = sinal vivo
export const SEM_SINAL_MS = 15 * 60 * 1000;   // depois disso a tela para de prometer distância
export const CHEGANDO_M = 150;                // até esta distância: "chegando"

const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);

/** { lat, lng } válidos ou null. (0,0) é rejeitado (GPS sem sinal). */
export function coordValida(c) {
  const lat = num(c?.lat), lng = num(c?.lng);
  if (lat === null || lng === null || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  if (lat === 0 && lng === 0) return null;
  return { lat, lng };
}

/** Resultado do GPS do cliente no checkout -> { ok, coord } ou { ok:false, motivo, texto }. Guarda 6 casas (~0,1 m). */
export function avaliarLocalizacaoCliente(pos) {
  const c = pos?.coords || pos || {};
  const coord = coordValida({ lat: c.latitude ?? c.lat, lng: c.longitude ?? c.lng });
  if (!coord) return { ok: false, motivo: 'invalida', texto: 'Não consegui ler a sua localização. Tente de novo ou digite o endereço.' };
  const precisao = num(c.accuracy ?? c.precisao);
  if (precisao !== null && precisao > PRECISAO_CHECKOUT_MAX_M) {
    return { ok: false, motivo: 'imprecisa', texto: `O GPS está impreciso (cerca de ${Math.round(precisao)} m). Vá para perto de uma janela ou ao ar livre e tente de novo.` };
  }
  const r6 = (n) => Math.round(n * 1e6) / 1e6;
  return { ok: true, coord: { lat: r6(coord.lat), lng: r6(coord.lng), ...(precisao !== null ? { precisao: Math.round(precisao) } : {}) } };
}

/** Mensagem para o erro do navegador (GeolocationPositionError.code). */
export function textoErroLocalizacao(codigo) {
  if (codigo === 1) return 'A permissão de localização foi negada. Você pode digitar o endereço normalmente.';
  if (codigo === 3) return 'Demorou demais para achar a sua localização. Tente de novo.';
  return 'Não foi possível obter a sua localização. Você pode digitar o endereço normalmente.';
}

/** Coordenada que vai no pedido: só entrega (delivery), só se válida. Remove o que não é do contrato. */
export function coordParaPedido(coord, tipoEntrega) {
  if (tipoEntrega === 'retirada') return null;
  const c = coordValida(coord);
  if (!c) return null;
  const p = num(coord?.precisao);
  return { lat: c.lat, lng: c.lng, ...(p !== null && p >= 0 && p <= 100000 ? { precisao: Math.round(p) } : {}) };
}

/** "120 m", "850 m", "1,3 km", "12 km". */
export function formatarDistancia(m) {
  const d = num(m);
  if (d === null || d < 0) return '';
  if (d < 1000) return `${Math.max(50, Math.round(d / 50) * 50)} m`;
  const dec = Math.round(d / 100) / 10; // km com 1 casa; 9,96 km já vira "10 km" (sem "10,0")
  return `${dec < 10 ? String(dec).replace('.', ',') : Math.round(dec)} km`;
}

/**
 * Estado da tela do cliente a partir de rastreio/{pedido} (ou null).
 * -> { estado: 'aguardando' | 'chegando' | 'perto' | 'a-caminho' | 'sem-sinal', distanciaM, texto, detalhe, progresso (0-100) }
 */
export function estadoRastreio(reg, agora = Date.now()) {
  // V75.136: entregador da loja a caminho, mas sem como medir a distância (cliente sem GPS e endereço não achado no mapa)
  if (reg?.semDistancia === true) return { estado: 'saiu', distanciaM: null, texto: 'Seu pedido saiu para entrega', detalhe: 'A distância aparece aqui quando der para calcular até o seu endereço.', progresso: 0 };
  const d = num(reg?.distanciaM), t = num(reg?.atualizadoEm);
  if (d === null || t === null) return { estado: 'aguardando', distanciaM: null, texto: 'Aguardando o sinal do entregador…', detalhe: 'A distância aparece assim que o entregador sair com o seu pedido.', progresso: 0 };
  const idade = Math.max(0, agora - t);
  if (idade > SEM_SINAL_MS) return { estado: 'aguardando', distanciaM: null, texto: 'Aguardando o sinal do entregador…', detalhe: 'Sem atualização há um tempo. Se precisar, fale com a loja.', progresso: 0 };
  const ini = Math.max(num(reg.inicialM) || 0, d);
  const progresso = ini > 0 ? Math.max(0, Math.min(100, Math.round((1 - d / ini) * 100))) : 0;
  if (idade > FRESCO_MS) return { estado: 'sem-sinal', distanciaM: d, texto: `Última posição: a cerca de ${formatarDistancia(d)}`, detalhe: 'Sem sinal do entregador neste momento (túnel ou celular sem internet).', progresso };
  if (d <= CHEGANDO_M) return { estado: 'chegando', distanciaM: d, texto: 'O entregador está chegando!', detalhe: 'Fique de olho no portão ou no interfone.', progresso: 100 };
  if (d <= 500) return { estado: 'perto', distanciaM: d, texto: `Está a cerca de ${formatarDistancia(d)}`, detalhe: 'Quase lá. Em linha reta; o caminho pelas ruas pode ser um pouco maior.', progresso };
  return { estado: 'a-caminho', distanciaM: d, texto: `Está a cerca de ${formatarDistancia(d)}`, detalhe: 'Distância em linha reta; o caminho pelas ruas pode ser um pouco maior.', progresso };
}

// V75.124 — previsão de chegada a partir da distância em linha reta: o caminho pelas ruas é ~35% maior,
// moto na cidade ~24 km/h, bicicleta ~13 km/h. É uma estimativa (o texto diz "cerca de").
const FATOR_RUAS = 1.35, KMH = { moto: 24, bicicleta: 13, carro: 22 };
/** { min, hora: 'HH:MM' } ou null. */
export function estimativaChegada(distM, veiculo = 'moto', agora = Date.now()) {
  const d = num(distM);
  if (d === null || d < 0) return null;
  const v = KMH[veiculo] || KMH.moto;
  const min = Math.max(1, Math.round((d * FATOR_RUAS) / 1000 / v * 60));
  const hora = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' }).format(new Date(agora + min * 60000));
  return { min, hora };
}
/**
 * Quem leva o pedido -> { nome, tipo, veiculo, placa, telefone, lojaNome } ou null.
 * V75.124: entrega parceira (nome, moto/bicicleta e placa). V75.136: entregador da LOJA (reg.loja === true):
 * telefone para o cliente ligar; veículo e placa só se a loja cadastrou (são opcionais).
 */
export function quemLeva(reg) {
  const e = reg && reg.entregador;
  if (!e || typeof e !== 'object') return null;
  const nome = String(e.nome || '').replace(/[<>]/g, '').trim().slice(0, 30);
  if (!nome) return null;
  const tipo = reg.loja === true ? 'loja' : 'parceiro';
  const veiculo = ['moto', 'bicicleta', 'carro'].includes(e.veiculo) ? e.veiculo : (tipo === 'parceiro' ? 'moto' : '');
  const placa = veiculo === 'moto' || veiculo === 'carro' ? String(e.placa || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) : '';
  const tel = String(e.telefone || '').replace(/\D/g, '');
  const telefone = tipo === 'loja' && tel.length >= 10 && tel.length <= 13 ? tel : '';
  const lojaNome = tipo === 'loja' ? String(e.lojaNome || '').replace(/[<>]/g, '').trim().slice(0, 60) : '';
  return { nome, tipo, veiculo, placa, telefone, lojaNome };
}

/** V75.136 — link de ligação: 34999990000 -> "tel:+5534999990000" (já com 55 fica igual). '' se inválido. */
export function linkLigar(telefone) {
  const d = String(telefone || '').replace(/\D/g, '');
  if (d.length < 10 || d.length > 13) return '';
  return 'tel:+' + (d.length >= 12 && d.startsWith('55') ? d : '55' + d);
}

/** V75.136 — linha de baixo do "quem leva": loja · veículo · placa (o que houver). */
export function detalheQuemLeva(q) {
  if (!q) return '';
  const veic = { moto: 'Moto', bicicleta: 'Bicicleta', carro: 'Carro' }[q.veiculo] || '';
  return [q.tipo === 'loja' ? q.lojaNome : '', veic, q.placa ? `placa ${q.placa}` : ''].filter(Boolean).join(' · ');
}

/** Posição da moto na pista (0 = loja, 100 = casa). Fica a até 76% para a casa continuar visível quando ele chega. */
export const posicaoMoto = (progresso) => { const n = Number(progresso); return Number.isFinite(n) ? Math.round(Math.min(76, Math.max(0, n))) : 0; };

/** O cliente só enxerga o cartão quando for o dono, pedido de entrega, "a caminho" e com localização salva. */
export function deveMostrarRastreio({ ehDono, pedido }) {
  if (!ehDono || !pedido) return false;
  if (pedido.tipoEntrega !== 'delivery' || pedido.status !== 'En camino') return false;
  if (pedido.entregaConfirmada === true) return false;
  return coordValida(pedido.entregaCoord) !== null;
}

/**
 * O que a tela de status do cliente mostra sobre o acompanhamento:
 * 'ativar' (pedido de entrega sem localização: oferece o botão), 'aguardar' (localização salva, entregador ainda não saiu),
 * 'ao-vivo' (a caminho: distância) ou null (não é o dono, retirada, entregue, cancelado).
 */
export function modoRastreio({ ehDono, pedido }) {
  if (!ehDono || !pedido || pedido.tipoEntrega !== 'delivery' || pedido.entregaConfirmada === true) return null;
  const st = pedido.status;
  if (st !== 'Pendiente' && st !== 'En preparación' && st !== 'En camino') return null;
  // V75.124: entrega parceira já tem a localização do cliente no servidor (endereço achado no mapa): acompanha sem pedir o GPS.
  // V75.136: o entregador da loja também (a API procura o endereço no mapa). A caminho, sempre ao vivo; sem o GPS do cliente
  // e sem registro ainda, a tela de status continua oferecendo o botão de ativar.
  if (st === 'En camino') return 'ao-vivo';
  return coordValida(pedido.entregaCoord) === null ? 'ativar' : 'aguardar';
}

/** Entregas (resposta de /entregador/minhas) que pedem GPS ligado agora: a caminho, ainda não confirmadas nem canceladas. */
export function entregasParaRastrear(entregas) {
  return (entregas || []).filter((e) => e && e.status === 'En camino' && e.confirmada !== true && e.cancelado !== true);
}

/** Decide se manda a posição agora: primeira vez, ou passados INTERVALO_ENVIO_MS, e só com precisão aceitável. */
export function devePublicarPosicao(ultimoEnvioEm, agora, precisao) {
  const p = num(precisao);
  if (p !== null && p > PRECISAO_ENTREGADOR_MAX_M) return false;
  return !ultimoEnvioEm || agora - ultimoEnvioEm >= INTERVALO_ENVIO_MS;
}

/** Já passou tempo demais desde o último envio? Então o app pede uma leitura do GPS por conta própria (o cliente não deve achar que o sinal caiu). */
export function precisaBatimento(ultimoEnvioEm, agora) {
  return !!ultimoEnvioEm && agora - ultimoEnvioEm >= BATIMENTO_MS;
}

/** Texto do cartão do entregador. estado: 'inativo' | 'pedindo' | 'ativo' | 'negado' | 'indisponivel' | 'erro'. */
export function textoLocalizacaoEntregador({ estado, precisao = null, enviadoEm = null, agora = Date.now() }) {
  switch (estado) {
    case 'ativo': {
      const seg = enviadoEm ? Math.max(0, Math.round((agora - enviadoEm) / 1000)) : null;
      const quando = seg === null ? 'ainda sem envio' : seg < 5 ? 'agora há pouco' : `há ${seg < 60 ? `${seg} s` : `${Math.round(seg / 60)} min`}`;
      return { tom: 'ok', titulo: 'Compartilhando a distância com o cliente', detalhe: `Mantenha o app aberto e a tela ligada. Último envio: ${quando}.` };
    }
    case 'pedindo': return { tom: 'aviso', titulo: 'Aguardando o GPS…', detalhe: 'Permita a localização quando o celular pedir.' };
    case 'negado': return { tom: 'erro', titulo: 'Localização bloqueada', detalhe: 'O cliente não vê a distância. Libere a localização deste site nas configurações do navegador e toque em "Tentar de novo".' };
    case 'indisponivel': return { tom: 'erro', titulo: 'Este aparelho não tem GPS no navegador', detalhe: 'A entrega continua normal, mas o cliente não verá a distância.' };
    case 'erro': return { tom: 'aviso', titulo: 'GPS instável', detalhe: precisao ? `Precisão ruim (${Math.round(precisao)} m). Vá para um local aberto.` : 'Tentando de novo…' };
    default: return { tom: 'neutro', titulo: 'Rastreio desligado', detalhe: 'Liga sozinho quando você sai com um pedido.' };
  }
}

/**
 * V75.137 — rastreio no card do pedido do PAINEL DA LOJA. Puro: recebe o status (já normalizado), o registro de rastreio/{pedido}
 * e o entregador da loja atribuído ({ nome, telefone } ou null). Devolve null (nada a mostrar) ou
 * { tom, chip, tipo, nome, acao, telefone, detalhe, dist, eta, progresso, nota }.
 */
export function painelRastreio({ status, reg = null, atribuido = null, agora = Date.now() }) {
  const st = String(status || '');
  const primeiro = (n) => String(n || '').replace(/[<>]/g, '').trim().split(/\s+/)[0].slice(0, 30);
  const telDe = (t) => { const d = String(t || '').replace(/\D/g, ''); return d.length >= 10 && d.length <= 13 ? d : ''; };
  const base = { dist: '', eta: null, progresso: null, nota: '', detalhe: '' };
  if (st === 'Pendiente' || st === 'En preparación') {
    const nome = primeiro(atribuido && atribuido.nome);
    if (!nome) return null;
    return { ...base, tom: 'neutro', chip: `${nome} vai levar`, tipo: 'loja', nome, acao: 'vai levar', telefone: telDe(atribuido.telefone), nota: 'A distância aparece aqui quando ele sair com o pedido.' };
  }
  if (st !== 'En camino') return null;
  const q = quemLeva(reg) || (primeiro(atribuido && atribuido.nome) ? { nome: primeiro(atribuido.nome), tipo: 'loja', veiculo: '', placa: '', telefone: telDe(atribuido.telefone), lojaNome: '' } : null);
  if (!q) return null;
  const veic = { moto: 'Moto', bicicleta: 'Bicicleta', carro: 'Carro' }[q.veiculo] || '';
  const r = { ...base, tipo: q.tipo, nome: q.nome, acao: 'está levando', telefone: q.tipo === 'loja' ? (q.telefone || telDe(atribuido && atribuido.telefone)) : '', detalhe: [veic, q.placa].filter(Boolean).join(' · ') };
  const e = reg ? estadoRastreio(reg, agora) : { estado: 'aguardando', distanciaM: null, progresso: 0 };
  if (e.estado === 'a-caminho' || e.estado === 'perto') {
    const eta = estimativaChegada(e.distanciaM, q.veiculo || 'moto', agora), dist = formatarDistancia(e.distanciaM);
    return { ...r, tom: 'ok', chip: `${q.nome} · ${dist}${eta ? ` · chega ~${eta.hora}` : ''}`, dist, eta, progresso: e.progresso };
  }
  if (e.estado === 'chegando') return { ...r, tom: 'ok', chip: `${q.nome} chegando`, dist: formatarDistancia(e.distanciaM), progresso: 100, nota: 'Chegando no cliente.' };
  if (e.estado === 'sem-sinal') return { ...r, tom: 'aviso', chip: `${q.nome} · sem sinal`, progresso: e.progresso, nota: `${e.texto}. O celular do entregador está sem internet ou com o app fechado.` };
  if (e.estado === 'saiu') return { ...r, tom: 'neutro', chip: `${q.nome} saiu · sem distância`, nota: 'Sem distância: o cliente não ativou o GPS e o endereço não foi achado no mapa.' };
  return { ...r, tom: 'neutro', chip: `${q.nome} saiu · aguardando sinal`, nota: 'O app do entregador ainda não mandou a posição. Peça para ele deixar o app aberto.' };
}
