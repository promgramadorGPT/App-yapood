// js/cupom-etiqueta.js — V75.133 (V75.134: só o ticket e o valor): etiqueta discreta de cupom no cartão da loja ("🎟 10% off"). Funções puras.
import { estadoValidadeCupom } from './regras.js';

const reais = (v) => {
  const n = Number(v) || 0;
  return `R$ ${Number.isInteger(n) ? n : n.toFixed(2).replace('.', ',')}`;
};

/** Cupons que o cliente pode usar AGORA (ativos, com código, já começaram e não venceram). */
export function cuponsVigentes(loja, agora = new Date()) {
  return Object.values(loja?.cupones || {}).filter((c) => c && c.ativo !== false && String(c.codigo || '').trim() && estadoValidadeCupom(c, agora) === 'ativo');
}

/** Texto curto de UM cupom, para a etiqueta do card. V75.134: só o valor ("10% off", "R$ 10 off", "Entrega grátis"), sem condições. */
export function rotuloCupom(c) {
  if (!c) return '';
  return c.tipo === 'porcentagem' ? `${Number(c.valor) || 0}% off`
    : c.tipo === 'fixo' ? `${reais(c.valor)} off`
    : 'Entrega grátis';
}

/**
 * Etiqueta de cupom do card da loja: o melhor cupom vigente (porcentagem maior, depois valor fixo maior, depois frete)
 * e quantos outros existem. Sem cupom vigente: null (o card não mostra etiqueta).
 */
export function etiquetaCupom(loja, agora = new Date()) {
  const lista = cuponsVigentes(loja, agora);
  if (!lista.length) return null;
  const peso = (c) => (c.tipo === 'porcentagem' ? 3000 + (Number(c.valor) || 0) : c.tipo === 'fixo' ? 1000 + (Number(c.valor) || 0) : 500) - (Number(c.minimo) > 0 ? 0.5 : 0);
  const melhor = [...lista].sort((a, b) => peso(b) - peso(a))[0];
  return { texto: rotuloCupom(melhor), outros: lista.length - 1 };
}

