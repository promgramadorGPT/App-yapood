// V75.112/113 — ENTREGA PARCEIRA no painel de pedidos da loja. Módulo isolado: se algo falhar aqui, os pedidos seguem normais.
// Mostra, em cada pedido de entrega pago online, o botão "Chamar entregador parceiro" e acompanha a corrida
// (procurando, a caminho, pedido pronto + código da coleta, em entrega, concluída). Fala só com as rotas /rede/corrida/* da API 2.18.x:
// quem decide é a API; este arquivo só mostra e pede.
import { auth, db, ref, get, onValue } from './firebase.js';
import { toast, confirmar } from './ui-mensagens.js';
import { elegivel, corridaDoPedido, estadoVisual, textoCancelar, textoAvisoChamada, resumoSituacao, mudancas, brl, ATIVAS, lojaLiberada } from './loja-parceira-util.js?v=75.115';

const API = 'https://api-mp-yapoodbr.onrender.com';
const INTERVALO_MS = 12000;
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = (id) => document.getElementById(id);

const est = { corridas: [], situacao: null, modos: ['na_hora'], cfg: undefined, carregadoEm: 0, indisponivel: false, erro: '', primeira: true, emVoo: null, ocupado: new Set(),
  lib: undefined, libFalhou: false, liberadaApi: undefined }; // V75.115: liberação do Master (rede/liberacao, ao vivo)
let timer = null, observador = null, injetando = false;

async function chamar(rota, corpo = {}) {
  const lojaId = window.__yapood?.lojaId;
  const token = await auth.currentUser?.getIdToken();
  if (!lojaId || !token) throw Object.assign(new Error('Sessão expirada. Entre novamente.'), { status: 401 });
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 60000); // a API gratuita do Render pode demorar para acordar
  try {
    const r = await fetch(API + rota, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({ lojaId, ...corpo }), signal: ctl.signal });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || d.error) throw Object.assign(new Error(d.error || 'Não foi possível concluir.'), { status: r.status, dados: d });
    return d;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('O servidor demorou para responder. Tente de novo em instantes.');
    if (e instanceof TypeError) throw new Error('Sem conexão com o servidor. Confira a internet e tente de novo.');
    throw e;
  } finally { clearTimeout(t); }
}

// ---------- configuração da rede (compensações do Master) ----------
async function lerConfig() {
  try {
    const s = await get(ref(db, 'rede/config'));
    const v = s.exists() ? s.val() : null;
    est.cfg = v ? { a_caminho: v.cancelaAteChegarPct, chegou: v.cancelaAposChegarPct, coletada: v.cancelaAposColetaPct } : null;
  } catch { est.cfg = null; }
}

// ---------- carregamento ----------
function carregar() {
  if (est.emVoo) return est.emVoo;
  est.emVoo = (async () => {
    try {
      if (est.cfg === undefined) await lerConfig();
      const d = await chamar('/rede/corrida/loja');
      const antes = est.corridas;
      est.corridas = d.corridas || []; est.situacao = d.situacao || null; est.modos = d.modosPermitidos || ['na_hora']; est.erro = ''; est.indisponivel = false; est.carregadoEm = Date.now();
      est.liberadaApi = typeof d.liberada === 'boolean' ? d.liberada : undefined; // API 2.19+
      if (!est.primeira) mudancas(antes, est.corridas).forEach((m) => toast(m.texto, m.tipo, 9000));
      est.primeira = false;
    } catch (e) {
      if (e.status === 404) est.indisponivel = true; // API antiga (sem entrega parceira): não mostra nada
      else if (e.status === 401 && !e.dados) est.erro = ''; // ainda sem login no painel: tenta de novo mais tarde, sem barulho
      else if (e.status === 401) est.erro = 'O servidor não reconheceu o seu login. Saia e entre de novo no painel.';
      else est.erro = e.message || 'Não foi possível carregar a entrega parceira.';
    } finally { est.emVoo = null; atualizarTela(); }
  })();
  return est.emVoo;
}

/**
 * V75.115 — a loja está liberada pelo Master? true / false / undefined (ainda lendo).
 * Vale o Firebase (ao vivo); se a leitura falhar (regras antigas), vale a resposta da API (API antiga, sem o campo = sem trava).
 */
function liberada() {
  if (est.lib !== undefined) return lojaLiberada(est.lib, window.__yapood?.lojaId);
  if (est.libFalhou) return est.liberadaApi !== false;
  return undefined;
}
const temCorridaViva = () => est.corridas.some((c) => ATIVAS.includes(c.estado));
/** Há pedido de entrega em aberto? Basta para a PRIMEIRA consulta (mostrar a situação no card); o acompanhamento contínuo usa precisaConsultar. */
function temEntregaAberta() { return (window.__yapood?.pedidos || []).some((p) => elegivel(p)); }
// loja não liberada também consulta UMA vez (sem mostrar nada): pode haver corrida de antes de o Master desligar
const precisaPrimeira = () => !est.carregadoEm && liberada() !== undefined && temEntregaAberta();
function precisaConsultar() {
  const peds = window.__yapood?.pedidos || [];
  if (temCorridaViva()) return true;
  return liberada() === true && peds.some((p) => elegivel(p)?.ok);
}
function agendar() {
  clearTimeout(timer);
  timer = setTimeout(async () => {
    if (!document.hidden && window.__yapood?.lojaId && !est.indisponivel && (precisaConsultar() || precisaPrimeira())) await carregar();
    agendar();
  }, INTERVALO_MS);
}

// ---------- tela ----------
function blocoHtml(p) {
  const el = elegivel(p);
  if (!el) return '';
  const c = corridaDoPedido(est.corridas, p.key);
  const k = esc(p.key);
  // V75.115: loja não liberada (ou ainda sem saber) só vê o bloco de uma corrida que já existe
  if (liberada() !== true && !(c && c.estado !== 'cancelada')) return '';
  const cab = '<strong><i class="fa-solid fa-motorcycle" aria-hidden="true"></i> Entrega parceira</strong>';
  // V75.113: o bloco sempre diz por que o botão não está lá (antes ficava escondido e não dava para saber o motivo)
  if (!c && !el.ok) return `<div class="pc-bloco pc-neutro" data-pc-motivo="${el.pendente ? 'pendente' : 'inelegivel'}">${cab}<p class="pc-detalhe">${esc(el.motivo)}</p></div>`;
  if (est.indisponivel) return `<div class="pc-bloco pc-aviso" data-pc-motivo="api">${cab}<p class="pc-detalhe">O servidor ainda não tem a entrega parceira. A API no Render precisa estar na versão 2.18.1 ou mais nova.</p></div>`;
  if (!est.carregadoEm) {
    if (est.erro) return `<div class="pc-bloco pc-aviso" data-pc-motivo="erro">${cab}<p class="pc-detalhe">${esc(est.erro)}</p><div class="pc-acoes"><button type="button" class="pc-btn" data-pc-acao="recarregar" data-pc-pedido="${k}">Tentar de novo</button></div></div>`;
    return `<div class="pc-bloco pc-neutro" data-pc-motivo="conectando">${cab}<p class="pc-detalhe">Conectando à entrega parceira… o servidor pode levar até um minuto para acordar.</p></div>`;
  }
  const ocupado = est.ocupado.has(p.key);
  const bt = (acao, rotulo, cls = '', icone = '') => `<button type="button" class="pc-btn ${cls}" data-pc-acao="${acao}" data-pc-pedido="${k}"${c ? ` data-pc-corrida="${esc(c.id)}"` : ''} ${ocupado ? 'disabled' : ''}>${icone ? `<i class="fa-solid ${icone}" aria-hidden="true"></i> ` : ''}${rotulo}</button>`;
  if (!c || c.estado === 'cancelada') {
    const antiga = c ? `<p class="pc-detalhe"><b>${esc(estadoVisual(c).titulo)}.</b> ${esc(estadoVisual(c).detalhe)}</p>` : '';
    if (!el.ok) return `<div class="pc-bloco pc-neutro">${cab}${antiga}<p class="pc-detalhe">${esc(el.motivo)}</p></div>`;
    const bloq = est.situacao && ['bloqueada', 'pausada', 'limite'].includes(est.situacao.estado);
    return `<div class="pc-bloco pc-neutro"><strong><i class="fa-solid fa-motorcycle" aria-hidden="true"></i> Entrega parceira</strong>${antiga}
      <p class="pc-detalhe">Um entregador independente leva este pedido. Taxa de ${brl(el.taxa)} para ele.</p>
      <div class="pc-acoes">${bt('chamar', 'Chamar entregador parceiro', 'pc-primario', 'fa-motorcycle')}</div>${ocupado ? '<p class="pc-detalhe">Enviando… se a API estiver acordando, pode levar até um minuto.</p>' : ''}${bloq ? `<p class="pc-detalhe pc-aviso">${esc(est.situacao.motivo || 'A entrega parceira está indisponível agora.')}</p>` : ''}</div>`;
  }
  const v = estadoVisual(c);
  const rot = { pronto: ['Pedido pronto', 'pc-primario', 'fa-box-open'], cancelar: ['Cancelar corrida', 'pc-perigo', ''], propria: ['Usar entregador da loja', '', 'fa-user'], esperar_mais: ['Esperar mais', 'pc-primario', 'fa-hourglass-half'] };
  const acoes = v.acoes.filter((a) => rot[a]).map((a) => bt(a, rot[a][0], rot[a][1], rot[a][2])).join('');
  return `<div class="pc-bloco pc-${v.tom}" data-pc-estado="${esc(c.estado)}"><strong><i class="fa-solid fa-motorcycle" aria-hidden="true"></i> ${esc(v.titulo)}</strong>
    <p class="pc-detalhe">${esc(v.detalhe)}</p>${v.codigo ? `<div class="pc-codigo" aria-label="Código da coleta"><span>Código da coleta</span><b>${esc(v.codigo)}</b></div>` : ''}
    ${v.alerta ? '<p class="pc-detalhe pc-aviso">O entregador registrou um problema no pedido ao coletar. Fica guardado para o caso de contestação.</p>' : ''}
    ${acoes ? `<div class="pc-acoes">${acoes}</div>` : ''}${ocupado ? '<p class="pc-detalhe">Enviando… se a API estiver acordando, pode levar até um minuto.</p>' : ''}</div>`;
}
function pillHtml(p) {
  const c = corridaDoPedido(est.corridas, p.key);
  if (!c || c.estado === 'cancelada') return est.carregadoEm && !est.indisponivel && liberada() === true && elegivel(p)?.ok ? '<span class="pc-pill pc-info" data-pc-disponivel="1"><i class="fa-solid fa-motorcycle" aria-hidden="true"></i> Entrega parceira disponível</span>' : '';
  if (!elegivelOuCorrida(p, c)) return '';
  const v = estadoVisual(c); if (!v || !v.pill) return '';
  return `<span class="pc-pill pc-${v.tom}"><i class="fa-solid fa-motorcycle" aria-hidden="true"></i> ${esc(v.pill)}</span>`;
}
const elegivelOuCorrida = (p, c) => !!c && (ATIVAS.includes(c.estado) || c.estado === 'entregue' || c.estado === 'propria');

function faixaHtml() {
  if (liberada() !== true && !temCorridaViva()) return '';
  const f = resumoSituacao(est.situacao);
  if (est.indisponivel) return '';
  if (est.erro && est.carregadoEm) return `<div class="pc-faixa pc-aviso"><strong>Entrega parceira</strong><span>${esc(est.erro)}</span></div>`;
  return f ? `<div class="pc-faixa pc-${f.tom}"><strong>${esc(f.titulo)}</strong><span>${esc(f.texto)}</span></div>` : '';
}

function injetarCard(card) {
  const key = card.querySelector('.order-summary')?.dataset.pedido; if (!key) return;
  const p = (window.__yapood?.pedidos || []).find((x) => x.key === key); if (!p) return;
  const detalhes = card.querySelector('.order-details');
  if (detalhes) {
    let bloco = detalhes.querySelector('.pc-bloco-raiz');
    const html = blocoHtml(p);
    if (!html) { bloco?.remove(); }
    else {
      if (!bloco) { bloco = document.createElement('div'); bloco.className = 'pc-bloco-raiz'; const acoes = detalhes.querySelector('.order-actions'); detalhes.insertBefore(bloco, acoes || null); }
      if (bloco.dataset.html !== html) { bloco.innerHTML = html; bloco.dataset.html = html; }
    }
  }
  const lado = card.querySelector('.order-summary-main');
  if (lado) {
    let pill = lado.querySelector('.pc-pill-raiz');
    const html = pillHtml(p);
    if (!html) pill?.remove();
    else { if (!pill) { pill = document.createElement('span'); pill.className = 'pc-pill-raiz'; lado.appendChild(pill); } if (pill.dataset.html !== html) { pill.innerHTML = html; pill.dataset.html = html; } }
  }
  card.dataset.pc = '1';
}
function atualizarTela() {
  const lista = $('lista-pedidos-loja'); if (!lista) return;
  injetando = true;
  try {
    lista.querySelectorAll('.order-card').forEach(injetarCard);
    let faixa = $('pc-faixa-raiz');
    const html = faixaHtml();
    if (!html) faixa?.remove();
    else {
      if (!faixa) { faixa = document.createElement('div'); faixa.id = 'pc-faixa-raiz'; lista.parentNode.insertBefore(faixa, lista); }
      if (faixa.dataset.html !== html) { faixa.innerHTML = html; faixa.dataset.html = html; }
    }
  } catch (e) { console.warn('Entrega parceira:', e); }
  finally { setTimeout(() => { injetando = false; }, 0); }
}

// ---------- ações ----------
async function dialogoChamar(pedido, taxa) {
  return new Promise((resolve) => {
    const fundo = document.createElement('div');
    fundo.className = 'pc-fundo';
    const fech = est.modos.includes('fechamento');
    fundo.innerHTML = `<div class="pc-caixa" role="dialog" aria-modal="true" aria-labelledby="pc-t"><h2 id="pc-t">Chamar entregador parceiro</h2>
      <p>Pedido #${esc(pedido.numeroPedido || pedido.key)} · taxa de entrega ${brl(taxa)}</p>
      <fieldset class="pc-modos"><legend>Quando você paga o entregador</legend>
        <label><input type="radio" name="pc-modo" value="na_hora" checked> <span><b>Na hora</b> — logo depois da entrega</span></label>
        <label class="${fech ? '' : 'pc-off'}"><input type="radio" name="pc-modo" value="fechamento" ${fech ? '' : 'disabled'}> <span><b>No fechamento</b> — no fim do expediente, com tempo para analisar a entrega${fech ? '' : ' <small>(libera depois de algumas entregas pagas em dia)</small>'}</span></label>
      </fieldset>
      <p class="pc-termo" id="pc-termo"></p>
      <div class="pc-acoes"><button type="button" class="pc-btn" data-fim="nao">Voltar</button><button type="button" class="pc-btn pc-primario" data-fim="sim">Chamar entregador</button></div></div>`;
    const termo = fundo.querySelector('#pc-termo');
    const atual = () => fundo.querySelector('input[name=pc-modo]:checked')?.value || 'na_hora';
    const pinta = () => { termo.textContent = textoAvisoChamada(taxa, atual()); };
    pinta(); fundo.addEventListener('change', pinta);
    const fecha = (v) => { document.removeEventListener('keydown', tecla); fundo.remove(); resolve(v); };
    const tecla = (e) => { if (e.key === 'Escape') fecha(null); };
    document.addEventListener('keydown', tecla);
    fundo.addEventListener('click', (e) => { if (e.target === fundo) return fecha(null); const b = e.target.closest('[data-fim]'); if (b) fecha(b.dataset.fim === 'sim' ? atual() : null); });
    document.body.appendChild(fundo);
    fundo.querySelector('[data-fim=sim]').focus();
  });
}

async function executar(pedidoKey, fn) {
  if (est.ocupado.has(pedidoKey)) return;
  est.ocupado.add(pedidoKey); atualizarTela();
  try { await fn(); }
  catch (e) {
    toast(e.message || 'Não foi possível concluir.', 'error', 9000);
    if (e.dados?.situacao) await carregar().catch(() => {});
  } finally { est.ocupado.delete(pedidoKey); await carregar().catch(() => {}); atualizarTela(); }
}

async function aoClicar(ev) {
  const b = ev.target.closest('[data-pc-acao]'); if (!b) return;
  ev.stopPropagation();
  const key = b.dataset.pcPedido, acao = b.dataset.pcAcao, corridaId = b.dataset.pcCorrida || '';
  const pedido = (window.__yapood?.pedidos || []).find((x) => x.key === key); if (!pedido) return;
  const c = corridaId ? est.corridas.find((x) => x.id === corridaId) : null;

  if (acao === 'chamar') {
    if (liberada() !== true) { toast('A entrega parceira ainda não está liberada para a sua loja.', 'error', 7000); return; }
    const el = elegivel(pedido); if (!el?.ok) { toast(el?.motivo || 'Este pedido não pode usar a entrega parceira.', 'error', 8000); return; }
    const modo = await dialogoChamar(pedido, el.taxa); if (!modo) return;
    return executar(key, async () => {
      await chamar('/rede/corrida/chamar', { pedidoKey: key, modo });
      toast('Entregador parceiro chamado. Avisamos aqui quando alguém aceitar.', 'success', 7000);
    });
  }
  if (acao === 'recarregar') { est.erro = ''; atualizarTela(); return carregar(); }
  if (!c) return;
  if (acao === 'pronto') {
    return executar(key, async () => {
      const d = await chamar('/rede/corrida/loja-acao', { corridaId, acao: 'pronto' });
      toast(d.corrida?.codigoColeta ? `Pedido pronto. Diga ao entregador o código ${d.corrida.codigoColeta}.` : 'Pedido marcado como pronto.', 'success', 10000);
    });
  }
  if (acao === 'cancelar') {
    const ok = await confirmar({ titulo: 'Cancelar a corrida do entregador parceiro?', texto: `${textoCancelar(c, est.cfg || undefined)} O pedido em si continua; só a corrida parceira é encerrada.`, rotulo: 'Cancelar corrida', cancelar: 'Voltar' });
    if (!ok) return;
    return executar(key, async () => {
      const d = await chamar('/rede/corrida/loja-acao', { corridaId, acao: 'cancelar' });
      toast(d.compensacao ? `Corrida cancelada. Compensação de ${brl(d.compensacao.valor)} (${d.compensacao.pct}% da taxa) a pagar ao entregador.` : 'Corrida cancelada. Sem custo.', 'success', 9000);
    });
  }
  if (acao === 'propria') {
    const ok = await confirmar({ titulo: 'Usar o entregador da própria loja?', texto: 'A corrida do entregador parceiro será encerrada, sem custo. Depois atribua o entregador da loja na aba Entregadores.', rotulo: 'Usar entregador da loja', cancelar: 'Voltar' });
    if (!ok) return;
    return executar(key, async () => { await chamar('/rede/corrida/loja-acao', { corridaId, acao: 'propria' }); toast('Corrida parceira encerrada. Atribua o entregador da loja.', 'success', 7000); });
  }
  if (acao === 'esperar_mais') {
    return executar(key, async () => { await chamar('/rede/corrida/loja-acao', { corridaId, acao: 'esperar_mais' }); toast('Mais alguns minutos de busca por um entregador.', 'info', 6000); });
  }
}

// ---------- uso por outros módulos ----------
/** O pedido tem corrida parceira em andamento? (o lembrete "nenhum entregador atribuído" não deve aparecer nesse caso) */
export function temCorridaAtiva(pedidoKey) {
  const c = corridaDoPedido(est.corridas, pedidoKey);
  return !!c && (ATIVAS.includes(c.estado) || c.estado === 'entregue');
}

export function iniciarParceira() {
  const lista = $('lista-pedidos-loja'); if (!lista || lista.dataset.pcIniciado) return;
  lista.dataset.pcIniciado = '1';
  lista.addEventListener('click', aoClicar);
  observador = new MutationObserver(() => {
    if (injetando) return;
    if (lista.querySelector('.order-card:not([data-pc])')) atualizarTela();
    if (!est.emVoo && !est.indisponivel && !est.erro && precisaPrimeira() && window.__yapood?.lojaId) carregar();
  });
  observador.observe(lista, { childList: true, subtree: true });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && !est.indisponivel && (precisaConsultar() || precisaPrimeira())) carregar(); });
  window.__yapoodParceira = { temCorridaAtiva, recarregar: () => carregar() };
  // V75.115: liberação do Master, ao vivo (o Master liga/desliga em "Entrega parceira" e o painel muda sozinho)
  try {
    onValue(ref(db, 'rede/liberacao'), (snap) => {
      est.lib = snap.val() || null; est.libFalhou = false;
      atualizarTela();
      if (window.__yapood?.lojaId && !est.indisponivel && (precisaPrimeira() || precisaConsultar())) carregar();
    }, () => { est.libFalhou = true; est.lib = undefined; atualizarTela(); if (window.__yapood?.lojaId && precisaPrimeira()) carregar(); });
  } catch (err) { console.warn('Entrega parceira (liberação):', err); est.libFalhou = true; }
  atualizarTela();
  if (window.__yapood?.lojaId && (precisaConsultar() || precisaPrimeira())) carregar();
  agendar();
}
