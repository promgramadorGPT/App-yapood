// js/checkout-cartao.js — Mercado Pago (Card Payment Brick) V72.
// Requer o SDK global carregado em cart.html: https://sdk.mercadopago.com/js/v2
import { toast } from './utils.js';
import { auth } from './firebase.js';

const BACKEND = 'https://api-mp-yapoodbr.onrender.com';

let brick = null;
let tentativaCartao = 0;

async function obterDeviceId() {
  const atual = String(window.MP_DEVICE_SESSION_ID || '').trim();
  if (atual) return atual;

  // O SDK JS do Mercado Pago normalmente já coleta o Device ID.
  // Se o global ainda não estiver disponível, carregamos o script de segurança como fallback.
  if (!document.querySelector('script[data-mp-security]')) {
    await new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = 'https://www.mercadopago.com/v2/security.js';
      s.setAttribute('view', 'checkout');
      s.setAttribute('data-mp-security', '1');
      s.onload = () => resolve();
      s.onerror = () => resolve();
      document.head.appendChild(s);
    });
  }

  const limite = Date.now() + 3000;
  while (Date.now() < limite) {
    const id = String(window.MP_DEVICE_SESSION_ID || '').trim();
    if (id) return id;
    await new Promise((r) => setTimeout(r, 100));
  }
  return '';
}

export async function desmontarCartao() {
  tentativaCartao++;
  if (!brick) return;
  try { await brick.unmount(); } catch { /* já desmontado */ }
  brick = null;
}

/**
 * @param {object} p
 * @param {string} p.containerId  id do elemento que recebe o formulário
 * @param {number} p.valor        total já com frete e cupom (fonte única: calcularTotais)
 * @param {string} [p.publicKey]
 * @param {(formData:object)=>Promise<void>} p.aoSubmeter  lança Erro para recusar
 */
async function garantirSDKMercadoPago() {
  if (typeof window.MercadoPago !== 'undefined') return;

  await new Promise((resolve) => setTimeout(resolve, 300));
  if (typeof window.MercadoPago !== 'undefined') return;

  let script = document.querySelector('script[data-mp-bricks-fallback]');
  if (!script) {
    script = document.createElement('script');
    script.src = 'https://sdk.mercadopago.com/js/v2';
    script.async = true;
    script.setAttribute('data-mp-bricks-fallback', '1');
    document.head.appendChild(script);
  }

  const limite = Date.now() + 8000;
  while (Date.now() < limite) {
    if (typeof window.MercadoPago !== 'undefined') return;
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error('Não foi possível carregar o Mercado Pago. Verifique a conexão ou bloqueio do navegador.');
}

export async function montarCartao({ containerId, valor, publicKey, aoSubmeter }) {
  if (!(valor > 0)) throw new Error('O total do pedido é R$ 0,00.');
  await garantirSDKMercadoPago();
  await desmontarCartao();

  const chave = String(publicKey || '').trim();
  if (!chave) throw new Error('Esta loja ainda não conectou o Mercado Pago. Escolha outra forma de pagamento.');

  const container = document.getElementById(containerId);
  if (!container) throw new Error('Não foi possível abrir o formulário de cartão.');
  container.innerHTML = '<div class="mp-carregando-cartao">Carregando formulário seguro do Mercado Pago…</div>';

  const valorMP = Number(Number(valor).toFixed(2));
  console.info('[MP] Iniciando Brick', { chave: `${chave.slice(0, 12)}…${chave.slice(-4)}`, origem: 'loja (conta conectada)', valor: valorMP, container: containerId });
  const mp = new window.MercadoPago(chave, { locale: 'pt-BR' });
  const tentativa = ++tentativaCartao;
  let pronto = false;
  const infoChave = `chave ${chave.slice(0, 12)}…${chave.slice(-4)} (da loja) · valor ${valorMP.toFixed(2)}`;
  // Teste direto da chave pública (não bloqueia: só gera diagnóstico legível no próprio celular).
  let testeChave = 'não testada';
  try {
    if (typeof mp.getIdentificationTypes === 'function') {
      const r = await Promise.race([mp.getIdentificationTypes(), new Promise((_, rej) => setTimeout(() => rej(new Error('sem resposta em 6s')), 6000))]);
      testeChave = Array.isArray(r) && r.length ? 'chave aceita pelo Mercado Pago' : 'resposta vazia';
    }
  } catch (e) {
    testeChave = `chave REJEITADA/sem resposta: ${e?.message || e?.status || JSON.stringify(e)}`;
  }
  console.info('[MP] Teste da chave pública:', testeChave);
  const config = {
    initialization: { amount: valorMP },
    customization: {
      visual: { style: { theme: 'default' } },
      paymentMethods: { maxInstallments: 6 }
    },
    callbacks: {
      onReady: () => { pronto = true; console.log('[MP] Card Payment Brick pronto.'); document.getElementById(containerId)?.classList.add('mp-brick-pronto'); },
      onSubmit: (formData) => aoSubmeter(formData),
      onError: (e) => { console.error('[MP] Card Payment Brick:', e, JSON.stringify(e, Object.getOwnPropertyNames(e || {}))); const box=document.getElementById(containerId); if(box&&!box.querySelector('.mp-erro-cartao')){const d=document.createElement('div');d.className='mp-erro-cartao';d.textContent='Não foi possível carregar o formulário de cartão. Detalhe: '+(e?.message||e?.cause||'erro desconhecido')+' | '+infoChave+' | '+testeChave;box.appendChild(d);}}
    }
  };
  const limite = new Promise((_, reject) => setTimeout(() => reject(new Error('O Mercado Pago demorou para carregar o formulário de cartão. Tente novamente.')), 15000));
  try {
    const criado = await Promise.race([mp.bricks().create('cardPayment', containerId, config), limite]);
    if (tentativa !== tentativaCartao) { try { await criado?.unmount?.(); } catch {} return; }
    brick = criado;
    console.log('[MP] Card Payment Brick instanciado com sucesso.');
    const fim = Date.now() + 15000;
    while (!pronto && Date.now() < fim) await new Promise((r) => setTimeout(r, 200));
    if (!pronto) throw new Error(`O formulário do Mercado Pago não carregou. Diagnóstico: ${infoChave} · ${testeChave}.`);
  } catch (err) {
    tentativaCartao++;
    throw err;
  }
}

/**
 * Chama o backend. IMPORTANTE (contrato para o backend):
 *  - `pedidoKey` é a chave do pedido em /pedidos/{pedidoKey}; o backend deve gravar `pagoStatus`/`paymentIdMP` AÍ
 *    (antes gravava em /pedidos/{numeroPedido}, criando um nó órfão que nunca era lido).
 *  - O backend RECALCULA o valor a partir de /pedidos/{pedidoKey}/total e ignora `amount` do cliente.
 *  - O backend exige Firebase ID Token no header Authorization.
 *  - O checkout envia o Device ID do Mercado Pago em X-meli-session-id para reforçar a análise antifraude.
 *  - O backend deve ler o token em /restaurantes_privado/{lojaId}/mp_token (e não mais em /restaurantes).
 */
export async function cobrarNoBackend({ formData, valor, pedidoKey, codigo, lojaId, email }) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 70_000); // instância gratuita do Render pode demorar ~50s para "acordar"
  try {
    toast('Processando pagamento… pode levar alguns segundos.');
    const idToken = await auth.currentUser?.getIdToken(true);
    if (!idToken) throw new Error('Sessão expirada. Entre novamente.');
    const deviceId = await obterDeviceId();
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${idToken}`
    };
    if (deviceId) headers['X-meli-session-id'] = deviceId;
    const resp = await fetch(`${BACKEND}/criar-pagamento-loja`, {
      method: 'POST', headers, signal: ctrl.signal,
      body: JSON.stringify({
        token: formData.token, amount: valor, installments: formData.installments,
        paymentMethodId: formData.payment_method_id, payer: formData.payer, email,
        pedidoId: codigo, pedidoKey, lojaId
      })
    });
    const dados = await resp.json().catch(() => ({}));
    if (!resp.ok || dados.error) throw new Error(dados.error || dados.statusDetail || 'O pagamento foi recusado.');
    return dados; // { status: 'approved' | 'in_process' | 'rejected' ... }
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('O servidor de pagamentos demorou demais. Tente novamente.');
    throw e;
  } finally { clearTimeout(timer); }
}
