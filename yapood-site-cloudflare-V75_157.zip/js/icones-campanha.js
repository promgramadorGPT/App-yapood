/**
 * V75.68 — Ícones por data (Dia das Crianças, Natal, promoções…).
 * Regras puras: sem Firebase e sem DOM, para poderem ser testadas.
 * O Master grava em `config_icones/{app}`: { url, de, ate, rotulo, atualizadoEm }.
 * Dentro do período (horário de Brasília) o app e as notificações usam a imagem da data;
 * fora dele voltam sozinhos ao ícone padrão.
 */
export const APPS_ICONE = [
  { id: 'cliente', nome: 'Cliente', padrao: 'icons/icons-192.png', badge: 'icons/badge-96.png' },
  { id: 'painel', nome: 'Painel do lojista', padrao: 'icons/adm-192.png', badge: 'icons/badge-96.png' },
  { id: 'entregador', nome: 'Entregador', padrao: 'icons/entregador-192.png', badge: 'icons/badge-entregador-96.png' },
  { id: 'master', nome: 'Master', padrao: 'icons/master-192.png', badge: 'icons/badge-master-96.png' }
];
export const IDS_ICONE = APPS_ICONE.map((a) => a.id);
export const HOST_ICONE = /^https:\/\/res\.cloudinary\.com\/[A-Za-z0-9_.\-\/%~]+$/;

/** Dia de hoje em Brasília (UTC−3), no formato AAAA-MM-DD. */
export function hojeBR(agoraMs = Date.now()) { return new Date(agoraMs - 3 * 3600000).toISOString().slice(0, 10); }

export function dataIsoValida(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}
export function urlIconeValida(u) { return typeof u === 'string' && u.length <= 300 && HOST_ICONE.test(u); }

/** A campanha vale hoje? (mesma regra do NotPush) */
export function campanhaAtiva(c, agoraMs = Date.now()) {
  if (!c || typeof c !== 'object') return false;
  if (!urlIconeValida(c.url) || !dataIsoValida(c.de) || !dataIsoValida(c.ate) || c.de > c.ate) return false;
  const h = hojeBR(agoraMs);
  return h >= c.de && h <= c.ate;
}

/** Situação para o Master: sem campanha / agendada / no ar / encerrada. */
export function situacaoCampanha(c, agoraMs = Date.now()) {
  if (!c || !urlIconeValida(c.url) || !dataIsoValida(c.de) || !dataIsoValida(c.ate) || c.de > c.ate) return 'nenhuma';
  const h = hojeBR(agoraMs);
  if (h < c.de) return 'agendada';
  if (h > c.ate) return 'encerrada';
  return 'no-ar';
}

/** Valida o formulário do Master e devolve o objeto pronto para gravar. */
export function validarCampanha({ app, url, de, ate, rotulo } = {}, agoraMs = Date.now()) {
  if (!IDS_ICONE.includes(app)) return { ok: false, erro: 'Escolha o app.' };
  if (!urlIconeValida(url)) return { ok: false, erro: 'Envie a imagem do ícone.' };
  if (!dataIsoValida(de)) return { ok: false, erro: 'Informe a data de início.' };
  if (!dataIsoValida(ate)) return { ok: false, erro: 'Informe a data de fim.' };
  if (de > ate) return { ok: false, erro: 'A data de fim não pode ser antes do início.' };
  if (ate < hojeBR(agoraMs)) return { ok: false, erro: 'O período já terminou. Escolha datas de hoje em diante.' };
  const nome = String(rotulo || '').trim().slice(0, 40);
  return { ok: true, dados: { url, de, ate, rotulo: nome, atualizadoEm: agoraMs } };
}

/** Qual app é esta página? (para escolher ícone e silhueta) */
export function appDaPagina(pathname = '') {
  const p = String(pathname).toLowerCase();
  if (p.includes('admin-loja')) return 'painel';
  if (p.includes('entregador')) return 'entregador';
  if (p.includes('master')) return 'master';
  return 'cliente';
}

export function infoDoApp(id) { return APPS_ICONE.find((a) => a.id === id) || APPS_ICONE[0]; }

/** Dimensões do quadrado final (limitado a 512 px) a partir da imagem original. */
export function ladoQuadrado(largura, altura, max = 512) {
  const menor = Math.min(Number(largura) || 0, Number(altura) || 0);
  return Math.max(1, Math.min(max, Math.floor(menor)));
}

/** Avisos sobre a imagem escolhida (não bloqueiam; só orientam). */
export function avisosDoIcone(largura, altura) {
  const av = [];
  if (!largura || !altura) return av;
  if (Math.min(largura, altura) < 192) av.push('A imagem é pequena (menos de 192 px) e pode ficar borrada.');
  if (Math.abs(largura - altura) / Math.max(largura, altura) > 0.05) av.push('A imagem não é quadrada: será cortada no centro.');
  return av;
}
