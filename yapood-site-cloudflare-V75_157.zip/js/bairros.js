// js/bairros.js — taxa de entrega por bairro. Funções puras (sem Firebase, sem DOM).
//
// Dados:
//   restaurantes/{lojaId}/bairrosConfig = { ativo: boolean, naoCadastrado: 'padrao' | 'bloquear' }
//   restaurantes/{lojaId}/bairros/{id}  = { nome, taxa, prazo?, ativo?, origem?: 'adm' | 'cliente' }   (id = slug do nome)
//   bairros_sugeridos/{lojaId}/{id}     = { nome, clienteUid, criadoEm, status: 'pendente' | 'aprovado' | 'ignorado' }
//
// Regra de cobrança (a mesma é conferida nas Rules do pedido):
//   - config desligada → taxa padrão da loja (precioEnvio), como sempre foi.
//   - bairro cadastrado e ativo → taxa do bairro.
//   - bairro cadastrado e inativo → loja não entrega lá (bloqueia).
//   - bairro não cadastrado → naoCadastrado 'padrao' cobra a taxa padrão e vira sugestão para o ADM; 'bloquear' impede o pedido.

export const MAX_NOME = 60;
export const MAX_TAXA = 1000;
export const MAX_PRAZO = 600;
export const MAX_KM = 500;

const semAcento = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '');
const MINUSCULAS = new Set(['de', 'da', 'do', 'das', 'dos', 'e']);

/** Id estável do bairro: sem acento, minúsculo, só letras e números ("Santa Mônica" → "santamonica"). '' se inválido. */
export function slugBairro(nome) {
  const s = semAcento(nome).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, MAX_NOME);
  return s.length >= 2 ? s : '';
}

/** Arruma o nome digitado: espaços, tamanho e Maiúsculas ("jardim  das flores" → "Jardim das Flores"). */
export function normalizarNomeBairro(nome) {
  const limpo = String(nome ?? '').replace(/\s+/g, ' ').replace(/[<>]/g, '').trim().slice(0, MAX_NOME);
  return limpo.split(' ').map((p, i) => {
    const m = p.toLowerCase();
    if (i > 0 && MINUSCULAS.has(m)) return m;
    return m.charAt(0).toUpperCase() + m.slice(1);
  }).join(' ');
}

export function configBairros(loja) {
  const c = loja?.bairrosConfig || {};
  return { ativo: c.ativo === true, naoCadastrado: c.naoCadastrado === 'bloquear' ? 'bloquear' : 'padrao' };
}

const numero = (v) => { const n = Number(String(v ?? '').replace(',', '.')); return Number.isFinite(n) ? n : NaN; };
export const taxaValida = (v) => { const n = numero(v); return n >= 0 && n <= MAX_TAXA; };

/** Distância (km) válida: número entre 0 e MAX_KM. */
export const kmValido = (v) => { if (v === null || v === undefined || v === '') return false; const n = numero(v); return n >= 0 && n <= MAX_KM; };
/** Arredonda para 1 casa ("6,04" → 6). null se inválido. */
export const normalizarKm = (v) => (kmValido(v) ? Math.round(numero(v) * 10) / 10 : null);
export const textoKm = (km) => (kmValido(km) ? `${String(normalizarKm(km)).replace('.', ',')} km` : '');

/** Bairros da loja, em ordem alfabética (pt-BR). */
export function listarBairros(loja) {
  return Object.entries(loja?.bairros || {})
    .filter(([, b]) => b && typeof b.nome === 'string' && Number.isFinite(Number(b.taxa)))
    .map(([id, b]) => ({ id, nome: b.nome, taxa: Number(b.taxa), prazo: Number.isFinite(Number(b.prazo)) ? Number(b.prazo) : null, ativo: b.ativo !== false, origem: b.origem || 'adm', distanciaKm: kmValido(b.distanciaKm) ? Number(b.distanciaKm) : null }))
    .sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
}

/**
 * V75.153 — taxa de entrega POR BAIRRO deste pedido: a que o cliente pagou, quando a loja cobra por bairro e o bairro está cadastrado.
 * Serve para mostrar no ADM e para sugerir ao atribuir o entregador. → { nome, taxa } ou null (retirada, cobrança por bairro desligada,
 * bairro não cadastrado/inativo ou entrega grátis: aí vale a taxa padrão do entregador).
 */
export function taxaBairroDoPedido(pedido, loja) {
  if (!pedido || pedido.tipoEntrega === 'retirada') return null;
  if (!configBairros(loja).ativo || !pedido.bairro) return null;
  const r = resolverBairro(loja, pedido.bairro);
  if (r.estado !== 'cadastrado') return null;
  const taxa = Number(pedido.precioEnvio ?? pedido.taxaEntrega);
  if (!Number.isFinite(taxa) || taxa <= 0) return null;
  return { nome: r.nome || pedido.bairro, taxa: Math.round(taxa * 100) / 100 };
}

export const bairroConhecido = (loja, nome) => { const id = slugBairro(nome); return !!id && !!loja?.bairros?.[id]; };

/**
 * Decide a taxa e se o pedido pode seguir para o bairro digitado.
 * estado: 'desligado' | 'informar' | 'cadastrado' | 'novo' | 'indisponivel' | 'bloqueado'
 */
export function resolverBairro(loja, nomeDigitado) {
  const padrao = Math.max(0, Number(loja?.precioEnvio) || 0);
  const cfg = configBairros(loja);
  const id = slugBairro(nomeDigitado);
  if (!cfg.ativo) return { estado: 'desligado', permitido: true, taxa: padrao, bairroId: id || null, nome: normalizarNomeBairro(nomeDigitado) };
  if (!id) return { estado: 'informar', permitido: false, taxa: padrao, bairroId: null, nome: '' };
  const b = loja?.bairros?.[id];
  if (b && Number.isFinite(Number(b.taxa))) {
    if (b.ativo === false) return { estado: 'indisponivel', permitido: false, taxa: padrao, bairroId: id, nome: b.nome };
    return { estado: 'cadastrado', permitido: true, taxa: Math.max(0, Number(b.taxa)), bairroId: id, nome: b.nome, prazo: Number.isFinite(Number(b.prazo)) ? Number(b.prazo) : null };
  }
  const nome = normalizarNomeBairro(nomeDigitado);
  if (cfg.naoCadastrado === 'bloquear') return { estado: 'bloqueado', permitido: false, taxa: padrao, bairroId: id, nome };
  return { estado: 'novo', permitido: true, taxa: padrao, bairroId: id, nome };
}

/** Mensagem curta para o cliente sob o campo Bairro. */
export function textoBairro(r, formatar) {
  const m = formatar || ((v) => `R$ ${Number(v).toFixed(2).replace('.', ',')}`);
  switch (r.estado) {
    case 'cadastrado': return `Entrega em ${r.nome}: ${r.taxa > 0 ? m(r.taxa) : 'grátis'}${r.prazo ? ` · cerca de ${r.prazo} min` : ''}`;
    case 'novo': return `Taxa de entrega: ${r.taxa > 0 ? m(r.taxa) : 'grátis'}. Vamos avisar a loja que você pediu neste bairro.`;
    case 'indisponivel': return `A loja não está entregando em ${r.nome} no momento.`;
    case 'bloqueado': return `A loja ainda não entrega em ${r.nome}.`;
    case 'informar': return 'Informe o bairro para calcular a taxa de entrega.';
    default: return '';
  }
}

/** Sugestão que o cliente grava para o ADM aprovar. null se o nome for inválido. */
export function montarSugestao(nome, uid, agora = new Date(), distancia = null) {
  const id = slugBairro(nome);
  const n = normalizarNomeBairro(nome);
  if (!id || n.length < 2 || !uid) return null;
  const dados = { nome: n, clienteUid: uid, criadoEm: agora.toISOString(), status: 'pendente' };
  // V75.42: distância loja → cliente (linha reta), estimada pelo app. `fonte`: 'endereco' (rua+bairro), 'bairro' ou 'gps'.
  const km = normalizarKm(distancia?.km);
  if (km !== null) { dados.distanciaKm = km; dados.distanciaFonte = ['endereco', 'bairro', 'gps'].includes(distancia?.fonte) ? distancia.fonte : 'bairro'; }
  return { id, dados };
}

/** "Centro, Santa Mônica\nJardim das Flores" → lista única [{id, nome}] (ignora repetidos e inválidos). */
export function parseListaBairros(texto) {
  const vistos = new Set(), saida = [];
  for (const parte of String(texto ?? '').split(/[\n,;]+/)) {
    const nome = normalizarNomeBairro(parte), id = slugBairro(nome);
    if (!id || vistos.has(id)) continue;
    vistos.add(id); saida.push({ id, nome });
  }
  return saida;
}

/** Registro pronto para gravar em restaurantes/{lojaId}/bairros/{id}. Lança Error se taxa/prazo forem inválidos. */
export function montarBairro({ nome, taxa, prazo, ativo = true, origem = 'adm', distanciaKm }) {
  const n = normalizarNomeBairro(nome);
  if (!slugBairro(n)) throw new Error('Nome de bairro inválido.');
  const t = numero(taxa);
  if (!(t >= 0 && t <= MAX_TAXA)) throw new Error(`Taxa inválida (0 a R$ ${MAX_TAXA}).`);
  const reg = { nome: n, taxa: Math.round(t * 100) / 100, ativo: ativo !== false, origem: origem === 'cliente' ? 'cliente' : 'adm' };
  if (prazo !== undefined && prazo !== null && String(prazo).trim() !== '') {
    const p = numero(prazo);
    if (!(p >= 1 && p <= MAX_PRAZO)) throw new Error(`Prazo inválido (1 a ${MAX_PRAZO} minutos).`);
    reg.prazo = Math.round(p);
  }
  if (distanciaKm !== undefined && distanciaKm !== null && String(distanciaKm).trim() !== '') {
    if (!kmValido(distanciaKm)) throw new Error(`Distância inválida (0 a ${MAX_KM} km).`);
    reg.distanciaKm = normalizarKm(distanciaKm);
  }
  return reg;
}

/**
 * Pedidos (não cancelados) por bairro: { id: { qtd, ultimo } }. Casa pelo bairroId, pelo nome gravado no pedido
 * ou pelo fim do endereço ("Rua X, 10 - Bairro"), para que bairros ainda não cadastrados também mostrem quantos pedidos vieram deles.
 */
export function contarPedidosPorBairro(pedidos, ids) {
  const alvo = [...new Set(ids || [])];
  const saida = {};
  for (const p of pedidos || []) {
    if (!p || /cancel/i.test(String(p.status || ''))) continue;
    const slugs = new Set([p.bairroId, slugBairro(p.bairro)].filter(Boolean));
    const fim = slugBairro(String(p.cliente?.direccion || '').split(' - ').pop());
    for (const id of alvo) {
      if (!(slugs.has(id) || fim === id)) continue;
      const o = (saida[id] ||= { qtd: 0, ultimo: '' });
      o.qtd++;
      const t = String(p.criadoEm || ''); if (t > o.ultimo) o.ultimo = t;
    }
  }
  return saida;
}

/**
 * Resumo da taxa de entrega da loja para a página da loja e a lista (V75.42).
 * Sem taxa por bairro: a taxa padrão. Com taxa por bairro: faixa entre o menor e o maior valor que pode ser cobrado
 * (bairros atendidos + taxa padrão, que vale para bairro novo quando a loja não bloqueia).
 * { gratis: tudo grátis, algumGratis: ao menos um caso grátis, min, max, variavel: min !== max }
 */
export function resumoTaxaLoja(loja) {
  const padrao = Math.max(0, Number(loja?.precioEnvio) || 0);
  const cfg = configBairros(loja);
  let valores = [padrao];
  if (cfg.ativo) {
    const doBairro = listarBairros(loja).filter((b) => b.ativo).map((b) => Math.max(0, b.taxa));
    valores = cfg.naoCadastrado === 'padrao' ? [...doBairro, padrao] : (doBairro.length ? doBairro : [padrao]);
  }
  const min = Math.min(...valores), max = Math.max(...valores);
  return { min, max, variavel: min !== max, gratis: max === 0, algumGratis: min === 0 };
}

/** Texto da taxa: "Entrega grátis", "Entrega R$ 5,00", "Entrega de R$ 3,00 a R$ 8,00", "Entrega grátis a R$ 8,00". */
export function textoTaxaLoja(loja, formatar) {
  const m = formatar || ((v) => `R$ ${Number(v).toFixed(2).replace('.', ',')}`);
  const r = resumoTaxaLoja(loja);
  if (r.gratis) return 'Entrega grátis';
  if (!r.variavel) return `Entrega ${m(r.min)}`;
  return r.min === 0 ? `Entrega grátis a ${m(r.max)}` : `Entrega de ${m(r.min)} a ${m(r.max)}`;
}
