// V75.17 — Presente fidelidade (front): regras puras compartilhadas entre cliente e ADM.
// Cada pedido CONCLUÍDO na loja avança uma casa; ao completar a meta o cliente ganha o presente escolhido pela loja.
// Nada é guardado "no saldo do cliente": o progresso é sempre derivado dos pedidos reais (status só a loja altera),
// e o presente usado fica marcado no pedido (premioFidelidade). Cancelar esse pedido devolve o presente.
import { arredondar, normalizarStatus, normalizarPagamento, calcularTotais, STATUS, PAGO } from './regras.js';

export const TIPOS_PREMIO = {
  frete_gratis: 'Entrega grátis',
  fixo: 'Desconto em reais',
  porcentagem: 'Desconto em porcentagem',
  pedido_gratis: 'Pedido grátis (até um valor)'
};
export const META_MIN = 2;
export const META_MAX = 30;
// Pedido online que ficou sem pagar não "gasta" o presente depois desse prazo.
const PRAZO_ABANDONO_MS = 30 * 60 * 1000;

const reais = (n) => `R$ ${arredondar(n).toFixed(2).replace('.', ',')}`;

export function tituloPremio(c) {
  if (!c) return '';
  if (c.tipo === 'frete_gratis') return 'Entrega grátis';
  if (c.tipo === 'fixo') return `${reais(c.valor)} de desconto`;
  if (c.tipo === 'porcentagem') return `${c.valor}% de desconto${c.valorMaximo > 0 ? ` (máx. ${reais(c.valorMaximo)})` : ''}`;
  if (c.tipo === 'pedido_gratis') return `Pedido grátis (até ${reais(c.valorMaximo)})`;
  return '';
}

// Lê e valida o que está gravado em restaurantes/{loja}/fidelidade. Devolve null se desligado ou incompleto.
export function configFidelidade(raw) {
  if (!raw || raw.ativo !== true) return null;
  const meta = Math.floor(Number(raw.meta));
  if (!(meta >= META_MIN && meta <= META_MAX)) return null;
  const tipo = raw.tipo;
  if (!TIPOS_PREMIO[tipo]) return null;
  const valor = arredondar(raw.valor), valorMaximo = arredondar(raw.valorMaximo), minimoPedido = arredondar(raw.minimoPedido);
  if (tipo === 'fixo' && !(valor > 0)) return null;
  if (tipo === 'porcentagem' && !(valor > 0 && valor <= 100)) return null;
  if (tipo === 'pedido_gratis' && !(valorMaximo > 0)) return null;
  const c = { meta, tipo, valor, valorMaximo, minimoPedido, inicioEm: String(raw.inicioEm || '') };
  return { ...c, titulo: tituloPremio(c) };
}

export function descontoPremio(cfg, subtotal, envio) {
  if (!cfg) return 0;
  const sub = arredondar(subtotal), env = arredondar(envio);
  let d = 0;
  if (cfg.tipo === 'frete_gratis') d = env;
  else if (cfg.tipo === 'fixo') d = cfg.valor;
  else if (cfg.tipo === 'porcentagem') { d = (sub * cfg.valor) / 100; if (cfg.valorMaximo > 0) d = Math.min(d, cfg.valorMaximo); }
  else if (cfg.tipo === 'pedido_gratis') d = Math.min(sub, cfg.valorMaximo);
  return arredondar(Math.max(0, Math.min(d, sub + env)));
}

// Mesmo formato de calcularTotais, mas com o presente no lugar do cupom (os dois nunca somam).
export function calcularTotaisComPremio(itens, precioEnvio, cupons, codigoCupom, premioCfg, uso = null) {
  if (!premioCfg) return { ...calcularTotais(itens, precioEnvio, cupons, codigoCupom, new Date(), uso), premio: null };
  const base = calcularTotais(itens, precioEnvio, [], '');
  const d = descontoPremio(premioCfg, base.subtotal, base.envio);
  return {
    ...base, desconto: d, total: arredondar(Math.max(0, base.subtotal + base.envio - d)), cupom: null, erroCupom: null,
    premio: { tipo: premioCfg.tipo, titulo: premioCfg.titulo, desconto: d }
  };
}

// Conta para a meta: pedido entregue, a partir do início do programa, acima do mínimo, que não usou presente
// e não foi totalmente reembolsado.
export function pedidoConta(p, cfg) {
  if (!p || !cfg) return false;
  if (normalizarStatus(p.status) !== STATUS.ENTREGUE) return false;
  if (p.premioFidelidade) return false;
  if (p.reembolso?.status === 'aprovado' && !p.reembolso.parcial) return false;
  if (cfg.minimoPedido > 0 && (Number(p.subtotal) || 0) < cfg.minimoPedido) return false;
  if (cfg.inicioEm && String(p.criadoEm || '') < cfg.inicioEm) return false;
  return true;
}

// Pedido que já "gastou" um presente: não cancelado e não abandonado sem pagamento.
export function pedidoConsomePremio(p, agora = new Date()) {
  if (!p?.premioFidelidade) return false;
  if (normalizarStatus(p.status) === STATUS.CANCELADO) return false;
  if (p.pagoStatus && normalizarPagamento(p.pagoStatus) === PAGO.PENDENTE) {
    const t = Date.parse(p.criadoEm || '');
    if (Number.isFinite(t) && agora.getTime() - t > PRAZO_ABANDONO_MS) return false;
  }
  return true;
}

export function progressoFidelidade(pedidos, uid, lojaId, cfg, agora = new Date()) {
  const vazio = { concluidos: 0, meta: cfg?.meta || 0, ganhos: 0, usados: 0, disponiveis: 0, posicao: 0, faltam: cfg?.meta || 0 };
  if (!cfg || !uid) return vazio;
  const meus = (pedidos || []).filter((p) => p && p.clienteUid === uid && p.lojaId === lojaId);
  const concluidos = meus.filter((p) => pedidoConta(p, cfg)).length;
  const ganhos = Math.floor(concluidos / cfg.meta);
  const usados = meus.filter((p) => pedidoConsomePremio(p, agora)).length;
  const disponiveis = Math.max(0, ganhos - usados);
  const posicao = disponiveis > 0 ? cfg.meta : concluidos % cfg.meta;
  return { concluidos, meta: cfg.meta, ganhos, usados, disponiveis, posicao, faltam: disponiveis > 0 ? 0 : cfg.meta - posicao };
}

// V75.36 — O presente é uma SURPRESA: o cliente só vê o que ganhou depois de abrir a caixa (overlay).
// `reveladosContados` = quantos presentes dessa loja ele já abriu neste aparelho. Pedido que já usou presente conta como aberto.
//  - novos: ganhos ainda fechados (mostram "Abrir presente"; não dá para usar antes de abrir)
//  - visiveis: ganhos já abertos e ainda não usados (aparecem em Cupons e no carrinho)
export function presentesParaCliente(pr, reveladosContados = 0) {
  const ganhos = Number(pr?.ganhos) || 0, usados = Number(pr?.usados) || 0, disp = Number(pr?.disponiveis) || 0;
  const revelados = Math.max(Number(reveladosContados) || 0, usados);
  const novos = Math.max(0, Math.min(disp, ganhos - revelados));
  return { novos, visiveis: Math.max(0, disp - novos), revelados };
}

// Texto de progresso SEM revelar o prêmio.
export function textoProgressoSurpresa(pr, cfg) {
  const feitos = cfg ? pr.concluidos % cfg.meta : 0;
  return `${feitos} de ${cfg.meta} pedidos concluídos. Faltam ${pr.faltam} para abrir seu presente surpresa.`;
}

// Para o ADM: o pedido que traz um presente confere com o histórico do cliente?
export function conferePremioPedido(pedido, pedidosLoja, cfg, agora = new Date()) {
  if (!pedido?.premioFidelidade) return null;
  if (!cfg) return { ok: false, motivo: 'O programa está desligado ou foi alterado.' };
  const pr = progressoFidelidade(pedidosLoja, pedido.clienteUid, pedido.lojaId, cfg, agora);
  const ok = pr.ganhos >= pr.usados && pr.usados >= 1;
  return { ok, concluidos: pr.concluidos, meta: pr.meta, ganhos: pr.ganhos, usados: pr.usados,
    motivo: ok ? '' : `O cliente tem ${pr.concluidos} pedido(s) concluído(s) (meta ${pr.meta}) e ${pr.usados} presente(s) em uso.` };
}

export function resumoPremioPedido(p) {
  const x = p?.premioFidelidade;
  return x ? `${x.titulo || 'Presente fidelidade'}` : '';
}
