// V75.36 — Cupons: seção "Meus presentes" (presentes de fidelidade já abertos) + caixas ainda fechadas.
// Independe do carrinho: lê os pedidos do cliente e usa as mesmas regras de Meus pedidos.
import { auth, onAuthStateChanged } from './firebase.js';
import { escapeHtml } from './regras.js';
import { obterCarrinho } from './utils.js';
import { buscarLoja, buscarPedidosDoCliente } from './pedido-service.js';
import { configFidelidade, progressoFidelidade, presentesParaCliente } from './fidelidade.js';
import { lerReveladas, marcarReveladas, mostrarPresente, pedirUsoNoCarrinho } from './fidelidade-presente.js';

const sec = document.getElementById('presentes');
const itens = new Map(); // lojaId -> dados do presente
let rodando = false;

async function montar(user) {
  if (!sec || rodando) return; rodando = true;
  try {
    if (!user) { sec.hidden = true; return; }
    const pedidos = await buscarPedidosDoCliente(user.uid);
    const lojas = new Map();
    for (const p of pedidos) if (p.lojaId && !lojas.has(p.lojaId)) lojas.set(p.lojaId, p.lojaNome || 'Restaurante');
    const reveladas = lerReveladas(user.uid);
    const cards = [];
    itens.clear();
    for (const [lojaId, nome] of lojas) {
      let loja = null; try { loja = await buscarLoja(lojaId); } catch { /* ignora a loja */ }
      const cfg = configFidelidade(loja?.fidelidade); if (!cfg) continue;
      const pr = progressoFidelidade(pedidos, user.uid, lojaId, cfg);
      const { novos, visiveis } = presentesParaCliente(pr, reveladas[lojaId]);
      const nomeLoja = loja?.nombre || nome;
      itens.set(lojaId, { lojaId, lojaNome: nomeLoja, titulo: cfg.titulo, quantidade: novos, ganhos: pr.ganhos });
      if (novos > 0) cards.push(`<div class="fid-pres fechado"><span class="fid-pres-ic" aria-hidden="true"><i class="fa-solid fa-gift"></i></span>
        <div class="fid-pres-info"><strong>${escapeHtml(nomeLoja)}</strong>Um presente surpresa está esperando por você.</div>
        <button type="button" class="fid-pres-btn" data-abrir="${escapeHtml(lojaId)}">Abrir</button></div>`);
      if (visiveis > 0) cards.push(`<div class="fid-pres"><span class="fid-pres-ic" aria-hidden="true"><i class="fa-solid fa-gift"></i></span>
        <div class="fid-pres-info"><strong>${escapeHtml(nomeLoja)}${visiveis > 1 ? ` · ${visiveis} presentes` : ''}</strong>${escapeHtml(cfg.titulo)}. Não soma com cupom.</div>
        <button type="button" class="fid-pres-btn" data-usar="${escapeHtml(lojaId)}">Usar</button></div>`);
    }
    sec.hidden = !cards.length;
    sec.innerHTML = cards.length ? `<h2><i class="fa-solid fa-gift" style="color:#e0a100" aria-hidden="true"></i> Meus presentes</h2>${cards.join('')}` : '';
    if (cards.length && location.hash === '#presentes') sec.scrollIntoView({ block: 'start' });
  } catch (e) { console.warn('Meus presentes:', e); }
  finally { rodando = false; }
}

sec?.addEventListener('click', (e) => {
  const uid = auth.currentUser?.uid; if (!uid) return;
  const ab = e.target.closest('[data-abrir]');
  if (ab) {
    const d = itens.get(ab.dataset.abrir); if (!d) return;
    mostrarPresente({ lojaNome: d.lojaNome, titulo: d.titulo, quantidade: d.quantidade, aoPegar: () => { marcarReveladas(uid, d.lojaId, d.ganhos); montar(auth.currentUser); } });
    return;
  }
  const us = e.target.closest('[data-usar]');
  if (us) {
    const lojaId = us.dataset.usar;
    pedirUsoNoCarrinho(lojaId);
    const c = obterCarrinho();
    location.href = c.lojaId === lojaId && c.itens?.length ? 'cart.html' : `restaurante.html?id=${encodeURIComponent(lojaId)}`;
  }
});

onAuthStateChanged(auth, (u) => montar(u));
