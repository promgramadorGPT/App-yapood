// V75.17 — Meus pedidos: barra do presente fidelidade por loja (ex.: ●-●-●-○-○-[caixa de presente]).
// V75.36 — O prêmio é surpresa: só aparece depois que o cliente abre a caixa (overlay com confetes) e o presente vai para Cupons.
// Módulo isolado (mesmo padrão do reembolso): se falhar, Meus pedidos segue igual.
import { auth, onAuthStateChanged } from './firebase.js';
import { escapeHtml } from './regras.js';
import { buscarLoja, buscarPedidosDoCliente } from './pedido-service.js';
import { configFidelidade, progressoFidelidade, presentesParaCliente, textoProgressoSurpresa } from './fidelidade.js';
import { lerReveladas, marcarReveladas, mostrarPresente } from './fidelidade-presente.js';

const lista = document.getElementById('lista-pedidos-historico');
let box = null;
const lojasCache = new Map();
let rodando = false;
let abriuAuto = false;
const abertos = new Map(); // lojaId -> dados para o overlay

function garantirBox() {
  if (box || !lista) return box;
  box = document.createElement('div');
  box.id = 'fidelidade-box';
  box.className = 'fid-box-pedidos';
  lista.parentNode.insertBefore(box, lista);
  return box;
}

async function cfgDaLoja(lojaId) {
  if (!lojasCache.has(lojaId)) {
    try { lojasCache.set(lojaId, await buscarLoja(lojaId)); } catch { lojasCache.set(lojaId, null); }
  }
  return lojasCache.get(lojaId);
}

function barra(cfg, pr) {
  const casas = Array.from({ length: cfg.meta }, (_, i) => `<i class="fid-casa${i < pr.posicao ? ' on' : ''}"></i>`).join('<b class="fid-liga"></b>');
  return `<div class="fid-barra" role="img" aria-label="${pr.posicao} de ${cfg.meta} pedidos">${casas}<b class="fid-liga"></b><i class="fa-solid fa-gift fid-presente${pr.disponiveis > 0 ? ' on' : ''}" aria-hidden="true"></i></div>`;
}

async function atualizar(user) {
  if (rodando) return; rodando = true;
  try {
    const b = garantirBox(); if (!b) return;
    if (!user) { b.innerHTML = ''; return; }
    const pedidos = await buscarPedidosDoCliente(user.uid);
    const porLoja = new Map();
    for (const p of pedidos) if (p.lojaId && !porLoja.has(p.lojaId)) porLoja.set(p.lojaId, p.lojaNome || 'Restaurante');
    const cards = [];
    const reveladas = lerReveladas(user.uid);
    abertos.clear();
    for (const [lojaId, nome] of porLoja) {
      const loja = await cfgDaLoja(lojaId);
      const cfg = configFidelidade(loja?.fidelidade);
      if (!cfg) continue;
      const pr = progressoFidelidade(pedidos, user.uid, lojaId, cfg);
      const { novos, visiveis } = presentesParaCliente(pr, reveladas[lojaId]);
      const nomeLoja = loja?.nombre || nome;
      if (novos > 0) abertos.set(lojaId, { lojaId, lojaNome: nomeLoja, titulo: cfg.titulo, quantidade: novos, ganhos: pr.ganhos });
      const pronto = novos > 0 || visiveis > 0;
      const texto = novos > 0
        ? `Seu presente chegou! Toque em “Abrir presente” para ver o que você ganhou.`
        : visiveis > 0
          ? `Você tem ${visiveis > 1 ? `${visiveis} presentes guardados` : 'um presente guardado'} em Cupons: <strong>${escapeHtml(cfg.titulo)}</strong>.`
          : escapeHtml(textoProgressoSurpresa(pr, cfg));
      cards.push(`<div class="fid-card${pronto ? ' pronto' : ''}">
        <div class="fid-cab"><strong><i class="fa-solid fa-gift fid-cab-icone" aria-hidden="true"></i> Presente fidelidade</strong><span class="fid-loja">${escapeHtml(nomeLoja)}</span></div>
        ${barra(cfg, { ...pr, disponiveis: novos + visiveis })}
        <p class="fid-txt">${texto}</p>
        ${novos > 0 ? `<button type="button" class="fid-btn" data-abrir-presente="${escapeHtml(lojaId)}">Abrir presente</button>` : ''}
        ${novos === 0 && visiveis > 0 ? '<a class="fid-link" href="cupons.html#presentes">Ver em Cupons</a>' : ''}
      </div>`);
    }
    b.innerHTML = cards.length ? cards.join('') : '';
    if (!abriuAuto && abertos.size && !document.getElementById('fid-overlay')) { abriuAuto = true; abrir([...abertos.keys()][0], user.uid); }
  } catch (e) { console.warn('Presente fidelidade:', e); }
  finally { rodando = false; }
}

// Overlay da caixa de presente: ao pegar, marca como aberto e leva o cliente para Cupons.
function abrir(lojaId, uid) {
  const d = abertos.get(lojaId); if (!d) return;
  mostrarPresente({ lojaNome: d.lojaNome, titulo: d.titulo, quantidade: d.quantidade, aoPegar: () => { marcarReveladas(uid, lojaId, d.ganhos); location.href = 'cupons.html#presentes'; } });
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-abrir-presente]');
  if (b && auth.currentUser) abrir(b.dataset.abrirPresente, auth.currentUser.uid);
});

onAuthStateChanged(auth, (user) => { atualizar(user); });
// Atualiza quando a lista de pedidos muda (pedido entregue, cancelado etc.).
if (lista) {
  let t = null;
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(() => atualizar(auth.currentUser), 600); }).observe(lista, { childList: true });
}
