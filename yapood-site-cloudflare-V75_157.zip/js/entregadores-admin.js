// V75.23 — Entregadores no ADM (refeito). Módulo isolado: se algo falhar aqui, pedidos e demais abas seguem normais.
// Abas: Equipe (cadastro, edição, convites) · Entregas (sem entregador, em andamento, concluídas) · Pagamentos (pagar em lote, extrato, comprovantes).
import { auth } from './firebase.js';
import { avisarEvento } from './notpush-evento.js';
import { taxaBairroDoPedido } from './bairros.js';
import { urlRota } from './rota.js';
import { urlApp } from './apps-config.js';
import { confirmar } from './ui-mensagens.js';
import {
  FORMAS, filtrarPorPeriodo, totais, agruparPorEntregador, estatisticas, pedidosSemEntregador, pendente,
  csvExtrato, textoComprovante, linkWhatsApp, formatarTelefone, arred, deveLembrarEntregador, cargaDoEntregador, textoCarga, saiuComPedidos, textoSaiu,
  entregaAtiva, botaoDoCard, ehTrocaEmRota, statusSaiu
} from './entregadores-util.js?v=75.137';

const API = 'https://api-mp-yapoodbr.onrender.com';
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const moeda = (v) => (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dia = (t) => (t ? new Date(t).toLocaleDateString('pt-BR') : '');
const diaHora = (t) => (t ? new Date(t).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '');
const pl = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;
const decimal = (v) => String(Number(v) || 0).replace('.', ',');
const aNumero = (v) => Number(String(v ?? '').replace(',', '.'));
const linkEntregador = () => urlApp('entregador', 'entregador.html');
// V75.136: veículo e placa opcionais (aparecem para o cliente só se preenchidos); bicicleta não tem placa
const VEICULOS = { moto: 'Moto', bicicleta: 'Bicicleta', carro: 'Carro' };
const temPlaca = (v) => v === 'moto' || v === 'carro';
const opcoesVeiculo = (atual = '') => `<option value="">Não informar</option>${Object.entries(VEICULOS).map(([k, n]) => `<option value="${k}"${k === atual ? ' selected' : ''}>${n}</option>`).join('')}`;
const textoVeiculo = (e) => [VEICULOS[e.veiculo] || '', temPlaca(e.veiculo) && e.placa ? 'placa ' + e.placa : ''].filter(Boolean).join(' · ');

const est = { ent: { entregadores: [], convites: [] }, taxas: [], entregas: [], acertos: [], periodo: 'tudo', aba: 'equipe', avisos: [] };
// V75.112: pedido com corrida da entrega parceira em andamento já tem quem entregue; não entra em "sem entregador"
const semParceiro = (lista) => lista.filter((p) => !window.__yapoodParceira?.temCorridaAtiva?.(p.key));
const lojaNome = () => document.querySelector('#loja-nome')?.value?.trim() || '';

async function chamar(rota, corpo = {}) {
  const lojaId = window.__yapood?.lojaId;
  const token = await auth.currentUser?.getIdToken();
  if (!lojaId || !token) throw new Error('Sessão expirada. Entre novamente.');
  const r = await fetch(API + rota, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({ lojaId, ...corpo }) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok || d.error) throw Object.assign(new Error(d.error || 'Não foi possível concluir.'), { status: r.status, codigo: d.codigo || '' });
  return d;
}
function msg(texto, erro = false) { const el = $('ent-adm-msg'); if (!el) return; el.textContent = texto || ''; el.className = 'ent-adm-msg' + (erro ? ' erro' : ' ok'); el.hidden = !texto; }
const numeroDe = (key) => est.entregas.find((e) => e.pedidoKey === key)?.numeroPedido || (window.__yapood?.pedidos || []).find((p) => p.key === key)?.numeroPedido || String(key).slice(-6).toUpperCase();

async function copiar(texto) {
  try { await navigator.clipboard.writeText(texto); return true; }
  catch { window.prompt('Copie o texto abaixo:', texto); return false; }
}

// ---------- Carregamento ----------
async function carregar() {
  est.avisos = [];
  const [l, t, en, ac] = await Promise.allSettled([chamar('/entregador/listar'), chamar('/entregador/taxas'), chamar('/entregador/entregas'), chamar('/entregador/acertos')]);
  if (l.status === 'rejected') throw l.reason;
  if (t.status === 'rejected') throw t.reason;
  est.ent = l.value; est.taxas = t.value.taxas || [];
  est.entregas = en.status === 'fulfilled' ? en.value.entregas : [];
  est.acertos = ac.status === 'fulfilled' ? ac.value.acertos : [];
  est.carregadoEm = Date.now();
  if (en.status === 'rejected' || ac.status === 'rejected') est.avisos.push('Parte das informações não carregou. Confirme que a API está na versão 2.6 ou mais nova.');
}

// V75.57 — usado pelo painel de pedidos antes de "Enviar para entrega". Qualquer falha ou demora = não lembrar (nunca trava o envio).
async function lembrarEntregador(pedido) {
  try {
    if (!est.carregadoEm || Date.now() - est.carregadoEm > 15000) {
      const r = await Promise.race([Promise.allSettled([chamar('/entregador/listar'), chamar('/entregador/entregas')]), new Promise((ok) => setTimeout(() => ok(null), 4000))]);
      if (!r || r[0].status !== 'fulfilled' || r[1].status !== 'fulfilled') return false;
      est.ent = r[0].value; est.entregas = r[1].value.entregas || []; est.carregadoEm = Date.now();
    }
    return deveLembrarEntregador(pedido, est.entregas, est.ent?.entregadores);
  } catch { return false; }
}
// V75.137: quem está atribuído a um pedido (para o rastreio no card do pedido, js/rastreio-adm.js)
function atribuidoDe(pedidoKey) {
  const e = entregaAtiva(pedidoKey, est.entregas); if (!e) return null;
  const p = (est.ent.entregadores || []).find((x) => x.uid === e.entregadorUid);
  return { uid: e.entregadorUid, nome: e.entregador || p?.nome || '', telefone: p?.telefone || '' };
}
// V75.137: o card do pedido precisa saber quem está atribuído mesmo sem abrir a aba Entregadores (no máximo a cada 45 s)
let cardsCarregando = false, cardsEm = 0;
async function carregarParaCards(forcar = false) {
  if (cardsCarregando || (!forcar && Date.now() - Math.max(cardsEm, est.carregadoEm || 0) < 45000)) return;
  if (!window.__yapood?.lojaId || !auth.currentUser) return;
  cardsCarregando = true; cardsEm = Date.now();
  try {
    const [l, en] = await Promise.all([chamar('/entregador/listar'), chamar('/entregador/entregas')]);
    est.ent = l; est.entregas = en.entregas || [];
  } catch { /* sem a API, os cards ficam como antes (só o botão Atribuir) */ }
  finally { cardsCarregando = false; }
  try { marcarCards(); } catch { /* nada */ }
  document.dispatchEvent(new CustomEvent('yapood:entregas'));
}
window.__yapoodEntregadores = { lembrar: lembrarEntregador, atribuidoDe, recarregar: () => carregarParaCards(true) };

async function abrir() {
  try { msg(''); await carregar(); renderTudo(); if (est.avisos.length) msg(est.avisos[0], true); }
  catch (err) { msg(err.message, true); }
}

// ---------- Render ----------
function renderTudo() { renderKpis(); renderEquipe(); renderEntregas(); renderPagamentos(); renderAcertos(); selecionarAba(est.aba); }

function renderKpis() {
  const ativos = est.ent.entregadores.filter((e) => e.ativo).length;
  const andamento = est.entregas.filter((e) => !e.confirmada && !e.cancelado).length;
  const t = totais(est.taxas);
  $('ent-kpi-ativos').textContent = String(ativos);
  $('ent-kpi-andamento').textContent = String(andamento);
  $('ent-kpi-apagar').textContent = moeda(t.pendenteValor);
  $('ent-adm-resumo').textContent = t.pendenteQtd ? `${pl(t.pendenteQtd, 'taxa pendente', 'taxas pendentes')}` : 'Tudo em dia';
  const semQtd = semParceiro(pedidosSemEntregador(window.__yapood?.pedidos || [], est.entregas)).length;
  const nE = $('ent-aba-n-entregas'); nE.textContent = String(semQtd); nE.hidden = !semQtd;
  const nP = $('ent-aba-n-pagamentos'); nP.textContent = String(t.pendenteQtd); nP.hidden = !t.pendenteQtd;
}

function cartaoEntregador(e) {
  const s = estatisticas(e.uid, est.entregas, est.taxas);
  const zap = linkWhatsApp(e.telefone);
  return `<article class="ent-pessoa${e.ativo ? '' : ' inativo'}" data-uid="${esc(e.uid)}">
    <div class="ent-avatar" aria-hidden="true">${esc((e.nome || '?').trim().charAt(0).toUpperCase())}</div>
    <div class="ent-pessoa-info">
      <strong>${esc(e.nome)} <span class="ent-status ${e.ativo ? 'ativo' : 'inativo'}">${e.ativo ? 'Ativo' : 'Inativo'}</span></strong>
      <span class="ent-contato">${esc(e.email)}${e.telefone ? ` · ${zap ? `<a href="${zap}" target="_blank" rel="noopener">${esc(formatarTelefone(e.telefone))}</a>` : esc(formatarTelefone(e.telefone))}` : ' · <b class="ent-devo">sem WhatsApp</b>'}${textoVeiculo(e) ? ' · ' + esc(textoVeiculo(e)) : ''}</span>
      <span class="ent-nums">Taxa padrão <b>${moeda(e.taxaPadrao)}</b> · ${s.emAndamento} em andamento · ${pl(s.concluidas, 'concluída', 'concluídas')}${s.aPagar ? ` · <b class="ent-devo">a pagar ${moeda(s.aPagar)}</b>` : ''}</span>
    </div>
    <div class="ent-pessoa-acoes">
      <button type="button" class="btn-secondary" data-ent-editar>Editar</button>
      <button type="button" class="btn-secondary" data-ent-ativar="${esc(e.uid)}" data-ativo="${e.ativo}">${e.ativo ? 'Desativar' : 'Ativar'}</button>
    </div>
    <form class="ent-edit-form" data-ent-edit="${esc(e.uid)}" hidden>
      <label>Nome<input name="nome" maxlength="80" value="${esc(e.nome)}" required></label>
      <div class="ent-linha-2">
        <label>WhatsApp<input name="telefone" type="tel" inputmode="tel" maxlength="20" value="${esc(formatarTelefone(e.telefone))}" placeholder="(34) 99999-0000" required></label>
        <label>Taxa padrão (R$)<input name="taxaPadrao" inputmode="decimal" value="${esc(decimal(e.taxaPadrao))}"></label>
      </div>
      <div class="ent-linha-2">
        <label><span>Veículo <small>opcional</small></span><select name="veiculo">${opcoesVeiculo(e.veiculo)}</select></label>
        <label><span>Placa <small>opcional</small></span><input name="placa" maxlength="8" autocapitalize="characters" value="${esc(temPlaca(e.veiculo) ? e.placa : '')}" placeholder="ABC1D23"${temPlaca(e.veiculo) ? '' : ' disabled'}></label>
      </div>
      <p class="ent-ajuda">A nova taxa vale para as próximas atribuições; entregas já atribuídas mantêm o valor combinado.</p>
      <div class="ent-botoes"><button type="submit" class="btn-primary">Salvar</button><button type="button" class="btn-secondary" data-ent-editar>Cancelar</button></div>
    </form>
  </article>`;
}
function cartaoConvite(c) {
  const zap = linkWhatsApp(c.telefone, `Olá, ${c.nome || ''}! Você foi cadastrado como entregador${lojaNome() ? ' da ' + lojaNome() : ''}. Entre com a conta Google ${c.email} em ${linkEntregador()}`);
  return `<article class="ent-pessoa convite" data-convite="${esc(c.email)}">
    <div class="ent-avatar convite" aria-hidden="true"><i class="fa-solid fa-envelope"></i></div>
    <div class="ent-pessoa-info">
      <strong>${esc(c.nome || c.email)} <span class="ent-status pendente">Convite pendente</span></strong>
      <span class="ent-contato">${esc(c.email)}${c.telefone ? ' · ' + esc(formatarTelefone(c.telefone)) : ''}</span>
      <span class="ent-nums">Aguardando o primeiro acesso com este e-mail Google.</span>
    </div>
    <div class="ent-pessoa-acoes">
      ${zap ? `<a class="btn-secondary" href="${zap}" target="_blank" rel="noopener">Enviar no WhatsApp</a>` : ''}
      <button type="button" class="btn-secondary" data-ent-copiar-link>Copiar link</button>
      <button type="button" class="btn-secondary" data-ent-cancelar-convite="${esc(c.email)}">Cancelar</button>
    </div>
  </article>`;
}
function renderEquipe() {
  const { entregadores, convites } = est.ent;
  const ordenados = [...entregadores].sort((a, b) => (b.ativo - a.ativo) || String(a.nome).localeCompare(String(b.nome), 'pt-BR'));
  $('ent-adm-lista').innerHTML = (convites.map(cartaoConvite).join('') + ordenados.map(cartaoEntregador).join(''))
    || '<p class="ent-adm-vazio">Nenhum entregador cadastrado ainda. Toque em "Cadastrar entregador" para começar.</p>';
}

function itemEntrega(x, { desfazer = false } = {}) {
  const situacao = x.cancelado ? 'Pedido cancelado' : x.confirmada ? `Entregue ${diaHora(x.confirmadaEm)}` : 'Em andamento';
  return `<div class="ent-entrega ${x.cancelado ? 'cancelada' : x.confirmada ? 'ok' : ''}"><div><span class="item-title">Pedido #${esc(x.numeroPedido)} · ${esc(x.clienteNome)}</span><span class="item-sub">${esc(situacao)} · ${esc(x.endereco || 'sem endereço')} · taxa ${moeda(x.taxa)}</span></div>${desfazer ? `<div class="ent-entrega-acoes">${statusSaiu(x.status) ? `<button type="button" class="btn-secondary" data-ent-trocar="${esc(x.pedidoKey)}">Trocar entregador</button>` : ''}<button type="button" class="btn-secondary" data-ent-desatribuir="${esc(x.pedidoKey)}">Desfazer</button></div><div class="ent-troca-form"></div>` : ''}</div>`;
}
function renderEntregas() {
  const sem = semParceiro(pedidosSemEntregador(window.__yapood?.pedidos || [], est.entregas));
  $('ent-sem-card').hidden = !sem.length;
  $('ent-sem-qtd').textContent = String(sem.length);
  $('ent-adm-sem').innerHTML = sem.map((p) => `<div class="ent-sem" data-pedido="${esc(p.key)}">
      <div><span class="item-title">Pedido #${esc(p.numeroPedido || p.key)} · ${esc(p.cliente?.nombre || 'Cliente')}</span><span class="item-sub">${esc(p.cliente?.direccion || 'sem endereço')}</span></div>
      <button type="button" class="btn-primary" data-ent-abrir-atrib>Atribuir</button><div class="ent-sem-form"></div></div>`).join('');
  const abertas = est.entregas.filter((x) => !x.confirmada && !x.cancelado);
  const fechadas = est.entregas.filter((x) => x.confirmada || x.cancelado);
  const grupos = new Map();
  abertas.forEach((x) => { if (!grupos.has(x.entregadorUid)) grupos.set(x.entregadorUid, []); grupos.get(x.entregadorUid).push(x); });
  const html = [...grupos].map(([, lista]) => {
    const r = lista.length > 1 ? urlRota(lista.map((x) => x.endereco)) : null;
    return `<div class="ent-adm-grupo"><div class="ent-adm-grupo-cab"><strong>${esc(lista[0].entregador)} · ${lista.length} entrega${lista.length > 1 ? 's' : ''} em andamento</strong>${r ? `<a class="btn-secondary" target="_blank" rel="noopener" href="${r.url}">Ver rota completa</a>` : ''}</div>${lista.map((x) => itemEntrega(x, { desfazer: true })).join('')}</div>`;
  }).join('');
  const concl = fechadas.length ? `<details class="ent-adm-grupo ent-adm-concluidas"><summary><strong>Concluídas e canceladas (${fechadas.length})</strong></summary>${fechadas.slice(0, 40).map((x) => itemEntrega(x)).join('')}</details>` : '';
  $('ent-adm-entregas').innerHTML = (html + concl) || '<p class="ent-adm-vazio">Nenhuma entrega atribuída ainda.</p>';
}

function renderPagamentos() {
  document.querySelectorAll('[data-ent-periodo]').forEach((b) => b.classList.toggle('ativa', b.dataset.entPeriodo === est.periodo));
  const grupos = agruparPorEntregador(filtrarPorPeriodo(est.taxas, est.periodo));
  $('ent-adm-taxas').innerHTML = grupos.map((g) => `<section class="ent-grupo" data-uid="${esc(g.entregadorUid)}">
    <header class="ent-grupo-cab"><div><strong>${esc(g.entregador)}</strong><span>${g.pendenteQtd ? `A pagar <b>${moeda(g.pendenteValor)}</b> · ${pl(g.pendenteQtd, 'taxa', 'taxas')}` : 'Tudo pago'} · pago ${moeda(g.pagoValor)}</span></div>
      ${g.pendenteQtd ? '<button type="button" class="btn-primary" data-ent-pagar-abrir>Pagar</button>' : ''}</header>
    <ul class="ent-taxas">${g.taxas.map((t) => `<li class="${pendente(t) ? 'pend' : 'paga'}"><label>${pendente(t) ? `<input type="checkbox" data-ent-chk value="${esc(t.pedidoKey)}" data-valor="${t.valor}" checked>` : '<i class="fa-solid fa-check" aria-hidden="true"></i>'}<span>Pedido #${esc(numeroDe(t.pedidoKey))} <small>${dia(t.criadoEm)}</small></span></label><strong>${moeda(t.valor)}</strong><em>${pendente(t) ? 'a pagar' : 'paga' + (t.pagoEm ? ' em ' + dia(t.pagoEm) : '')}</em></li>`).join('')}</ul>
    <form class="ent-pagar-form" data-ent-pagar-form="${esc(g.entregadorUid)}" hidden>
      <p class="ent-pagar-resumo" aria-live="polite"></p>
      <div class="ent-linha-2">
        <label>Como foi pago<select name="forma">${Object.entries(FORMAS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></label>
        <label>Observação <small>opcional</small><input name="obs" maxlength="200" placeholder="Ex.: semana 1"></label>
      </div>
      <div class="ent-botoes"><button type="submit" class="btn-primary">Confirmar pagamento</button><button type="button" class="btn-secondary" data-ent-pagar-fechar>Cancelar</button></div>
    </form>
  </section>`).join('') || '<p class="ent-adm-vazio">Nenhuma taxa neste período. A taxa nasce quando o entregador confirma a entrega com o código do cliente.</p>';
}

function renderAcertos() {
  $('ent-adm-acertos').innerHTML = est.acertos.map((a) => `<div class="ent-acerto"><div><span class="item-title">${esc(a.entregador)} · ${moeda(a.valorTotal)}</span><span class="item-sub">${diaHora(a.criadoEm)} · ${a.qtd} entrega(s) · ${esc(FORMAS[a.forma] || a.forma)}${a.obs ? ' · ' + esc(a.obs) : ''}</span></div><button type="button" class="btn-secondary" data-ent-comprovante="${esc(a.id)}">Copiar comprovante</button></div>`).join('')
    || '<p class="ent-adm-vazio">Os pagamentos que você registrar aparecem aqui, com comprovante para copiar e enviar.</p>';
}

function selecionarAba(nome) {
  est.aba = nome;
  document.querySelectorAll('[data-ent-aba]').forEach((b) => { const on = b.dataset.entAba === nome; b.classList.toggle('ativa', on); b.setAttribute('aria-selected', String(on)); });
  ['equipe', 'entregas', 'pagamentos'].forEach((a) => { const el = $('ent-aba-' + a); if (el) el.hidden = a !== nome; });
}

// ---------- Atribuir (aba Entregas e botão dentro do card do pedido) ----------
async function montarFormAtribuir(host, pedidoKey) {
  if (!host || host.querySelector('.ent-atribuir-form')) return;
  if (!est.ent.entregadores.length) est.ent = await chamar('/entregador/listar');
  // V75.104: o status dos pedidos muda a toda hora (o lojista despacha): confere as entregas na hora de abrir o formulário
  try { est.entregas = (await chamar('/entregador/entregas')).entregas || est.entregas; } catch { /* usa o que já tem; a API confere de novo */ }
  // V75.103/104: quem JÁ SAIU com pedido fica bloqueado até concluir; quem ainda está em preparo aceita quantos pedidos quiser. Livres primeiro, bloqueados por último.
  // V75.137: troca com o pedido já na rua: o entregador atual sai da lista
  const atual = entregaAtiva(pedidoKey, est.entregas), naRua = !!atual && statusSaiu(atual.status);
  const ativos = est.ent.entregadores.filter((e) => e.ativo && !(naRua && e.uid === atual.entregadorUid))
    .map((e) => ({ ...e, carga: cargaDoEntregador(e.uid, est.entregas, pedidoKey), saiu: saiuComPedidos(e.uid, est.entregas, pedidoKey) }))
    .sort((a, b) => (a.saiu > 0) - (b.saiu > 0) || a.carga - b.carga);
  if (!ativos.length) throw new Error(naRua ? 'Não há outro entregador ativo para assumir este pedido.' : 'Cadastre um entregador na aba Entregadores primeiro.');
  const rotulo = (e) => e.saiu ? `${esc(e.nome)} · ${esc(textoSaiu(e.saiu))} (indisponível até concluir)` : `${esc(e.nome)} · ${esc(textoCarga(e.carga))}`;
  const livre = ativos.find((e) => !e.saiu);
  // V75.153: com "cobrar por bairro" ligado, a taxa do bairro do pedido já vem preenchida (o lojista pode mudar). Lê a loja na hora: a configuração pode ter mudado.
  let lojaAtual = window.__yapood?.loja || null;
  try { const fb = await import('./firebase.js'); const s = await fb.get(fb.ref(fb.db, `restaurantes/${window.__yapood?.lojaId}`)); if (s.exists()) lojaAtual = s.val(); } catch { /* usa a loja já carregada */ }
  const doBairro = taxaBairroDoPedido((window.__yapood?.pedidos || []).find((x) => x.key === pedidoKey), lojaAtual);
  const taxaInicial = doBairro ? doBairro.taxa : (livre || ativos[0]).taxaPadrao;
  const f = document.createElement('div'); f.className = 'ent-atribuir-form'; f.dataset.pedido = pedidoKey;
  f.innerHTML = `<label>Entregador <select data-ent-sel>${ativos.map((e) => `<option value="${esc(e.uid)}" data-taxa="${e.taxaPadrao}" data-carga="${e.carga}" data-saiu="${e.saiu}"${e.saiu ? ' disabled' : ''}${e === livre ? ' selected' : ''}>${rotulo(e)}</option>`).join('')}</select></label>
    <p class="ent-carga" data-ent-carga hidden></p>
    <label>Taxa do entregador (R$) <input data-ent-taxa inputmode="decimal" value="${esc(decimal(taxaInicial))}"></label>${doBairro ? `<p class="ent-taxa-bairro" data-ent-taxa-bairro><i class="fa-solid fa-location-dot" aria-hidden="true"></i> Taxa do bairro ${esc(doBairro.nome)} (${moeda(doBairro.taxa)}) preenchida automaticamente. Você pode alterar.</p>` : ''}
    <div><button type="button" class="btn-primary" data-ent-confirmar data-pedido="${esc(pedidoKey)}"${livre ? '' : ' disabled'}>${naRua ? 'Passar o pedido' : 'Atribuir'}</button><button type="button" class="btn-secondary" data-ent-fechar>Fechar</button></div><p class="ent-adm-msg" role="alert">${livre ? '' : 'Todos os entregadores já saíram com pedidos. Aguarde algum concluir a entrega para atribuir este pedido.'}</p>`;
  const nota = () => { const o = f.querySelector('select').selectedOptions[0], n = Number(o?.dataset.carga) || 0, p = f.querySelector('[data-ent-carga]'); p.hidden = !n; p.textContent = n ? `Este entregador ainda não saiu: o pedido entra como a parada ${n + 1} da rota dele, que é fechada quando você enviar o primeiro pedido para entrega.` : ''; };
  f.querySelector('select').addEventListener('change', (e) => { if (!doBairro) f.querySelector('[data-ent-taxa]').value = decimal(e.target.selectedOptions[0].dataset.taxa); nota(); }); // com taxa do bairro, trocar o entregador não a sobrescreve
  nota();
  host.append(f);
}
async function confirmarAtribuir(btn) {
  const f = btn.closest('.ent-atribuir-form'); btn.disabled = true;
  const uid = f.querySelector('select').value, taxa = aNumero(f.querySelector('[data-ent-taxa]').value);
  if (!Number.isFinite(taxa) || taxa < 0) throw new Error('Taxa inválida.');
  const saiu = saiuComPedidos(uid, est.entregas, btn.dataset.pedido);
  if (saiu > 0) { btn.disabled = false; throw new Error(`Este entregador ${textoSaiu(saiu)} e só pode receber novos pedidos depois de concluir.`); }
  const carga = cargaDoEntregador(uid, est.entregas, btn.dataset.pedido);
  if (carga > 0 && !await confirmar({ titulo: 'Adicionar à rota deste entregador?', texto: `${f.querySelector('select').selectedOptions[0].textContent.split(' · ')[0]} tem ${textoCarga(carga)} ainda em preparo. O pedido será adicionado à rota dele como a parada ${carga + 1}.`, rotulo: 'Adicionar à rota', cancelar: 'Voltar' })) { btn.disabled = false; return; }
  // V75.137: o pedido já saiu com outro entregador (moto quebrou etc.): confirma e passa o pedido com tudo para o novo
  const atual = entregaAtiva(btn.dataset.pedido, est.entregas);
  const nomeNovo = f.querySelector('select').selectedOptions[0].textContent.split(' · ')[0];
  const confirmarTroca = () => confirmar({ titulo: 'Passar o pedido para outro entregador?', texto: `O pedido já saiu com ${atual?.entregador || 'outro entregador'}. Troque só se ele não puder terminar a entrega (moto quebrou, problema na rua) e o pedido já estiver com ${nomeNovo}. ${nomeNovo} recebe o endereço, o código do cliente e o rastreio; ${atual?.entregador || 'o anterior'} deixa de ver o pedido.`, rotulo: 'Passar o pedido', cancelar: 'Voltar' });
  let trocaEmRota = ehTrocaEmRota(atual, atual?.status, uid);
  if (trocaEmRota && !await confirmarTroca()) { btn.disabled = false; return; }
  try { await chamar('/entregador/atribuir', { pedidoKey: btn.dataset.pedido, entregadorUid: uid, taxa, ...(trocaEmRota ? { trocaEmRota: true } : {}) }); }
  catch (err) {
    if (err.codigo !== 'ja-saiu' || trocaEmRota) throw err;
    if (!await confirmarTroca()) { btn.disabled = false; return; } // o lojista despachou enquanto o formulário estava aberto
    trocaEmRota = true;
    await chamar('/entregador/atribuir', { pedidoKey: btn.dataset.pedido, entregadorUid: uid, taxa, trocaEmRota: true });
  }
  avisarEvento({ pedidoKey: btn.dataset.pedido, evento: 'atribuido' }); // push para o entregador (não espera, não atrapalha)
  const nome = f.querySelector('select').selectedOptions[0].textContent;
  if (trocaEmRota) msg(`Pedido passado para ${nomeNovo}. O rastreio do cliente recomeça quando o app dele mandar a posição.`); // a lista é redesenhada logo em seguida
  f.innerHTML = `<p class="ent-adm-msg ok">${trocaEmRota ? `Pedido passado para ${esc(nomeNovo)}. O rastreio do cliente recomeça quando o app dele mandar a posição.` : `Entrega atribuída a ${esc(nome)}.`}</p>`;
  carregar().then(() => { renderTudo(); try { marcarCards(); } catch { /* nada */ } document.dispatchEvent(new CustomEvent('yapood:entregas')); }).catch(() => {});
}

// ---------- Eventos ----------
const comAviso = async (alvo, fn) => {
  try { alvo.disabled = true; await fn(); }
  catch (err) { const f = alvo.closest('.ent-atribuir-form'); if (f) f.querySelector('.ent-adm-msg').textContent = err.message; else msg(err.message, true); }
  finally { alvo.disabled = false; }
};
const refrescar = async () => { await carregar(); renderTudo(); };

document.addEventListener('click', async (ev) => {
  const t = ev.target;
  const alvo = t.closest('[data-ent-aba],[data-ent-periodo],[data-ent-editar],[data-ent-ativar],[data-ent-copiar-link],[data-ent-cancelar-convite],[data-ent-abrir-atrib],.ent-atribuir,[data-ent-confirmar],[data-ent-fechar],[data-ent-desatribuir],[data-ent-trocar],[data-ent-pagar-abrir],[data-ent-pagar-fechar],[data-ent-comprovante],#ent-btn-csv,#ent-btn-atualizar');
  if (!alvo) return;
  if (alvo.dataset.entAba) { selecionarAba(alvo.dataset.entAba); return; }
  if (alvo.dataset.entPeriodo) { est.periodo = alvo.dataset.entPeriodo; renderPagamentos(); return; }
  if (alvo.dataset.entEditar !== undefined) { alvo.closest('.ent-pessoa').querySelector('.ent-edit-form').hidden ^= true; return; }
  if (alvo.dataset.entCopiarLink !== undefined) { await copiar(linkEntregador()); msg('Link copiado. O entregador deve entrar com o e-mail Google cadastrado.'); return; }
  if (alvo.dataset.entPagarAbrir !== undefined) { const g = alvo.closest('.ent-grupo'); g.querySelector('.ent-pagar-form').hidden = false; atualizarResumoPagar(g); return; }
  if (alvo.dataset.entPagarFechar !== undefined) { alvo.closest('.ent-pagar-form').hidden = true; return; }
  if (alvo.id === 'ent-btn-csv') { baixarCsv(); return; }
  if (alvo.dataset.entFechar !== undefined) { alvo.closest('.ent-atribuir-form')?.remove(); return; }
  if (alvo.dataset.entComprovante) {
    const a = est.acertos.find((x) => x.id === alvo.dataset.entComprovante);
    if (a) { await copiar(textoComprovante(a, lojaNome())); msg('Comprovante copiado. Cole no WhatsApp para enviar ao entregador.'); }
    return;
  }
  if (alvo.dataset.entAbrirAtrib !== undefined) { await comAviso(alvo, () => montarFormAtribuir(alvo.closest('.ent-sem').querySelector('.ent-sem-form'), alvo.closest('.ent-sem').dataset.pedido)); return; }
  if (alvo.classList.contains('ent-atribuir')) { const card = alvo.closest('.order-card'); if (card) await comAviso(alvo, () => montarFormAtribuir(alvo.parentElement, card.querySelector('[data-pedido]')?.dataset.pedido)); return; }
  if (alvo.dataset.entConfirmar !== undefined) { await comAviso(alvo, () => confirmarAtribuir(alvo)); return; }
  if (alvo.dataset.entAtivar) {
    const ativar = alvo.dataset.ativo !== 'true';
    if (!ativar && !await confirmar({ titulo: 'Desativar entregador?', texto: 'Ele deixa de receber novas entregas e perde o acesso ao painel.', rotulo: 'Desativar', perigo: true })) return;
    await comAviso(alvo, async () => { await chamar('/entregador/ativar', { entregadorUid: alvo.dataset.entAtivar, ativo: ativar }); await refrescar(); }); return;
  }
  if (alvo.dataset.entCancelarConvite) {
    if (!await confirmar({ titulo: 'Cancelar convite?', texto: 'A pessoa não conseguirá mais entrar com este convite.', rotulo: 'Cancelar convite', perigo: true })) return;
    await comAviso(alvo, async () => { await chamar('/entregador/cancelar-convite', { email: alvo.dataset.entCancelarConvite }); msg('Convite cancelado.'); await refrescar(); }); return;
  }
  if (alvo.dataset.entTrocar) { await comAviso(alvo, () => montarFormAtribuir(alvo.closest('.ent-entrega').querySelector('.ent-troca-form'), alvo.dataset.entTrocar)); return; }
  if (alvo.dataset.entDesatribuir) {
    if (!await confirmar({ titulo: 'Desfazer atribuição?', texto: 'O pedido volta para "Aguardando entregador".', rotulo: 'Desfazer' })) return;
    await comAviso(alvo, async () => { await chamar('/entregador/desatribuir', { pedidoKey: alvo.dataset.entDesatribuir }); msg('Atribuição desfeita.'); await refrescar(); }); return;
  }
  if (alvo.id === 'ent-btn-atualizar') { await comAviso(alvo, async () => { await refrescar(); msg('Atualizado.'); }); }
});

function atualizarResumoPagar(grupo) {
  const marcadas = [...grupo.querySelectorAll('[data-ent-chk]:checked')];
  const soma = arred(marcadas.reduce((s, c) => s + (Number(c.dataset.valor) || 0), 0));
  const resumo = grupo.querySelector('.ent-pagar-resumo');
  resumo.textContent = marcadas.length ? `Você vai registrar o pagamento de ${moeda(soma)} (${marcadas.length} taxa${marcadas.length > 1 ? 's' : ''}).` : 'Marque ao menos uma taxa para pagar.';
  grupo.querySelector('.ent-pagar-form [type=submit]').disabled = !marcadas.length;
}
document.addEventListener('change', (ev) => { const c = ev.target.closest('[data-ent-chk]'); if (c) atualizarResumoPagar(c.closest('.ent-grupo')); });
// V75.136: placa só para moto e carro
function veiculoDoForm(f) {
  const veiculo = f.veiculo?.value || '';
  return { veiculo, placa: temPlaca(veiculo) ? String(f.placa?.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '') : '' };
}
document.addEventListener('change', (ev) => {
  const sel = ev.target.closest('select[name="veiculo"]'); if (!sel) return;
  const placa = sel.form?.placa; if (!placa) return;
  placa.disabled = !temPlaca(sel.value); if (placa.disabled) placa.value = '';
});

function baixarCsv() {
  const lista = filtrarPorPeriodo(est.taxas, est.periodo);
  if (!lista.length) return msg('Não há taxas neste período para exportar.', true);
  const blob = new Blob([csvExtrato(lista, numeroDe)], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `extrato-entregadores-${est.periodo}.csv`;
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

document.addEventListener('submit', async (ev) => {
  const f = ev.target;
  const btn = f.querySelector('button[type=submit]');
  try {
    if (f.id === 'ent-adm-form') {
      ev.preventDefault(); btn.disabled = true;
      await chamar('/entregador/convidar', { nome: f.nome.value, email: f.email.value, telefone: f.telefone.value, taxa: aNumero(f.taxa.value) || 0, ...veiculoDoForm(f) });
      f.reset(); f.placa.disabled = true; $('ent-novo').open = false;
      msg('Entregador cadastrado. Peça para ele entrar com esse e-mail Google em ' + linkEntregador());
      await refrescar();
    } else if (f.matches('[data-ent-edit]')) {
      ev.preventDefault(); btn.disabled = true;
      const taxa = aNumero(f.taxaPadrao.value);
      if (!Number.isFinite(taxa) || taxa < 0) throw new Error('Taxa inválida.');
      await chamar('/entregador/editar', { entregadorUid: f.dataset.entEdit, nome: f.nome.value, telefone: f.telefone.value, taxaPadrao: taxa, ...veiculoDoForm(f) });
      msg('Dados do entregador atualizados.'); await refrescar();
    } else if (f.matches('[data-ent-pagar-form]')) {
      ev.preventDefault(); btn.disabled = true;
      const chaves = [...f.closest('.ent-grupo').querySelectorAll('[data-ent-chk]:checked')].map((c) => c.value);
      if (!chaves.length) throw new Error('Marque ao menos uma taxa.');
      const r = await chamar('/entregador/pagar-lote', { entregadorUid: f.dataset.entPagarForm, forma: f.forma.value, obs: f.obs.value, pedidoKeys: chaves });
      await refrescar();
      msg(`Pagamento de ${moeda(r.valorTotal)} registrado (${r.qtd} taxa${r.qtd > 1 ? 's' : ''}).${r.ignoradas ? ` ${r.ignoradas} já estava(m) paga(s).` : ''} Use "Copiar comprovante" para enviar ao entregador.`);
    }
  } catch (err) { msg(err.message, true); if (btn) btn.disabled = false; }
});

document.querySelectorAll('[data-tab="modulo-entregadores"],[data-tab-link="modulo-entregadores"]').forEach((b) => b.addEventListener('click', abrir));

// Atualiza sozinho enquanto a aba está aberta e visível (sem poluir o servidor: a cada 60 s).
setInterval(() => {
  if (document.hidden || !$('modulo-entregadores')?.classList.contains('active')) return;
  carregar().then(renderTudo).catch(() => {});
}, 60000);

// ---------- Botão "Atribuir entregador" dentro dos cards da aba Pedidos ----------
// V75.137: "Atribuir entregador" sem ninguém; "Trocar entregador" antes de sair; depois que saiu, a troca fica na aba Entregadores.
function marcarCards() {
  const lista = $('lista-pedidos-loja'), pedidos = window.__yapood?.pedidos || [];
  if (!lista) return;
  let temAtivo = false;
  lista.querySelectorAll('.order-card').forEach((card) => {
    const key = card.querySelector('[data-pedido]')?.dataset.pedido, p = pedidos.find((x) => x.key === key);
    const modo = botaoDoCard(p, p ? entregaAtiva(p.key, est.entregas) : null, !!(p && (window.__yapoodParceira?.temCorridaAtiva?.(p.key) || (p.entregaParceira === true && statusSaiu(p.status)))));
    if (modo) temAtivo = true;
    let b = card.querySelector('.ent-atribuir');
    if (!modo) { if (b && !b.parentElement?.querySelector('.ent-atribuir-form')) b.remove(); return; }
    const texto = modo === 'trocar' ? 'Trocar entregador' : 'Atribuir entregador';
    if (!b) { b = document.createElement('button'); b.type = 'button'; b.className = 'btn-secondary ent-atribuir'; (card.querySelector('.order-actions') || card).after(b); }
    if (b.textContent !== texto) b.textContent = texto; // só mexe se mudou (o MutationObserver chama de novo)
    if (b.dataset.modo !== modo) b.dataset.modo = modo;
  });
  if (temAtivo || pedidos.some((p) => p.tipoEntrega === 'delivery' && statusSaiu(p.status))) carregarParaCards();
}
const listaPedidos = $('lista-pedidos-loja');
if (listaPedidos) new MutationObserver(() => { try { marcarCards(); } catch (e) { console.warn('Entregadores:', e); } }).observe(listaPedidos, { childList: true, subtree: true });

// V75.137: com a aba Pedidos aberta, confere de tempos em tempos quem está com cada pedido (o card mostra "Carlos vai levar")
setInterval(() => {
  if (document.hidden || !$('modulo-pedidos')?.classList.contains('active')) return;
  try { marcarCards(); } catch { /* nada */ }
}, 45000);
