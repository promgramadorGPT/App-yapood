// js/perfil-dados.js — V75.135: regras puras do Perfil (Meus dados, Endereços, Forma de pagamento preferida). Sem DOM, sem banco.
import { MAX_OUTROS } from './enderecos.js';

/** Telefone com DDD (10 ou 11 dígitos, aceita +55). → { ok, telefone: só dígitos } | { ok:false, erro } */
export function validarTelefone(v) {
  let d = String(v ?? '').replace(/\D/g, '');
  if (d.length > 11 && d.startsWith('55')) d = d.slice(2);
  if (d.length < 10 || d.length > 11) return { ok: false, erro: 'Informe o telefone com DDD, ex.: (34) 99999-9999.' };
  return { ok: true, telefone: d };
}

/** E-mail opcional (vazio vale). Precisa dele para pagar online. → { ok, email } | { ok:false, erro } */
export function validarEmail(v) {
  const e = String(v ?? '').trim().toLowerCase();
  if (!e) return { ok: true, email: '' };
  if (e.length > 120 || !/^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}$/.test(e)) return { ok: false, erro: 'E-mail inválido. Ex.: nome@email.com' };
  return { ok: true, email: e };
}

/**
 * Onde gravar um endereço editado no Perfil. Casa e Trabalho têm lugar fixo; "Outro" mantém o próprio id (ou ganha um novo).
 * → { id, substitui: id de outro endereço que será trocado (Casa/Trabalho já existente) | null, apagar: id antigo a apagar | null, erro? }
 */
export function idAoEditarEndereco(idAntigo, rotulo, existentes, agora = Date.now()) {
  const lista = existentes || [];
  let id;
  if (rotulo === 'casa' || rotulo === 'trabalho') id = rotulo;
  else if (idAntigo && String(idAntigo).startsWith('outro_')) id = idAntigo;
  else {
    const outros = lista.filter((e) => e.rotulo === 'outro' && e.id !== idAntigo);
    if (outros.length >= MAX_OUTROS) return { erro: `Você já tem ${MAX_OUTROS} endereços em "Outro". Apague um antes.` };
    id = `outro_${agora.toString(36)}`;
  }
  const substitui = lista.some((e) => e.id === id && e.id !== idAntigo) ? id : null;
  return { id, substitui, apagar: idAntigo && idAntigo !== id ? idAntigo : null };
}

// Mesmos valores do <select id="forma-pago"> do carrinho.
export const FORMAS = Object.freeze([
  { valor: 'PIX', nome: 'Pix' },
  { valor: 'Mercado Pago', nome: 'Cartão de crédito online' },
  { valor: 'Cartão / Débito (pagar ao entregador)', nome: 'Cartão na entrega' },
  { valor: 'Dinheiro', nome: 'Dinheiro' }
]);
export const formaValida = (v) => FORMAS.some((f) => f.valor === v);
export const nomeDaForma = (v) => FORMAS.find((f) => f.valor === v)?.nome || '';
