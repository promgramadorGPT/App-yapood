// V75.16 — Reembolso (front): regras puras compartilhadas entre cliente e ADM.
// O dinheiro só volta de verdade pelo Mercado Pago (backend/painel); aqui ficam o pedido, a decisão e o registro.
import { normalizarPagamento, normalizarStatus, PAGO, STATUS } from './regras.js';

export const REEMBOLSO = { SOLICITADO: 'solicitado', APROVADO: 'aprovado', RECUSADO: 'recusado' };

// Comentários prontos (motivos plausíveis de cancelamento com reembolso).
export const MOTIVOS_REEMBOLSO = [
  { id: 'engano', texto: 'Pedi por engano ou mudei de ideia' },
  { id: 'demora', texto: 'O pedido está demorando mais do que o previsto' },
  { id: 'duplicado', texto: 'Fiz o pedido ou o pagamento em duplicidade' },
  { id: 'dados', texto: 'Errei o endereço ou os dados do pedido' },
  { id: 'itens', texto: 'Quero trocar ou retirar itens do pedido' },
  { id: 'cobranca', texto: 'O valor cobrado está diferente do pedido' },
  { id: 'loja', texto: 'A loja não confirmou ou não está atendendo' },
  { id: 'outro', texto: 'Outro motivo' }
];

export const POLITICA = {
  cancelamento: [
    'Pagamento na entrega: não há cobrança antes da entrega, então não há reembolso. Enquanto o pedido está pendente, você pode cancelar na tela do pedido.',
    'Pedido pago (PIX ou cartão) que a loja ainda não aceitou: toque em “Solicitar cancelamento e reembolso” na tela do pedido e receba 100% do valor, depois da confirmação da loja.',
    'Depois que a loja aceita e começa o preparo, o cancelamento não é feito pelo aplicativo: fale com a loja. Ela pode aprovar um reembolso total ou parcial.',
    'Se a loja cancelar um pedido pago, o reembolso é de 100%.',
    'Se a loja recusar o reembolso, ela informa o motivo e o pedido segue normalmente.',
    'O valor aprovado volta para a mesma forma de pagamento. O prazo para aparecer depende do Mercado Pago e do seu banco ou cartão.',
    'Depois que a entrega é confirmada com o código, o cancelamento pelo aplicativo não é mais possível. Se houver um problema com o pedido, use “Relatar um problema” em até 24 horas.'
  ],
  reclamacoes: [
    'Pedido entregue com problema (item faltando, item errado, comida fria ou que não chegou)? Em até 24 horas depois da entrega, abra o pedido em “Ver Estado” e toque em “Relatar um problema”. Você pode anexar uma foto.',
    'A loja responde em até 24 horas: ela pode resolver, recusar ou aprovar um reembolso total ou parcial.',
    'Se a loja não responder no prazo, ou se você não concordar com a resposta, o YAPOOD analisa o caso e decide. A decisão do YAPOOD é final.',
    'Pedidos pagos na entrega (dinheiro): quando o reembolso é aprovado, a loja devolve o valor direto a você.',
    'Para dúvidas sobre um pedido em andamento, use “Entrar em contato com o restaurante” na tela do pedido.'
  ]
};

export function podeSolicitarReembolso(p, uid) {
  if (!p || !uid || p.clienteUid !== uid) return false;
  if (p.reembolso) return false;
  if (normalizarPagamento(p.pagoStatus) !== PAGO.APROVADO) return false;
  // Condição V75.16.1: o cliente só pede enquanto a loja ainda não aceitou (nada foi gasto).
  // Depois disso, só a loja decide (total ou parcial).
  if (normalizarStatus(p.status) !== STATUS.PENDENTE || p.entregaConfirmada === true) return false;
  return true;
}

// Pedido pago, sem reembolso registrado e já passou da fase "pendente": a loja pode registrar um reembolso (total ou parcial).
export function lojaPodeReembolsar(p) {
  if (!p || p.reembolso) return false;
  if (pagoNaEntrega(p)) return normalizarStatus(p.status) === STATUS.ENTREGUE; // V75.109: o cliente só pagou na entrega — só há o que devolver depois de entregue
  if (normalizarPagamento(p.pagoStatus) !== PAGO.APROVADO) return false;
  return normalizarStatus(p.status) !== STATUS.PENDENTE;
}

/** V75.109 — pedido pago na entrega (dinheiro, maquininha…): o dinheiro está com a loja, então ela devolve direto ao cliente. */
export const pagoNaEntrega = (p) => !!p && normalizarPagamento(p.pagoStatus) === PAGO.NA_ENTREGA;
/** Reembolso aprovado que a loja devolve direto ao cliente e ainda não confirmou que devolveu. */
export const devolucaoDiretaPendente = (p) => !!p?.reembolso && p.reembolso.status === REEMBOLSO.APROVADO && p.reembolso.devolucaoDireta === true && !p.reembolso.devolvidoDiretoEm;

export function montarSolicitacaoReembolso(p, { motivoId, comentario }, agora = new Date()) {
  const m = MOTIVOS_REEMBOLSO.find((x) => x.id === motivoId);
  if (!m) throw new Error('Escolha um motivo.');
  const c = String(comentario || '').trim().slice(0, 300);
  if (m.id === 'outro' && c.length < 5) throw new Error('Conte o que aconteceu no comentário.');
  return {
    status: REEMBOLSO.SOLICITADO, origem: 'cliente', motivoId: m.id, motivo: m.texto, statusPedido: normalizarStatus(p.status),
    ...(c ? { comentario: c } : {}),
    valor: Number(p.total) || 0, formaPagamento: String(p.formaPagamento || '').slice(0, 60),
    solicitadoEm: agora.toISOString()
  };
}

// Loja cancelou um pedido já pago: o reembolso nasce aprovado.
export function montarReembolsoLoja(p, agora = new Date()) {
  const iso = agora.toISOString();
  return {
    status: REEMBOLSO.APROVADO, origem: 'loja', motivoId: 'loja_cancelou', motivo: 'Pedido cancelado pela loja',
    valor: Number(p.total) || 0, valorOriginal: Number(p.total) || 0, parcial: false,
    formaPagamento: String(p.formaPagamento || '').slice(0, 60),
    solicitadoEm: iso, respondidoEm: iso
  };
}

// Reembolso decidido pela loja (total ou parcial) depois que o pedido já foi aceito.
/**
 * V75.101: reembolso TOTAL cancela o pedido (mesmo já entregue): o status passa a "Cancelado" e o valor sai das Finanças e da rota.
 * Reembolso parcial só cancela se a loja marcar "Cancelar o pedido junto". Pedido já cancelado nunca é cancelado de novo.
 */
export function deveCancelarNoReembolso(p, dados, marcouCancelar = false) {
  if (normalizarStatus(p && p.status) === STATUS.CANCELADO) return false;
  return !!marcouCancelar || !(dados && dados.parcial === true);
}

export function montarReembolsoLojaManual(p, { valor, motivo, por }, agora = new Date()) {
  const total = Number(p.total) || 0;
  const v = Math.round((Number(valor) || 0) * 100) / 100;
  if (!(v > 0)) throw new Error('Informe o valor a devolver.');
  if (v > total + 0.001) throw new Error('O valor não pode ser maior que o total do pedido.');
  const m = String(motivo || '').trim();
  if (m.length < 5) throw new Error('Informe o motivo do reembolso.');
  const iso = agora.toISOString();
  return {
    status: REEMBOLSO.APROVADO, origem: 'loja', motivoId: 'loja_decidiu', motivo: m.slice(0, 120),
    valor: v, valorOriginal: total, parcial: v < total - 0.009,
    formaPagamento: String(p.formaPagamento || '').slice(0, 60),
    statusPedido: normalizarStatus(p.status), solicitadoEm: iso, respondidoEm: iso, ...(por ? { decididoPor: por } : {}),
    ...(pagoNaEntrega(p) ? { devolucaoDireta: true } : {})
  };
}

// V75.35 — Reembolso decidido pelo Master (mediação de um relato de problema). Nasce aprovado; a API devolve com o token da loja.
export function masterPodeReembolsar(p) {
  if (!p) return false;
  if (pagoNaEntrega(p)) { if (normalizarStatus(p.status) !== STATUS.ENTREGUE) return false; } // V75.109: pago na entrega, só depois de entregue
  else if (normalizarPagamento(p.pagoStatus) !== PAGO.APROVADO) return false;
  return !p.reembolso || p.reembolso.status === REEMBOLSO.RECUSADO;
}
export function montarReembolsoMaster(p, { valor, motivo, por }, agora = new Date()) {
  const total = Number(p.total) || 0;
  const v = Math.round((Number(valor) || 0) * 100) / 100;
  if (!(v > 0)) throw new Error('Informe o valor a devolver.');
  if (v > total + 0.001) throw new Error('O valor não pode ser maior que o total do pedido.');
  const m = String(motivo || '').trim() || 'Relato de problema aprovado pelo YAPOOD';
  const iso = agora.toISOString();
  return {
    status: REEMBOLSO.APROVADO, origem: 'master', motivoId: 'master_decidiu', motivo: m.slice(0, 120),
    valor: v, valorOriginal: total, parcial: v < total - 0.009,
    formaPagamento: String(p.formaPagamento || '').slice(0, 60),
    statusPedido: normalizarStatus(p.status), solicitadoEm: iso, respondidoEm: iso, ...(por ? { decididoPor: por } : {}),
    ...(pagoNaEntrega(p) ? { devolucaoDireta: true } : {})
  };
}

// Histórico do cliente nesta loja (sinal de abuso para quem decide o reembolso).
export function historicoCliente(pedidos, uid, excluirKey) {
  const h = { pedidos: 0, entregues: 0, cancelados: 0, reembolsos: 0, aprovados: 0, recusados: 0, valorReembolsado: 0 };
  for (const p of pedidos || []) {
    if (!p || p.clienteUid !== uid || p.key === excluirKey) continue;
    h.pedidos++;
    const s = normalizarStatus(p.status);
    if (s === STATUS.ENTREGUE) h.entregues++;
    if (s === STATUS.CANCELADO) h.cancelados++;
    if (p.reembolso) {
      h.reembolsos++;
      if (p.reembolso.status === REEMBOLSO.APROVADO) { h.aprovados++; h.valorReembolsado += Number(p.reembolso.valor) || 0; }
      if (p.reembolso.status === REEMBOLSO.RECUSADO) h.recusados++;
    }
  }
  h.alerta = h.aprovados >= 2 || h.reembolsos >= 3 || h.cancelados >= 3;
  return h;
}

export function rotuloReembolso(r) {
  if (!r) return '';
  if (r.status === REEMBOLSO.APROVADO) return 'Aprovado';
  if (r.status === REEMBOLSO.RECUSADO) return 'Recusado';
  return 'Solicitado';
}

export function textoReembolsoCliente(r) {
  if (!r) return '';
  const rs = (n) => (Number(n) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  // V75.145 — saldo na loja
  if (r.status === REEMBOLSO.APROVADO && r.escolha?.tipo === 'saldo') {
    return `Você escolheu receber em saldo na loja: ${rs(r.escolha.valor)}${r.escolha.bonus > 0 ? ` (com ${rs(r.escolha.bonus)} de bônus)` : ''}. Use no próximo pedido nesta loja; o saldo não vence.`;
  }
  if (r.status === REEMBOLSO.APROVADO && r.execucao?.status === 'concluido' && r.execucao.tipo === 'saldo') {
    return `O valor voltou como saldo nesta loja (${rs(r.execucao.valorSaldo ?? r.valor)}). Use no próximo pedido; o saldo não vence.`;
  }
  if (r.status === REEMBOLSO.APROVADO && r.execucao?.status === 'concluido' && r.execucao.valorSaldo > 0) {
    return `O Mercado Pago devolveu ${rs(r.execucao.valorMP)} para a forma de pagamento usada e ${rs(r.execucao.valorSaldo)} voltaram como saldo nesta loja.`;
  }
  if (r.status === REEMBOLSO.APROVADO && r.devolucaoDireta === true) { // V75.109: pedido pago na entrega
    const v = (Number(r.valor) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    return r.devolvidoDiretoEm
      ? `A loja confirmou que devolveu ${v} direto a você.`
      : `Reembolso aprovado. Como você pagou na entrega, a loja devolve ${v} direto a você. Se precisar, combine com ela pelo WhatsApp.`;
  }
  if (r.status === REEMBOLSO.APROVADO && r.execucao?.status === 'concluido') {
    return 'O Mercado Pago já devolveu o valor para a forma de pagamento usada. O prazo para aparecer depende do seu banco ou cartão.';
  }
  if (r.status === REEMBOLSO.APROVADO) {
    if (r.parcial) return 'A loja aprovou um reembolso parcial. O valor volta para a forma de pagamento usada; o prazo depende do Mercado Pago e do seu banco.';
    return r.origem === 'loja'
      ? 'A loja aprovou o reembolso. O valor volta para a forma de pagamento usada; o prazo depende do Mercado Pago e do seu banco.'
      : 'Seu reembolso foi aprovado. O valor volta para a forma de pagamento usada; o prazo depende do Mercado Pago e do seu banco.';
  }
  if (r.status === REEMBOLSO.RECUSADO) return 'A loja recusou o reembolso e o pedido segue normalmente. Se precisar, fale com ela pelo WhatsApp.';
  return 'Solicitação enviada. Aguarde a resposta da loja.';
}
