// js/cadastro-lojista-ui.js — V75.47: tela de cadastro do lojista (admin-loja.html). Regras e validações ficam em cadastro-lojista.js (testadas).
import { NOTPUSH_API } from './notificaciones-config.js';
import { db, auth, ref, set, get, onValue } from './firebase.js';
import {
  CADASTRO, validarCadastro, montarCadastro, formatarDocumentoParcial, formatarTelefoneParcial, formatarDocumento, formatarNascimentoParcial, nascimentoParaBR,
  dimensoesReduzidas, fotoValida, PREFIXO_FOTO, LIMITE_FOTO_CHARS
} from './cadastro-lojista.js';
import { TERMOS_LOJISTA, textoContatoDados } from './termos-lojista.js?v=75.116';
import { avisosDaFoto } from './foto-qualidade.js';
import { estadoAvisosLojista } from './avisos-lojista.js';

const $ = (id) => document.getElementById(id);
const fmt = (iso) => {
  const t = Date.parse(iso);
  return Number.isFinite(t) ? new Date(t).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
};

let desligar = null;       // cancela a escuta do cadastro
let fotoAtual = '';        // data:image/jpeg;base64,… já reduzida
let preparado = false;

/** Lê a imagem, reduz e comprime em JPEG até caber no limite das regras. */
export async function comprimirImagem(arquivo) {
  if (!arquivo || !/^image\//.test(arquivo.type || '')) throw new Error('Escolha uma foto (JPG ou PNG).');
  let bmp;
  try { bmp = await createImageBitmap(arquivo, { imageOrientation: 'from-image' }); }
  catch {
    bmp = await new Promise((ok, no) => {
      const url = URL.createObjectURL(arquivo), img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); ok(img); };
      img.onerror = () => { URL.revokeObjectURL(url); no(new Error('Não foi possível ler esta imagem.')); };
      img.src = url;
    });
  }
  const w = bmp.width || bmp.naturalWidth, h = bmp.height || bmp.naturalHeight;
  let lado = 1400, qualidade = 0.82;
  for (let tentativa = 0; tentativa < 8; tentativa++) {
    const { largura, altura } = dimensoesReduzidas(w, h, lado);
    const tela = document.createElement('canvas');
    tela.width = largura; tela.height = altura;
    const ctx = tela.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, largura, altura);
    ctx.drawImage(bmp, 0, 0, largura, altura);
    const url = tela.toDataURL('image/jpeg', qualidade);
    if (url.length <= LIMITE_FOTO_CHARS - 20000 && url.startsWith(PREFIXO_FOTO)) return url;
    qualidade = Math.max(0.5, qualidade - 0.08);
    lado = Math.round(lado * 0.85);
  }
  throw new Error('A foto ficou grande demais. Tente uma foto com menos zoom ou menor.');
}

function mostrarErros(erros) {
  document.querySelectorAll('#form-cadastro-lojista [data-erro]').forEach((el) => {
    const msg = erros?.[el.dataset.erro];
    el.hidden = !msg; el.textContent = msg || '';
  });
}
function mostrarAvisosFoto(avisos) {
  const el = $('cad-foto-aviso'); if (!el) return;
  el.hidden = !avisos.length;
  el.innerHTML = avisos.length ? `<strong>Antes de enviar, confira:</strong><ul>${avisos.map((a) => `<li>${a.texto}</li>`).join('')}</ul>Se estiver legível, pode enviar assim mesmo. Se não, toque em “Trocar foto”.` : '';
}
function erroGeral(msg) { const e = $('cad-erro-geral'); e.hidden = !msg; e.textContent = msg || ''; }

function preencher(cad) {
  if (!cad) return;
  $('cad-nome').value = cad.nomeCompleto || '';
  $('cad-doc').value = formatarDocumento(cad.doc);
  $('cad-nasc').value = nascimentoParaBR(cad.nascimento);
  $('cad-zap').value = formatarTelefoneParcial(cad.whatsapp);
  $('cad-loja').value = cad.nomeLoja || '';
}

function mostrar(estado, cad) {
  $('cad-form-wrap').hidden = estado === 'pendente';
  $('cad-pendente').hidden = estado !== 'pendente';
  const rec = $('cad-recusa');
  if (estado === 'recusado') {
    rec.hidden = false;
    rec.textContent = `Seu cadastro não foi aprovado. Motivo: ${cad?.motivoRecusa || 'não informado'}. Corrija os dados abaixo e envie de novo.`;
    if (!$('cad-nome').value) preencher(cad);
  } else rec.hidden = true;
  if (estado === 'pendente') $('cad-pendente-quando').textContent = cad?.enviadoEm ? `Enviado em ${fmt(cad.enviadoEm)}.` : '';
}

async function avisarMaster(user) {
  try {
    const idToken = await user.getIdToken(true);
    await fetch(`${NOTPUSH_API}/notificar-cadastro`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` }, body: JSON.stringify({ evento: 'novo' }), keepalive: true
    });
  } catch (e) { console.warn('[cadastro] aviso ao Master não saiu:', e); }   // o Master também vê a fila na aba Solicitações
}

function prepararFormulario(user) {
  if (preparado) return;
  preparado = true;
  const t = TERMOS_LOJISTA;
  $('cad-termos-titulo').textContent = t.titulo;
  $('cad-termos-aviso').textContent = t.aviso;
  $('cad-termos-lista').innerHTML = t.itens.map(([a, b]) => `<li><strong>${a}.</strong> ${b}</li>`).join('');
  // V75.116: contato para assuntos de dados pessoais (Master → Configuração). Sem e-mail ou sem leitura: aponta para o suporte.
  const cont = $('cad-contato-dados');
  if (cont) { cont.textContent = textoContatoDados(''); get(ref(db, 'config_plataforma/contato_dados/email')).then((s) => { cont.textContent = textoContatoDados(s.val()); }).catch(() => {}); }
  $('cad-nasc').addEventListener('input', (e) => { e.target.value = formatarNascimentoParcial(e.target.value); });

  $('cad-doc').addEventListener('input', (e) => { e.target.value = formatarDocumentoParcial(e.target.value); });
  $('cad-zap').addEventListener('input', (e) => { e.target.value = formatarTelefoneParcial(e.target.value); });

  const CAMPOS = { 'cad-nome': 'nomeCompleto', 'cad-doc': 'documento', 'cad-nasc': 'nascimento', 'cad-zap': 'whatsapp', 'cad-loja': 'nomeLoja', 'cad-aceite': 'aceite' };
  $('form-cadastro-lojista').addEventListener('input', (e) => {   // some o erro do campo assim que a pessoa mexe nele
    const k = CAMPOS[e.target.id], el = k && document.querySelector(`[data-erro="${k}"]`);
    if (el) { el.hidden = true; el.textContent = ''; }
  });

  // V75.108: dois botões — "Tirar foto" abre a câmera traseira direto (capture); "Escolher da galeria" abre os arquivos. Os dois usam o mesmo tratamento.
  document.querySelector('[data-cad-camera]').addEventListener('click', () => $('cad-foto-cam').click());
  document.querySelector('[data-cad-galeria]').addEventListener('click', () => $('cad-foto').click());
  const aoEscolherFoto = async (e) => {
    const arq = e.target.files?.[0];
    if (!arq) return;
    $('cad-foto-txt').textContent = 'Preparando…';
    mostrarAvisosFoto([]);
    try {
      fotoAtual = await comprimirImagem(arq);
      $('cad-foto-previa').src = fotoAtual; $('cad-foto-previa').hidden = false;
      $('cad-foto-txt').textContent = 'Tirar outra foto';
      const ef = document.querySelector('[data-erro="foto"]'); ef.hidden = true; ef.textContent = '';
      mostrarAvisosFoto(await avisosDaFoto(fotoAtual));   // só avisa (escura, reflexo, tremida, pequena); não impede o envio
    } catch (err) {
      fotoAtual = ''; $('cad-foto-previa').hidden = true;
      $('cad-foto-txt').textContent = 'Tirar foto';
      mostrarErros({ foto: err.message });
    }
    e.target.value = '';
  };
  $('cad-foto').addEventListener('change', aoEscolherFoto);
  $('cad-foto-cam').addEventListener('change', aoEscolherFoto);

  $('form-cadastro-lojista').addEventListener('submit', async (e) => {
    e.preventDefault();
    erroGeral('');
    const u = auth.currentUser || user;
    const v = validarCadastro({
      nomeCompleto: $('cad-nome').value, documento: $('cad-doc').value, nascimento: $('cad-nasc').value, whatsapp: $('cad-zap').value,
      nomeLoja: $('cad-loja').value, aceitou: $('cad-aceite').checked, temFoto: fotoValida(fotoAtual)
    });
    mostrarErros(v.erros);
    if (!v.ok) { document.querySelector('#form-cadastro-lojista .cad-erro:not([hidden])')?.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
    const btn = $('cad-enviar'), html = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> Enviando…';
    try {
      const agora = new Date();
      await set(ref(db, `lojistas_documentos/${u.uid}`), { foto: fotoAtual, enviadoEm: agora.toISOString() });   // a foto vai primeiro: as regras exigem que ela exista
      await set(ref(db, `lojistas_cadastro/${u.uid}`), montarCadastro(v.dados, { email: u.email || '', agora }));
      fotoAtual = '';
      avisarMaster(u);
    } catch (err) {
      console.error(err);
      erroGeral(/permission/i.test(err?.message || '') ? 'Não foi possível enviar: confira os dados e tente de novo. Se continuar, avise o suporte.' : 'Não foi possível enviar agora. Verifique sua conexão e tente de novo.');
    } finally { btn.disabled = false; btn.innerHTML = html; }
  });
}

// ---- V75.92: avisos de aprovação (cria o token do aparelho com um toque do lojista) ----
let avisosRegistrado = false, avisosErro = '';
const carregarPush = () => import('./notificaciones.js').catch((e) => { console.warn('[NotPush] indisponível:', e); return null; });
function desenharAvisos() {
  const box = $('cad-push'), btn = $('cad-push-btn'); if (!box) return;
  const e = estadoAvisosLojista({ suporte: 'Notification' in window, permissao: 'Notification' in window ? Notification.permission : 'denied', registrado: avisosRegistrado, erro: avisosErro });
  box.hidden = false; box.className = `cad-push cad-push-${e.tipo}`;
  $('cad-push-texto').textContent = e.texto;
  btn.hidden = !e.botao; btn.textContent = e.botao;
}
async function ativarAvisos() {
  avisosErro = '';
  try {
    const push = await carregarPush();
    if (!push?.ativarNotificacoes) throw new Error('serviço de avisos indisponível agora');
    avisosRegistrado = !!(await push.ativarNotificacoes());
  } catch (err) { avisosRegistrado = false; avisosErro = err?.message || 'erro desconhecido'; console.warn('[NotPush]', err); }
  desenharAvisos();
}
let avisosLigado = false;
function iniciarAvisos() {
  avisosRegistrado = false; avisosErro = '';
  if (!avisosLigado && $('cad-push-btn')) {
    avisosLigado = true;
    $('cad-push-btn').addEventListener('click', async () => { $('cad-push-btn').disabled = true; await ativarAvisos(); $('cad-push-btn').disabled = false; });
  }
  // Já permitido: registra o aparelho sem perguntar nada. Senão mostra o botão (o navegador só deixa pedir a permissão num toque).
  if ('Notification' in window && Notification.permission === 'granted') ativarAvisos(); else desenharAvisos();
}

/**
 * Mostra o cadastro conforme o status e acompanha em tempo real.
 * `aprovado(cad)` é chamado quando o Master aprova (ou já estava aprovado) — aí o app libera a criação da loja.
 */
export function abrirCadastro({ user, aprovado }) {
  fecharCadastro();
  prepararFormulario(user);
  fotoAtual = ''; $('cad-foto-previa').hidden = true; $('cad-foto-txt').textContent = 'Tirar foto'; mostrarAvisosFoto([]);
  mostrarErros({}); erroGeral('');
  iniciarAvisos();
  desligar = onValue(ref(db, `lojistas_cadastro/${user.uid}`), (snap) => {
    const cad = snap.val();
    if (cad?.status === CADASTRO.APROVADO) { fecharCadastro(); aprovado(cad); return; }
    mostrar(cad?.status || 'novo', cad);
  }, (err) => { console.error(err); mostrar('novo', null); erroGeral('Não foi possível consultar o seu cadastro. Recarregue a página.'); });
}

export function fecharCadastro() {
  if (desligar) { try { desligar(); } catch { /* já encerrado */ } desligar = null; }
}
