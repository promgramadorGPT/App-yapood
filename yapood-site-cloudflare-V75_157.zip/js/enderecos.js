// js/enderecos.js — endereços salvos do cliente (Casa / Trabalho / Outro). Funções puras: sem Firebase, sem DOM.
// Armazenamento: usuarios/{uid}/enderecos/{id}. "casa" e "trabalho" têm id fixo (um de cada); "outro" tem até MAX_OUTROS.

export const ROTULOS = {
  casa: { nome: 'Casa', icone: 'fa-house' },
  trabalho: { nome: 'Trabalho', icone: 'fa-briefcase' },
  outro: { nome: 'Outro', icone: 'fa-location-dot' }
};
export const MAX_OUTROS = 5;

const texto = (v, max) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const semAcento = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

/** Junta rua e bairro no texto que vai no pedido ("Rua Goiás 185 - Centro"), sem repetir o bairro se já estiver na rua. */
export function montarEndereco(rua, bairro) {
  const r = texto(rua, 200), b = texto(bairro, 80);
  if (!b) return r;
  if (semAcento(r).includes(semAcento(b))) return r;
  return `${r} - ${b}`;
}

/** Chave para comparar endereços (ignora caixa, acento e espaços). */
export const chaveEndereco = (rua, bairro) => semAcento(`${texto(rua, 200)}|${texto(bairro, 80)}`).replace(/[^a-z0-9|]/g, '');

export function mesmoEndereco(a, b) {
  if (!a || !b) return false;
  return chaveEndereco(a.rua, a.bairro) === chaveEndereco(b.rua, b.bairro);
}

/** Valida e normaliza um endereço do formulário. Devolve { ok, erro, endereco }. */
export function validarEndereco({ rotulo, rua, bairro, referencia } = {}) {
  const r = texto(rua, 200), b = texto(bairro, 80);
  if (r.length < 5) return { ok: false, erro: 'Informe a rua e o número.', campo: 'rua' };
  if (b.length < 2) return { ok: false, erro: 'Informe o bairro.', campo: 'bairro' };
  const rot = ROTULOS[rotulo] ? rotulo : 'outro';
  return { ok: true, endereco: { rotulo: rot, rua: r, bairro: b, referencia: texto(referencia, 120) } };
}

/** Objeto do Firebase → lista [{id, ...}] ordenada: Casa, Trabalho, depois os outros. Ignora registros inválidos. */
export function listarEnderecos(obj) {
  const ordem = { casa: 0, trabalho: 1, outro: 2 };
  return Object.entries(obj || {})
    .map(([id, e]) => ({ id, ...(e || {}) }))
    .filter((e) => typeof e.rua === 'string' && e.rua.length >= 5 && typeof e.bairro === 'string' && e.bairro.length >= 2)
    .map((e) => ({ ...e, rotulo: ROTULOS[e.rotulo] ? e.rotulo : 'outro' }))
    .sort((a, b) => (ordem[a.rotulo] - ordem[b.rotulo]) || String(a.criadoEm || '').localeCompare(String(b.criadoEm || '')));
}

/**
 * Decide o id onde salvar. Casa/Trabalho sobrescrevem o anterior. "Outro" cria novo; no limite, substitui o mais antigo.
 * `existentes` é a lista de listarEnderecos().
 */
export function idParaSalvar(rotulo, existentes, agora = Date.now()) {
  if (rotulo === 'casa') return 'casa';
  if (rotulo === 'trabalho') return 'trabalho';
  const outros = (existentes || []).filter((e) => e.rotulo === 'outro');
  if (outros.length >= MAX_OUTROS) return outros[0].id;
  return `outro_${agora.toString(36)}`;
}

/** Texto curto do cartão: "Centro · Rua Goiás 185". */
export const resumoEndereco = (e) => `${e.bairro} · ${e.rua}`;

/**
 * V75.125 — como o carrinho mostra o endereço: 'card' (cliente com endereço salvo escolhido: só o cartão, sem os campos)
 * ou 'form' (sem endereço salvo, ou adicionando um novo).
 */
export function modoEndereco({ enderecos, selecionado, novo } = {}) {
  if (novo || !selecionado) return 'form';
  return (enderecos || []).some((e) => e && e.id === selecionado) ? 'card' : 'form';
}

/** V75.125 — endereço que o carrinho escolhe sozinho: o último usado, se ainda existir; senão o primeiro (Casa, Trabalho...). */
export function enderecoPadrao(enderecos, ultimoId) {
  const lista = enderecos || [];
  return lista.find((e) => e.id === ultimoId) || lista[0] || null;
}
