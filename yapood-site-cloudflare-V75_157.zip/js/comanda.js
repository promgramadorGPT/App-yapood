// V75.62 — Comanda impressa (térmica 58/80 mm). Função pura: devolve o HTML; quem imprime é o admin-loja.js.
// Só preto e branco (impressora térmica). Logo = olhos e sorriso da marca, embutida (sem depender de rede).
export const LOGO_COMANDA = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANUAAAD2AQAAAABpA/+2AAAEW0lEQVR42u1YO47cRhB93SR2GRiYCScwMDzCZgqHR9kjOHQmGvBBdBSGDvcIFGBACilhA86Cw1LQv+pPtaW1ZMCAGCzIfdPVVdX1eV2KAABQzYbkuWr3tiN7PEYiRsAgr8NcwZYKtlawrYLdJEwBGKV1IzBJ2FAygsyzAAeKn9Wt6yD7s61gTQXLLWDYUMEeKlhXwYCjiLV4lLBbxYbngvHKxNenI6D2cnw+AaBg/p/8HAAAZ38EICJaDWbiqHHQhrfhjNZY12cTA9pvx/y9cBtsqEw+xOegi/2fU2bE2eviDLt3auLgddnj0L5xnyXhvnFsjXN3teeleXoRuEUGm+OAmoDeYz4TJveLIYkJJ4C8AGa6NX4DVJQPcc5r/zcvLb94LC9JR+S6OCf0PpZuPsaaDcCtNbtcdbF6oCBzD1XDYmv687vSOrvqFLC0yo19qCFzVlGo4LOanv+MfVKtx9h+I4DrEbejsO4vAJ8dxorjBFwHANQX163+lHPsyaZZCTPF6zYWMAo7Z9hLEK3LqpgNeXgCZ+94VfD1HPbNsIm5L5XpXy+ZTGLCU2xnuZFiGzNGC+aVzm9hErRgHrB/UyxN3JrEdvb++zfI5DImXWQZxXV70ot3YdkJRFK6dxUMupJm/yI391eue60u6gfY8BP7iX03bPyf6Dm8cl0fPn/72nUJL1h/sH2dLpF8S7bidYoz917HVwct75d/tZwrcRJAvCjf836Q9dQxkakzNmHE62iTjp9JxS/aYGPgncFHbbKuZ37oDMYCpmXcVYMHxRDJ0OKZDYYdLixAvF4Jf1FMrLIyukJAuqZyx5Q8hXcNAGp0XTQYcXJ6DYFya0a/iUL02guQfY/uY4r9rvF8t2V2H/1/zHczAsCvAICDIRqBNc+MQE9WvN2PdnbjIgBviGi15qgPpz0bcSiRhbBZyX9Xe/4YxDqxsztvOoPYKzKfC5MX8Z7DsCdRpiKF+1XwGVXs2yvYcwVbyvMVANAzqo/ss6+u5d/t3OcK9rozqt9v9womHVMjDZeAWzwvKNg+S9ijbCAtLGPTM+pEAzVa0UANHU2PYkyJRmhglIzQwAB8lLC+cu7HcHHNsE5SVJtyOFXuCLN0D5gERW1cb5XY3cv5Dly7YsxcXX8fBW6zlXNwVWR6VqGOXF0v3iQ9h4Ki721PfSh49N0CuHZ0STTBvakFbe5RcvfpBplHX7zPckVXf9cesuFomJU8ZHn2zje2FemoGWhY31yze7X22fuSTUy0v9JTMlLw3KZPlHli6452PsRGA51rwBsft5r2e3C1Vcej4T1wIss2QtL8DeDRN/U5sn4ElO/vtHg+4XePZvA0MJFtqMl3YFbMluewLfwHAFzCfoZtnDnxCL3j5DYyZ6f4ZM8G6CXMpIPMJEAPERYH4SXqVadsihb4C/H202wRf1FjNnCl4oZnn5u5UEo4ERPaZFPNJe7Aa8SzHEE30/+YZ438wJKeOrCDBvAF9DH0wTbKCMcAAAAASUVORK5CYII=';

import { detalhesDaLinha } from './combo.js';
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export const CSS_COMANDA = `@page{margin:2mm}
*{box-sizing:border-box}
body{margin:0;font-family:Arial,Helvetica,sans-serif;color:#000;font-size:12px;line-height:1.35;width:100%}
.c{text-align:center}
.logo{display:block;margin:0 auto 2px;height:12mm;width:auto}
.marca{font-weight:800;letter-spacing:.2em;font-size:10px;text-align:center}
.loja{font-size:16px;font-weight:800;text-align:center;margin-top:6px;line-height:1.15;overflow-wrap:anywhere}
.loja-info{text-align:center;font-size:11px;margin-top:2px;overflow-wrap:anywhere}
.sep{border-top:2px solid #000;margin:7px 0}
.sep.t{border-top:1px dashed #000;margin:6px 0}
.num{font-size:20px;font-weight:900;text-align:center;line-height:1.1}
.data{text-align:center;font-size:11px;margin-top:1px}
.tipo{background:#000;color:#fff;font-weight:800;font-size:14px;text-align:center;padding:3px 2px;margin:6px 0 2px;letter-spacing:.05em}
.bloco b{font-weight:800}
.bloco div{margin-top:1px;overflow-wrap:anywhere}
table{width:100%;border-collapse:collapse}
td{padding:3px 0;vertical-align:top}
td.q{width:8mm;font-weight:800;white-space:nowrap}
td.v{text-align:right;white-space:nowrap;padding-left:4px;font-weight:700}
.nome{font-weight:800;font-size:13px;overflow-wrap:anywhere}
.un{font-size:10px}
.extra{font-size:11px;padding-left:2mm}
.obs{border:1.5px solid #000;padding:4px 5px;margin-top:6px;overflow-wrap:anywhere}
.obs b{display:block}
.linha{display:flex;justify-content:space-between;gap:6px;margin-top:2px}
.total{display:flex;justify-content:space-between;gap:6px;font-size:17px;font-weight:900;margin-top:6px}
.pag{margin-top:6px;font-size:11px}
.cobrar{border:2.5px solid #000;text-align:center;padding:5px 3px;margin-top:7px}
.cobrar small{display:block;font-size:11px;font-weight:700;letter-spacing:.04em}
.cobrar strong{display:block;font-size:19px;font-weight:900;line-height:1.15}
.cobrar .troco{margin-top:3px;font-size:12px;font-weight:800}
.pago{border:2.5px solid #000;text-align:center;padding:5px 3px;margin-top:7px;font-weight:900;font-size:14px}
.pago small{display:block;font-size:11px;font-weight:700}
.rodape{text-align:center;margin-top:9px;font-size:11px}
.rodape strong{display:block;font-size:12px}
.fim{height:6mm}`;

/**
 * @param {object} d
 *  pedido  — registro do pedido
 *  loja    — { nome, telefone, endereco, cidade }
 *  moeda   — (n) => 'R$ 10,00'
 *  forma   — texto curto da forma de pagamento (ex.: 'Dinheiro', 'PIX')
 *  pagamento — 'online' | 'entrega' | 'pendente'  (quem recebe o dinheiro)
 *  troco   — já sanitizado ({precisa:true,paraValor,devolver} | {precisa:false} | null); só aparece quando há valor a cobrar
 */
export function montarComanda({ pedido: p = {}, loja = {}, moeda, forma = '', pagamento = 'entrega', troco = null } = {}) {
  const itensArray = Array.isArray(p.itens) ? p.itens : Object.values(p.itens || {});
  const itens = itensArray.map((i) => {
    const q = Number(i.qtd) || 0, u = Number(i.precio) || 0;
    const extras = detalhesDaLinha(i).map((x) => `<div class="extra">${esc(x)}</div>`).join('');
    return `<tr><td class="q">${q}×</td><td><div class="nome">${esc(i.nombre || 'Item')}</div>${extras}<div class="un">${moeda(u)} un.</div></td><td class="v">${moeda(u * q)}</td></tr>`;
  }).join('');
  const subRaw = Number(p.subtotal);
  const subtotal = Number.isFinite(subRaw) ? subRaw : itensArray.reduce((s, i) => s + (Number(i.precio) || 0) * (Number(i.qtd) || 0), 0);
  const envio = Math.max(0, Number(p.precioEnvio ?? p.taxaEntrega ?? 0) || 0);
  const desconto = Math.max(0, Number(p.desconto) || 0);
  const total = Number(p.total) || Math.max(0, subtotal + envio - desconto);
  const saldo = Math.min(total, Math.max(0, Number(p.saldo?.usado) || 0)); // V75.145: saldo da loja usado no pedido
  const aCobrar = Math.max(0, Math.round((total - saldo) * 100) / 100);
  const retirada = p.tipoEntrega === 'retirada';
  const c = p.cliente || {};
  const numero = esc(p.numeroPedido || p.key || '');
  const quando = p.criadoEm ? new Date(p.criadoEm) : null;
  const dataHora = quando && !isNaN(quando) ? quando.toLocaleString('pt-BR') : '';
  const linha = (rot, val) => (val ? `<div><b>${rot}:</b> ${esc(val)}</div>` : '');
  const nomeLoja = esc(loja.nome || '');
  const lojaEnd = [loja.endereco, loja.cidade].filter(Boolean).join(' - ');
  const observacao = c.observacion || c.observacao || '';

  let blocoPagamento = '';
  if (pagamento === 'online') blocoPagamento = p.pagoComSaldo === true ? '<div class="pago">PAGO COM SALDO<small>Saldo na loja · nada a cobrar</small></div>' : `<div class="pago">PAGO ONLINE<small>${esc(forma)} · nada a cobrar</small></div>`;
  else if (pagamento === 'entrega') {
    blocoPagamento = `<div class="cobrar"><small>COBRAR NA ${retirada ? 'RETIRADA' : 'ENTREGA'}${forma ? ' · ' + esc(forma).toUpperCase() : ''}</small><strong>${moeda(aCobrar)}</strong>${troco?.precisa === true ? `<div class="troco">TROCO PARA ${moeda(troco.paraValor)}<br>DEVOLVER ${moeda(troco.devolver)}</div>` : troco?.precisa === false ? '<div class="troco">Sem troco</div>' : ''}</div>`;
  } else blocoPagamento = `<div class="pag"><b>Pagamento:</b> ${esc(forma) || 'pendente'} (aguardando confirmação)</div>`;

  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Pedido #${numero}</title><style>${CSS_COMANDA}</style></head><body>
<img class="logo" src="${LOGO_COMANDA}" alt=""><div class="marca">YAPOOD</div>
${nomeLoja ? `<div class="loja">${nomeLoja}</div>` : ''}${loja.telefone ? `<div class="loja-info">Tel.: ${esc(loja.telefone)}</div>` : ''}${lojaEnd ? `<div class="loja-info">${esc(lojaEnd)}</div>` : ''}
<div class="sep"></div>
<div class="num">PEDIDO #${numero}</div><div class="data">${esc(dataHora)}</div>
<div class="tipo">${retirada ? 'RETIRADA NA LOJA' : 'ENTREGA'}</div>
<div class="bloco">${linha('Cliente', c.nome || c.nombre || 'Cliente')}${linha('Telefone', c.telefone || c.telefono || '')}${retirada ? '' : linha('Endereço', c.direccion || c.endereco || '')}${retirada ? '' : linha('Bairro', p.bairro || '')}${retirada ? '' : linha('Referência', c.referencia || c['referência'] || '')}</div>
<div class="sep t"></div>
<table><tbody>${itens}</tbody></table>
${observacao ? `<div class="obs"><b>OBSERVAÇÕES</b>${esc(observacao)}</div>` : ''}
<div class="sep t"></div>
<div class="linha"><span>Subtotal</span><span>${moeda(subtotal)}</span></div>
${desconto > 0 ? `<div class="linha"><span>Desconto</span><span>-${moeda(desconto)}</span></div>` : ''}${envio > 0 ? `<div class="linha"><span>Taxa de entrega</span><span>${moeda(envio)}</span></div>` : ''}
<div class="total"><span>TOTAL</span><span>${moeda(total)}</span></div>
${saldo > 0 ? `<div class="linha"><span>Saldo da loja</span><span>-${moeda(saldo)}</span></div>` : ''}
${blocoPagamento}
<div class="sep t"></div>
<div class="rodape"><strong>Obrigado pela preferência!</strong>Pedido feito pelo app YAPOOD</div><div class="fim"></div>
</body></html>`;
}
