// js/abertura-loja.js — V75.138: aviso de abertura da loja (regras puras, sem DOM nem Firebase).
// 5 min antes do horário de abrir, o painel da loja pergunta "Estou pronto / Não estou pronto". A resposta fica em
// restaurantes/{id}/abertura = { chave, resposta: 'pronto' | 'adiado' | 'hoje-nao', abreAs?, em }.
// "Não estou pronto" adia (abreAs = novo horário) ou fecha o resto do dia; enquanto isso o cliente vê a loja fechada (regras.js).

export const AVISO_ANTES_MIN = 5;   // abre o aviso 5 min antes
export const AVISO_DEPOIS_MIN = 10; // painel aberto um pouco depois do horário: ainda pergunta
export const ADIAR_MIN = [15, 30, 60];
const DIAS = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado'];
const MIN = 60000;
const minutos = (hhmm) => { const m = /^(\d{1,2}):(\d{2})/.exec(String(hhmm || '')); return m ? Number(m[1]) * 60 + Number(m[2]) : null; };
const noDia = (agora, min) => { const d = new Date(agora); d.setHours(0, 0, 0, 0); d.setMinutes(min); return d; };
const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);

/** Horário de abrir de HOJE (Date) pelos horários da loja; null se hoje está fechado ou sem horário. */
export function aberturaDeHoje(horarios, agora = new Date()) {
  const h = horarios && horarios[DIAS[new Date(agora).getDay()]];
  if (!h || h.aberto === false) return null;
  const a = minutos(h.abre);
  return a === null ? null : noDia(agora, a);
}
/** Fim do turno que abre hoje (Date). Turno que passa da meia-noite termina amanhã. */
export function fimDoTurnoDeHoje(horarios, agora = new Date()) {
  const h = horarios && horarios[DIAS[new Date(agora).getDay()]];
  const a = minutos(h && h.abre), f = minutos(h && h.fecha);
  if (a === null || f === null) { const d = noDia(agora, 0); d.setDate(d.getDate() + 1); return d; }
  const d = noDia(agora, f); if (f <= a) d.setDate(d.getDate() + 1);
  return d;
}

/** A loja está segurando a abertura agora? -> { ate: ms, motivo } ou null. Usado no cliente (regras.js) e no painel. */
export function aberturaSegurada(abertura, agora = Date.now()) {
  const ab = abertura || {}, ate = num(ab.abreAs), t = typeof agora === 'number' ? agora : new Date(agora).getTime();
  if ((ab.resposta !== 'adiado' && ab.resposta !== 'hoje-nao') || ate === null || ate <= t) return null;
  return { ate, motivo: ab.resposta === 'hoje-nao' ? 'Fechado hoje' : `Abre às ${hhmm(ate)}` };
}
export const hhmm = (ms) => { const d = new Date(ms); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };

/**
 * Deve mostrar o aviso agora? -> null ou { abreEm: ms, chave, faltamMin, jaPassou }.
 * Só com a loja ativa; de 5 min antes até 10 min depois do horário (o de hoje, ou o novo horário de um adiamento);
 * some quando já houve resposta para esse horário (chave).
 */
export function avisoAbertura(loja, agora = Date.now()) {
  if (!loja || loja.activo === false) return null;
  const t = typeof agora === 'number' ? agora : new Date(agora).getTime();
  const ab = loja.abertura || {};
  if (ab.resposta === 'hoje-nao' && num(ab.abreAs) !== null && ab.abreAs > t) return null; // "não vou abrir hoje"
  const adiada = ab.resposta === 'adiado' && num(ab.abreAs) !== null && ab.abreAs > t - AVISO_DEPOIS_MIN * MIN ? ab.abreAs : null;
  const hoje = aberturaDeHoje(loja.horarios, t);
  const alvo = adiada ?? (hoje ? hoje.getTime() : null);
  if (alvo === null) return null;
  const diff = alvo - t;
  if (diff > AVISO_ANTES_MIN * MIN || diff < -AVISO_DEPOIS_MIN * MIN) return null;
  const chave = String(alvo);
  if (ab.chave === chave && ab.resposta) return null; // já respondeu para este horário
  // respondeu depois que o aviso de hoje já podia aparecer (ex.: adiou para 18:15 e disse "pronto" às 18:10): hoje está resolvido
  if (adiada === null && ab.resposta && num(ab.em) !== null && ab.em >= alvo - AVISO_ANTES_MIN * MIN) return null;
  return { abreEm: alvo, chave, faltamMin: Math.max(0, Math.ceil(diff / MIN)), jaPassou: diff <= 0 };
}

/** Opções do "Não estou pronto", contadas a partir do horário de abrir (ou de agora, se ele já passou). */
export function opcoesAdiar(abreEm, horarios, agora = Date.now()) {
  const base = Math.max(abreEm, agora);
  const fim = fimDoTurnoDeHoje(horarios, abreEm).getTime();
  return [
    ...ADIAR_MIN.map((m) => ({ tipo: 'adiado', min: m, abreAs: base + m * MIN, rotulo: `Abrir às ${hhmm(base + m * MIN)}`, extra: m < 60 ? `+${m} min` : '+1 h' })).filter((o) => o.abreAs < fim),
    { tipo: 'hoje-nao', abreAs: fim, rotulo: 'Não vou abrir hoje', extra: '' }
  ];
}

/** O que gravar em restaurantes/{id}/abertura para cada resposta. */
export function respostaAbertura(chave, opcao, agora = Date.now()) {
  if (!opcao || opcao.tipo === 'pronto') return { chave: String(chave), resposta: 'pronto', abreAs: null, em: agora };
  return { chave: String(chave), resposta: opcao.tipo === 'hoje-nao' ? 'hoje-nao' : 'adiado', abreAs: Math.round(opcao.abreAs), em: agora };
}
