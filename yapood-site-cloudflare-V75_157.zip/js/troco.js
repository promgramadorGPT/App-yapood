// V75.60 — Troco no pagamento em dinheiro. Regras puras (sem DOM), testadas em tests/troco.test.mjs.
const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;

/** "100", "100,50", "R$ 1.000,00", "1000.5" → número; inválido → NaN. */
export function lerValorTroco(texto) {
  let s = String(texto ?? '').replace(/R\$|\s/g, '');
  if (!s || /[^0-9.,]/.test(s)) return NaN;
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');          // 1.000,50 → 1000.50
  else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');          // 1.000 → 1000
  const n = Number(s);
  return Number.isFinite(n) ? arred(n) : NaN;
}

/**
 * Valida a resposta do cliente.
 * entrada: { precisa: true | false | null, texto }  ·  total: valor do pedido.
 * saída: { ok:true, troco:{ precisa:false } | { precisa:true, paraValor, devolver } } ou { ok:false, erro }.
 */
export function validarTroco({ precisa, texto } = {}, total = 0) {
  if (precisa !== true && precisa !== false) return { ok: false, erro: 'Informe se você precisa de troco.' };
  if (!precisa) return { ok: true, troco: { precisa: false } };
  const valor = lerValorTroco(texto), tot = arred(total);
  const rs = (v) => 'R$ ' + v.toFixed(2).replace('.', ',');
  if (!Number.isFinite(valor) || valor <= 0) return { ok: false, erro: 'Informe para quanto você precisa de troco. Ex.: 100,00' };
  if (valor < tot) return { ok: false, erro: `O valor precisa ser maior que o total do pedido (${rs(tot)}).` };
  if (valor > 10000) return { ok: false, erro: 'Valor muito alto para troco.' };
  if (valor === tot) return { ok: true, troco: { precisa: false } };         // paga o valor exato: não precisa de troco
  return { ok: true, troco: { precisa: true, paraValor: valor, devolver: arred(valor - tot) } };
}

/** Texto curto para a loja, o entregador, a impressão e o WhatsApp. */
export function textoTroco(troco, formatar = (v) => 'R$ ' + Number(v).toFixed(2).replace('.', ',')) {
  if (!troco || typeof troco !== 'object') return '';
  if (troco.precisa === true && Number(troco.paraValor) > 0) return `Troco para ${formatar(troco.paraValor)} (devolver ${formatar(troco.devolver)})`;
  if (troco.precisa === false) return 'Sem troco';
  return '';
}

/** Sanitiza o que vem do banco (nunca confia no formato). */
export function trocoSeguro(troco) {
  if (!troco || typeof troco !== 'object') return null;
  if (troco.precisa === true) {
    const p = arred(troco.paraValor), d = arred(troco.devolver);
    return p > 0 && d >= 0 && p <= 10000 ? { precisa: true, paraValor: p, devolver: d } : null;
  }
  return troco.precisa === false ? { precisa: false } : null;
}
