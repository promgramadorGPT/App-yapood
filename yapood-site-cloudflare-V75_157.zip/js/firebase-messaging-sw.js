importScripts('https://www.gstatic.com/firebasejs/12.0.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/12.0.0/firebase-messaging-compat.js');
firebase.initializeApp({
  apiKey:'AIzaSyDJAKE0w6YeGjos9E21SnsLEh0PIEhK5hI',
  authDomain:'yapoodbr-delivery.firebaseapp.com',
  databaseURL:'https://yapoodbr-delivery-default-rtdb.firebaseio.com',
  projectId:'yapoodbr-delivery',
  storageBucket:'yapoodbr-delivery.firebasestorage.app',
  messagingSenderId:'469832240218',
  appId:'1:469832240218:web:868056b23bf792fc005c63'
});
const messaging=firebase.messaging();
messaging.onBackgroundMessage(payload=>{
  const n=payload.notification||{};
  self.registration.showNotification(n.title||'YAPOOD',{body:n.body||'',icon:'/icons/icons-192.png',data:payload.data||{}});
});
