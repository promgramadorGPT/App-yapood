import { db, auth, ref, onValue, set, update, query, orderByChild, equalTo, onAuthStateChanged } from './firebase.js';
import { escapeHtml, normalizarStatus, rotuloStatus, STATUS } from './regras.js';
import { formatarMoeda, urlSegura, imgOtimizada, toast, comTrava, salvarCarrinho, IMG_LOJA_PADRAO } from './utils.js';
import { registrarNotaNoAgregado } from './pedido-service.js';
import { nomeDoCliente } from './perfil-nome.js?v=75.106';
import { aplicarBloqueio } from './avaliacao-tags.js?v=75.139';

const $ = (id) => document.getElementById(id);
const listaContainer = $('lista-pedidos-historico');
const modalAvaliacao = $('modal-avaliacao');

const pedidosCache = {};
window.__yapoodPedidos = { get cache() { return pedidosCache; } }; // somente leitura (módulo de reembolso)
let pedidoAvaliando = null;
let notaComida = 0, notaEntrega = 0, tagsComida = [], tagsEntrega = [];
let cancelarEscuta = null;
let avaliacaoSolicitada = false;

const SLUG = { [STATUS.PENDENTE]: 'pendiente', [STATUS.PREPARANDO]: 'preparando', [STATUS.ENTREGA]: 'camino', [STATUS.ENTREGUE]: 'entregado', [STATUS.CANCELADO]: 'cancelado' };

onAuthStateChanged(auth, (user) => {
  cancelarEscuta?.(); cancelarEscuta = null;
  if (!user) {
    listaContainer.innerHTML = '<div class="msg-vacio"><i class="fa-solid fa-user-lock"></i><p>Entre para ver seu histórico de pedidos.</p><a class="btn-link" href="perfil.html">Entrar</a></div>';
    return;
  }
  cancelarEscuta = onValue(query(ref(db, 'pedidos'), orderByChild('clienteUid'), equalTo(user.uid)), renderizarHistorico, (err) => {
    console.error(err);
    listaContainer.innerHTML = '<p class="erro">Erro ao carregar seus pedidos.</p>';
  });
});

function renderizarHistorico(snap) {
  if (!snap.exists()) {
    listaContainer.innerHTML = '<div class="msg-vacio"><i class="fa-solid fa-utensils"></i><p>Você ainda não realizou nenhum pedido.</p></div>';
    return;
  }
  const lista = Object.entries(snap.val()).map(([k, p]) => ({ firebaseKey: k, ...p }))
    .sort((a, b) => String(b.criadoEm || '').localeCompare(String(a.criadoEm || '')));
  lista.forEach((p) => { pedidosCache[p.firebaseKey] = p; });

  listaContainer.innerHTML = lista.map((p) => {
    const status = normalizarStatus(p.status);
    const resumo = (Array.isArray(p.itens) ? p.itens : []).map((i) => `${Number(i.qtd) || 1}x ${escapeHtml(i.nombre || 'Produto')}`).join(', ');
    const chave = escapeHtml(p.firebaseKey);
    let btnAval = '';
    if (status === STATUS.ENTREGUE) {
      btnAval = p.avaliado
        ? `<button class="btn-avaliado" disabled><i class="fa-solid fa-star" style="color:#ffc107"></i> Avaliado (${Number(p.notaMediaAvaliacao) || 5}★)</button>`
        : `<button class="btn-avaliar" data-acao="avaliar" data-key="${chave}"><i class="fa-solid fa-star"></i> Avaliar loja</button>`;
    }
    return `<div class="card-pedido">
      <div class="header-card-pedido">
        <div class="info-loja-topo">
          <img src="${escapeHtml(imgOtimizada(urlSegura(p.lojaLogo || p.lojaFoto, IMG_LOJA_PADRAO), 160))}" alt="" class="logo-loja-thumb" loading="lazy">
          <div class="detalhes-loja-topo"><h3>${escapeHtml(p.lojaNome || 'Restaurante')}</h3><span class="num-pedido">Pedido #${escapeHtml(p.numeroPedido || 'S/N')}</span></div>
        </div>
        <span class="badge-status status-${SLUG[status]}">${escapeHtml(rotuloStatus(status))}</span>
      </div>
      <div class="corpo-card-pedido">
        <p class="resumo-itens">${resumo || 'Sem detalles'}</p>
        <span class="valor-total">Total: ${formatarMoeda(p.total)}</span>
      </div>
      <div class="acoes-card-pedido">
        ${btnAval}
        <button class="btn-status" data-acao="status" data-num="${escapeHtml(p.numeroPedido)}"><i class="fa-solid fa-clock-rotate-left"></i> Ver Estado</button>
        <button class="btn-repetir" data-acao="repetir" data-key="${chave}"><i class="fa-solid fa-rotate-right"></i> Pedir de novo</button>
      </div></div>`;
  }).join('');

  // Permite que status.html abra diretamente a avaliação do pedido entregue.
  if (!avaliacaoSolicitada) {
    const chaveSolicitada = new URLSearchParams(location.search).get('avaliar');
    if (chaveSolicitada && pedidosCache[chaveSolicitada]) {
      avaliacaoSolicitada = true;
      setTimeout(() => abrirModalAvaliacao(chaveSolicitada), 0);
    }
  }
}

listaContainer.addEventListener('click', (e) => {
  const b = e.target.closest('[data-acao]'); if (!b) return;
  if (b.dataset.acao === 'status') location.href = `status.html?num=${encodeURIComponent(b.dataset.num)}`;
  if (b.dataset.acao === 'avaliar') abrirModalAvaliacao(b.dataset.key);
  if (b.dataset.acao === 'repetir') repetirPedido(b.dataset.key);
});

function repetirPedido(chave) {
  const p = pedidosCache[chave]; if (!p) return;
  // Preços/disponibilidade são revalidados no carrinho (reconciliarItensComMenu), então repetir é seguro.
  salvarCarrinho({ lojaId: p.lojaId, itens: (p.itens || []).map((i) => ({ id: i.id, nombre: i.nombre, precio: i.precio, qtd: i.qtd, ...(Array.isArray(i.opcoes) ? { opcoes: i.opcoes } : {}), ...(Array.isArray(i.adicionais) ? { adicionais: i.adicionais } : {}), ...(i.obs ? { obs: i.obs } : {}) })) }); // V75.127: com as escolhas (o carrinho confere no cardápio atual)
  location.href = 'cart.html';
}

// ---------- Modal de avaliação (as funções globais são chamadas pelos onclick do pedidos.html) ----------
function abrirModalAvaliacao(chave) {
  const p = pedidosCache[chave]; if (!p) return;
  if (normalizarStatus(p.status) !== STATUS.ENTREGUE) return toast('A avaliação estará disponível quando o pedido for entregue.', 'error');
  if (p.avaliado) return toast('Este pedido já foi avaliado.', 'info');
  pedidoAvaliando = p; notaComida = 0; notaEntrega = 0; tagsComida = []; tagsEntrega = [];
  $('avaliacao-loja-nome').textContent = p.lojaNome || 'Restaurante';
  $('avaliacao-comentario').value = ''; $('qtd-caracteres').textContent = '0';
  document.querySelectorAll('.tag-opainter').forEach((t) => t.classList.remove('ativa'));
  document.querySelectorAll('#modal-avaliacao .tags-container, .tags-container').forEach(aplicarBloqueio);
  window.voltarParaComida(); pintar('estrelas-comida', 0); pintar('estrelas-entrega', 0);
  modalAvaliacao.style.display = 'flex';
}
window.fecharModalAvaliacao = () => { modalAvaliacao.style.display = 'none'; };

window.avancarParaEntrega = () => {
  if (!notaComida) return toast('Selecione pelo menos uma estrela para a comida.', 'error');
  $('etapa-comida').style.display = 'none'; $('etapa-entrega').style.display = 'block';
  $('titulo-etapa-avaliacao').textContent = 'Como foi a entrega?';
  $('ponto-etapa-1').classList.remove('ativo'); $('ponto-etapa-2').classList.add('ativo');
};
window.voltarParaComida = () => {
  $('etapa-entrega').style.display = 'none'; $('etapa-comida').style.display = 'block';
  $('titulo-etapa-avaliacao').textContent = 'Como estava a comida?';
  $('ponto-etapa-2').classList.remove('ativo'); $('ponto-etapa-1').classList.add('ativo');
};
window.atualizarContadorCaracteres = (el) => { $('qtd-caracteres').textContent = el.value.length; };
window.toggleTag = (el, categoria) => {
  if (el.disabled) return; // V75.139: tag bloqueada (contradiz a já marcada)
  const lista = categoria === 'comida' ? tagsComida : tagsEntrega;
  const txt = el.textContent.trim(); const i = lista.indexOf(txt);
  el.classList.toggle('ativa', i < 0);
  if (i < 0) lista.push(txt); else lista.splice(i, 1);
  aplicarBloqueio(el.closest('.tags-container'));
};

function pintar(containerId, nota) {
  document.querySelectorAll(`#${containerId} .estrela`).forEach((e) => { e.style.color = Number(e.dataset.valor) <= nota ? '#ffc107' : '#ccc'; });
}
document.querySelectorAll('#estrelas-comida .estrela').forEach((e) => e.addEventListener('click', () => { notaComida = Number(e.dataset.valor); pintar('estrelas-comida', notaComida); }));
document.querySelectorAll('#estrelas-entrega .estrela').forEach((e) => e.addEventListener('click', () => { notaEntrega = Number(e.dataset.valor); pintar('estrelas-entrega', notaEntrega); }));

$('btn-enviar-avaliacao')?.addEventListener('click', (ev) => {
  if (!notaEntrega) return toast('Selecione pelo menos uma estrela para a entrega.', 'error');
  if (!pedidoAvaliando || !auth.currentUser) return;
  comTrava(ev.currentTarget, async () => {
    const p = pedidoAvaliando, user = auth.currentUser;
    const notaMedia = (notaComida + notaEntrega) / 2;
    try {
      await set(ref(db, `avaliacoes/${p.lojaId}/${p.firebaseKey}`), {
        pedidoId: p.firebaseKey, numeroPedido: p.numeroPedido, clienteUid: user.uid,
        clienteNome: await nomeDoCliente(user), notaComida, notaEntrega, notaMedia,
        tagsComida, tagsEntrega, comentario: $('avaliacao-comentario').value.trim(), aprovada: !$('avaliacao-comentario').value.trim(), criadoEm: new Date().toISOString()
      });
      await update(ref(db, `pedidos/${p.firebaseKey}`), { avaliado: true, notaMediaAvaliacao: Math.round(notaMedia) });
      await registrarNotaNoAgregado(p.lojaId, { notaComida, notaEntrega }).catch((e) => console.warn('Agregado não atualizado:', e));
      toast('Muito obrigado pela sua avaliação!', 'success');
      window.fecharModalAvaliacao();
    } catch (e) {
      console.error('Erro ao salvar a avaliação:', e);
      toast('Não foi possível enviar sua avaliação. Tente novamente.', 'error');
    }
  });
});
