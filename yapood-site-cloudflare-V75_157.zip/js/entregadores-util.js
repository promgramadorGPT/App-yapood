// js/entregadores-util.js — regras puras da aba Entregadores (sem DOM, sem Firebase). Testadas em tests/entregadores-admin.test.mjs.

export const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const FORMAS = { pix: 'PIX', dinheiro: 'Dinheiro', outro: 'Outro' };
export const PERIODOS = { hoje: 'Hoje', '7': '7 dias', '30': '30 dias', tudo: 'Tudo' };

const DIA = 24 * 60 * 60 * 1000;

/** Início do período em ms (0 = sem limite). "hoje" = meia-noite local. */
export function periodoInicio(chave, agora = new Date()) {
  if (chave === 'hoje') { const d = new Date(agora); d.setHours(0, 0, 0, 0); return d.getTime(); }
  if (chave === '7') return agora.getTime() - 7 * DIA;
  if (chave === '30') return agora.getTime() - 30 * DIA;
  return 0;
}

/** Taxas dentro do período (pela data em que a taxa nasceu, isto é, quando a entrega foi confirmada). */
export const filtrarPorPeriodo = (taxas, chave, agora = new Date()) => {
  const ini = periodoInicio(chave, agora);
  return (taxas || []).filter((t) => (Number(t.criadoEm) || 0) >= ini);
};

export const pendente = (t) => t.statusPagamento !== 'pago';

export function totais(taxas) {
  const pend = (taxas || []).filter(pendente);
  return {
    pendenteValor: arred(pend.reduce((s, t) => s + (Number(t.valor) || 0), 0)), pendenteQtd: pend.length,
    pagoValor: arred((taxas || []).filter((t) => !pendente(t)).reduce((s, t) => s + (Number(t.valor) || 0), 0)),
    total: arred((taxas || []).reduce((s, t) => s + (Number(t.valor) || 0), 0))
  };
}

/** [{ entregadorUid, entregador, taxas:[...], ...totais }] — quem tem mais a pagar vem primeiro. */
export function agruparPorEntregador(taxas) {
  const mapa = new Map();
  for (const t of taxas || []) {
    if (!mapa.has(t.entregadorUid)) mapa.set(t.entregadorUid, { entregadorUid: t.entregadorUid, entregador: t.entregador, taxas: [] });
    mapa.get(t.entregadorUid).taxas.push(t);
  }
  return [...mapa.values()]
    .map((g) => ({ ...g, taxas: g.taxas.sort((a, b) => (b.criadoEm || 0) - (a.criadoEm || 0)), ...totais(g.taxas) }))
    .sort((a, b) => (b.pendenteValor - a.pendenteValor) || String(a.entregador).localeCompare(String(b.entregador), 'pt-BR'));
}

/** Números do cartão de cada entregador. */
export function estatisticas(uid, entregas, taxas) {
  const minhas = (entregas || []).filter((e) => e.entregadorUid === uid);
  const t = totais((taxas || []).filter((x) => x.entregadorUid === uid));
  return {
    emAndamento: minhas.filter((e) => !e.confirmada && !e.cancelado).length,
    concluidas: minhas.filter((e) => e.confirmada).length,
    aPagar: t.pendenteValor, aPagarQtd: t.pendenteQtd
  };
}

/** V75.103 — entregas em andamento (não entregues nem canceladas) de um entregador; `ignorar` é o pedido que está sendo (re)atribuído. */
export function cargaDoEntregador(uid, entregas, ignorar = '') {
  return (entregas || []).filter((e) => e.entregadorUid === uid && !e.confirmada && !e.cancelado && e.pedidoKey !== ignorar).length;
}

const SAIU = new Set(['en camino', 'a caminho', 'entrega', 'em_entrega', 'em entrega']);
export const statusSaiu = (status) => SAIU.has(String(status || '').trim().toLowerCase());
/**
 * V75.104 — quantos pedidos o entregador JÁ SAIU para entregar (despachados, ainda não entregues nem cancelados).
 * Com 1 ou mais ele fica fechado para novas atribuições até concluir; enquanto os pedidos estão em preparo, aceita quantos forem.
 */
export function saiuComPedidos(uid, entregas, ignorar = '') {
  return (entregas || []).filter((e) => e.entregadorUid === uid && !e.confirmada && !e.cancelado && e.pedidoKey !== ignorar && statusSaiu(e.status)).length;
}
export const textoSaiu = (n) => n === 1 ? 'saiu com 1 pedido' : `saiu com ${n} pedidos`;
export const textoCarga = (n) => n <= 0 ? 'livre' : n === 1 ? '1 entrega em andamento' : `${n} entregas em andamento`;

/** V75.137 — a entrega ativa (não entregue nem cancelada) de um pedido, ou null. */
export function entregaAtiva(pedidoKey, entregas) {
  return (entregas || []).find((e) => e && e.pedidoKey === pedidoKey && !e.confirmada && !e.cancelado) || null;
}
/**
 * V75.137 — botão do card do pedido: 'atribuir' (sem entregador), 'trocar' (tem entregador e o pedido ainda não saiu) ou null.
 * Depois que o pedido saiu, a troca (moto quebrou etc.) fica só na aba Entregadores, com aviso. Com corrida do parceiro, nada.
 */
export function botaoDoCard(pedido, entrega, temParceiro = false) {
  if (!pedido || pedido.tipoEntrega !== 'delivery' || pedido.entregaConfirmada || /cancel|entreg(ado|ue)/i.test(String(pedido.status || ''))) return null;
  if (temParceiro) return null;
  if (!entrega) return 'atribuir';
  return statusSaiu(pedido.status) ? null : 'trocar';
}
/** V75.137 — passar para `novoUid` um pedido que já saiu com outro entregador? (pede confirmação e vai com trocaEmRota) */
export const ehTrocaEmRota = (entrega, status, novoUid) => !!entrega && !!entrega.entregadorUid && entrega.entregadorUid !== novoUid && statusSaiu(status);

/** Pedidos de entrega ainda sem entregador (não cancelados nem entregues, sem atribuição ativa). */
export function pedidosSemEntregador(pedidos, entregas) {
  const atribuidos = new Set((entregas || []).filter((e) => !e.cancelado).map((e) => e.pedidoKey));
  return (pedidos || []).filter((p) => p.tipoEntrega === 'delivery'
    && !/cancel|entreg(ado|ue)/i.test(String(p.status || ''))
    && !p.entregaConfirmada
    && !atribuidos.has(p.key));
}

/**
 * V75.57 — Vale lembrar o lojista de atribuir um entregador antes de despachar?
 * Sim quando é delivery, ainda sem entregador, e a loja TEM entregador ativo (sem equipe não há o que esquecer).
 * `entregadores` desconhecido (null/undefined) conta como "pode ter".
 */
export function deveLembrarEntregador(pedido, entregas, entregadores) {
  if (!pedido || pedidosSemEntregador([pedido], entregas).length === 0) return false;
  if (Array.isArray(entregadores) && !entregadores.some((e) => e && e.ativo !== false)) return false;
  return true;
}

const csvCel = (v) => { const s = String(v ?? ''); return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
const dataBR = (t) => (t ? new Date(t).toLocaleDateString('pt-BR') : '');
const num = (v) => String(arred(v)).replace('.', ',');

/** Extrato em CSV (separador ';', decimais com vírgula — abre direto no Excel em português). `numeroDe(pedidoKey)` devolve o nº do pedido. */
export function csvExtrato(taxas, numeroDe = (k) => k) {
  const linhas = [['Entregador', 'Pedido', 'Data da entrega', 'Valor (R$)', 'Situação', 'Pago em']];
  for (const t of taxas || []) linhas.push([t.entregador, numeroDe(t.pedidoKey), dataBR(t.criadoEm), num(t.valor), pendente(t) ? 'A pagar' : 'Paga', dataBR(t.pagoEm)]);
  const tt = totais(taxas);
  linhas.push([], ['Total a pagar', '', '', num(tt.pendenteValor)], ['Total pago', '', '', num(tt.pagoValor)]);
  return '﻿' + linhas.map((l) => l.map(csvCel).join(';')).join('\r\n');
}

/** Texto do comprovante para copiar/enviar no WhatsApp. */
export function textoComprovante(acerto, lojaNome = '') {
  const moeda = (v) => (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const quando = acerto.criadoEm ? new Date(acerto.criadoEm).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '';
  return [
    `*Comprovante de pagamento${lojaNome ? ' — ' + lojaNome : ''}*`,
    `Entregador: ${acerto.entregador}`,
    `Valor: ${moeda(acerto.valorTotal)} (${acerto.qtd} entrega${acerto.qtd === 1 ? '' : 's'})`,
    `Forma: ${FORMAS[acerto.forma] || acerto.forma}`,
    quando ? `Data: ${quando}` : '',
    acerto.obs ? `Obs.: ${acerto.obs}` : ''
  ].filter(Boolean).join('\n');
}

/** Link do WhatsApp para o telefone brasileiro (só dígitos). '' se não houver telefone. */
export function linkWhatsApp(telefone, texto = '') {
  const d = String(telefone ?? '').replace(/\D/g, '');
  if (d.length < 10) return '';
  const completo = d.length <= 11 ? '55' + d : d;
  return `https://wa.me/${completo}${texto ? '?text=' + encodeURIComponent(texto) : ''}`;
}

export function formatarTelefone(telefone) {
  const d = String(telefone ?? '').replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return d;
}
