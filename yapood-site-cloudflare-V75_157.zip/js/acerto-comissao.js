// js/acerto-comissao.js — V75.50: acerto da comissão "a acertar" (pedidos pagos na entrega ou sem split) entre a loja e o YaPOOD.
// Funções puras (sem Firebase/DOM). Testadas em tests/acerto-comissao.test.mjs.
//
// Regra: a comissão dos pedidos ENTREGUES fecha toda segunda-feira (00:00 de Brasília) e vence PRAZO dias depois (padrão 7).
// Os pagamentos registrados pelo Master abatem do fechamento mais antigo para o mais novo. Passou do vencimento sem quitar: a loja pode ser suspensa.
import { STATUS, normalizarStatus } from './regras.js';
import { comissaoDoPedido } from './comissao.js';
import { cpfValido, cnpjValido, somenteDigitos } from './cadastro-lojista.js';

export const PRAZO_PADRAO_DIAS = 7;
export const FORMAS = Object.freeze({ pix: 'Pix', transferencia: 'Transferência', link: 'Link de pagamento', outro: 'Outro' });
export const TIPOS_CHAVE = Object.freeze({ cpf: 'CPF', cnpj: 'CNPJ', telefone: 'Telefone', email: 'E-mail', aleatoria: 'Chave aleatória' });

const DIA = 86400000, OFFSET_BR = -180;
const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;
const limpar = (s, max) => String(s ?? '').trim().replace(/\s+/g, ' ').slice(0, max);

// ---------- Datas (Brasília, semana de segunda a domingo) ----------
/** Instante (ms UTC) da segunda-feira 00:00 de Brasília que começa a semana do instante `ms`. */
export function inicioDaSemana(ms, offsetMin = OFFSET_BR) {
  const local = ms + offsetMin * 60000;
  const dia = Math.floor(local / DIA);
  const dow = (dia + 3) % 7;                       // 0 = segunda (1970-01-01 foi quinta)
  return (dia - dow) * DIA - offsetMin * 60000;
}
const dataDoPedido = (p) => {
  for (const v of [p?.entregadoEm, p?.finalizadoEm, p?.atualizadoEm, p?.criadoEm]) { const t = Date.parse(v); if (Number.isFinite(t)) return t; }
  return NaN;
};
export const prazoValido = (v) => { const n = Math.floor(Number(v)); return n >= 1 && n <= 60 ? n : PRAZO_PADRAO_DIAS; };

// ---------- Cálculo ----------
/** Comissões "a acertar" dos pedidos entregues: [{t, valor}] (reembolso aprovado já reduz o valor). */
export function comissoesAAcertar(pedidos) {
  const out = [];
  for (const p of pedidos || []) {
    if (!p || normalizarStatus(p.status) !== STATUS.ENTREGUE) continue;
    const c = comissaoDoPedido(p);
    const t = dataDoPedido(p);
    if (c.modo === 'a_acertar' && c.valor > 0 && Number.isFinite(t)) out.push({ t, valor: c.valor });
  }
  return out;
}
export const totalPago = (acertos) => arred(Object.values(acertos || {}).reduce((s, a) => s + (Number(a?.valor) > 0 ? Number(a.valor) : 0), 0));

/**
 * Situação de uma loja. `acertos` = {id: {valor, em, ...}} (pagamentos confirmados pelo Master).
 * Devolve fechamentos (semanas), saldo vencido, a vencer, em aberto (semana corrente, ainda não fechada) e o estado geral.
 */
export function situacaoAcerto({ pedidos = [], acertos = {}, agora = new Date(), prazoDias = PRAZO_PADRAO_DIAS } = {}) {
  const prazo = prazoValido(prazoDias), agoraMs = new Date(agora).getTime();
  const porSemana = new Map();
  for (const c of comissoesAAcertar(pedidos)) {
    const ini = inicioDaSemana(c.t);
    porSemana.set(ini, arred((porSemana.get(ini) || 0) + c.valor));
  }
  const semanas = [...porSemana.entries()].sort((a, b) => a[0] - b[0]).map(([inicio, devido]) => ({ inicio, fecha: inicio + 7 * DIA, vence: inicio + 7 * DIA + prazo * DIA, devido, pago: 0, saldo: devido }));
  let pagoRestante = totalPago(acertos);
  const pago = pagoRestante;
  const fechadas = semanas.filter((s) => s.fecha <= agoraMs), aberta = semanas.filter((s) => s.fecha > agoraMs);
  for (const s of fechadas) { const abate = arred(Math.min(pagoRestante, s.devido)); s.pago = abate; s.saldo = arred(s.devido - abate); pagoRestante = arred(pagoRestante - abate); }
  const credito = pagoRestante;
  const emAbertoBruto = arred(aberta.reduce((t, s) => t + s.devido, 0));
  const emAberto = arred(Math.max(0, emAbertoBruto - credito));
  const vencidas = fechadas.filter((s) => s.saldo > 0 && s.vence <= agoraMs);
  const aVencer = fechadas.filter((s) => s.saldo > 0 && s.vence > agoraMs);
  const saldoVencido = arred(vencidas.reduce((t, s) => t + s.saldo, 0));
  const saldoAVencer = arred(aVencer.reduce((t, s) => t + s.saldo, 0));
  const proximo = [...vencidas, ...aVencer].sort((a, b) => a.vence - b.vence)[0] || null;
  const estado = saldoVencido > 0 ? 'vencido' : saldoAVencer > 0 ? 'a_vencer' : emAberto > 0 ? 'em_aberto' : 'em_dia';
  return {
    prazoDias: prazo, semanas: fechadas, estado,
    totalDevido: arred(fechadas.reduce((t, s) => t + s.devido, 0)), totalPago: pago, credito,
    saldoVencido, saldoAVencer, saldoFechado: arred(saldoVencido + saldoAVencer), emAberto,
    venceEm: proximo ? proximo.vence : null,
    diasParaVencer: proximo ? Math.ceil((proximo.vence - agoraMs) / DIA) : null,    // negativo = dias de atraso
    diasDeAtraso: vencidas.length ? Math.floor((agoraMs - vencidas[0].vence) / DIA) : 0
  };
}

/** Situação de todas as lojas para o Master, com as vencidas primeiro. */
export function situacaoPorLoja({ pedidos = [], acertos = {}, lojas = {}, agora = new Date(), prazoDias = PRAZO_PADRAO_DIAS } = {}) {
  const grupos = new Map();
  for (const p of Array.isArray(pedidos) ? pedidos : Object.values(pedidos || {})) { if (p?.lojaId) { if (!grupos.has(p.lojaId)) grupos.set(p.lojaId, []); grupos.get(p.lojaId).push(p); } }
  const ids = new Set([...grupos.keys(), ...Object.keys(acertos || {})]);
  const peso = { vencido: 0, a_vencer: 1, em_aberto: 2, em_dia: 3 };
  return [...ids].map((lojaId) => {
    const s = situacaoAcerto({ pedidos: grupos.get(lojaId) || [], acertos: acertos?.[lojaId] || {}, agora, prazoDias });
    return { lojaId, nome: lojas?.[lojaId]?.nombre || lojas?.[lojaId]?.nome || lojaId, ...s };
  }).filter((l) => l.totalDevido > 0 || l.totalPago > 0 || l.emAberto > 0).sort((a, b) => peso[a.estado] - peso[b.estado] || b.saldoFechado - a.saldoFechado || a.nome.localeCompare(b.nome, 'pt-BR'));
}
export const totaisAcerto = (linhas) => (linhas || []).reduce((t, l) => ({ vencido: arred(t.vencido + l.saldoVencido), aVencer: arred(t.aVencer + l.saldoAVencer), emAberto: arred(t.emAberto + l.emAberto), lojasVencidas: t.lojasVencidas + (l.estado === 'vencido' ? 1 : 0) }), { vencido: 0, aVencer: 0, emAberto: 0, lojasVencidas: 0 });

export const ROTULO_ESTADO = Object.freeze({ vencido: 'Vencido', a_vencer: 'A vencer', em_aberto: 'Semana em andamento', em_dia: 'Em dia' });
const reais = (v) => 'R$ ' + (Math.round(Number(v) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
/** V75.58 — frase no card "Comissão gerada" de Finanças com o saldo REAL (zera quando a loja paga). */
export function textoSaldoResumo(s, tem = true) {
  if (!tem) return '';
  const fechado = Math.round((Number(s?.saldoFechado) || 0) * 100) / 100, aberto = Math.round((Number(s?.emAberto) || 0) * 100) / 100;
  if (fechado <= 0 && aberto <= 0) return 'Saldo a pagar ao YaPOOD: R$ 0,00. Nada em aberto.';
  const partes = [`Saldo a pagar ao YaPOOD: ${reais(fechado)}`];
  if (aberto > 0) partes.push(`semana em andamento: ${reais(aberto)}`);
  return partes.join(' · ') + ' (veja “Comissão a pagar”).';
}

export const dataBRms = (ms) => new Date(ms - 3 * 3600000).toISOString().slice(0, 10).split('-').reverse().join('/');

/** Frase para a loja (painel) conforme a situação. Vazio quando não há nada a mostrar. */
export function avisoParaLoja(s) {
  if (!s) return '';
  if (s.estado === 'vencido') return `Você tem ${reais(s.saldoVencido)} de comissão vencida desde ${dataBRms(s.venceEm)}. Pague hoje para não ter a loja suspensa.`;
  if (s.estado === 'a_vencer') return `Você tem ${reais(s.saldoAVencer)} de comissão para pagar até ${dataBRms(s.venceEm)} (${s.diasParaVencer} ${s.diasParaVencer === 1 ? 'dia' : 'dias'}). Depois dessa data a loja pode ser suspensa.`;
  return '';
}
/** Mensagem de cobrança para o Master mandar pelo WhatsApp. */
export function mensagemCobranca({ nomeLoja, saldo, venceEm, vencido }) {
  const quando = venceEm ? dataBRms(venceEm) : '';
  return vencido
    ? `Olá! Aqui é do YaPOOD. A comissão de ${reais(saldo)} da loja ${nomeLoja} venceu em ${quando}. Pague hoje pelo painel (aba Finanças, "Comissão do YaPOOD") para a loja não ser suspensa. Qualquer dúvida, é só responder esta mensagem.`
    : `Olá! Aqui é do YaPOOD. A comissão de ${reais(saldo)} da loja ${nomeLoja} vence em ${quando}. Você paga pelo painel (aba Finanças, "Comissão do YaPOOD"). Qualquer dúvida, é só responder esta mensagem.`;
}

// ---------- Registros (Master e loja) ----------
const URL_HTTPS = /^https:\/\/[^\s]{4,480}$/;
export function montarAcerto({ valor, forma = 'pix', obs = '', avisoId = '' }, { uid, agora = new Date() }) {
  const v = arred(typeof valor === 'string' ? valor.replace(/\./g, '').replace(',', '.') : valor);
  if (!(v > 0) || v > 1000000) throw new Error('Informe o valor pago (maior que zero).');
  if (!FORMAS[forma]) throw new Error('Escolha a forma de pagamento.');
  const o = limpar(obs, 200);
  return { valor: v, forma, em: new Date(agora).toISOString(), por: String(uid || ''), ...(o ? { obs: o } : {}), ...(avisoId ? { avisoId: String(avisoId).slice(0, 64) } : {}) };
}
export function montarAviso({ valor, forma = 'pix', obs = '', comprovante = '' }, { agora = new Date() } = {}) {
  const v = arred(typeof valor === 'string' ? valor.replace(/\./g, '').replace(',', '.') : valor);
  if (!(v > 0) || v > 1000000) throw new Error('Informe o valor que você pagou.');
  if (!FORMAS[forma]) throw new Error('Escolha a forma de pagamento.');
  const o = limpar(obs, 200), c = String(comprovante || '').trim();
  if (c && !URL_HTTPS.test(c)) throw new Error('O comprovante não pôde ser anexado. Tente de novo.');
  return { valor: v, forma, em: new Date(agora).toISOString(), status: 'pendente', ...(o ? { obs: o } : {}), ...(c ? { comprovante: c } : {}) };
}

// ---------- Dados para pagamento (Master → loja) ----------
export function normalizarChavePix(tipo, valor) {
  const bruto = String(valor ?? '').trim();
  switch (tipo) {
    case 'cpf': { const d = somenteDigitos(bruto); if (!cpfValido(d)) throw new Error('CPF da chave Pix inválido.'); return d; }
    case 'cnpj': { const d = somenteDigitos(bruto); if (!cnpjValido(d)) throw new Error('CNPJ da chave Pix inválido.'); return d; }
    case 'telefone': { let d = somenteDigitos(bruto); if (d.length === 12 || d.length === 13) { if (!d.startsWith('55')) throw new Error('Telefone da chave Pix inválido.'); d = d.slice(2); } if (d.length !== 10 && d.length !== 11) throw new Error('Telefone da chave Pix inválido (com DDD).'); return '+55' + d; }
    case 'email': { const e = bruto.toLowerCase(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) || e.length > 77) throw new Error('E-mail da chave Pix inválido.'); return e; }
    case 'aleatoria': { const k = bruto.toLowerCase(); if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(k)) throw new Error('A chave aleatória deve ter o formato 123e4567-e89b-12d3-a456-426614174000.'); return k; }
    default: throw new Error('Escolha o tipo da chave Pix.');
  }
}
/** Valida o formulário do Master. Tudo é opcional, exceto o prazo; mas se informar a chave, o nome do recebedor e a cidade são obrigatórios (o QR Code precisa). */
export function montarConfigAcerto({ tipoChave = '', chavePix = '', beneficiario = '', cidade = '', dadosBancarios = '', linkPagamento = '', prazoDias = PRAZO_PADRAO_DIAS }) {
  const out = { prazoDias: prazoValido(prazoDias) };
  const chave = String(chavePix || '').trim();
  if (chave) {
    out.tipoChave = tipoChave; out.chavePix = normalizarChavePix(tipoChave, chave);
    out.beneficiario = limpar(semAcento(beneficiario), 25); out.cidade = limpar(semAcento(cidade), 15);
    if (out.beneficiario.length < 2) throw new Error('Informe o nome de quem recebe o Pix (até 25 letras).');
    if (out.cidade.length < 2) throw new Error('Informe a cidade de quem recebe o Pix.');
  }
  const banc = limpar(dadosBancarios, 300); if (banc) out.dadosBancarios = banc;
  const link = String(linkPagamento || '').trim(); if (link) { if (!URL_HTTPS.test(link) || link.length > 300) throw new Error('O link de pagamento deve começar com https://.'); out.linkPagamento = link; }
  if (!out.chavePix && !out.dadosBancarios && !out.linkPagamento) throw new Error('Informe ao menos uma forma de pagamento (chave Pix, dados bancários ou link).');
  return out;
}
export const formasDisponiveis = (cfg) => ({ pix: !!(cfg?.chavePix && cfg?.beneficiario && cfg?.cidade), transferencia: !!cfg?.dadosBancarios, link: !!cfg?.linkPagamento });

// ---------- Pix copia e cola (BR Code estático, com valor) ----------
const semAcento = (v) => String(v ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\x20-\x7E]/g, '');
const campo = (id, valor) => id + String(valor.length).padStart(2, '0') + valor;
export function crc16(texto) {                       // CRC-16/CCITT-FALSE
  let crc = 0xFFFF;
  for (let i = 0; i < texto.length; i++) { crc ^= texto.charCodeAt(i) << 8; for (let b = 0; b < 8; b++) crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF; }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}
export function payloadPix({ chave, valor, beneficiario, cidade, txid = '***' }) {
  const k = String(chave || '').trim();
  if (!k || k.length > 77) throw new Error('Chave Pix inválida.');
  const v = arred(valor);
  const conta = campo('00', 'br.gov.bcb.pix') + campo('01', k);
  const base = campo('00', '01') + campo('01', '11') + campo('26', conta) + campo('52', '0000') + campo('53', '986')
    + (v > 0 ? campo('54', v.toFixed(2)) : '') + campo('58', 'BR')
    + campo('59', (semAcento(beneficiario).trim() || 'RECEBEDOR').slice(0, 25)) + campo('60', (semAcento(cidade).trim() || 'BRASIL').slice(0, 15))
    + campo('62', campo('05', String(txid).replace(/[^A-Za-z0-9]/g, '').slice(0, 25) || '***')) + '6304';
  return base + crc16(base);
}
