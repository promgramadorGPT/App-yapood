// js/master-acertos.js — V75.50: aba "Acertos" do Master (comissão "a acertar" das lojas). Regras puras em acerto-comissao.js.
import { situacaoPorLoja, totaisAcerto, ROTULO_ESTADO, dataBRms, mensagemCobranca, montarAcerto, montarConfigAcerto, FORMAS, PRAZO_PADRAO_DIAS } from './acerto-comissao.js';
import { normalizarWhatsApp } from './anuncie.js';

/**
 * ctx: { S, $, esc, aviso, executar, confirmar, logar, fmtData, vazio, selo, db, ref, set, update, push, suspender }
 * Devolve { render, pendentes }.
 */
export function iniciarAcertosMaster(ctx) {
  const { S, $, esc, aviso, executar, confirmar, logar, fmtData, vazio, selo, db, ref, set, update, push, suspender } = ctx;
  const reais = (v) => 'R$ ' + (Math.round(Number(v) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  const prazo = () => S.cfgAcerto?.prazoDias || PRAZO_PADRAO_DIAS;
  const linhas = () => situacaoPorLoja({ pedidos: S.pedidos, acertos: S.acertos || {}, lojas: S.lojas, prazoDias: prazo() });
  const nomeLoja = (id) => S.lojas?.[id]?.nombre || S.lojas?.[id]?.nome || id;
  const listaAvisos = () => Object.entries(S.avisosAcerto || {}).flatMap(([lojaId, m]) => Object.entries(m || {}).map(([id, a]) => ({ ...a, id, lojaId })));
  const avisosPendentes = () => listaAvisos().filter((a) => a.status === 'pendente').sort((a, b) => String(a.em).localeCompare(String(b.em)));
  const SELO = { vencido: 'erro', a_vencer: 'aviso', em_aberto: 'info', em_dia: 'ok' };

  const pendentes = () => avisosPendentes().length + linhas().filter((l) => l.estado === 'vencido').length;

  function render() {
    if (!$('ac-kpis')) return;
    const ls = linhas(), t = totaisAcerto(ls), pend = avisosPendentes();
    const kpi = (r, v, sub, ic, cor = '') => `<article class="m-kpi ${cor}"><i class="fa-solid ${ic}" aria-hidden="true"></i><span>${esc(r)}</span><strong>${esc(v)}</strong><small>${esc(sub)}</small></article>`;
    $('ac-kpis').innerHTML = kpi('Vencido', reais(t.vencido), `${t.lojasVencidas} loja(s)`, 'fa-triangle-exclamation', t.vencido > 0 ? 'm-kpi-erro' : '') + kpi('A vencer', reais(t.aVencer), `prazo de ${prazo()} dias após o fechamento`, 'fa-hourglass-half') + kpi('Semana em andamento', reais(t.emAberto), 'fecha na próxima segunda', 'fa-calendar-week') + kpi('Avisos de pagamento', String(pend.length), pend.length ? 'esperando você conferir' : 'nenhum pendente', 'fa-bell');
    $('ac-nota').textContent = `Calculado com os ${S.pedidos.length.toLocaleString('pt-BR')} pedidos carregados (aba Pedidos → “Pedidos carregados do banco”). Se a loja tiver pedidos mais antigos que isso, aumente o limite para o saldo ficar completo.`;
    renderAvisos(pend);
    renderLojas(ls);
    renderConfig();
    renderSelectLojas(ls);
  }

  function renderAvisos(pend) {
    $('ac-avisos').innerHTML = pend.length
      ? `<table class="m-tabela"><thead><tr><th>Loja</th><th>Valor</th><th>Forma</th><th>Enviado</th><th>Detalhes</th><th></th></tr></thead><tbody>${pend.map((a) => `<tr><td>${esc(nomeLoja(a.lojaId))}</td><td><b>${reais(a.valor)}</b></td><td>${esc(FORMAS[a.forma] || a.forma)}</td><td>${esc(fmtData(a.em, true))}</td><td>${a.obs ? esc(a.obs) : ''}${a.comprovante ? ` <a href="${esc(a.comprovante)}" target="_blank" rel="noopener noreferrer">ver comprovante</a>` : ''}</td><td><div class="m-acoes"><button type="button" class="m-btn m-btn-principal" data-ac="aviso-ok" data-loja="${esc(a.lojaId)}" data-id="${esc(a.id)}">Confirmar</button><button type="button" class="m-btn m-btn-perigo" data-ac="aviso-nao" data-loja="${esc(a.lojaId)}" data-id="${esc(a.id)}">Não recebi</button></div></td></tr>`).join('')}</tbody></table>`
      : vazio('fa-circle-check', 'Nenhum aviso de pagamento esperando.');
  }

  function renderLojas(ls) {
    $('ac-lista').innerHTML = ls.length
      ? `<table class="m-tabela"><thead><tr><th>Loja</th><th>Situação</th><th>Vencido</th><th>A vencer</th><th>Em andamento</th><th>Vence em</th><th></th></tr></thead><tbody>${ls.map((l) => {
        const sus = !!S.suspensas?.[l.lojaId];
        const zap = normalizarWhatsApp(S.lojas?.[l.lojaId]?.telefono || S.lojas?.[l.lojaId]?.telefone || S.lojas?.[l.lojaId]?.whatsapp || '');
        const cobrar = l.saldoFechado > 0 && zap ? `<a class="m-btn m-btn-leve" target="_blank" rel="noopener noreferrer" href="https://wa.me/${zap}?text=${encodeURIComponent(mensagemCobranca({ nomeLoja: l.nome, saldo: l.saldoFechado, venceEm: l.venceEm, vencido: l.estado === 'vencido' }))}"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> Cobrar</a>` : '';
        return `<tr><td>${esc(l.nome)}${sus ? ' ' + selo('erro', 'Suspensa') : ''}</td><td>${selo(SELO[l.estado], ROTULO_ESTADO[l.estado])}${l.diasDeAtraso > 0 ? `<small class="m-nota"> ${l.diasDeAtraso} dia(s) de atraso</small>` : ''}</td><td>${l.saldoVencido > 0 ? `<b class="m-neg">${reais(l.saldoVencido)}</b>` : '—'}</td><td>${l.saldoAVencer > 0 ? reais(l.saldoAVencer) : '—'}</td><td>${l.emAberto > 0 ? reais(l.emAberto) : '—'}</td><td>${l.saldoFechado > 0 && l.venceEm ? esc(dataBRms(l.venceEm)) : '—'}</td><td><div class="m-acoes"><button type="button" class="m-btn m-btn-leve" data-ac="registrar" data-loja="${esc(l.lojaId)}" data-valor="${l.saldoFechado}">Registrar</button>${cobrar}${l.estado === 'vencido' && !sus ? ` <button type="button" class="m-btn m-btn-perigo" data-ac="suspender" data-loja="${esc(l.lojaId)}"><i class="fa-solid fa-ban" aria-hidden="true"></i> Suspender</button>` : ''}</div></td></tr>`;
      }).join('')}</tbody></table>`
      : vazio('fa-circle-check', S.pedidosOk ? 'Nenhuma loja com comissão a acertar.' : 'Carregando…');
  }

  function renderSelectLojas(ls) {
    const sel = $('ac-loja'); if (!sel) return;
    const atual = sel.value;
    const ids = new Set([...ls.map((l) => l.lojaId), ...Object.keys(S.lojas || {})]);
    const opcoes = [...ids].sort((a, b) => nomeLoja(a).localeCompare(nomeLoja(b), 'pt-BR'));
    const html = '<option value="">Escolha a loja</option>' + opcoes.map((id) => `<option value="${esc(id)}">${esc(nomeLoja(id))}</option>`).join('');
    if (sel.dataset.assinatura !== html) { sel.innerHTML = html; sel.dataset.assinatura = html; sel.value = atual; }
  }

  function renderConfig() {
    const c = S.cfgAcerto || {}, ativo = document.activeElement;
    const campos = { 'ac-cfg-tipo': c.tipoChave || 'cnpj', 'ac-cfg-chave': c.chavePix || '', 'ac-cfg-benef': c.beneficiario || '', 'ac-cfg-cidade': c.cidade || '', 'ac-cfg-banco': c.dadosBancarios || '', 'ac-cfg-link': c.linkPagamento || '', 'ac-cfg-prazo': String(c.prazoDias || PRAZO_PADRAO_DIAS) };
    if ($('ac-cfg-form').contains(ativo) || $('ac-cfg-form').dataset.sujo) return;       // não apaga o que está sendo digitado
    for (const [id, v] of Object.entries(campos)) $(id).value = v;
    $('ac-cfg-estado').textContent = c.chavePix || c.dadosBancarios || c.linkPagamento ? 'As lojas já veem estes dados na aba Finanças.' : 'Ainda não configurado: as lojas veem “o YaPOOD ainda não cadastrou os dados de pagamento”.';
  }

  async function confirmarAviso(lojaId, id) {
    const a = S.avisosAcerto?.[lojaId]?.[id]; if (!a) return;
    const c = await confirmar({ titulo: 'Confirmar o pagamento?', texto: `${nomeLoja(lojaId)} avisou que pagou ${reais(a.valor)} (${FORMAS[a.forma] || a.forma}). Confira que o dinheiro caiu na sua conta antes de confirmar.`, rotulo: 'Confirmar pagamento' });
    if (!c.ok) return;
    const ok = await executar(async () => {
      const novo = push(ref(db, `acertos_comissao/${lojaId}`));
      await set(novo, montarAcerto({ valor: a.valor, forma: a.forma, obs: a.obs || '', avisoId: id }, { uid: S.user.uid }));
      await update(ref(db, `acerto_avisos/${lojaId}/${id}`), { status: 'confirmado', resolvidoEm: new Date().toISOString() });
    }, 'Pagamento confirmado.');
    if (ok) await logar('acerto.confirmar', nomeLoja(lojaId), reais(a.valor));
  }
  async function recusarAviso(lojaId, id) {
    const a = S.avisosAcerto?.[lojaId]?.[id]; if (!a) return;
    const c = await confirmar({ titulo: 'Não recebi este pagamento', texto: `O aviso de ${reais(a.valor)} de ${nomeLoja(lojaId)} fica como “não confirmado” e o saldo não muda. A loja vê isso no painel.`, motivo: true, rotulo: 'Marcar como não recebido', perigo: true });
    if (!c.ok) return;
    const ok = await executar(() => update(ref(db, `acerto_avisos/${lojaId}/${id}`), { status: 'recusado', resolvidoEm: new Date().toISOString(), ...(c.motivo ? { motivo: String(c.motivo).slice(0, 200) } : {}) }), 'Aviso marcado como não recebido.');
    if (ok) await logar('acerto.recusar', nomeLoja(lojaId), c.motivo || reais(a.valor));
  }

  function mensagemForm(t, erro) { const m = $('ac-msg'); m.textContent = t; m.classList.toggle('m-nota-erro', !!erro); }
  async function registrarPagamento(e) {
    e.preventDefault();
    const lojaId = $('ac-loja').value;
    if (!lojaId) return mensagemForm('Escolha a loja.', true);
    let reg;
    try { reg = montarAcerto({ valor: $('ac-valor').value, forma: $('ac-forma').value, obs: $('ac-obs').value }, { uid: S.user.uid }); } catch (err) { return mensagemForm(err.message, true); }
    const c = await confirmar({ titulo: 'Registrar pagamento?', texto: `${nomeLoja(lojaId)} pagou ${reais(reg.valor)} (${FORMAS[reg.forma]}). O saldo da loja diminui na hora e o registro não pode ser editado depois.`, rotulo: 'Registrar' });
    if (!c.ok) return;
    const ok = await executar(() => set(push(ref(db, `acertos_comissao/${lojaId}`)), reg), 'Pagamento registrado.');
    if (ok) { await logar('acerto.registrar', nomeLoja(lojaId), `${reais(reg.valor)} · ${FORMAS[reg.forma]}`); $('ac-form').reset(); mensagemForm(''); }
  }
  async function salvarConfig(e) {
    e.preventDefault();
    let cfg;
    try { cfg = montarConfigAcerto({ tipoChave: $('ac-cfg-tipo').value, chavePix: $('ac-cfg-chave').value, beneficiario: $('ac-cfg-benef').value, cidade: $('ac-cfg-cidade').value, dadosBancarios: $('ac-cfg-banco').value, linkPagamento: $('ac-cfg-link').value, prazoDias: $('ac-cfg-prazo').value }); } catch (err) { $('ac-cfg-estado').textContent = err.message; $('ac-cfg-estado').classList.add('m-nota-erro'); return; }
    $('ac-cfg-estado').classList.remove('m-nota-erro');
    const c = await confirmar({ titulo: 'Salvar os dados de pagamento?', texto: `As lojas passam a ver estes dados para pagar a comissão. Prazo: ${cfg.prazoDias} dias depois do fechamento semanal. Confira a chave Pix: pagamentos feitos nela caem na sua conta.`, rotulo: 'Salvar' });
    if (!c.ok) return;
    const ok = await executar(() => set(ref(db, 'config_plataforma/acerto'), { ...cfg, atualizadoEm: new Date().toISOString(), atualizadoPor: S.user?.uid || '' }), 'Dados de pagamento salvos.');
    if (ok) { delete $('ac-cfg-form').dataset.sujo; await logar('acerto.config', 'dados de pagamento', `prazo ${cfg.prazoDias} dias`); }
  }

  // eventos
  const raiz = $('ac-raiz');
  if (raiz) {
    raiz.addEventListener('click', (e) => {
      const b = e.target.closest('[data-ac]'); if (!b) return;
      const { ac, loja, id, valor } = b.dataset;
      if (ac === 'aviso-ok') return void confirmarAviso(loja, id);
      if (ac === 'aviso-nao') return void recusarAviso(loja, id);
      if (ac === 'suspender') return void suspender(loja);
      if (ac === 'registrar') { $('ac-loja').value = loja; $('ac-valor').value = Number(valor) > 0 ? String(valor).replace('.', ',') : ''; $('ac-form').scrollIntoView({ behavior: 'smooth', block: 'center' }); $('ac-valor').focus(); }
    });
    $('ac-form').addEventListener('submit', registrarPagamento);
    $('ac-cfg-form').addEventListener('submit', salvarConfig);
    $('ac-cfg-form').addEventListener('input', () => { $('ac-cfg-form').dataset.sujo = '1'; });
  }
  return { render, pendentes };
}
