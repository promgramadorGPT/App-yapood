// js/master-cidades.js — V75.72: aba "Cidades" do Master (lojas fundadoras: meta de vagas, liberação e 0% de comissão por prazo).
// As regras puras estão em cidades.js (testadas). A liberação é feita pela API (cidades-api.js), nunca direto no banco.
import { PECAS, TELAS_CARROSSEL, desenharPeca, miniatura, paraBlob, nomeDoArquivo } from './kit-cidade.js';
import { textosDivulgacao, textosCarrossel, linksDaCidade } from './kit-textos.js';
import { UFS, validarCidade, listarCidades, resumoCidade, lojasSemCidade, acharCidadeDoTexto, rotuloCidade, resumirInteressados, validarTestador, chaveEmailTestador } from './cidades.js';

/**
 * ctx: { S, $, esc, aviso, executar, confirmar, logar, vazio, selo, db, ref, set, update, remove, liberarCidade }
 * S.cidades e S.lojas/S.suspensas vêm do master.js. Devolve { render }.
 */
export function iniciarCidadesMaster(ctx) {
  const { S, $, esc, aviso, executar, confirmar, logar, vazio, selo, db, ref, set, update, remove, liberarCidade } = ctx;
  let sujo = false;          // alguém está digitando na lista: não redesenha por cima
  let liberando = null;      // id da cidade em liberação (evita clique duplo)

  const dataBR = (ms) => (Number.isFinite(Number(ms)) ? new Date(Number(ms)).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '—');
  const dataIsoBR = (iso) => { const t = Date.parse(iso); return Number.isFinite(t) ? dataBR(t) : '—'; };
  const agoraIso = () => new Date().toISOString();

  // O seletor de estado é montado aqui para a lista de UFs existir num lugar só.
  const selUf = $('cid-uf');
  if (selUf && selUf.options.length <= 1) selUf.insertAdjacentHTML('beforeend', UFS.map((u) => `<option value="${u}">${u}</option>`).join(''));

  // ----- kit de divulgação (imagens e textos por cidade) -----
  const kitCache = new Map();      // chave (cidade + números + cor) -> html das miniaturas
  const kitAbertos = new Set();    // cidades com o bloco aberto
  const preparando = new Set();    // chaves em desenho (evita desenhar duas vezes)
  const dadosKit = (c, r) => ({ cidade: { nome: c.nome, uf: c.uf, isencaoMeses: c.isencaoMeses, meta: r.meta }, vagas: r.vagas, links: linksDaCidade(location.origin, c.id), tema: { primaria: S.tema?.primaria, sobre: S.tema?.sobre } });
  const chaveKit = (c, r) => [c.id, r.vagas, r.meta, c.isencaoMeses, S.tema?.primaria || '', S.tema?.sobre || '', location.origin].join('|');
  const rotuloPublico = { lojista: 'Para lojistas (cadastrar a loja)', cliente: 'Para clientes (pedir aviso)' };

  function kitCorpo(c, r, thumbs) {
    const dk = dadosKit(c, r), tx = textosDivulgacao(dk), car = textosCarrossel(dk);
    const cid = esc(c.id);
    const botao = (attr, v, icone, rot) => `<button type="button" class="m-btn m-btn-leve m-btn-mini" data-kit-${attr}="${v}" data-cid="${cid}"><i class="${icone}" aria-hidden="true"></i> ${rot}</button>`;
    const imagem = (p) => (thumbs?.[p.id] ? `<img src="${thumbs[p.id]}" alt="${esc(p.rotulo)}" loading="lazy">` : '<div class="kit-esp">Preparando…</div>');
    const copiar = (chave, rot, texto, linhas) => `<label class="kit-texto">${rot}<textarea readonly rows="${linhas}" data-kit-texto="${chave}-${cid}">${esc(texto)}</textarea></label>${botao('copiar', chave, 'fa-regular fa-copy', 'Copiar texto')}`;
    const grupo = (pub) => `<div class="kit-grupo"><h3>${rotuloPublico[pub]}</h3>
      <div class="kit-pecas">${PECAS.filter((p) => p.publico === pub && p.grupo === 'chamada').map((p) => `<figure class="kit-peca">${imagem(p)}<figcaption><b>${esc(p.rotulo)}</b><small>${esc(p.formato)}</small>
        <span class="kit-botoes">${botao('baixar', p.id, 'fa-solid fa-download', 'Baixar')}${botao('enviar', p.id, 'fa-solid fa-share-nodes', 'Enviar')}</span></figcaption></figure>`).join('')}</div>
      ${copiar(pub, 'Texto para WhatsApp / legenda', tx[pub].whatsapp, 6)}
      <h4 class="kit-sub">Carrossel “Como funciona” (${TELAS_CARROSSEL} telas, 1080 × 1350)</h4>
      <div class="kit-carrossel">${PECAS.filter((p) => p.publico === pub && p.grupo === 'carrossel').map((p) => `<figure class="kit-tela">${imagem(p)}<figcaption>${p.tela}</figcaption></figure>`).join('')}</div>
      <span class="kit-botoes">${botao('serie-baixar', pub, 'fa-solid fa-download', 'Baixar as ' + TELAS_CARROSSEL)}${botao('serie-enviar', pub, 'fa-solid fa-share-nodes', 'Enviar as ' + TELAS_CARROSSEL)}</span>
      <p class="m-nota">Publique as ${TELAS_CARROSSEL} imagens juntas, na ordem, como um post de carrossel (no Instagram: “selecionar vários”).</p>
      ${copiar(pub + '-leg', 'Legenda do carrossel', car[pub].legenda, 9)}</div>`;
    return `<p class="m-nota">As imagens usam a cor do app, o contador atual (<b>${r.vagas} de ${r.meta}</b>) e um QR Code que já abre ${esc(rotuloCidade(c))}. Se o número mudar, baixe de novo.</p>${grupo('lojista')}${grupo('cliente')}`;
  }
  async function prepararKit(id) {
    const c = S.cidades?.[id]; if (!c) return;
    const cc = { ...c, id }, r = resumoCidade(cc, S.lojas, S.suspensas), chave = chaveKit(cc, r);
    if (kitCache.has(chave) || preparando.has(chave)) return;
    preparando.add(chave);
    try {
      const thumbs = {};
      for (const p of PECAS) thumbs[p.id] = miniatura(await desenharPeca(p, dadosKit(cc, r)), p.grupo === 'carrossel' ? 200 : 240);
      kitCache.set(chave, kitCorpo(cc, r, thumbs));
    } catch (e) { console.error(e); kitCache.set(chave, `<p class="m-nota m-nota-erro">Não foi possível montar as imagens: ${esc(e.message || 'erro')}.</p>`); }
    preparando.delete(chave);
    const alvo = document.querySelector(`[data-kit="${CSS.escape(id)}"] .cid-kit-corpo`);
    if (alvo && kitAbertos.has(id)) alvo.innerHTML = kitCache.get(chave);
  }
  const kitBloco = (c, r) => `<details class="cid-kit" data-kit="${esc(c.id)}"${kitAbertos.has(c.id) ? ' open' : ''}><summary class="m-btn m-btn-leve"><i class="fa-solid fa-bullhorn" aria-hidden="true"></i> Divulgação</summary><div class="cid-kit-corpo">${kitAbertos.has(c.id) ? (kitCache.get(chaveKit(c, r)) || '<p class="m-nota">Preparando as imagens…</p>') : ''}</div></details>`;
  async function arquivoDaPeca(pecaId, cidadeId) {
    const c = S.cidades?.[cidadeId], peca = PECAS.find((p) => p.id === pecaId);
    if (!c || !peca) throw new Error('Cidade ou peça não encontrada.');
    const cc = { ...c, id: cidadeId };
    const blob = await paraBlob(await desenharPeca(peca, dadosKit(cc, resumoCidade(cc, S.lojas, S.suspensas))));
    return new File([blob], nomeDoArquivo(peca, cidadeId), { type: 'image/png' });
  }

  function cartao(c) {
    const r = resumoCidade(c, S.lojas, S.suspensas);
    const aberta = c.status === 'aberta';
    const meses = Number(c.isencaoMeses) || 6;
    const nomes = r.lojas.slice(0, 8).map((l) => `<span class="cid-loja${l.ativa ? '' : ' cid-loja-off'}">${esc(l.nome)}</span>`).join('');
    const mais = r.lojas.length > 8 ? `<span class="cid-loja cid-loja-mais">+${r.lojas.length - 8}</span>` : '';
    const todasDela = Object.values(S.lojas || {}).filter((l) => l && l.cidadeId === c.id).length; // inclui suspensas: só apaga a cidade vazia de verdade
    const regra = aberta
      ? `Liberada em ${dataIsoBR(c.abertaEm)}. As lojas que estavam aqui nesse dia ficam sem comissão até <b>${dataBR(c.isencaoAte)}</b>; as que entram depois pagam a comissão normal.`
      : `Quando você liberar, as lojas que estiverem aqui nesse dia ficam <b>${meses} ${meses === 1 ? 'mês' : 'meses'} sem comissão</b>. Quem entrar depois paga a comissão normal.`;
    return `<article class="m-card cid-card" data-cidade="${esc(c.id)}">
      <div class="m-card-topo"><div><h2>${esc(rotuloCidade(c))}</h2><p class="m-sub">${regra}</p></div>${aberta ? selo('ok', 'Aberta') : selo('aviso', 'Em espera')}</div>
      <div class="cid-barra" role="progressbar" aria-valuemin="0" aria-valuemax="${r.meta}" aria-valuenow="${Math.min(r.vagas, r.meta)}" aria-label="Lojas cadastradas"><i style="width:${r.pct}%"></i></div>
      <p class="cid-contagem"><b>${r.vagas}</b> de ${r.meta} lojas${r.metaBatida ? ' · <span class="cid-ok">meta batida</span>' : ` · faltam ${r.faltam}`}</p>
      ${nomes ? `<div class="cid-lojas">${nomes}${mais}</div>` : '<p class="m-nota">Nenhuma loja nesta cidade ainda.</p>'}
      <div class="m-acoes cid-acoes">
        ${aberta ? '' : `<button type="button" class="m-btn m-btn-principal" data-cid-liberar="${esc(c.id)}"${liberando === c.id ? ' disabled' : ''}><i class="fa-solid fa-lock-open" aria-hidden="true"></i> ${liberando === c.id ? 'Liberando…' : 'Liberar cidade'}</button>`}
        <details class="cid-editar"><summary class="m-btn m-btn-leve">Ajustar</summary>
          <div class="m-form-linha">
            <label>Meta de lojas<input type="number" min="1" max="1000" step="1" value="${r.meta}" data-cid-meta></label>
            ${aberta ? '' : `<label>Meses sem comissão<input type="number" min="1" max="24" step="1" value="${meses}" data-cid-meses></label>`}
            <button type="button" class="m-btn m-btn-principal m-btn-mini" data-cid-salvar="${esc(c.id)}">Salvar</button>
          </div>
          ${aberta ? '<p class="m-nota">Os meses sem comissão não mudam depois de liberada: o prazo das lojas já foi definido.</p>' : ''}
        </details>
        ${todasDela === 0 ? `<button type="button" class="m-btn m-btn-perigo m-btn-mini" data-cid-remover="${esc(c.id)}"><i class="fa-solid fa-trash" aria-hidden="true"></i> Excluir</button>` : ''}
      </div>
      ${kitBloco(c, r)}
    </article>`;
  }

  function cartaoSemCidade(itens, cidades) {
    const opcoes = cidades.map((c) => `<option value="${esc(c.id)}">${esc(rotuloCidade(c))}</option>`).join('');
    return `<article class="m-card cid-card" id="cid-sem-cidade">
      <div class="m-card-topo"><div><h2>Lojas sem cidade</h2><p class="m-sub">Lojas antigas que ainda não escolheram a cidade. Escolha por elas (ou peça para o lojista escolher em “Dados da loja”). Sem cidade a loja continua vendendo, mas não entra na contagem nem na isenção.</p></div>${selo('aviso', String(itens.length))}</div>
      <div class="m-lista">${itens.map((l) => {
        const sug = acharCidadeDoTexto(l.texto, cidades);
        return `<div class="cid-linha" data-cid-loja="${esc(l.id)}"><span><b>${esc(l.nome)}</b>${l.texto ? `<small>informou: ${esc(l.texto)}</small>` : ''}</span>
          <select data-cid-escolha aria-label="Cidade de ${esc(l.nome)}"><option value="">Escolha…</option>${opcoes.replace(`value="${esc(sug)}"`, `value="${esc(sug)}" selected`)}</select>
          <button type="button" class="m-btn m-btn-leve m-btn-mini" data-cid-atribuir="${esc(l.id)}">Atribuir</button></div>`;
      }).join('')}</div>
    </article>`;
  }

  // ----- lista de interessados (clientes que pediram aviso) -----
  function cartaoInteressados(grupos) {
    const linhas = grupos.map((g) => {
      const tag = g.cadastrada ? (g.status === 'aberta' ? selo('ok', 'Aberta') : selo('aviso', 'Em espera')) : selo('info', 'Não cadastrada');
      const acao = g.cadastrada ? '' : `<button type="button" class="m-btn m-btn-leve m-btn-mini" data-int-criar="${esc(g.cidadeKey)}"><i class="fa-solid fa-plus" aria-hidden="true"></i> Criar cidade</button>`;
      return `<div class="cid-linha cid-int" data-int="${esc(g.cidadeKey)}"><span><b>${esc(g.nome)}${g.uf ? ` - ${esc(g.uf)}` : ''}</b><small>${g.total} ${g.total === 1 ? 'pessoa quer ser avisada' : 'pessoas querem ser avisadas'}${g.ultima ? ` · último pedido em ${dataIsoBR(g.ultima)}` : ''}</small></span>${tag}
        <span class="cid-int-acoes">${acao}<button type="button" class="m-btn m-btn-leve m-btn-mini" data-int-copiar="${esc(g.cidadeKey)}"><i class="fa-regular fa-copy" aria-hidden="true"></i> Copiar WhatsApps</button><button type="button" class="m-btn m-btn-perigo m-btn-mini" data-int-limpar="${esc(g.cidadeKey)}" aria-label="Limpar a lista de ${esc(g.nome)}"><i class="fa-solid fa-trash" aria-hidden="true"></i></button></span></div>`;
    }).join('');
    return `<article class="m-card cid-card" id="cid-interessados">
      <div class="m-card-topo"><div><h2>Lista de interessados</h2><p class="m-sub">Clientes que tocaram em “Avise-me quando abrir”. Quando abrir a cidade, copie os números e avise no WhatsApp; depois limpe a lista daquela cidade.</p></div>${selo('info', String(grupos.reduce((t, g) => t + g.total, 0)))}</div>
      <div class="m-lista">${linhas}</div></article>`;
  }
  function renderInteressados() {
    const el = $('cidades-interessados'); if (!el) return;
    const grupos = resumirInteressados(S.listaEspera, S.cidades);
    el.innerHTML = grupos.length ? cartaoInteressados(grupos) : '';
  }

  // ----- modo demonstração: qualquer pessoa vê o app aberto por um tempo; não libera a cidade, não concede isenção, não permite pedidos -----
  let relogio = null;
  const demoAtiva = () => S.demo?.ativo === true && Number(S.demo.ate) > Date.now();
  const hora = (ms) => new Date(ms).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' });
  function renderDemo() {
    const el = $('cidades-demo'); if (!el) return;
    clearTimeout(relogio);
    const on = demoAtiva();
    if (on) relogio = setTimeout(renderDemo, Math.min(Number(S.demo.ate) - Date.now() + 500, 60000));
    el.innerHTML = `<div class="m-card-topo"><div><h2>Modo demonstração</h2><p class="m-sub">Mostra o app aberto para <b>qualquer pessoa</b> (sócios, convidados), mesmo com a cidade em espera. Não libera a cidade, não dá isenção de comissão e os <b>pedidos continuam bloqueados</b>. Desliga sozinho no horário e dá para desligar antes.</p></div>${on ? selo('ok', `Ligado até ${hora(Number(S.demo.ate))}`) : selo('off', 'Desligado')}</div>
      <div class="m-acoes cid-acoes">${on
        ? '<button type="button" class="m-btn m-btn-perigo" data-demo-desligar><i class="fa-solid fa-power-off" aria-hidden="true"></i> Desligar agora</button>'
        : [1, 2, 4].map((h) => `<button type="button" class="m-btn ${h === 2 ? 'm-btn-principal' : 'm-btn-leve'}" data-demo-ligar="${h}"><i class="fa-solid fa-eye" aria-hidden="true"></i> Ligar por ${h} ${h === 1 ? 'hora' : 'horas'}</button>`).join('')}</div>`;
  }
  $('cidades-demo')?.addEventListener('click', async (ev) => {
    const lig = ev.target.closest('[data-demo-ligar]'), des = ev.target.closest('[data-demo-desligar]');
    if (lig) {
      const h = Number(lig.dataset.demoLigar), ate = Date.now() + h * 3600000;
      const dados = { ativo: true, ate, por: S.user?.uid || '', em: agoraIso() };
      if (await executar(() => set(ref(db, 'config_plataforma/demo_cidades'), dados), `Demonstração ligada até ${hora(ate)}.`)) {
        await logar('cidade.demo', 'Ligado', `por ${h} hora(s), até ${hora(ate)}`);
        S.demo = dados; renderDemo();
      }
    } else if (des) {
      const dados = { ativo: false, em: agoraIso(), por: S.user?.uid || '' };
      if (await executar(() => set(ref(db, 'config_plataforma/demo_cidades'), dados), 'Demonstração desligada. O app voltou ao normal.')) {
        await logar('cidade.demo', 'Desligado');
        S.demo = dados; renderDemo();
      }
    }
  });

  // ----- testadores por e-mail: veem o app aberto e conseguem pedir/pagar mesmo com a cidade em espera -----
  const dataHora = (iso) => { const t = Date.parse(iso); return Number.isFinite(t) ? new Date(t).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : ''; };
  function renderTestadores() {
    const el = $('cidades-testadores'); if (!el) return;
    if (el.contains(document.activeElement) && document.activeElement.id === 'tst-email') return; // não apaga o que está sendo digitado
    const lista = Object.entries(S.testadores || {}).filter(([, v]) => v && v.email).sort((a, b) => String(a[1].email).localeCompare(String(b[1].email)));
    el.innerHTML = `<div class="m-card-topo"><div><h2>Testadores</h2><p class="m-sub">Pessoas de confiança que podem <b>ver o app aberto e fazer pedidos de verdade</b> (Pix, cartão e dinheiro) mesmo com a cidade em espera, para testar o Mercado Pago. Digite o <b>e-mail da conta Google</b> que a pessoa usa no app: ela não precisa de mais nada, só entrar. Para valer o teste, peça de uma loja que não seja dela. Remova quando acabar.</p></div>${selo(lista.length ? 'ok' : 'off', String(lista.length))}</div>
      <form id="form-testador" class="m-form-linha" novalidate><label class="m-grow">E-mail do testador<input id="tst-email" type="email" inputmode="email" autocomplete="off" maxlength="160" placeholder="amigo@gmail.com"></label><button type="submit" class="m-btn m-btn-principal">Adicionar</button></form>
      <p id="tst-erro" class="m-nota m-nota-erro" role="alert" hidden></p>
      ${lista.length ? `<div class="m-lista">${lista.map(([k, v]) => `<div class="cid-linha cid-tst" data-tst="${esc(k)}"><span><b>${esc(v.email)}</b>${v.em ? `<small>adicionado em ${dataHora(v.em)}</small>` : ''}</span><button type="button" class="m-btn m-btn-perigo m-btn-mini" data-tst-remover="${esc(k)}"><i class="fa-solid fa-trash" aria-hidden="true"></i> Remover</button></div>`).join('')}</div>` : '<p class="m-nota">Nenhum testador por e-mail.</p>'}`;
  }
  $('cidades-testadores')?.addEventListener('submit', async (ev) => {
    if (ev.target.id !== 'form-testador') return;
    ev.preventDefault();
    const erro = $('tst-erro');
    const v = validarTestador($('tst-email').value, S.testadores, { por: S.user?.uid || '' });
    if (!v.ok) { erro.hidden = false; erro.textContent = v.erro; return; }
    erro.hidden = true;
    if (await executar(() => set(ref(db, `testadores_email/${v.chave}`), v.dados), `${v.dados.email} agora é testador.`)) {
      await logar('testador.add', v.dados.email);
      S.testadores = { ...(S.testadores || {}), [v.chave]: v.dados };
      $('tst-email').value = ''; renderTestadores();
    }
  });
  $('cidades-testadores')?.addEventListener('click', async (ev) => {
    const b = ev.target.closest('[data-tst-remover]'); if (!b) return;
    const k = b.dataset.tstRemover, t = S.testadores?.[k]; if (!t) return;
    const conf = await confirmar({ titulo: `Remover ${t.email}?`, texto: 'A pessoa volta a ver o app como qualquer cliente: em cidade em espera, sem poder pedir.', rotulo: 'Remover', perigo: true });
    if (!conf.ok) return;
    if (await executar(() => remove(ref(db, `testadores_email/${k}`)), 'Testador removido.')) {
      await logar('testador.remover', t.email);
      const { [k]: _fora, ...resto } = S.testadores || {}; S.testadores = resto; renderTestadores();
    }
  });

  function render() {
    const lista = $('cidades-lista');
    if (!lista) return;
    if (sujo && lista.contains(document.activeElement)) return;
    const cidades = listarCidades(S.cidades);
    const sem = lojasSemCidade(S.lojas, S.suspensas);
    const abertos = new Set([...lista.querySelectorAll('details[open]')].map((d) => d.closest('[data-cidade]')?.dataset.cidade));
    lista.innerHTML = (cidades.length ? cidades.map(cartao).join('') : vazio('fa-city', 'Nenhuma cidade cadastrada. Cadastre a primeira acima: enquanto não houver cidades, o app funciona como antes.'))
      + (cidades.length && sem.length ? cartaoSemCidade(sem, cidades) : '');
    lista.querySelectorAll('[data-cidade]').forEach((el) => { if (abertos.has(el.dataset.cidade)) el.querySelector('details')?.setAttribute('open', ''); });
    kitAbertos.forEach((id) => { if (S.cidades?.[id]) prepararKit(id); else kitAbertos.delete(id); });
    renderInteressados();
    renderDemo();
    renderTestadores();
    const res = $('cid-resumo');
    if (res) {
      const esp = cidades.filter((c) => c.status === 'espera').length;
      res.textContent = cidades.length ? `${cidades.length} cidade(s): ${esp} em espera, ${cidades.length - esp} aberta(s).` : '';
    }
  }

  // ----- nova cidade -----
  const erro = (msg) => { const e = $('cid-erro'); if (e) { e.hidden = !msg; e.textContent = msg || ''; } };
  $('form-cidade')?.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const v = validarCidade({ nome: $('cid-nome').value, uf: $('cid-uf').value, meta: $('cid-meta').value, isencaoMeses: $('cid-meses').value }, S.cidades);
    if (!v.ok) { erro(v.erro); return; }
    erro('');
    if (await executar(() => set(ref(db, `cidades/${v.id}`), { ...v.dados, criadoEm: agoraIso() }), `${v.dados.nome} - ${v.dados.uf} cadastrada. Está em espera.`)) {
      await logar('cidade.criar', `${v.dados.nome} - ${v.dados.uf}`, `meta ${v.dados.meta} lojas · ${v.dados.isencaoMeses} meses sem comissão`);
      S.cidades = { ...(S.cidades || {}), [v.id]: { ...v.dados, criadoEm: agoraIso() } };
      $('form-cidade').reset(); $('cid-meta').value = 30; $('cid-meses').value = 6;
      render();
    }
  });

  // ----- lista -----
  const lista = $('cidades-lista');
  lista?.addEventListener('input', () => { sujo = true; });
  lista?.addEventListener('change', () => { sujo = true; });
  lista?.addEventListener('click', async (ev) => {
    const lib = ev.target.closest('[data-cid-liberar]'), salvar = ev.target.closest('[data-cid-salvar]'), rem = ev.target.closest('[data-cid-remover]'), atr = ev.target.closest('[data-cid-atribuir]');

    if (lib) {
      const id = lib.dataset.cidLiberar, c = S.cidades?.[id];
      if (!c || liberando) return;
      const r = resumoCidade({ ...c, id }, S.lojas, S.suspensas);
      const meses = Number(c.isencaoMeses) || 6;
      const conf = await confirmar({
        titulo: `Liberar ${rotuloCidade(c)}?`,
        texto: `A cidade abre para pedidos agora. As ${r.vagas} loja(s) que estão nela hoje ficam ${meses} ${meses === 1 ? 'mês' : 'meses'} sem comissão, a partir de hoje. Lojas que entrarem depois pagam a comissão normal. Não dá para desfazer as isenções.`,
        aviso: r.metaBatida ? '' : (r.vagas === 0 ? 'Atenção: ainda não há nenhuma loja nesta cidade.' : `Atenção: a meta era ${r.meta} lojas e só há ${r.vagas}.`),
        rotulo: 'Liberar cidade'
      });
      if (!conf.ok) return;
      liberando = id; sujo = false; render();
      try {
        const out = await liberarCidade(id);
        aviso(`${rotuloCidade(c)} liberada: ${out.lojas} loja(s) sem comissão até ${dataBR(out.ate)}.`);
        S.cidades = { ...S.cidades, [id]: { ...c, status: 'aberta', abertaEm: agoraIso(), isencaoAte: out.ate } };
      } catch (e) { console.error(e); aviso(e.message || 'Não foi possível liberar a cidade.', 'erro'); }
      finally { liberando = null; render(); }
    } else if (salvar) {
      const id = salvar.dataset.cidSalvar, c = S.cidades?.[id], box = salvar.closest('[data-cidade]');
      if (!c) return;
      const mesesEl = box.querySelector('[data-cid-meses]');
      const v = validarCidade({ nome: c.nome, uf: c.uf, meta: box.querySelector('[data-cid-meta]').value, isencaoMeses: mesesEl ? mesesEl.value : c.isencaoMeses }, {});
      if (!v.ok) { aviso(v.erro, 'erro'); return; }
      const campos = { meta: v.dados.meta, ...(mesesEl ? { isencaoMeses: v.dados.isencaoMeses } : {}), atualizadoEm: agoraIso(), atualizadoPor: S.user?.uid || '' };
      if (await executar(() => update(ref(db, `cidades/${id}`), campos), 'Cidade atualizada.')) {
        await logar('cidade.editar', rotuloCidade(c), `meta ${campos.meta}${mesesEl ? ` · ${campos.isencaoMeses} meses` : ''}`);
        S.cidades = { ...S.cidades, [id]: { ...c, ...campos } };
        sujo = false; render();
      }
    } else if (rem) {
      const id = rem.dataset.cidRemover, c = S.cidades?.[id];
      if (!c) return;
      const conf = await confirmar({ titulo: `Excluir ${rotuloCidade(c)}?`, texto: 'A cidade some da lista. Só é possível porque nenhuma loja está nela.', rotulo: 'Excluir', perigo: true });
      if (!conf.ok) return;
      if (await executar(() => remove(ref(db, `cidades/${id}`)), 'Cidade excluída.')) {
        await logar('cidade.remover', rotuloCidade(c));
        const { [id]: _fora, ...resto } = S.cidades || {}; S.cidades = resto; render();
      }
    } else if (atr) {
      const lojaId = atr.dataset.cidAtribuir, linha = atr.closest('[data-cid-loja]');
      const cidadeId = linha.querySelector('[data-cid-escolha]').value;
      const c = S.cidades?.[cidadeId];
      if (!c) { aviso('Escolha a cidade da loja.', 'erro'); return; }
      const nome = S.lojas?.[lojaId]?.nombre || S.lojas?.[lojaId]?.nome || lojaId;
      if (await executar(() => update(ref(db, `restaurantes/${lojaId}`), { cidadeId, cidade: rotuloCidade(c) }), `${nome} agora é de ${rotuloCidade(c)}.`)) {
        await logar('loja.cidade', nome, rotuloCidade(c));
        S.lojas = { ...S.lojas, [lojaId]: { ...S.lojas[lojaId], cidadeId, cidade: rotuloCidade(c) } };
        sujo = false; render();
      }
    }
  });

  // ----- interessados -----
  $('cidades-interessados')?.addEventListener('click', async (ev) => {
    const criar = ev.target.closest('[data-int-criar]'), copiar = ev.target.closest('[data-int-copiar]'), limpar = ev.target.closest('[data-int-limpar]');
    const grupo = (k) => resumirInteressados(S.listaEspera, S.cidades).find((g) => g.cidadeKey === k);
    if (criar) {
      const g = grupo(criar.dataset.intCriar); if (!g) return;
      $('cid-nome').value = g.nome; $('cid-uf').value = g.uf;
      $('card-cidade-nova')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      aviso(`Confira a meta e toque em cadastrar para criar ${g.nome}${g.uf ? ` - ${g.uf}` : ''}.`);
    } else if (copiar) {
      const g = grupo(copiar.dataset.intCopiar); if (!g) return;
      const texto = g.zaps.join('\n');
      try { await navigator.clipboard.writeText(texto); aviso(`${g.total} número(s) copiado(s).`); }
      catch { window.prompt('Copie os números:', g.zaps.join(', ')); }
    } else if (limpar) {
      const g = grupo(limpar.dataset.intLimpar); if (!g) return;
      const conf = await confirmar({ titulo: `Limpar a lista de ${g.nome}?`, texto: `Remove ${g.total} pedido(s) de aviso. Use depois de avisar o pessoal. Não dá para desfazer.`, rotulo: 'Limpar lista', perigo: true });
      if (!conf.ok) return;
      const apagar = {};
      for (const [id, r] of Object.entries(S.listaEspera || {})) if (r && r.cidadeKey === g.cidadeKey) apagar[id] = null;
      if (await executar(() => update(ref(db, 'lista_espera'), apagar), 'Lista limpa.')) {
        await logar('cidade.lista', `${g.nome}${g.uf ? ` - ${g.uf}` : ''}`, `${g.total} pedido(s) de aviso removidos`);
        S.listaEspera = Object.fromEntries(Object.entries(S.listaEspera || {}).filter(([id]) => !(id in apagar)));
        render();
      }
    }
  });

  // ----- kit: abrir/fechar, baixar, enviar, copiar -----
  lista?.addEventListener('toggle', (ev) => {
    const d = ev.target; if (!d.matches?.('details.cid-kit')) return;
    const id = d.dataset.kit;
    if (d.open) { kitAbertos.add(id); prepararKit(id); const alvo = d.querySelector('.cid-kit-corpo'); if (alvo && !alvo.innerHTML.trim()) alvo.innerHTML = '<p class="m-nota">Preparando as imagens…</p>'; }
    else kitAbertos.delete(id);
  }, true);
  const baixarArquivo = (arq) => { const url = URL.createObjectURL(arq), a = document.createElement('a'); a.href = url; a.download = arq.name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000); };
  lista?.addEventListener('click', async (ev) => {
    const bx = ev.target.closest('[data-kit-baixar]'), en = ev.target.closest('[data-kit-enviar]'), cp = ev.target.closest('[data-kit-copiar]');
    const sb = ev.target.closest('[data-kit-serie-baixar]'), se = ev.target.closest('[data-kit-serie-enviar]');
    if (!bx && !en && !cp && !sb && !se) return;
    if (cp) {
      const area = lista.querySelector(`[data-kit-texto="${cp.dataset.kitCopiar}-${CSS.escape(cp.dataset.cid)}"]`);
      try { await navigator.clipboard.writeText(area.value); aviso('Texto copiado.'); } catch { area.select(); aviso('Selecione e copie o texto.', 'erro'); }
      return;
    }
    const btn = bx || en || sb || se, antes = btn.innerHTML; btn.disabled = true; btn.textContent = 'Gerando…';
    try {
      if (sb || se) { // carrossel inteiro, na ordem
        const pub = (sb || se).dataset.kitSerieBaixar || (sb || se).dataset.kitSerieEnviar, arqs = [];
        for (const p of PECAS.filter((x) => x.publico === pub && x.grupo === 'carrossel')) arqs.push(await arquivoDaPeca(p.id, btn.dataset.cid));
        if (se && navigator.canShare?.({ files: arqs })) await navigator.share({ files: arqs });
        else { for (const a of arqs) { baixarArquivo(a); await new Promise((ok) => setTimeout(ok, 350)); } if (se) aviso('Este aparelho não compartilha arquivos direto: as imagens foram baixadas.'); }
      } else {
        const arq = await arquivoDaPeca(btn.dataset.kitBaixar || btn.dataset.kitEnviar, btn.dataset.cid);
        if (en && navigator.canShare?.({ files: [arq] })) { await navigator.share({ files: [arq] }); }
        else { baixarArquivo(arq); if (en) aviso('Este aparelho não compartilha arquivos direto: a imagem foi baixada.'); }
      }
    } catch (e) { if (e?.name !== 'AbortError') { console.error(e); aviso(e.message || 'Não foi possível gerar a imagem.', 'erro'); } }
    finally { btn.disabled = false; btn.innerHTML = antes; }
  });

  return { render };
}
