import { db, ref, onValue } from './firebase.js';
import { escapeHtml } from './regras.js';

const id = new URLSearchParams(location.search).get('id');
const $ = (x) => document.getElementById(x);
const setText = (id, value) => { const el = $(id); if (el) el.textContent = value; };
const setHtml = (id, value) => { const el = $(id); if (el) el.innerHTML = value; };

const estrelas = (n) => {
  const r = Math.max(0, Math.min(5, Math.round(Number(n) || 0)));
  return '★'.repeat(r) + '☆'.repeat(5 - r);
};

if (!id) {
  location.href = 'index.html';
} else {
  onValue(ref(db, `restaurantes/${id}`), (s) => {
    const l = s.val();
    if (!l) return;
    const nome = l.nombre || l.nome || 'Restaurante';
    setText('titulo-avaliaciones', `Avaliações de ${nome}`);
    document.title = `Avaliações - ${nome}`;
  }, (err) => console.warn('Avaliações/restaurante:', err));

  onValue(ref(db, `lojas/${id}`), (s) => {
    const a = s.val() || {};
    const m = Number(a.avaliacaoMedia) || 0;
    setHtml('media-avaluaciones', `<i class="fa-solid fa-star"></i> ${m.toFixed(1)}`);
    setText('total-avaluaciones', `(${Number(a.totalAvaliacoes) || 0} avaliações)`);
  }, (err) => console.warn('Avaliações/loja:', err));

  onValue(ref(db, `avaliacoes/${id}`), (s) => {
    const all = s.exists() ? Object.values(s.val() || {}) : [];
    const lista = all
      .filter((x) => x && (!String(x.comentario || '').trim() || x.respostaLoja || x.respuestaTienda))
      .sort((a, b) => String(b.criadoEm || '').localeCompare(String(a.criadoEm || '')));

    const html = lista.length ? lista.map((i) => {
      const nome = escapeHtml(String(i.clienteNome || 'Cliente').trim().split(' ')[0]);
      const tags = [...(i.tagsComida || []), ...(i.tagsEntrega || [])]
        .map((t) => `<span class="tag-review">${escapeHtml(t)}</span>`).join('');
      const resposta = i.respostaLoja || i.respuestaTienda || '';
      return `<article class="card-comentario-item">
        <div class="comentario-header">
          <div class="cliente-info">
            <strong>${nome}</strong>
            <span class="comentario-data">${i.criadoEm ? new Date(i.criadoEm).toLocaleDateString('es') : ''}</span>
          </div>
          <div class="estrelas-comentario">${estrelas(i.notaMedia)}</div>
        </div>
        <div class="detalhes-subnotas"><small>Comida: <strong>${Number(i.notaComida) || 0}★</strong></small> • <small>Entrega: <strong>${Number(i.notaEntrega) || 0}★</strong></small></div>
        ${i.comentario ? `<p class="texto-comentario">“${escapeHtml(i.comentario)}”</p>` : `<p class="texto-comentario texto-sin-comentario">O cliente deixou sua avaliação sem comentário.</p>`}
        ${resposta ? `<div class="respuesta-tienda"><strong><i class="fa-solid fa-store"></i> Resposta da loja</strong><p>${escapeHtml(resposta)}</p></div>` : ''}
        <div class="tags-container">${tags}</div>
      </article>`;
    }).join('') : '<p class="msg-vazio">Ainda não há comentários respondidos pela loja.</p>';

    setHtml('lista-todas-avaliacoes', html);
  }, (err) => {
    console.warn('Avaliações/lista:', err);
    setHtml('lista-todas-avaliacoes', '<p class="msg-vazio">Não foi possível carregar as avaliações.</p>');
  });
}
