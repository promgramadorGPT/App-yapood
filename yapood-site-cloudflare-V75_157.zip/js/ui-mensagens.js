// V75.26 — Mensagens personalizadas (toast + confirmação) no lugar dos alert()/confirm() nativos do navegador.
// Sem dependências: injeta o próprio CSS, então funciona em qualquer página.
const ID_ESTILO = 'ym-estilo';
const CSS = `
#ym-toasts{position:fixed;z-index:2147483646;top:calc(12px + env(safe-area-inset-top));left:12px;right:12px;display:flex;flex-direction:column;gap:10px;align-items:center;pointer-events:none}
.ym-toast{pointer-events:auto;display:flex;align-items:flex-start;gap:12px;width:min(440px,100%);padding:13px 14px;border-radius:14px;background:#fff;color:#14202b;border:1px solid #e1e6ec;border-left:5px solid var(--ym-cor,#1b4fd8);box-shadow:0 10px 30px rgba(20,32,43,.22);font:600 .95rem/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;opacity:0;transform:translateY(-10px);transition:opacity .2s ease,transform .2s ease;cursor:pointer}
.ym-toast.ym-show{opacity:1;transform:none}
.ym-toast svg{flex:0 0 22px;width:22px;height:22px;margin-top:1px;color:var(--ym-cor,#1b4fd8)}
.ym-toast span{flex:1;min-width:0;overflow-wrap:anywhere}
.ym-toast button{flex:0 0 auto;border:0;background:none;color:#5b6b7a;font-size:1.3rem;line-height:1;padding:0 2px;cursor:pointer}
.ym-success{--ym-cor:#0b6b4f}.ym-error{--ym-cor:#b3261e}.ym-warn{--ym-cor:#b26a00}.ym-info{--ym-cor:#1b4fd8}
@media (min-width:700px){#ym-toasts{left:auto;right:18px;align-items:flex-end}}
.ym-fundo{position:fixed;inset:0;z-index:2147483647;background:rgba(10,18,26,.55);display:grid;place-items:center;padding:16px}
.ym-caixa{width:min(420px,100%);background:#fff;color:#14202b;border-radius:18px;padding:22px 20px 18px;box-shadow:0 24px 70px rgba(0,0,0,.35);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.ym-caixa h2{margin:0 0 8px;font-size:1.15rem}
.ym-caixa p{margin:0 0 18px;color:#46566a;font-size:.98rem;line-height:1.5;overflow-wrap:anywhere}
.ym-acoes{display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap}
.ym-acoes button{min-height:46px;padding:0 18px;border-radius:12px;border:1px solid #d5dce3;background:#fff;color:#14202b;font-weight:700;font-size:.98rem;font-family:inherit;cursor:pointer}
.ym-acoes .ym-sim{background:#14202b;border-color:#14202b;color:#fff}
.ym-acoes .ym-sim.ym-perigo{background:#b3261e;border-color:#b3261e}
.ym-acoes button:focus-visible{outline:3px solid #f5b400;outline-offset:2px}
@media (max-width:520px){.ym-fundo{align-items:end;padding:0}.ym-caixa{border-radius:18px 18px 0 0;width:100%;padding-bottom:calc(18px + env(safe-area-inset-bottom))}.ym-acoes button{flex:1}}
@media (prefers-reduced-motion:reduce){.ym-toast{transition:none}}
`;
const ICONES = {
  success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="m8 12.5 2.8 2.8L16 9.5"/></svg>',
  error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="m9 9 6 6M15 9l-6 6"/></svg>',
  warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4M12 17.2v.1"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7.2v.1"/></svg>'
};

function garantirEstilo() {
  if (document.getElementById(ID_ESTILO)) return;
  const s = document.createElement('style');
  s.id = ID_ESTILO; s.textContent = CSS;
  document.head.appendChild(s);
}

/** Adivinha o tipo pelo texto (usado quando um alert() antigo é redirecionado para o toast). */
export function tipoDaMensagem(msg) {
  const t = String(msg || '').toLowerCase();
  if (/não foi possível|nao foi possivel|erro|falh|inválid|invalid|negad|recus|obrigat|informe|confira|selecione|expirou|bloquead|indispon/.test(t)) return 'error';
  if (/salv|atualizad|enviad|copiad|sucesso|conectad|desconectad|cancelad|ativad|criad|removid|exclu[ií]d|pronto/.test(t)) return 'success';
  return 'info';
}
export function duracaoDaMensagem(msg, tipo = 'info') {
  const base = tipo === 'error' ? 6500 : 4000;
  return Math.min(14000, Math.max(base, String(msg || '').length * 55));
}

/** Aviso rápido no topo da tela. tipo: success | error | warn | info. */
export function toast(msg, tipo = 'info', ms) {
  if (typeof document === 'undefined') return null;
  garantirEstilo();
  const t = ICONES[tipo] ? tipo : 'info';
  let caixa = document.getElementById('ym-toasts');
  if (!caixa) {
    caixa = document.createElement('div');
    caixa.id = 'ym-toasts';
    document.body.appendChild(caixa);
  }
  const el = document.createElement('div');
  el.className = `ym-toast ym-${t}`;
  el.setAttribute('role', t === 'error' ? 'alert' : 'status');
  el.innerHTML = `${ICONES[t]}<span></span><button type="button" aria-label="Fechar">×</button>`;
  el.querySelector('span').textContent = String(msg ?? '');
  while (caixa.children.length >= 4) caixa.firstChild.remove();
  caixa.appendChild(el);
  requestAnimationFrame(() => el.classList.add('ym-show'));
  let fechado = false;
  const fechar = () => { if (fechado) return; fechado = true; el.classList.remove('ym-show'); setTimeout(() => el.remove(), 220); };
  el.addEventListener('click', fechar);
  setTimeout(fechar, ms || duracaoDaMensagem(msg, t));
  return fechar;
}

/**
 * Confirmação em janela própria. Devolve Promise<boolean>.
 * confirmar('Texto') ou confirmar({ titulo, texto, rotulo, cancelar, perigo }).
 */
export function confirmar(opcoes) {
  const o = typeof opcoes === 'string' ? { texto: opcoes } : (opcoes || {});
  if (typeof document === 'undefined') return Promise.resolve(false);
  garantirEstilo();
  return new Promise((resolve) => {
    const antes = document.activeElement;
    const fundo = document.createElement('div');
    fundo.className = 'ym-fundo';
    fundo.innerHTML = `<div class="ym-caixa" role="alertdialog" aria-modal="true" aria-labelledby="ym-t" aria-describedby="ym-x"><h2 id="ym-t"></h2><p id="ym-x"></p><div class="ym-acoes"><button type="button" class="ym-nao"></button><button type="button" class="ym-sim"></button></div></div>`;
    fundo.querySelector('h2').textContent = o.titulo || 'Confirmar';
    fundo.querySelector('p').textContent = o.texto || '';
    const nao = fundo.querySelector('.ym-nao'), sim = fundo.querySelector('.ym-sim');
    nao.textContent = o.cancelar || 'Voltar';
    sim.textContent = o.rotulo || 'Confirmar';
    if (o.perigo) sim.classList.add('ym-perigo');
    const fim = (v) => { document.removeEventListener('keydown', tecla, true); fundo.remove(); try { antes?.focus?.(); } catch { /* sem foco */ } resolve(v); };
    const tecla = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); fim(false); }
      else if (e.key === 'Tab') { e.preventDefault(); (document.activeElement === sim ? nao : sim).focus(); }
    };
    nao.addEventListener('click', () => fim(false));
    sim.addEventListener('click', () => fim(true));
    fundo.addEventListener('click', (e) => { if (e.target === fundo) fim(false); });
    document.addEventListener('keydown', tecla, true);
    document.body.appendChild(fundo);
    (o.perigo ? nao : sim).focus();
  });
}

/** Faz todo alert() antigo aparecer como toast personalizado (não bloqueia a tela). */
export function instalarAlertaPersonalizado() {
  if (typeof window === 'undefined' || window.__ymAlerta) return;
  window.__ymAlerta = true;
  window.alert = (msg) => { const m = String(msg ?? ''); toast(m, tipoDaMensagem(m)); };
}
instalarAlertaPersonalizado();
