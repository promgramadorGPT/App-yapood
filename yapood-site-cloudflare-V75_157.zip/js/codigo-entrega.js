// V75.13 — Código de entrega na tela de status do cliente.
// Módulo isolado: se falhar, a tela de status continua igual. O código vem do backend, só para o dono do pedido.
import { auth } from './firebase.js';
import { normalizarStatus, STATUS } from './regras.js';

const API = 'https://api-mp-yapoodbr.onrender.com';
const container = document.getElementById('card-status-container');
const cache = new Map();   // pedidoKey -> código já mostrado (só em memória)

function elegivel(p) {
  if (!p || !auth.currentUser?.uid || auth.currentUser.uid !== p.clienteUid) return false;
  if (p.tipoEntrega !== 'delivery' || p.entregaConfirmada === true) return false;
  const s = normalizarStatus(p.status);
  return s !== STATUS.ENTREGUE && s !== STATUS.CANCELADO;
}
function caixa(key) {
  const codigo = cache.get(key);
  const el = document.createElement('div');
  el.className = 'codigo-entrega';
  el.innerHTML = codigo
    ? `<h4>Código de entrega</h4><p class="codigo-entrega-valor" aria-label="Código ${codigo.split('').join(' ')}">${codigo}</p><p class="codigo-entrega-ajuda">Informe este código ao entregador só quando ele chegar com o seu pedido. Não envie por mensagem.</p>`
    : `<h4>Código de entrega</h4><p class="codigo-entrega-ajuda">Você vai precisar dele para receber o pedido. Mostre só quando o entregador chegar.</p><button type="button" class="codigo-entrega-btn">Mostrar código</button><p class="codigo-entrega-erro" role="alert" hidden></p>`;
  return el;
}
function inserir() {
  const p = window.__yapoodStatus?.pedido, card = container?.querySelector('.card-status');
  if (!card || card.querySelector('.codigo-entrega') || !elegivel(p)) return;
  (card.querySelector('.detalhes-status') || card.lastElementChild)?.before(caixa(p._key));
}
container?.addEventListener('click', async (ev) => {
  const btn = ev.target.closest('.codigo-entrega-btn'); if (!btn) return;
  const p = window.__yapoodStatus?.pedido, erro = btn.parentElement.querySelector('.codigo-entrega-erro');
  if (!elegivel(p)) return;
  btn.disabled = true; erro.hidden = true;
  try {
    const token = await auth.currentUser.getIdToken();
    const r = await fetch(`${API}/entrega/meu-codigo`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({ pedidoKey: p._key }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.codigo) throw new Error(d.error || 'Não foi possível mostrar o código agora.');
    cache.set(p._key, d.codigo);
    btn.closest('.codigo-entrega').replaceWith(caixa(p._key));
  } catch (err) { erro.textContent = err.message; erro.hidden = false; btn.disabled = false; }
});
if (container) new MutationObserver(() => { try { inserir(); } catch (e) { console.warn('Código de entrega:', e); } }).observe(container, { childList: true, subtree: true });
