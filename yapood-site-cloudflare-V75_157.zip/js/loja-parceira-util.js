// V75.112 — Entrega parceira no painel da LOJA: regras de apresentação (puras, sem DOM e sem rede).
// Quem decide de verdade é a API (rotas /rede/corrida/*); aqui só se escolhe o que mostrar e o que avisar.
import { STATUS, PAGO, normalizarStatus, normalizarPagamento } from './regras.js';

export const MAX_TAXA_AVISO = 100; // só para o texto; o limite real é o da API
export const PADRAO_COMPENSACAO = { antes_aceite: 0, a_caminho: 25, chegou: 50, coletada: 100 }; // mesmos números de /rede/config

const arred = (v) => Math.round((Number(v) || 0) * 100) / 100;
export const brl = (v) => arred(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
export const hora = (ms) => (ms ? new Date(ms).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '');
export function haMinutos(ms, agora = Date.now()) {
  if (!ms) return '';
  const m = Math.max(0, Math.floor((agora - ms) / 60000));
  return m < 1 ? 'agora há pouco' : m === 1 ? 'há 1 min' : m < 60 ? `há ${m} min` : `há ${Math.floor(m / 60)} h`;
}

/** O pedido pode ganhar o botão? Espelha a API (avaliarPedido). `null` = nem mostrar bloco (pedido já encerrado ou retirada). */
export function elegivel(p) {
  if (!p) return null;
  const st = normalizarStatus(p.status);
  if (st === STATUS.ENTREGUE || st === STATUS.CANCELADO || p.entregaConfirmada === true) return null;
  if (p.tipoEntrega !== 'delivery') return null;
  const pago = normalizarPagamento(p.pagoStatus);
  if (pago === PAGO.PENDENTE) {
    return { ok: false, pendente: true, motivo: 'Aguardando a confirmação do pagamento online (Pix ou cartão). O botão aparece assim que o pagamento for aprovado.' };
  }
  if (pago !== PAGO.APROVADO) {
    return { ok: false, motivo: 'A entrega parceira só vale para pedido pago online. Com pagamento na entrega, o entregador carregaria o dinheiro da loja.' };
  }
  if (!(arred(p.precioEnvio) > 0)) return { ok: false, motivo: 'Este pedido não tem taxa de entrega. Sem taxa não há o que pagar ao entregador parceiro.' };
  return { ok: true, taxa: arred(p.precioEnvio) };
}

/** A corrida que vale para o pedido: a mais recente. */
export function corridaDoPedido(corridas, pedidoKey) {
  const lista = (corridas || []).filter((c) => c && c.pedidoKey === pedidoKey).sort((a, b) => (b.criadaEm || 0) - (a.criadaEm || 0));
  return lista[0] || null;
}

export const ATIVAS = ['aberta', 'aceita', 'pronta', 'coletada', 'sem_entregador'];

/** Em que momento a loja estaria cancelando (igual à API). */
export function momentoDoCancelamento(c) {
  if (!c) return 'antes_aceite';
  if (c.estado === 'aberta' || c.estado === 'sem_entregador') return 'antes_aceite';
  if (c.estado === 'coletada') return 'coletada';
  return c.chegouEm != null ? 'chegou' : 'a_caminho';
}
export function compensacaoSeCancelar(c, cfg = PADRAO_COMPENSACAO) {
  const momento = momentoDoCancelamento(c);
  const pct = Number(cfg[momento] ?? PADRAO_COMPENSACAO[momento]) || 0;
  return { momento, pct, valor: arred((Number(c?.taxa) || 0) * pct / 100) };
}
export function textoCancelar(c, cfg) {
  const k = compensacaoSeCancelar(c, cfg);
  if (!k.pct) return 'Ainda não há entregador na corrida. Cancelar agora não gera custo.';
  const fase = { a_caminho: 'está a caminho da loja', chegou: 'já chegou na loja', coletada: 'já coletou o pedido' }[k.momento];
  return `O entregador ${fase}. Cancelando agora, a loja deve ${k.pct}% da taxa (${brl(k.valor)}) a ele.`;
}

export function textoAvisoChamada(taxa, modo = 'na_hora') {
  return `A taxa de ${brl(taxa)} vai integralmente para o entregador. Pagar essa taxa é responsabilidade da loja, depois que a entrega for concluída. `
    + (modo === 'fechamento'
      ? 'Você escolheu pagar no fechamento: o pagamento vence no fim do expediente, com tempo para você analisar a entrega. '
      : 'Você escolheu pagar na hora: o pagamento vence em poucos minutos depois da entrega. ')
    + 'Atraso trava a entrega parceira e, depois de 24 horas, pausa a loja.';
}

/** Faixa sobre a situação da loja. `null` quando está tudo em dia e sem dívida. */
export function resumoSituacao(sit) {
  if (!sit || typeof sit !== 'object') return null;
  const aberto = arred(sit.aberto);
  if (sit.estado === 'bloqueada' || sit.estado === 'pausada') return { tom: 'erro', titulo: sit.estado === 'pausada' ? 'Loja pausada pela entrega parceira' : 'Entrega parceira bloqueada', texto: sit.motivo || `Há ${brl(aberto)} em taxas a pagar a entregadores.` };
  if (sit.estado === 'limite') return { tom: 'aviso', titulo: 'Limite de taxas a pagar atingido', texto: sit.motivo || `Você tem ${brl(aberto)} em taxas a pagar (limite ${brl(sit.limite)}). Pague para voltar a chamar entregadores.` };
  if (aberto > 0) return { tom: 'info', titulo: 'Taxas a pagar a entregadores', texto: `${brl(aberto)} em aberto${sit.limite ? ` (limite ${brl(sit.limite)})` : ''}.` };
  return null;
}

/**
 * O que mostrar para a corrida. Devolve { titulo, detalhe, tom, acoes[], pill, ativa }.
 * `acoes` usa os nomes das ações da API (pronto, cancelar, propria, esperar_mais) e 'chamar' quando dá para chamar de novo.
 */
export function estadoVisual(c, agora = Date.now()) {
  if (!c) return null;
  const ent = c.entregador || {};
  const quem = ent.nome ? ent.nome : 'O entregador';
  const veic = [ent.veiculo, ent.placa].filter(Boolean).join(' ');
  const modo = c.modoPag === 'fechamento' ? 'no fechamento' : 'na hora';
  switch (c.estado) {
    case 'aberta':
      return { ativa: true, tom: 'info', pill: 'Procurando entregador', titulo: 'Procurando entregador parceiro', detalhe: `Chamado ${haMinutos(c.abertaDesde || c.criadaEm, agora)}. Se ninguém aceitar em poucos minutos, você escolhe esperar mais ou usar entregador próprio. Quando alguém aceitar, marque o pedido como pronto.`, acoes: ['cancelar'] };
    case 'sem_entregador':
      return { ativa: true, tom: 'aviso', pill: 'Sem entregador', titulo: 'Nenhum entregador aceitou a tempo', detalhe: 'Escolha: esperar mais um pouco ou usar o entregador da própria loja.', acoes: ['esperar_mais', 'propria', 'cancelar'] };
    case 'aceita':
      return { ativa: true, tom: 'ok', pill: c.chegouEm ? 'Entregador na loja' : 'Entregador a caminho', titulo: `${quem} aceitou a entrega`, detalhe: [veic, ent.celular ? `Contato ${ent.celular}` : '', c.chegouEm ? `Chegou às ${hora(c.chegouEm)}. Marque o pedido como pronto quando estiver lacrado.` : `Aceitou às ${hora(c.aceitaEm)} e vem para a loja. Marque o pedido como pronto quando estiver lacrado.`].filter(Boolean).join(' · '), acoes: ['pronto', 'cancelar'] };
    case 'pronta':
      return { ativa: true, tom: 'ok', pill: c.codigoColeta ? `Código da coleta ${c.codigoColeta}` : 'Pedido pronto', titulo: 'Pedido pronto para coleta', detalhe: `Diga ao entregador o código de 4 dígitos abaixo: ele só consegue coletar com esse código.`, codigo: c.codigoColeta || '', acoes: ['cancelar'] };
    case 'coletada':
      return { ativa: true, tom: 'ok', pill: 'Em entrega', titulo: `${quem} saiu com o pedido`, detalhe: [`Coletou às ${hora(c.coletadaEm)}`, c.coletaEstado === 'ressalva' ? `Registrou um problema no pedido: ${c.coletaObs || 'sem descrição'}` : 'Registrou o pedido lacrado e em bom estado'].join(' · '), alerta: c.coletaEstado === 'ressalva', acoes: ['cancelar'] };
    case 'entregue':
      return { ativa: false, tom: 'ok', pill: 'Entrega concluída', titulo: `Entregue por ${quem}`, detalhe: `Taxa de ${brl(c.taxa)} a pagar ao entregador ${modo}. O pagamento pelo app ainda será liberado: a dívida já fica registrada.`, acoes: [] };
    case 'cancelada': {
      const comp = c.compensacaoValor > 0 ? ` Compensação de ${brl(c.compensacaoValor)} (${c.compensacaoPct}% da taxa) a pagar ao entregador.` : '';
      return { ativa: false, tom: 'neutro', pill: 'Corrida cancelada', titulo: 'Corrida da entrega parceira cancelada', detalhe: `Sem entregador parceiro neste pedido.${comp}`, acoes: ['chamar'] };
    }
    case 'propria':
      return { ativa: false, tom: 'neutro', pill: 'Entrega própria', titulo: 'Entrega pelo entregador da loja', detalhe: 'A corrida parceira foi encerrada. Atribua o entregador da loja na aba Entregadores.', acoes: [] };
    default:
      return { ativa: false, tom: 'neutro', pill: '', titulo: 'Entrega parceira', detalhe: '', acoes: [] };
  }
}

/** Mudanças que merecem aviso (toast) quando a lista é atualizada. Compara a lista anterior com a nova. */
export function mudancas(antes, depois) {
  const ant = new Map((antes || []).map((c) => [c.id, c.estado]));
  const msgs = [];
  for (const c of depois || []) {
    const a = ant.get(c.id);
    if (a === undefined || a === c.estado) continue;
    const num = c.numeroPedido ? `#${c.numeroPedido}` : '';
    const quem = c.entregador?.nome || 'Um entregador';
    if (c.estado === 'aceita') msgs.push({ tipo: 'success', texto: `${quem} aceitou a entrega do pedido ${num}. Marque como pronto quando estiver lacrado.` });
    else if (c.estado === 'sem_entregador') msgs.push({ tipo: 'warn', texto: `Nenhum entregador aceitou o pedido ${num}. Escolha esperar mais ou entregador próprio.` });
    else if (c.estado === 'coletada') msgs.push({ tipo: 'info', texto: `${quem} coletou o pedido ${num} e saiu para entregar.` });
    else if (c.estado === 'entregue') msgs.push({ tipo: 'success', texto: `Pedido ${num} entregue pelo entregador parceiro. Taxa de ${brl(c.taxa)} a pagar.` });
    else if (c.estado === 'aberta' && (a === 'aceita' || a === 'pronta')) msgs.push({ tipo: 'warn', texto: `O entregador desistiu do pedido ${num}. A corrida voltou para a lista de entregadores.` });
  }
  return msgs;
}

/**
 * V75.115 — a loja pode usar a entrega parceira? Lê /rede/liberacao (o Master liga em "Entrega parceira").
 * Mesma regra da API 2.19: sem o nó = desligada; "teste" vale só para as lojas marcadas; "todas" libera geral.
 */
export function lojaLiberada(lib, lojaId) {
  const o = lib && typeof lib === 'object' ? lib : {};
  if (o.modo === 'todas') return true;
  return o.modo === 'teste' && !!lojaId && o.lojas?.[lojaId] === true;
}
