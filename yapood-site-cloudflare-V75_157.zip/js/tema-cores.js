// V75.41 — Cor principal do app (tema). Contas puras: a partir de UMA cor, calcula as variações que a interface usa.
// A cor fica em config_plataforma/tema (só o Master grava). Nada aqui toca o DOM nem o banco.

export const COR_PADRAO = '#efb638';          // amarelo-mostarda do logo
export const CHAVE_CACHE = 'yapood_tema_v1';   // últimas variações aplicadas (evita "piscar" a cor antiga)
export const CHAVE_TESTE = 'yapood_tema_teste'; // cor em teste, só neste aparelho

/** Aceita "#abc", "abc", "#aabbcc" (qualquer caixa). Devolve "#aabbcc" minúsculo ou null. */
export function normalizarHex(v) {
  let s = String(v ?? '').trim().toLowerCase().replace(/^#/, '');
  if (/^[0-9a-f]{3}$/.test(s)) s = s.split('').map((c) => c + c).join('');
  return /^[0-9a-f]{6}$/.test(s) ? `#${s}` : null;
}

const paraRgb = (hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
const paraHex = ([r, g, b]) => `#${[r, g, b].map((x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')).join('')}`;

export function luminancia(hex) {
  const [r, g, b] = paraRgb(hex).map((x) => { const c = x / 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
/** Razão de contraste WCAG entre duas cores (1 a 21). */
export function contraste(a, b) {
  const [x, y] = [luminancia(a), luminancia(b)].sort((m, n) => n - m);
  return (x + 0.05) / (y + 0.05);
}

function paraHsl(hex) {
  const [r, g, b] = paraRgb(hex).map((x) => x / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
  if (!d) return [0, 0, l];
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  const h = max === r ? ((g - b) / d + (g < b ? 6 : 0)) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h * 60, s, l];
}
function deHsl([h, s, l]) {
  if (!s) return paraHex([l * 255, l * 255, l * 255]);
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = (t) => { t = (t + 360) % 360 / 360; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
  return paraHex([f(h + 120) * 255, f(h) * 255, f(h - 120) * 255]);
}
const misturar = (hex, com, parte) => paraHex(paraRgb(hex).map((x, i) => x * (1 - parte) + paraRgb(com)[i] * parte));

/** Escurece mantendo o tom até atingir o contraste pedido contra `fundo` (usado para texto e ícones sobre fundo claro). */
function escurecerAte(hex, fundo, minimo) {
  let [h, s, l] = paraHsl(hex), cor = hex;
  for (let i = 0; i < 60 && contraste(cor, fundo) < minimo; i++) { l = Math.max(0, l - 0.02); cor = deHsl([h, s, l]); }
  return cor;
}

/**
 * Variações da cor principal:
 *  primaria — fundos de botões, abas e selos; escura — hover/pressionado; suave — fundos claros de destaque;
 *  sobre — cor do texto/ícone DENTRO da primária (branco ou quase preto, o que ler melhor);
 *  texto — a primária usada como texto/ícone sobre fundo claro, escurecida o bastante para ser legível (contraste ≥ 4,5);
 *  rgb — "r, g, b" para sombras translúcidas.
 */
export const PREFERENCIAS_SOBRE = ['auto', 'branco', 'escuro'];
export const normalizarSobre = (v) => (PREFERENCIAS_SOBRE.includes(v) ? v : 'auto');

export function derivarTema(entrada, preferenciaSobre = 'auto') {
  const hex = normalizarHex(entrada) || COR_PADRAO;
  const pref = normalizarSobre(preferenciaSobre);
  // "auto" escolhe o que lê melhor; "branco"/"escuro" respeitam a escolha do Master mesmo que o contraste fique menor.
  const sobre = pref === 'branco' ? '#ffffff' : pref === 'escuro' ? '#1b1b1b'
    : (contraste(hex, '#ffffff') >= contraste(hex, '#1b1b1b') ? '#ffffff' : '#1b1b1b');
  const [h, s, l] = paraHsl(hex);
  return {
    primaria: hex,
    escura: deHsl([h, s, Math.max(0, l - 0.09)]),
    suave: misturar(hex, '#ffffff', 0.88),
    sobre,
    pref,
    texto: escurecerAte(hex, '#ffffff', 4.5),
    rgb: paraRgb(hex).join(', ')
  };
}

/** Nome das variáveis CSS gravadas no :root. */
/** Versão da mesma cor, um pouco mais escura, em que o texto branco chega ao contraste pedido (padrão 3,5:1). */
export function corParaTextoBranco(entrada, minimo = 3.5) {
  const hex = normalizarHex(entrada) || COR_PADRAO;
  return escurecerAte(hex, '#ffffff', minimo);
}

export const VARIAVEIS = { primaria: '--cor-primaria', escura: '--cor-primaria-escura', suave: '--cor-primaria-suave', sobre: '--cor-sobre-primaria', texto: '--cor-primaria-texto', rgb: '--cor-primaria-rgb' };

/** Sugestões para o Master testar com um toque. */
export const SUGESTOES = [
  ['Mostarda (logo)', '#efb638'], ['Laranja', '#f57c00'], ['Verde', '#1b9b56'], ['Azul', '#1b6ef3'],
  ['Roxo', '#7657d9'], ['Rosa', '#e0407f'], ['Turquesa', '#0aa5a5'], ['Grafite', '#2b3440']
];
