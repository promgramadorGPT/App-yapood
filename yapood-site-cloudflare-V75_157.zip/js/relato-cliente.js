// V75.35 — "Relatar um problema" na tela de status (cliente). Módulo isolado, no mesmo padrão do reembolso:
// se falhar, a tela de status segue igual.
import { db, auth, ref, set, serverTimestamp } from './firebase.js';
import { escapeHtml } from './regras.js';
import { toast, formatarMoeda } from './utils.js';
import {
  MOTIVOS_RELATO, RELATO, podeRelatar, prazoRelato, textoPrazo, montarRelato, podeContestar, montarContestacao,
  rotuloRelato, textoRelatoCliente
} from './relato.js';

const container = document.getElementById('card-status-container');
const pedirAbrir = new URLSearchParams(location.search).get('relato') === '1';
let abriuAuto = false;

// Foto do celular costuma passar de 5 MB: reduz para até 1280 px antes de enviar.
async function reduzirImagem(file, max = 1280, qualidade = 0.82) {
  if (!file || !/^image\/(jpeg|png|webp|heic|heif)$/i.test(file.type)) throw new Error('Use uma foto JPG, PNG ou WEBP.');
  let bmp;
  try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch {
    bmp = await new Promise((ok, erro) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => erro(new Error('Não foi possível ler a foto.')); i.src = URL.createObjectURL(file); });
  }
  const w = bmp.width || bmp.naturalWidth, h = bmp.height || bmp.naturalHeight;
  const k = Math.min(1, max / Math.max(w, h));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const blob = await new Promise((ok) => c.toBlob(ok, 'image/jpeg', qualidade));
  if (!blob) throw new Error('Não foi possível preparar a foto.');
  return new File([blob], 'relato.jpg', { type: 'image/jpeg' });
}

const assinatura = (p) => {
  const r = p.relato;
  return r ? `r:${r.status}:${r.respondidoEm || ''}:${r.contestacao ? 'c' : ''}` : `n:${podeRelatar(p, auth.currentUser?.uid) ? 'pode' : 'nao'}`;
};

function caixa(p) {
  const el = document.createElement('div');
  el.className = 'rb-box rl-box';
  el.dataset.assinatura = assinatura(p);
  const r = p.relato;
  if (r) {
    el.classList.add(`rl-${r.status}`);
    el.innerHTML = `<h4><i class="fa-solid fa-triangle-exclamation"></i> Problema relatado: ${escapeHtml(rotuloRelato(r))}</h4>
      <p>${escapeHtml(textoRelatoCliente(r))}</p>
      <p class="rb-meta">${escapeHtml(r.motivo || '')}${r.comentario ? ` · “${escapeHtml(r.comentario)}”` : ''}</p>
      ${r.foto ? `<a class="rl-foto" href="${escapeHtml(r.foto)}" target="_blank" rel="noopener"><img src="${escapeHtml(r.foto)}" alt="Foto enviada no relato" loading="lazy"></a>` : ''}
      ${r.resposta ? `<p class="rb-resposta"><strong>Resposta${r.respondidoPorTipo === 'master' ? ' do YAPOOD' : ' da loja'}:</strong> ${escapeHtml(r.resposta)}</p>` : ''}
      ${r.status === RELATO.REEMBOLSADO && r.valorReembolso ? `<p class="rb-meta">Valor aprovado: ${formatarMoeda(r.valorReembolso)}</p>` : ''}
      ${r.contestacao ? `<p class="rb-resposta"><strong>Você contestou:</strong> ${escapeHtml(r.contestacao.comentario)}<br><small>O YAPOOD vai analisar e responder aqui.</small></p>` : ''}
      ${podeContestar(r) ? '<button type="button" class="rb-link" data-contestar>Não concordo com a resposta</button>' : ''}`;
  } else if (podeRelatar(p, auth.currentUser?.uid)) {
    const falta = textoPrazo(prazoRelato(p).restanteMs);
    el.innerHTML = `<h4><i class="fa-solid fa-triangle-exclamation"></i> Teve algum problema com o pedido?</h4>
      <p>Faltou item, veio errado, chegou frio ou não chegou? Conte para a loja${falta ? ` — você ainda tem ${escapeHtml(falta)} para relatar` : ''}. Se a loja não resolver, o YAPOOD decide.</p>
      <button type="button" class="rb-btn" data-relatar>Relatar um problema</button>`;
  } else {
    return null;
  }
  return el;
}

function inserir() {
  const p = window.__yapoodStatus?.pedido, card = container?.querySelector('.card-status');
  if (!card || !p || !auth.currentUser?.uid || auth.currentUser.uid !== p.clienteUid) return;
  const atual = card.querySelector('.rl-box');
  const sig = assinatura(p);
  if (atual && atual.dataset.assinatura === sig) return;
  const nova = caixa(p);
  if (!nova) { atual?.remove(); return; }
  if (atual) atual.replaceWith(nova);
  else (card.querySelector('.acoes-status') || card).before(nova);
  if (pedirAbrir && !abriuAuto && podeRelatar(p, auth.currentUser.uid)) { abriuAuto = true; abrirRelato(p); }
}

function modalBase(titulo, corpo) {
  const el = document.createElement('div');
  el.className = 'rb-overlay';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-modal', 'true');
  el.innerHTML = `<div class="rb-modal"><div class="rb-head"><h3>${titulo}</h3><button type="button" class="rb-fechar" data-fechar aria-label="Fechar">&times;</button></div>${corpo}</div>`;
  return el;
}

function abrirRelato(p) {
  if (document.getElementById('modal-relato')) return;
  const falta = textoPrazo(prazoRelato(p).restanteMs);
  const el = modalBase('Relatar um problema', `
    <p class="rb-sub">Pedido #${escapeHtml(p.numeroPedido || '')} · ${formatarMoeda(p.total)}${falta ? ` · prazo restante: ${escapeHtml(falta)}` : ''}</p>
    <div class="rb-motivos">${MOTIVOS_RELATO.map((m) => `<label class="rb-motivo"><input type="radio" name="rl-motivo" value="${m.id}"><span>${escapeHtml(m.texto)}</span></label>`).join('')}</div>
    <label class="rb-label" for="rl-comentario">O que aconteceu? <small id="rl-conta">0/300</small></label>
    <textarea id="rl-comentario" maxlength="300" placeholder="Descreva rapidamente (mínimo de 10 caracteres)..."></textarea>
    <span class="rb-label">Foto (recomendado)</span>
    <div class="rl-foto-acoes">
      <button type="button" class="rb-btn rb-btn-sec" data-foto-camera><i class="fa-solid fa-camera"></i> Tirar foto</button>
      <button type="button" class="rb-btn rb-btn-sec" data-foto-galeria><i class="fa-solid fa-image"></i> Da galeria</button>
    </div>
    <input type="file" id="rl-foto" accept="image/*" hidden>
    <input type="file" id="rl-camera" accept="image/*" capture="environment" hidden>
    <div id="rl-previa" class="rl-previa" hidden><img alt="Prévia da foto"><button type="button" class="rb-link" data-tirar-foto>Remover foto</button></div>
    <p class="rb-erro" hidden></p>
    <div class="rb-acoes"><button type="button" class="rb-btn rb-btn-sec" data-fechar>Voltar</button><button type="button" class="rb-btn" data-enviar>Enviar relato</button></div>`);
  el.id = 'modal-relato';
  const $ = (s) => el.querySelector(s);
  const erro = $('.rb-erro');
  let arquivo = null;

  $('#rl-comentario').addEventListener('input', (e) => { $('#rl-conta').textContent = `${e.target.value.length}/300`; });
  // Tirar foto (câmera traseira) ou escolher da galeria: os dois caem no mesmo tratamento (reduz para até 1280 px antes de enviar).
  const aoEscolherFoto = async (e) => {
    erro.hidden = true;
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      arquivo = await reduzirImagem(f);
      $('#rl-previa img').src = URL.createObjectURL(arquivo);
      $('#rl-previa').hidden = false;
    } catch (err) { arquivo = null; e.target.value = ''; $('#rl-previa').hidden = true; erro.textContent = err.message; erro.hidden = false; }
  };
  $('#rl-foto').addEventListener('change', aoEscolherFoto);
  $('#rl-camera').addEventListener('change', aoEscolherFoto);
  el.addEventListener('click', async (e) => {
    if (e.target === el || e.target.closest('[data-fechar]')) return el.remove();
    if (e.target.closest('[data-foto-camera]')) { $('#rl-camera').click(); return; }
    if (e.target.closest('[data-foto-galeria]')) { $('#rl-foto').click(); return; }
    if (e.target.closest('[data-tirar-foto]')) { arquivo = null; $('#rl-foto').value = ''; $('#rl-camera').value = ''; $('#rl-previa').hidden = true; return; }
    const enviar = e.target.closest('[data-enviar]'); if (!enviar) return;
    erro.hidden = true;
    try {
      const motivoId = el.querySelector('input[name="rl-motivo"]:checked')?.value;
      // valida antes de gastar upload
      montarRelato(p, { motivoId, comentario: $('#rl-comentario').value }, 0);
      enviar.disabled = true;
      let foto = '';
      if (arquivo) { enviar.textContent = 'Enviando foto…'; foto = await window.uploadImagemRelato(arquivo); }
      enviar.textContent = 'Enviando relato…';
      const dados = montarRelato(p, { motivoId, comentario: $('#rl-comentario').value, foto }, serverTimestamp());
      await set(ref(db, `pedidos/${p._key}/relato`), dados);
      el.remove();
      toast('Relato enviado. A loja vai responder nesta tela.', 'success');
    } catch (err) {
      console.warn('Relato:', err);
      enviar.disabled = false; enviar.textContent = 'Enviar relato';
      erro.textContent = err?.code === 'PERMISSION_DENIED' || /permission/i.test(err?.message || '')
        ? 'Não foi possível enviar agora (o prazo pode ter terminado). Fale com a loja pelo WhatsApp.'
        : (err?.message || 'Não foi possível enviar. Tente novamente.');
      erro.hidden = false;
    }
  });
  document.body.appendChild(el);
}

function abrirContestacao(p) {
  if (document.getElementById('modal-contestacao')) return;
  const el = modalBase('Não concordo com a resposta', `
    <p class="rb-sub">Explique por que a resposta não resolveu. O YAPOOD analisa o caso e a decisão dele é final.</p>
    <label class="rb-label" for="rl-contestacao">Sua explicação</label>
    <textarea id="rl-contestacao" maxlength="300" placeholder="Mínimo de 10 caracteres..."></textarea>
    <p class="rb-erro" hidden></p>
    <div class="rb-acoes"><button type="button" class="rb-btn rb-btn-sec" data-fechar>Voltar</button><button type="button" class="rb-btn" data-enviar>Enviar ao YAPOOD</button></div>`);
  el.id = 'modal-contestacao';
  const erro = el.querySelector('.rb-erro');
  el.addEventListener('click', async (e) => {
    if (e.target === el || e.target.closest('[data-fechar]')) return el.remove();
    const enviar = e.target.closest('[data-enviar]'); if (!enviar) return;
    erro.hidden = true;
    try {
      const dados = montarContestacao(p.relato, el.querySelector('#rl-contestacao').value);
      enviar.disabled = true;
      await set(ref(db, `pedidos/${p._key}/relato/contestacao`), dados);
      el.remove();
      toast('Enviado ao YAPOOD. Você verá a decisão aqui.', 'success');
    } catch (err) {
      console.warn('Contestação:', err);
      enviar.disabled = false;
      erro.textContent = err?.code === 'PERMISSION_DENIED' || /permission/i.test(err?.message || '') ? 'Não foi possível enviar agora.' : (err?.message || 'Não foi possível enviar.');
      erro.hidden = false;
    }
  });
  document.body.appendChild(el);
}

container?.addEventListener('click', (ev) => {
  const p = window.__yapoodStatus?.pedido;
  if (!p) return;
  if (ev.target.closest('[data-relatar]') && podeRelatar(p, auth.currentUser?.uid)) abrirRelato(p);
  if (ev.target.closest('[data-contestar]') && podeContestar(p.relato)) abrirContestacao(p);
});
if (container) new MutationObserver(() => { try { inserir(); } catch (e) { console.warn('Relato:', e); } }).observe(container, { childList: true, subtree: true });
