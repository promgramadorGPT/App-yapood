// Registra o Service Worker (PWA). Caminho relativo: funciona na raiz e em subpastas (GitHub Pages).
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW no registrado:', e));
  });
}
