// V75.50 — gerador de QR Code (modo byte, correção de erro nível M) sem dependências, só para o Pix "copia e cola" do acerto.
// Segue a ISO/IEC 18004: Reed-Solomon em GF(256), máscaras 0–7 com penalidade, versões 1–25 (até ~500 caracteres).
const ECC_POR_BLOCO_M = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28];
const BLOCOS_M        = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21];
const VERSAO_MAX = 25;
const bit = (n, i) => ((n >>> i) & 1) !== 0;

function modulosBrutos(v) {
  let r = (16 * v + 128) * v + 64;
  if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; }
  return r;
}
const capacidadeDados = (v) => Math.floor(modulosBrutos(v) / 8) - ECC_POR_BLOCO_M[v] * BLOCOS_M[v];

// ---- Reed-Solomon (GF 256, polinômio 0x11D) ----
function multiplicar(x, y) { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z; }
function geradorRS(grau) {
  const r = new Array(grau).fill(0); r[grau - 1] = 1; let raiz = 1;
  for (let i = 0; i < grau; i++) { for (let j = 0; j < r.length; j++) { r[j] = multiplicar(r[j], raiz); if (j + 1 < r.length) r[j] ^= r[j + 1]; } raiz = multiplicar(raiz, 0x02); }
  return r;
}
function restoRS(dados, gerador) {
  const r = gerador.map(() => 0);
  for (const b of dados) { const f = b ^ r.shift(); r.push(0); gerador.forEach((c, i) => { r[i] ^= multiplicar(c, f); }); }
  return r;
}

function codificar(bytes, v) {
  const bits = [];
  const por = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
  por(0b0100, 4); por(bytes.length, v <= 9 ? 8 : 16);
  for (const b of bytes) por(b, 8);
  const cap = capacidadeDados(v) * 8;
  por(0, Math.min(4, cap - bits.length));
  por(0, (8 - (bits.length % 8)) % 8);
  for (let p = 0xEC; bits.length < cap; p ^= 0xEC ^ 0x11) por(p, 8);
  const dados = []; for (let i = 0; i < bits.length; i += 8) dados.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  // divide em blocos, calcula o ECC e intercala
  const nBlocos = BLOCOS_M[v], eccLen = ECC_POR_BLOCO_M[v], brutos = Math.floor(modulosBrutos(v) / 8);
  const curtos = nBlocos - (brutos % nBlocos), tamCurto = Math.floor(brutos / nBlocos);
  const gerador = geradorRS(eccLen), blocos = [];
  for (let i = 0, k = 0; i < nBlocos; i++) {
    const d = dados.slice(k, k + tamCurto - eccLen + (i < curtos ? 0 : 1)); k += d.length;
    const e = restoRS(d, gerador); if (i < curtos) d.push(0); blocos.push(d.concat(e));
  }
  const saida = [];
  for (let i = 0; i < blocos[0].length; i++) blocos.forEach((b, j) => { if (i !== tamCurto - eccLen || j >= curtos) saida.push(b[i]); });
  return saida;
}

function posicoesAlinhamento(v) {
  if (v === 1) return [];
  const n = Math.floor(v / 7) + 2, tam = v * 4 + 17, passo = Math.ceil((v * 4 + 4) / (n * 2 - 2)) * 2;
  const r = [6]; for (let p = tam - 7; r.length < n; p -= passo) r.splice(1, 0, p);
  return r;
}

function montar(v, dadosFinais, mascara) {
  const tam = v * 4 + 17;
  const m = Array.from({ length: tam }, () => new Array(tam).fill(false));
  const fn = Array.from({ length: tam }, () => new Array(tam).fill(false));
  const set = (x, y, cor) => { m[y][x] = cor; fn[y][x] = true; };
  for (let i = 0; i < tam; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
  const finder = (cx, cy) => { for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = Math.max(Math.abs(dx), Math.abs(dy)), x = cx + dx, y = cy + dy; if (x >= 0 && x < tam && y >= 0 && y < tam) set(x, y, d !== 2 && d !== 4); } };
  finder(3, 3); finder(tam - 4, 3); finder(3, tam - 4);
  const al = posicoesAlinhamento(v);
  al.forEach((cy, i) => al.forEach((cx, j) => {
    if ((i === 0 && j === 0) || (i === 0 && j === al.length - 1) || (i === al.length - 1 && j === 0)) return;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
  }));
  // formato (nível M = 0b00) e versão
  const dadosFmt = (0 << 3) | mascara; let resto = dadosFmt;
  for (let i = 0; i < 10; i++) resto = (resto << 1) ^ ((resto >>> 9) * 0x537);
  const fmt = ((dadosFmt << 10) | resto) ^ 0x5412;
  for (let i = 0; i <= 5; i++) set(8, i, bit(fmt, i));
  set(8, 7, bit(fmt, 6)); set(8, 8, bit(fmt, 7)); set(7, 8, bit(fmt, 8));
  for (let i = 9; i < 15; i++) set(14 - i, 8, bit(fmt, i));
  for (let i = 0; i < 8; i++) set(tam - 1 - i, 8, bit(fmt, i));
  for (let i = 8; i < 15; i++) set(8, tam - 15 + i, bit(fmt, i));
  set(8, tam - 8, true);
  if (v >= 7) {
    let r = v; for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1F25);
    const bitsV = (v << 12) | r;
    for (let i = 0; i < 18; i++) { const a = tam - 11 + (i % 3), b = Math.floor(i / 3); set(a, b, bit(bitsV, i)); set(b, a, bit(bitsV, i)); }
  }
  // dados em zigue-zague
  let k = 0;
  for (let dir = tam - 1; dir >= 1; dir -= 2) {
    if (dir === 6) dir = 5;
    for (let vert = 0; vert < tam; vert++) for (let j = 0; j < 2; j++) {
      const x = dir - j, sobe = ((dir + 1) & 2) === 0, y = sobe ? tam - 1 - vert : vert;
      if (!fn[y][x] && k < dadosFinais.length * 8) { m[y][x] = bit(dadosFinais[k >>> 3], 7 - (k & 7)); k++; }
    }
  }
  const inverte = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x) => x % 3 === 0, (x, y) => (x + y) % 3 === 0, (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0, (x, y) => ((((x * y) % 2) + ((x * y) % 3)) % 2) === 0, (x, y) => ((((x + y) % 2) + ((x * y) % 3)) % 2) === 0][mascara];
  for (let y = 0; y < tam; y++) for (let x = 0; x < tam; x++) if (!fn[y][x] && inverte(x, y)) m[y][x] = !m[y][x];
  return m;
}

function penalidade(m) {
  const tam = m.length; let p = 0, escuros = 0;
  const linhaTxt = (get) => { let s = ''; for (let i = 0; i < tam; i++) s += get(i) ? '1' : '0'; return s; };
  const cadeias = [];
  for (let i = 0; i < tam; i++) { cadeias.push(linhaTxt((j) => m[i][j])); cadeias.push(linhaTxt((j) => m[j][i])); }
  for (const s of cadeias) {
    const corridas = s.match(/0+|1+/g); for (const c of corridas) if (c.length >= 5) p += 3 + (c.length - 5);
    p += 40 * ((s.match(/(?=(00001011101|10111010000))/g) || []).length);
  }
  for (let y = 0; y < tam; y++) for (let x = 0; x < tam; x++) {
    if (m[y][x]) escuros++;
    if (x < tam - 1 && y < tam - 1 && m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
  }
  const total = tam * tam; p += (Math.ceil(Math.abs(escuros * 20 - total * 10) / total) - 1) * 10;
  return p;
}

/** Devolve a matriz (true = módulo escuro) do QR Code do texto, em UTF-8. */
export function qrMatriz(texto, { mascara: forcada } = {}) {
  const bytes = Array.from(new TextEncoder().encode(String(texto ?? '')));
  let v = 1;
  const precisa = (ver) => 4 + (ver <= 9 ? 8 : 16) + bytes.length * 8;
  while (v <= VERSAO_MAX && precisa(v) > capacidadeDados(v) * 8) v++;
  if (v > VERSAO_MAX) throw new Error('Texto grande demais para o QR Code.');
  const dados = codificar(bytes, v);
  let melhor = null, nota = Infinity;
  for (let mascara = 0; mascara < 8; mascara++) { if (forcada !== undefined && mascara !== forcada) continue; const m = montar(v, dados, mascara), n = penalidade(m); if (n < nota) { nota = n; melhor = m; } }
  return melhor;
}

/** SVG pronto para usar (innerHTML) — fundo branco, margem de 4 módulos, escala fluida pelo CSS. */
export function qrSvg(texto, { margem = 4, rotulo = 'QR Code' } = {}) {
  const m = qrMatriz(texto), tam = m.length + margem * 2;
  let d = ''; m.forEach((lin, y) => { let x = 0; while (x < lin.length) { if (!lin[x]) { x++; continue; } let f = x; while (f < lin.length && lin[f]) f++; d += `M${x + margem} ${y + margem}h${f - x}v1h-${f - x}z`; x = f; } });
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${tam} ${tam}" role="img" aria-label="${String(rotulo).replace(/[<>&"]/g, '')}" shape-rendering="crispEdges"><rect width="${tam}" height="${tam}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}
