// V75.72 — Cidades do YAPOOD (funções puras, sem DOM nem Firebase). Usado pelo Master e pelo cadastro da loja.
// Dados: cidades/{cidadeId} = { nome, uf, status: 'espera' | 'aberta', meta, isencaoMeses, abertaEm, ... }
//        restaurantes/{lojaId}/cidadeId. Quem libera a cidade (e concede a isenção às lojas) é a API, nunca esta tela.

import { normalizarWhatsApp } from './anuncie.js';

export const UFS = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'];
export const META_PADRAO = 30;
export const MESES_PADRAO = 6;

const semAcento = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '');

export function cidadeIdValido(id) {
  return typeof id === 'string' && /^[a-z0-9]+(-[a-z0-9]+)*$/.test(id) && id.length <= 80;
}

/** "Uberlândia" + "MG" → "uberlandia-mg" (mesmo cálculo da API). */
export function gerarCidadeId(nome, uf) {
  const base = semAcento(`${nome ?? ''} ${uf ?? ''}`).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return cidadeIdValido(base) ? base : '';
}

export const rotuloCidade = (c) => (c ? `${c.nome}${c.uf ? ` - ${c.uf}` : ''}` : '');

/** Valida o formulário "Nova cidade". Devolve { ok, erro } ou { ok, id, dados }. */
export function validarCidade({ nome, uf, meta, isencaoMeses } = {}, existentes = {}) {
  const n = String(nome ?? '').trim().replace(/\s+/g, ' ');
  const u = String(uf ?? '').trim().toUpperCase();
  if (n.length < 2) return { ok: false, erro: 'Informe o nome da cidade.' };
  if (n.length > 80) return { ok: false, erro: 'O nome da cidade é grande demais (máximo 80 letras).' };
  if (!UFS.includes(u)) return { ok: false, erro: 'Escolha o estado (UF).' };
  const m = meta === '' || meta == null ? META_PADRAO : Number(meta);
  if (!Number.isInteger(m) || m < 1 || m > 1000) return { ok: false, erro: 'A meta de lojas deve ser um número inteiro de 1 a 1000.' };
  const mm = isencaoMeses === '' || isencaoMeses == null ? MESES_PADRAO : Number(isencaoMeses);
  if (!Number.isInteger(mm) || mm < 1 || mm > 24) return { ok: false, erro: 'Os meses sem comissão devem ser um número inteiro de 1 a 24.' };
  const id = gerarCidadeId(n, u);
  if (!id) return { ok: false, erro: 'Não foi possível gerar o código desta cidade. Use só letras e números no nome.' };
  if (existentes && existentes[id]) return { ok: false, erro: `${n} - ${u} já está cadastrada.` };
  return { ok: true, id, dados: { nome: n, uf: u, status: 'espera', meta: m, isencaoMeses: mm } };
}

/** Lista as cidades em ordem: em espera primeiro, depois abertas; dentro de cada grupo, por nome. */
export function listarCidades(cidades) {
  return Object.entries(cidades || {})
    .filter(([id, c]) => cidadeIdValido(id) && c && typeof c === 'object' && c.nome)
    .map(([id, c]) => ({ id, ...c, status: c.status === 'aberta' ? 'aberta' : 'espera' }))
    .sort((a, b) => (a.status === b.status ? semAcento(a.nome).localeCompare(semAcento(b.nome), 'pt-BR') : a.status === 'espera' ? -1 : 1));
}

/** Lojas de uma cidade (não suspensas), com nome para mostrar na tela. */
export function lojasDaCidade(lojas, suspensas, cidadeId) {
  return Object.entries(lojas || {})
    .filter(([id, l]) => l && l.cidadeId === cidadeId && !(suspensas && suspensas[id]))
    .map(([id, l]) => ({ id, nome: l.nombre || l.nome || 'Sem nome', ativa: l.activo !== false }));
}

/** Números da barra de vagas: quantas lojas já entraram, quantas faltam, e quanto da meta está cumprido (0 a 100). */
export function resumoCidade(cidade, lojas, suspensas) {
  const meta = Math.max(1, Number(cidade?.meta) || META_PADRAO);
  const dela = lojasDaCidade(lojas, suspensas, cidade?.id);
  const vagas = dela.length;
  return { meta, vagas, faltam: Math.max(0, meta - vagas), pct: Math.min(100, Math.round((vagas / meta) * 100)), metaBatida: vagas >= meta, lojas: dela };
}

/** Lojas que ainda não têm cidade escolhida (cadastros antigos). */
export function lojasSemCidade(lojas, suspensas) {
  return Object.entries(lojas || {})
    .filter(([id, l]) => l && !l.cidadeId && !(suspensas && suspensas[id]))
    .map(([id, l]) => ({ id, nome: l.nombre || l.nome || 'Sem nome', texto: String(l.cidade || l.ciudad || '').trim() }));
}

/**
 * Tenta descobrir a cidade cadastrada a partir do texto livre antigo ("Uberlândia - MG", "Uberlândia/MG", "uberlandia, mg").
 * Só devolve um id quando há UMA correspondência clara; sem UF, o nome precisa ser único entre as cidades.
 */
export function acharCidadeDoTexto(texto, cidades) {
  const lista = Array.isArray(cidades) ? cidades : listarCidades(cidades);
  const t = semAcento(texto).toLowerCase().replace(/\s+/g, ' ').trim();
  if (!t) return '';
  const m = t.match(/^(.*?)\s*[-/,]\s*([a-z]{2})$/);
  const nome = (m ? m[1] : t).trim();
  const uf = m ? m[2].toUpperCase() : '';
  const ach = lista.filter((c) => semAcento(c.nome).toLowerCase().trim() === nome && (!uf || String(c.uf).toUpperCase() === uf));
  return ach.length === 1 ? ach[0].id : '';
}

/** O cliente/loja vê uma cidade em espera como "chegando em breve". */
export const emEspera = (c) => !!c && c.status !== 'aberta';

/**
 * Como o cadastro da loja mostra a cidade:
 * - sem cidades cadastradas pelo Master → campo de texto livre (o app antigo continua igual);
 * - com cidades → lista para escolher. Se a loja já tem cidadeId, a escolha fica travada (quem troca é o Master);
 *   se não tem, tenta pré-selecionar pelo texto antigo ("Uberlândia - MG").
 */
export function planejarSeletorCidade({ cidades, lojaCidadeId = '', textoAntigo = '' } = {}) {
  const lista = listarCidades(cidades);
  if (!lista.length) return { modo: 'texto', opcoes: [], selecionada: '', travada: false, dica: '' };
  const jaTem = lojaCidadeId && lista.some((c) => c.id === lojaCidadeId);
  const selecionada = jaTem ? lojaCidadeId : acharCidadeDoTexto(textoAntigo, lista);
  return {
    modo: 'seletor',
    opcoes: lista.map((c) => ({ id: c.id, rotulo: rotuloCidade(c) })),
    selecionada,
    travada: !!jaTem,
    dica: jaTem ? 'Para mudar de cidade, fale com o suporte do YAPOOD.' : (selecionada ? 'Confira se é esta a cidade da sua loja.' : 'Escolha a cidade onde sua loja atende. Depois de salvar, só o suporte pode trocar.')
  };
}

// ---------------------------------------------------------------------------------------------------
// Lado do CLIENTE (V75.73): em que cidade ele está, quais lojas aparecem e a lista de interessados.
// ---------------------------------------------------------------------------------------------------
export const CHAVE_CIDADE = 'yapood_cidade';

/**
 * Em qual cidade o cliente está?
 *  - 'sem-cidades'   : o Master ainda não cadastrou cidades → o app funciona como antes;
 *  - 'aberta'/'espera': ele escolheu (ou o GPS indicou) uma cidade cadastrada;
 *  - 'desconhecida'  : o GPS indicou uma cidade que não está cadastrada (texto em `texto`);
 *  - 'nao-definida'  : cidades existem, mas ele não escolheu e não há GPS.
 * A escolha manual vale mais que o GPS.
 */
export function resolverCidadeCliente({ cidades, escolhidaId = '', gps = null } = {}) {
  const lista = listarCidades(cidades);
  if (!lista.length) return { tipo: 'sem-cidades', cidade: null };
  const tipoDe = (c) => (c.status === 'aberta' ? 'aberta' : 'espera');
  const escolhida = escolhidaId ? lista.find((c) => c.id === escolhidaId) : null;
  if (escolhida) return { tipo: tipoDe(escolhida), cidade: escolhida, origem: 'escolha' };
  const nomeGps = String(gps?.cidade || '').trim();
  if (nomeGps) {
    const uf = String(gps.uf || '').trim().toUpperCase();
    const id = acharCidadeDoTexto(uf ? `${nomeGps} - ${uf}` : nomeGps, lista);
    const c = id ? lista.find((x) => x.id === id) : null;
    if (c) return { tipo: tipoDe(c), cidade: c, origem: 'gps' };
    return { tipo: 'desconhecida', cidade: null, texto: uf ? `${nomeGps} - ${uf}` : nomeGps, nome: nomeGps, uf };
  }
  return { tipo: 'nao-definida', cidade: null };
}

/**
 * A loja aparece na vitrine deste cliente?
 * - sem cidades cadastradas, ou loja antiga sem cidade: sempre (o raio de entrega por GPS continua filtrando);
 * - loja de cidade em espera: nunca aparece na lista (ninguém consegue pedir);
 * - cidade do cliente aberta: só as lojas dela;
 * - cidade do cliente em espera: nenhuma loja de cidade (só as antigas, sem cidade);
 * - cidade desconhecida ou não escolhida: lojas das cidades abertas (o GPS e o raio de entrega filtram).
 */
export function lojaVisivelNaCidade(loja, res, cidades) {
  if (!res || res.tipo === 'sem-cidades') return true;
  const id = loja?.cidadeId;
  if (!id) return true;
  const c = cidades?.[id];
  if (!c) return true;
  if (c.status !== 'aberta') return false;
  if (res.tipo === 'aberta') return res.cidade.id === id;
  if (res.tipo === 'espera') return false;
  return true;
}

/** Barra de vagas mostrada ao cliente (conta todas as lojas que já escolheram a cidade). */
export function progressoPublico(cidade, lojas) {
  const meta = Math.max(1, Number(cidade?.meta) || META_PADRAO);
  const vagas = Object.values(lojas || {}).filter((l) => l && l.cidadeId === cidade?.id).length;
  return { meta, vagas, faltam: Math.max(0, meta - vagas), pct: Math.min(100, Math.round((vagas / meta) * 100)), metaBatida: vagas >= meta };
}

/** Esta loja está numa cidade em espera? (a tela da loja e o carrinho avisam; o servidor é quem realmente barra). */
export function bloqueioDaCidade(loja, cidade, podeFurar = false) {
  if (!loja?.cidadeId || !cidade || cidade.status !== 'espera' || podeFurar === true) return { bloqueada: false };
  return { bloqueada: true, nome: cidade.nome, motivo: `Chegando em breve em ${cidade.nome}` };
}

/** Formulário "Avise-me quando abrir": devolve o registro de lista_espera/{id} (o id junta a cidade e o WhatsApp, então repetir não duplica). */
export function validarInteressado({ cidadeId = '', nome = '', uf = '', whatsapp = '', cidades = {}, uid = '' } = {}, agora = new Date()) {
  const zap = normalizarWhatsApp(whatsapp);
  if (!zap) return { ok: false, erro: 'Informe um WhatsApp com DDD. Ex.: (34) 99999-9999.' };
  let cidadeKey = '', n = '', u = '';
  const c = cidadeId && cidades ? cidades[cidadeId] : null;
  if (c && cidadeIdValido(cidadeId)) { cidadeKey = cidadeId; n = String(c.nome); u = String(c.uf); }
  else {
    n = String(nome ?? '').trim().replace(/\s+/g, ' '); u = String(uf ?? '').trim().toUpperCase();
    if (n.length < 2 || n.length > 80) return { ok: false, erro: 'Informe o nome da sua cidade.' };
    if (!UFS.includes(u)) return { ok: false, erro: 'Escolha o estado (UF).' };
    cidadeKey = gerarCidadeId(n, u);
    if (!cidadeKey) return { ok: false, erro: 'Não foi possível reconhecer esta cidade. Use só letras e números.' };
  }
  const dados = { cidadeKey, cidade: n, uf: u, whatsapp: zap, criadoEm: new Date(agora).toISOString(), ...(uid ? { uid: String(uid).slice(0, 128) } : {}) };
  return { ok: true, id: `${cidadeKey}-${zap}`, dados };
}

/** Agrupa a lista de interessados por cidade (para o Master): mais pedidas primeiro. */
export function resumirInteressados(lista, cidades = {}) {
  const mapa = new Map();
  for (const [id, r] of Object.entries(lista || {})) {
    if (!r || !r.cidadeKey || !r.whatsapp) continue;
    const g = mapa.get(r.cidadeKey) || { cidadeKey: r.cidadeKey, nome: r.cidade || r.cidadeKey, uf: r.uf || '', total: 0, zaps: [], ultima: '' };
    g.total += 1; g.zaps.push(String(r.whatsapp));
    if (String(r.criadoEm || '') > g.ultima) g.ultima = String(r.criadoEm || '');
    mapa.set(r.cidadeKey, g);
  }
  return [...mapa.values()].map((g) => ({ ...g, cadastrada: !!cidades?.[g.cidadeKey], status: cidades?.[g.cidadeKey]?.status || '' }))
    .sort((a, b) => b.total - a.total || semAcento(a.nome).localeCompare(semAcento(b.nome), 'pt-BR'));
}

/** Chave de testadores_email/{chave}: e-mail em minúsculas com "," no lugar de "." (o Firebase não aceita ponto na chave). '' se o e-mail não serve. */
export function chaveEmailTestador(email) {
  const e = String(email ?? '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) || e.length > 160 || /[#$\[\]/]/.test(e)) return '';
  return e.replace(/\./g, ',');
}

/** Cadastro de testador pelo e-mail (Master). `lista` = testadores_email atual, para não repetir. */
export function validarTestador(email, lista = {}, { por = '' } = {}, agora = new Date()) {
  const chave = chaveEmailTestador(email);
  if (!chave) return { ok: false, erro: 'Informe um e-mail válido (o mesmo da conta Google do testador).' };
  if (lista && lista[chave]) return { ok: false, erro: 'Este e-mail já é testador.' };
  const e = String(email).trim().toLowerCase();
  return { ok: true, chave, dados: { email: e, em: new Date(agora).toISOString(), ...(por ? { por: String(por).slice(0, 128) } : {}) } };
}
