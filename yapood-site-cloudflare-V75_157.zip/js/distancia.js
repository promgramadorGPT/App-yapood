// js/distancia.js — V75.42: distância (km, em linha reta) entre a loja e o endereço do cliente.
//
// Serve para o ADM ver "Loja X ↔ cliente a 6 km" ao aprovar um bairro novo, e para o bairro já ficar salvo com esse km.
// É uma ESTIMATIVA: usa o mapa aberto (Nominatim/OpenStreetMap). Nunca atrapalha o pedido:
// qualquer falha, lentidão (> TEMPO_MAX_MS) ou loja sem coordenadas resulta em `null` (o bairro segue sem km e o ADM digita).
//
// Ordem de tentativa (`fonte`):
//   'endereco' → rua + bairro buscados perto da loja;  'bairro' → só o bairro;  'gps' → posição do aparelho (menos confiável).
import { calcularDistanciaKm } from './geo.js';
import { MAX_KM, slugBairro } from './bairros.js';

export const TEMPO_MAX_MS = 4000;
const RAIO_GRAUS = 0.45;   // ≈ 50 km ao redor da loja: evita achar uma rua homônima em outra cidade
const PREFIXO_CACHE = 'distKm_v1_';

const coordenada = (v) => { const n = Number(v); return v !== null && v !== undefined && v !== '' && Number.isFinite(n) ? n : null; };

/** Coordenadas da loja ({lat,lng}) ou null. */
export function coordenadasDaLoja(loja) {
  const lat = coordenada(loja?.lat), lng = coordenada(loja?.lng);
  return lat !== null && lng !== null && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0) ? { lat, lng } : null;
}

/** "Rua X, 10 - Centro" + "Centro" → "Rua X, 10". Sem o bairro no fim, devolve o texto todo. */
export function ruaDoEndereco(direccion, bairro) {
  const partes = String(direccion ?? '').split(' - ').map((p) => p.trim()).filter(Boolean);
  if (partes.length > 1 && slugBairro(partes[partes.length - 1]) === slugBairro(bairro)) partes.pop();
  return partes.join(' - ');
}

/** URL de busca do Nominatim limitada a uma caixa em volta da loja. */
export function urlBusca(texto, centro, raio = RAIO_GRAUS) {
  const { lat, lng } = centro;
  const caixa = [lng - raio, lat + raio, lng + raio, lat - raio].map((n) => n.toFixed(5)).join(','); // esquerda,topo,direita,base
  const p = new URLSearchParams({ format: 'json', limit: '1', countrycodes: 'br', bounded: '1', viewbox: caixa, q: texto });
  return `https://nominatim.openstreetmap.org/search?${p}`;
}

/** Consultas, da mais precisa para a menos: [{ q, fonte }]. */
export function consultasDeEndereco(rua, bairro) {
  const r = String(rua ?? '').replace(/\s+/g, ' ').trim(), b = String(bairro ?? '').replace(/\s+/g, ' ').trim();
  const lista = [];
  if (r.length >= 3 && b) lista.push({ q: `${r}, ${b}`, fonte: 'endereco' });
  if (b) lista.push({ q: b, fonte: 'bairro' });
  return lista;
}

/** Aceita só uma distância plausível. */
const km = (a, b) => {
  if (!a || !b) return null;
  const d = calcularDistanciaKm(a.lat, a.lng, b.lat, b.lng);
  return Number.isFinite(d) && d >= 0 && d <= MAX_KM ? d : null;
};

/**
 * Calcula a distância. `buscar(texto, centro)` devolve {lat,lng} ou null; `gps()` devolve {lat,lng} ou null.
 * Ambos são injetados (o navegador usa fetch/Geolocation; os testes usam dados falsos).
 * Retorna { km, fonte } ou null.
 */
export async function estimarDistancia({ loja, rua, bairro, buscar, gps }) {
  const origem = coordenadasDaLoja(loja);
  if (!origem) return null;
  for (const c of consultasDeEndereco(rua, bairro)) {
    try {
      const d = km(origem, await buscar(c.q, origem));
      if (d !== null) return { km: d, fonte: c.fonte };
    } catch { /* tenta a próxima */ }
  }
  try {
    const d = km(origem, gps ? await gps() : null);
    if (d !== null) return { km: d, fonte: 'gps' };
  } catch { /* sem GPS */ }
  return null;
}

// ---------- Parte do navegador ----------
function buscarNominatim(texto, centro) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TEMPO_MAX_MS);
  return fetch(urlBusca(texto, centro), { signal: ctrl.signal, headers: { Accept: 'application/json' } })
    .then((r) => (r.ok ? r.json() : []))
    .then((lista) => {
      const o = Array.isArray(lista) ? lista[0] : null;
      const lat = coordenada(o?.lat), lng = coordenada(o?.lon);
      return lat !== null && lng !== null ? { lat, lng } : null;
    })
    .finally(() => clearTimeout(t));
}

function posicaoGuardada() {
  try {
    const c = JSON.parse(sessionStorage.getItem('pos_cache_v1') || 'null');
    return c && Number.isFinite(c.lat) && Number.isFinite(c.lng) ? { lat: c.lat, lng: c.lng } : null;
  } catch { return null; }
}

const emAndamento = new Map();

/**
 * Versão do navegador, com cache (localStorage, 30 dias) e uma só consulta por endereço ao mesmo tempo
 * (a tela do carrinho já começa a calcular enquanto o cliente digita; o envio do pedido reaproveita).
 * Sempre resolve (nunca rejeita) em até ~TEMPO_MAX_MS * 2.
 */
export function distanciaParaEndereco({ lojaId, loja, direccion, bairro }) {
  const rua = ruaDoEndereco(direccion, bairro);
  const chave = `${PREFIXO_CACHE}${lojaId}_${slugBairro(bairro)}_${slugBairro(rua)}`;
  try {
    const c = JSON.parse(localStorage.getItem(chave) || 'null');
    if (c && Date.now() - c.t < 30 * 24 * 3600 * 1000 && Number.isFinite(c.km)) return Promise.resolve({ km: c.km, fonte: c.fonte });
  } catch { /* sem cache */ }
  if (emAndamento.has(chave)) return emAndamento.get(chave);
  let relogio;
  const limite = new Promise((r) => { relogio = setTimeout(() => r(null), TEMPO_MAX_MS * 2); });
  const p = Promise.race([
    estimarDistancia({ loja, rua, bairro, buscar: buscarNominatim, gps: async () => posicaoGuardada() }),
    limite
  ]).catch(() => null).then((res) => {
    clearTimeout(relogio);
    emAndamento.delete(chave);
    if (res && res.fonte !== 'gps') { try { localStorage.setItem(chave, JSON.stringify({ ...res, t: Date.now() })); } catch { /* sem storage */ } }
    return res;
  });
  emAndamento.set(chave, p);
  return p;
}
