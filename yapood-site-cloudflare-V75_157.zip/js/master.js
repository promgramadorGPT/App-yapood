// V75.25 — Painel Master. Regras de cálculo ficam em master-util.js (testadas); aqui só tela e gravações.
import { NOTPUSH_API } from './notificaciones-config.js';
import { db, auth, googleProvider, onAuthStateChanged, signInWithPopup, signOut, ref, get, set, update, remove, push, onValue, query, orderByChild, limitToLast } from './firebase.js';
import { escapeHtml as esc, STATUS, normalizarStatus, rotuloStatus, rotuloPagamento, normalizarPagamento, PAGO } from './regras.js';
import { comissaoDoPedido } from './comissao.js';
import * as U from './master-util.js';
import { ehVideo, tagMidia } from './midia.js';
import { RELATO, precisaDoMaster, motivoMasterAlerta, rotuloRelato, montarRespostaRelato, montarReembolsoDoRelato } from './relato.js';
import { masterPodeReembolsar, montarReembolsoMaster, pagoNaEntrega } from './reembolso.js?v=75.145';
import { devolverPeloMercadoPago } from './reembolso-api.js?v=75.145';
import { normalizarWhatsApp, formatarWhatsApp } from './anuncie.js';
import { normalizarHex, derivarTema, contraste, corParaTextoBranco, normalizarSobre, COR_PADRAO, CHAVE_TESTE, SUGESTOES, VARIAVEIS } from './tema-cores.js';
import { iniciarCadastrosMaster } from './master-cadastros.js?v=75.116';
import { iniciarAcertosMaster } from './master-acertos.js';
import { iniciarCidadesMaster } from './master-cidades.js';
import { iniciarRedeMaster } from './master-rede.js?v=75.144';
import { iniciarFaxinaMaster } from './master-faxina.js?v=75.120';
import { iniciarLimitesMaster } from './master-limites.js?v=75.151';
import { liberarCidade } from './cidades-api.js';
import { APPS_ICONE, validarCampanha, situacaoCampanha, urlIconeValida, ladoQuadrado, avisosDoIcone } from './icones-campanha.js';
import { PUB, ROTULO_PUB, montarPublicidade, resumoPublicidade, receitaYapood, registrosDePublicidade } from './financeiro.js';
import { seletorLoja, linkDaLoja, lojaDoLink } from './destino-loja.js?v=75.138';

const $ = (id) => document.getElementById(id);
const BASE = [['hamburguesas', 'Hambúrgueres'], ['pizzería', 'Pizzaria'], ['comida-japonesa', 'Comida japonesa'], ['salados-empanadas', 'Salgados / Empanadas'], ['comida-mexicana', 'Comida mexicana'], ['dulces-postres', 'Doces e sobremesas'], ['bebidas', 'Bebidas'], ['crepes', 'Crepes']];
const TITULOS = { resumen: 'Resumo', pedidos: 'Pedidos', relatos: 'Relatos', cadastros: 'Solicitações', lojas: 'Lojas', cidades: 'Cidades', rede: 'Entrega parceira', usuarios: 'Usuários', financeiro: 'Financeiro', acertos: 'Acertos', marketing: 'Marketing', categorias: 'Categorias', atividade: 'Atividade', limites: 'Limites e planos', configuracion: 'Configuração' };

const S = {
  user: null, entrou: false, view: 'resumen',
  categorias: {}, cadastros: {}, cadastrosOk: false, cidades: {}, listaEspera: {}, demo: null, testadores: {}, lojas: {}, suspensas: {}, banners: {}, aviso: {}, comissao: null, tema: null, publicidade: {},
  limites: {}, icones: {}, pedidos: [], pedidosOk: false, usuarios: {}, usuariosOk: false, bloqueados: {}, admins: {}, log: [], campanhas: [],
  limite: 600, serie: 'pedidos', lojaFiltro: 'todas', usrFiltro: 'todos', vis: { ped: 50, usr: 50 }, gaveta: null, falhas: new Set()
};
let inscricoes = [];
let painelCadastros = null;
let painelAcertos = null;
let painelCidades = null;
let painelRede = null;
let painelLimites = null;
let quadro = 0;

// ---------- utilidades ----------
const BRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const moeda = (v) => BRL.format(Number(v) || 0);
const fmtData = (iso, ano = false) => {
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return '—';
  return new Date(t).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', ...(ano ? { year: 'numeric' } : {}), hour: '2-digit', minute: '2-digit' });
};
function quando(iso) {
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return '—';
  const min = Math.round((Date.now() - t) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return `há ${min} min`;
  if (min < 1440) return `há ${Math.round(min / 60)} h`;
  if (min < 43200) return `há ${Math.round(min / 1440)} d`;
  return fmtData(iso, true).slice(0, 10);
}
const nomeLoja = (id, p) => U.nomeDaLoja(S.lojas, id, p);
const curto = (uid) => (uid ? String(uid).slice(0, 6) + '…' : '—');
const nomeDoCliente = (p) => p?.cliente?.nome || p?.cliente?.nombre || 'Cliente';
function quemEh(uid) {
  const u = S.usuarios[uid];
  const a = S.admins[uid];
  return (u && (u.nome || u.nombre || u.email)) || (a && (a.nome || a.email)) || curto(uid);
}
const selo = (cls, txt) => `<span class="m-selo m-selo-${cls}">${esc(txt)}</span>`;
const vazio = (icone, txt) => `<div class="m-vazio"><i class="fa-solid ${icone}" aria-hidden="true"></i><p>${esc(txt)}</p></div>`;
const seloStatus = (s) => {
  const n = normalizarStatus(s);
  const cls = { [STATUS.PENDENTE]: 'aviso', [STATUS.PREPARANDO]: 'info', [STATUS.ENTREGA]: 'info', [STATUS.ENTREGUE]: 'ok', [STATUS.CANCELADO]: 'off' }[n];
  return selo(cls, rotuloStatus(n));
};

function traduzirErro(e) {
  const m = String(e?.code || e?.message || e);
  if (/permission[_ -]?denied/i.test(m)) return 'O banco recusou a gravação. Confirme se as regras (regras/database.rules.RASCUNHO-V75.73.json) foram publicadas no Firebase.';
  return e?.message || 'Não foi possível concluir.';
}
let tToast = 0;
function aviso(msg, tipo = 'ok') {
  const t = $('m-toast');
  t.textContent = msg;
  t.className = `m-toast m-toast-${tipo}`;
  t.hidden = false;
  clearTimeout(tToast);
  tToast = setTimeout(() => { t.hidden = true; }, tipo === 'erro' ? 7000 : 3500);
}
async function executar(fn, msgOk) {
  try {
    const r = await fn();
    if (msgOk) aviso(msgOk);
    return r === undefined ? true : r;
  } catch (e) {
    console.error(e);
    aviso(traduzirErro(e), 'erro');
    return false;
  }
}
async function logar(acao, alvo = '', detalhe = '') {
  try {
    const r = push(ref(db, 'master_log'));
    await set(r, U.registroLog(S.user, acao, alvo, detalhe));
  } catch (e) { console.warn('log', e); }
}

// ---------- confirmação ----------
let resolverConfirma = null;
function confirmar({ titulo, texto, aviso: av = '', motivo = false, rotulo = 'Confirmar', perigo = false }) {
  return new Promise((resolve) => {
    $('m-confirma-titulo').textContent = titulo;
    $('m-confirma-texto').textContent = texto;
    $('m-confirma-aviso').hidden = !av;
    $('m-confirma-aviso').textContent = av;
    $('m-confirma-motivo-wrap').hidden = !motivo;
    $('m-confirma-motivo').value = '';
    const sim = $('m-confirma-sim');
    sim.textContent = rotulo;
    sim.className = `m-btn ${perigo ? 'm-btn-perigo-cheio' : 'm-btn-principal'}`;
    $('m-confirma').hidden = false;
    resolverConfirma = (ok) => { $('m-confirma').hidden = true; resolverConfirma = null; resolve({ ok, motivo: ok ? $('m-confirma-motivo').value.trim().slice(0, 200) : '' }); };
    (motivo ? $('m-confirma-motivo') : sim).focus();
  });
}
$('m-confirma-sim').addEventListener('click', () => resolverConfirma?.(true));
$('m-confirma-nao').addEventListener('click', () => resolverConfirma?.(false));
$('m-confirma').addEventListener('click', (e) => { if (e.target === $('m-confirma')) resolverConfirma?.(false); });

// ---------- gaveta (detalhes) ----------
function abrirGaveta(tipo, id) { S.gaveta = { tipo, id }; renderGaveta(); $('m-gaveta').hidden = false; $('m-gaveta-fechar').focus(); }
function fecharGaveta() { S.gaveta = null; $('m-gaveta').hidden = true; }
$('m-gaveta-fechar').addEventListener('click', fecharGaveta);
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (resolverConfirma) return resolverConfirma(false);
  if (!$('m-relato').hidden) return fecharRelatoMaster();
  if (!$('m-cadastro').hidden) return painelCadastros?.fechar();
  if (!$('banner-modal').hidden) return closeBannerModal();
  if (!$('categoria-modal').hidden) return closeModal();
  if (S.gaveta) fecharGaveta();
  else fecharMenu();
});

// ---------- navegação ----------
function abrirMenu() { $('m-side').classList.add('aberto'); $('m-veu').hidden = false; $('m-menu').setAttribute('aria-expanded', 'true'); }
function fecharMenu() { $('m-side').classList.remove('aberto'); $('m-veu').hidden = true; $('m-menu').setAttribute('aria-expanded', 'false'); }
function setView(v) {
  if (!TITULOS[v]) v = 'resumen';
  S.view = v;
  document.querySelectorAll('.master-view').forEach((s) => s.classList.toggle('active', s.dataset.section === v));
  document.querySelectorAll('.master-nav').forEach((b) => { const on = b.dataset.view === v; b.classList.toggle('active', on); if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  $('m-titulo').textContent = TITULOS[v];
  document.title = `${TITULOS[v]} · YAPOOD Master`;
  fecharMenu();
  if (location.hash !== '#' + v) history.replaceState(null, '', '#' + v);
  window.scrollTo({ top: 0, behavior: 'auto' });
  renderView(v);
}
$('m-menu').addEventListener('click', () => ($('m-side').classList.contains('aberto') ? fecharMenu() : abrirMenu()));
$('m-veu').addEventListener('click', fecharMenu);
document.querySelectorAll('.master-nav').forEach((b) => b.addEventListener('click', () => setView(b.dataset.view)));

// ---------- dados ----------
function falha(nome) {
  S.falhas.add(nome);
  const nomes = { 'rede/entregadores': 'entregadores da entrega parceira', rede_relatos: 'relatos dos entregadores (regras V75.144)', rede_exclusoes: 'pedidos de exclusão dos entregadores (regras V75.144)', 'rede/liberacao': 'liberação da entrega parceira (regras V75.115)', pedidos: 'pedidos', usuarios: 'usuários', admins: 'equipe', usuarios_bloqueados: 'bloqueios', lojas_suspensas: 'suspensões', master_log: 'atividade', master_campanhas: 'campanhas', lojistas_cadastro: 'solicitações de lojistas', acertos_comissao: 'acertos de comissão', acerto_avisos: 'avisos de pagamento', cidades: 'cidades', lista_espera: 'lista de interessados', 'config_plataforma/demo_cidades': 'modo demonstração', testadores_email: 'testadores' };
  const lista = [...S.falhas].map((n) => nomes[n] || n).join(', ');
  const f = $('m-aviso-dados');
  f.hidden = false;
  f.innerHTML = `<i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i>Sem permissão para ler: <b>${esc(lista)}</b>. Publique no Firebase o arquivo <b>regras/database.rules.RASCUNHO-V75.73.json</b> (Realtime Database → Regras) e atualize.`;
  setSync('Sem permissão', false);
  agendar();
}
function setSync(txt, ok = true) { const s = $('m-sync'); s.textContent = txt; s.className = `m-sync ${ok ? 'm-sync-ok' : 'm-sync-erro'}`; }
function ouvir(caminho, aoReceber, consulta = null, nome = caminho) {
  const alvo = consulta ? consulta(ref(db, caminho)) : ref(db, caminho);
  const off = onValue(alvo, (snap) => { S.falhas.delete(nome); aoReceber(snap.val()); agendar(); }, () => falha(nome));
  inscricoes.push(off);
}
function ouvirPedidos() {
  inscricoes = inscricoes.filter((f) => { if (f.__pedidos) { try { f(); } catch { /* já encerrado */ } return false; } return true; });
  const alvo = query(ref(db, 'pedidos'), orderByChild('criadoEm'), limitToLast(S.limite));
  const off = onValue(alvo, (snap) => {
    S.falhas.delete('pedidos');
    const v = snap.val() || {};
    S.pedidos = Object.entries(v).map(([key, p]) => ({ ...p, key }));
    S.pedidosOk = true;
    if (!S.falhas.size) { $('m-aviso-dados').hidden = true; setSync('Ao vivo'); }
    agendar();
  }, () => falha('pedidos'));
  off.__pedidos = true;
  inscricoes.push(off);
}
async function carregarUsuarios() {
  try {
    S.usuarios = (await get(ref(db, 'usuarios'))).val() || {};
    S.usuariosOk = true; S.falhas.delete('usuarios');
    if (!S.falhas.size) $('m-aviso-dados').hidden = true;
  } catch (e) { console.error(e); falha('usuarios'); }
  agendar();
}
function iniciarDados() {
  encerrarDados();
  setSync('Conectando…');
  ouvir('categorias_loja', (v) => { S.categorias = v || {}; });
  ouvir('restaurantes', (v) => { S.lojas = v || {}; });
  ouvir('cidades', (v) => { S.cidades = v || {}; });
  ouvir('lista_espera', (v) => { S.listaEspera = v || {}; });
  ouvir('config_plataforma/demo_cidades', (v) => { S.demo = v || null; });
  ouvir('testadores_email', (v) => { S.testadores = v || {}; });
  ouvir('banners', (v) => { S.banners = v || {}; });
  ouvir('config_plataforma/limites', (v) => { S.limites = v || {}; });
  ouvir('aviso_app', (v) => { S.aviso = v || {}; });
  ouvir('config_icones', (v) => { S.icones = v || {}; });
  ouvir('config_plataforma/comissao', (v) => { S.comissao = v; });
  ouvir('config_plataforma/push_cupom', (v) => { S.pushCupom = v || {}; });
  ouvir('config_plataforma/anuncie', (v) => { S.anuncie = v || {}; });
  ouvir('config_plataforma/tema', (v) => { S.tema = v || null; });
  ouvir('config_plataforma/sacola', (v) => { S.sacola = v || null; }); // V75.131: cores da barra do carrinho e da sacola
  ouvir('publicidade', (v) => { S.publicidade = v || {}; });
  ouvir('lojas_suspensas', (v) => { S.suspensas = v || {}; });
  ouvir('usuarios_bloqueados', (v) => { S.bloqueados = v || {}; });
  ouvir('admins', (v) => { S.admins = v || {}; });
  ouvir('config_plataforma/acerto', (v) => { S.cfgAcerto = v || {}; });
  ouvir('acertos_comissao', (v) => { S.acertos = v || {}; });
  ouvir('acerto_avisos', (v) => { S.avisosAcerto = v || {}; });
  ouvir('lojistas_cadastro', (v) => { S.cadastros = v || {}; S.cadastrosOk = true; });
  ouvir('rede/entregadores', (v) => { S.redeEnts = v || {}; S.redeEntsOk = true; }); // V75.115: análise dos entregadores (selo no menu)
  // V75.144 (API 2.28): relatos dos entregadores sobre lojas e pedidos de exclusão (LGPD). Leitura só do Master (regras V75.144).
  ouvir('rede_relatos', (v) => { S.redeRelatos = v || {}; S.redeRelatosOk = true; });
  ouvir('rede_exclusoes', (v) => { S.redeExclusoes = v || {}; S.redeExclusoesOk = true; });
  ouvir('rede/liberacao', (v) => { S.redeLib = v; S.redeLibOk = true; });
  ouvir('config_plataforma/contato_dados', (v) => { S.contatoDados = v || null; }); // V75.116: e-mail para assuntos de dados pessoais (LGPD)
  ouvir('master_log', (v) => { S.log = Object.entries(v || {}).map(([id, l]) => ({ ...l, id })).sort((a, b) => String(b.em).localeCompare(String(a.em))); }, (r) => query(r, orderByChild('em'), limitToLast(150)));
  ouvir('master_campanhas', (v) => { S.campanhas = Object.entries(v || {}).map(([id, l]) => ({ ...l, id })).sort((a, b) => String(b.em).localeCompare(String(a.em))); }, (r) => query(r, orderByChild('em'), limitToLast(30)));
  ouvirPedidos();
  carregarUsuarios();
}
function encerrarDados() { inscricoes.forEach((f) => { try { f(); } catch { /* ignora */ } }); inscricoes = []; }

// ---------- renderização ----------
function agendar() {
  if (quadro) return;
  quadro = requestAnimationFrame(() => { quadro = 0; renderView(S.view); renderNavBadge(); if (S.gaveta) renderGaveta(); });
}
function renderView(v) {
  ({
    resumen: renderResumo, pedidos: renderPedidos, relatos: renderRelatos, cadastros: () => painelCadastros?.render(), lojas: renderLojas, cidades: () => painelCidades?.render(), rede: () => painelRede?.render(), usuarios: renderUsuarios, financeiro: renderFinanceiro, acertos: () => painelAcertos?.render(),
    marketing: renderMarketing, categorias: renderCategorias, atividade: renderAtividade, limites: () => painelLimites?.render(), configuracion: renderConfig
  }[v] || (() => {}))();
}
function renderNavBadge() {
  const n = S.pedidos.filter((p) => normalizarStatus(p.status) === STATUS.PENDENTE).length;
  const b = $('nav-badge-pedidos');
  b.hidden = !n; b.textContent = n > 99 ? '99+' : String(n);
  const r = S.pedidos.filter((p) => precisaDoMaster(p)).length;
  const br = $('nav-badge-relatos');
  br.hidden = !r; br.textContent = r > 99 ? '99+' : String(r);
  const nc = painelCadastros ? painelCadastros.pendentes() : 0;
  const bc = $('nav-badge-cadastros');
  bc.hidden = !nc; bc.textContent = nc > 99 ? '99+' : String(nc);
  const na = painelAcertos ? painelAcertos.pendentes() : 0;
  const ba = $('nav-badge-acertos');
  if (ba) { ba.hidden = !na; ba.textContent = na > 99 ? '99+' : String(na); }
  const nr = painelRede ? painelRede.pendentes() : 0;
  const brd = $('nav-badge-rede');
  if (brd) { brd.hidden = !nr; brd.textContent = nr > 99 ? '99+' : String(nr); }
}

const kpi = (rotulo, valor, sub = '', icone = 'fa-chart-line', cor = '') => `<article class="m-kpi ${cor}"><i class="fa-solid ${icone}" aria-hidden="true"></i><span>${esc(rotulo)}</span><strong>${valor}</strong>${sub ? `<small>${sub}</small>` : ''}</article>`;

function renderResumo() {
  const agora = new Date();
  const r = U.resumoGeral(S.pedidos, agora);
  const lojasLista = Object.entries(S.lojas);
  const ativas = lojasLista.filter(([id, l]) => l?.activo !== false && !S.suspensas[id]).length;
  const nUsuarios = Object.keys(S.usuarios).length;
  const nBloq = Object.keys(S.bloqueados).length;
  const carregando = !S.pedidosOk;
  const v = (x) => (carregando ? '—' : x);
  $('kpis').innerHTML = [
    kpi('Vendas hoje', v(moeda(r.hoje.gmv)), `${r.hoje.pedidos} pedido(s)`, 'fa-sack-dollar', 'k-verde'),
    kpi('Vendas · 7 dias', v(moeda(r.d7.gmv)), `${r.d7.pedidos} pedido(s)`, 'fa-calendar-week'),
    kpi('Vendas · 30 dias', v(moeda(r.d30.gmv)), `ticket médio ${moeda(r.d30.ticket)}`, 'fa-calendar-days'),
    kpi('Comissão · 30 dias', v(moeda(r.d30.comissao)), S.comissao?.percentual == null ? 'não definida: veja Configuração' : `${S.comissao.percentual}% · só vale para pedidos feitos depois de definir`, 'fa-percent', 'k-azul'),
    kpi('Pedidos em andamento', v(r.emAndamento), `${r.porStatus[STATUS.PENDENTE]} pendente(s)`, 'fa-bell-concierge', r.porStatus[STATUS.PENDENTE] ? 'k-alerta' : ''),
    kpi('Lojas ativas', `${ativas}<em>/${lojasLista.length}</em>`, `${Object.keys(S.suspensas).filter((id) => S.lojas[id]).length} suspensa(s)`, 'fa-store'),
    kpi('Usuários', S.usuariosOk ? nUsuarios.toLocaleString('pt-BR') : '—', `${nBloq} bloqueado(s)`, 'fa-users'),
    kpi('Cancelados', v(r.porStatus[STATUS.CANCELADO]), 'nos pedidos carregados', 'fa-ban')
  ].join('');

  const serie = U.serieDiaria(S.pedidos, 14, agora);
  const larg = Math.max(300, Math.round($('grafico').clientWidth || 640));
  $('grafico').innerHTML = U.svgSerie(serie, S.serie, { largura: larg, altura: larg < 480 ? 200 : 230 });
  document.querySelectorAll('[data-serie]').forEach((b) => b.classList.toggle('ativo', b.dataset.serie === S.serie));

  const al = U.alertas({ pedidos: S.pedidos, lojas: S.lojas, suspensas: S.suspensas }, agora);
  $('alertas').innerHTML = al.length
    ? al.map((a) => `<button type="button" class="m-alerta m-alerta-${a.nivel}" data-acao="alerta" data-ir="${a.ir}" data-filtro="${esc(a.filtro || '')}" data-status="${esc(a.status || '')}"><i class="fa-solid ${a.icone}" aria-hidden="true"></i><span>${esc(a.texto)}</span><i class="fa-solid fa-chevron-right m-seta" aria-hidden="true"></i></button>`).join('')
    : vazio('fa-circle-check', 'Tudo certo por aqui.');

  const top = U.rankingLojas(S.pedidos, S.lojas, 30, agora, 5);
  const maior = Math.max(1, ...top.map((l) => l.gmv));
  $('top-lojas').innerHTML = top.length
    ? top.map((l, i) => `<button type="button" class="m-rank" data-acao="ver-loja" data-id="${esc(l.lojaId)}"><b>${i + 1}</b><span class="m-rank-nome">${esc(l.nome)}<i style="width:${Math.max(4, (l.gmv / maior) * 100).toFixed(0)}%"></i></span><span class="m-rank-valor">${moeda(l.gmv)}<small>${l.pedidos} ped.</small></span></button>`).join('')
    : vazio('fa-store', 'Ainda sem vendas nos últimos 30 dias.');

  const ult = [...S.pedidos].sort((a, b) => String(b.criadoEm).localeCompare(String(a.criadoEm))).slice(0, 8);
  $('ultimos-pedidos').innerHTML = ult.length
    ? ult.map((p) => `<button type="button" class="m-mini" data-acao="ver-pedido" data-id="${esc(p.key)}"><span><b>#${esc(p.numeroPedido || p.key.slice(-6))}</b> · ${esc(nomeLoja(p.lojaId, p))}<small>${esc(quando(p.criadoEm))} · ${esc(nomeDoCliente(p))}</small></span><span class="m-mini-dir">${moeda(p.total)}${seloStatus(p.status)}</span></button>`).join('')
    : vazio('fa-receipt', 'Nenhum pedido ainda.');

  const datas = S.pedidos.map((p) => p.criadoEm).filter(Boolean).sort();
  $('resumo-base').textContent = S.pedidosOk
    ? `Números calculados com os ${S.pedidos.length.toLocaleString('pt-BR')} pedidos mais recentes carregados${datas.length ? ` (desde ${fmtData(datas[0], true).slice(0, 10)})` : ''}.${S.pedidos.length >= S.limite ? ' Há pedidos mais antigos que não entram na conta — aumente o limite em Pedidos.' : ''}`
    : 'Carregando pedidos…';
}

// --- Pedidos ---
function pedidosFiltrados() {
  const dias = Number($('ped-periodo').value) || 0;
  return U.filtrarPedidos(S.pedidos, { status: $('ped-status').value, lojaId: $('ped-loja').value, busca: $('ped-busca').value, desde: U.inicioPeriodo(dias) });
}
function preencherSelectLojas() {
  const sel = $('ped-loja');
  const atual = sel.value;
  const opcoes = Object.entries(S.lojas).map(([id, l]) => [id, l?.nombre || l?.nome || id]).sort((a, b) => a[1].localeCompare(b[1], 'pt-BR'));
  const html = '<option value="">Todas as lojas</option>' + opcoes.map(([id, n]) => `<option value="${esc(id)}">${esc(n)}</option>`).join('');
  if (sel.dataset.html !== html) { sel.innerHTML = html; sel.dataset.html = html; sel.value = atual; }
}
function renderPedidos() {
  preencherSelectLojas();
  const lista = pedidosFiltrados();
  const mostra = lista.slice(0, S.vis.ped);
  $('pedidos-lista').innerHTML = !S.pedidosOk ? vazio('fa-spinner fa-spin', 'Carregando pedidos…')
    : mostra.length ? `<table class="m-tabela"><thead><tr><th>Pedido</th><th>Loja</th><th>Cliente</th><th>Status</th><th>Pagamento</th><th class="num">Total</th><th></th></tr></thead><tbody>${mostra.map((p) => `<tr data-acao="ver-pedido" data-id="${esc(p.key)}"><td data-label="Pedido"><b>#${esc(p.numeroPedido || p.key.slice(-6))}</b><small>${esc(fmtData(p.criadoEm))}</small></td><td data-label="Da loja">${esc(nomeLoja(p.lojaId, p))}</td><td data-label="Cliente">${esc(nomeDoCliente(p))}</td><td data-label="Status">${seloStatus(p.status)}</td><td data-label="Pagamento">${esc(rotuloPagamento(p.pagoStatus))}</td><td data-label="Total" class="num"><b>${moeda(p.total)}</b></td><td class="acoes"><button type="button" class="m-btn m-btn-leve m-btn-mini" data-acao="ver-pedido" data-id="${esc(p.key)}">Detalhes</button></td></tr>`).join('')}</tbody></table>`
      : vazio('fa-receipt', 'Nenhum pedido encontrado com esses filtros.');
  $('pedidos-contagem').textContent = S.pedidosOk ? `${mostra.length} de ${lista.length} pedido(s) · ${S.pedidos.length} carregados` : '';
  $('ped-mais').hidden = lista.length <= mostra.length;
}

// --- Relatos de problema (V75.35) ---
function relatosDoMaster() {
  const filtro = $('rel-filtro')?.value || 'decidir';
  const lista = S.pedidos.filter((p) => p.relato);
  const f = filtro === 'decidir' ? lista.filter((p) => precisaDoMaster(p)) : filtro === 'abertos' ? lista.filter((p) => p.relato.status === RELATO.ABERTO) : lista;
  return f.sort((a, b) => Number(precisaDoMaster(b)) - Number(precisaDoMaster(a)) || String(b.relato.abertoEm).localeCompare(String(a.relato.abertoEm)));
}
function seloRelato(p) {
  const r = p.relato;
  const cls = { aberto: 'aviso', resolvido: 'ok', reembolsado: 'ok', recusado: 'off' }[r.status] || 'off';
  return selo(cls, rotuloRelato(r)) + (precisaDoMaster(p) ? selo('erro', motivoMasterAlerta(p)) : '') + (r.contestacao && !precisaDoMaster(p) ? selo('info', 'Contestado') : '');
}
function renderRelatos() {
  const lista = relatosDoMaster();
  $('relatos-lista').innerHTML = !S.pedidosOk ? vazio('fa-spinner fa-spin', 'Carregando…')
    : lista.length ? `<table class="m-tabela"><thead><tr><th>Pedido</th><th>Loja</th><th>Cliente</th><th>Problema</th><th>Situação</th><th>Relatado</th><th></th></tr></thead><tbody>${lista.map((p) => `<tr data-acao="ver-relato" data-id="${esc(p.key)}"><td data-label="Pedido"><b>#${esc(p.numeroPedido || p.key.slice(-6))}</b></td><td data-label="Loja">${esc(nomeLoja(p.lojaId, p))}</td><td data-label="Cliente">${esc(nomeDoCliente(p))}</td><td data-label="Problema">${esc(p.relato.motivo || '')}${p.relato.foto ? ' <i class="fa-solid fa-image" title="Tem foto" aria-label="Tem foto"></i>' : ''}</td><td data-label="Situação" class="selos">${seloRelato(p)}</td><td data-label="Relatado">${esc(quando(p.relato.abertoEm))}</td><td class="acoes"><button type="button" class="m-btn m-btn-leve m-btn-mini" data-acao="ver-relato" data-id="${esc(p.key)}">Analisar</button></td></tr>`).join('')}</tbody></table>`
      : vazio('fa-circle-check', $('rel-filtro').value === 'decidir' ? 'Nenhum relato precisa de decisão do Master agora.' : 'Nenhum relato encontrado.');
}
let relatoMasterKey = null;
function abrirRelatoMaster(key) {
  const p = S.pedidos.find((x) => x.key === key);
  if (!p?.relato) { aviso('Relato não encontrado entre os pedidos carregados.', 'erro'); return; }
  const r = p.relato;
  relatoMasterKey = key;
  const online = normalizarPagamento(p.pagoStatus) === PAGO.APROVADO;
  const podeDinheiro = masterPodeReembolsar(p);
  $('mrl-titulo').textContent = `Relato · pedido #${p.numeroPedido || key.slice(-6)}`;
  $('mrl-corpo').innerHTML = `
    <div>${seloRelato(p)}</div>
    <dl class="m-dados">${linhaDado('Loja', esc(nomeLoja(p.lojaId, p)))}${linhaDado('Cliente', esc(nomeDoCliente(p)))}${linhaDado('Total do pedido', moeda(p.total))}${linhaDado('Pagamento', esc(p.formaPagamento || '—') + (online ? '' : ' (na entrega)'))}${linhaDado('Entregue', esc(fmtData(p.entregaConfirmadaEm || p.atualizadoEm, true)))}${linhaDado('Relatado', esc(fmtData(r.abertoEm, true)))}</dl>
    <div><b>${esc(r.motivo || '')}</b><p class="m-citacao">${esc(r.comentario || 'Sem comentário')}</p></div>
    ${r.foto ? `<a href="${esc(r.foto)}" target="_blank" rel="noopener"><img class="m-relato-foto" src="${esc(r.foto)}" alt="Foto enviada pelo cliente" data-oculta></a>` : ''}
    ${r.resposta ? `<div><b>Resposta ${r.respondidoPorTipo === 'master' ? 'do Master' : 'da loja'}</b><p class="m-citacao">${esc(r.resposta)}</p></div>` : ''}
    ${r.valorReembolso ? `<p class="m-nota">Reembolso registrado: ${moeda(r.valorReembolso)}</p>` : ''}
    ${r.contestacao ? `<div><b>O cliente contestou</b><p class="m-citacao">${esc(r.contestacao.comentario)}</p></div>` : ''}
    ${p.reembolso ? `<p class="m-nota">Reembolso do pedido: ${esc(p.reembolso.status)} · ${moeda(p.reembolso.valor)}${p.reembolso.escolha?.tipo === 'saldo' ? ` · o cliente escolheu saldo na loja (${moeda(p.reembolso.escolha.valor)})` : p.reembolso.execucao?.status === 'concluido' && p.reembolso.execucao.tipo === 'saldo' ? ' · devolvido como saldo na loja' : p.reembolso.execucao?.status === 'concluido' ? ' · já devolvido pelo Mercado Pago' : p.reembolso.devolucaoDireta ? (p.reembolso.devolvidoDiretoEm ? ' · devolvido direto pela loja' : ' · a loja devolve direto (pago na entrega)') : ''}</p>` : ''}`;
  $('mrl-resposta').value = '';
  $('mrl-valor').value = (Number(p.total) || 0).toFixed(2);
  $('mrl-valor-wrap').hidden = !podeDinheiro;
  $('mrl-reembolsar').hidden = !podeDinheiro; // V75.109: vale também para pago na entrega (a loja devolve direto)
  const av = $('mrl-aviso');
  av.hidden = false;
  av.textContent = !online ? (podeDinheiro ? 'Pedido pago na entrega: ao reembolsar, a LOJA devolve o valor direto ao cliente (o YAPOOD não envia dinheiro). O valor sai das Finanças da loja e a comissão diminui na mesma proporção.' : 'Pedido pago na entrega ainda não entregue, ou já com reembolso: aqui você só registra a decisão do relato (“Resolvido” ou “Não procede”).')
    : p.reembolso && !podeDinheiro ? 'Este pedido já tem um reembolso aprovado. Aqui você só registra a decisão do relato.'
    : 'Ao reembolsar, o valor é devolvido ao cliente pelo Mercado Pago, com o token da própria loja. A decisão do Master é final para a loja e para o cliente.';
  $('mrl-erro').hidden = true;
  $('m-relato').hidden = false;
  $('mrl-resposta').focus();
}
function fecharRelatoMaster() { $('m-relato').hidden = true; relatoMasterKey = null; }
async function decidirRelatoMaster(modo) {
  const p = S.pedidos.find((x) => x.key === relatoMasterKey);
  if (!p?.relato) return;
  const erro = $('mrl-erro'), botoes = ['mrl-recusar', 'mrl-resolver', 'mrl-reembolsar'].map($);
  erro.hidden = true;
  const por = S.user.uid;
  try {
    botoes.forEach((b) => { b.disabled = true; });
    if (modo === 'reembolsar') {
      const resposta = $('mrl-resposta').value;
      const valor = masterPodeReembolsar(p) ? $('mrl-valor').value : Number(p.total) || 0;
      const patch = montarReembolsoDoRelato({ valor, resposta, por, porTipo: 'master' });
      let devolvido = false, aviso2 = '';
      if (masterPodeReembolsar(p)) {
        const dados = montarReembolsoMaster(p, { valor, motivo: String(resposta || '').trim() || `Relato: ${p.relato.motivo || ''}`, por });
        await set(ref(db, `pedidos/${p.key}/reembolso`), dados);
        await update(ref(db, `pedidos/${p.key}/relato`), patch);
        if (pagoNaEntrega(p)) aviso2 = ' Pedido pago na entrega: a loja devolve o valor direto ao cliente.';
        else if (p.paymentIdMP) {
          try { await devolverPeloMercadoPago(p.key); devolvido = true; }
          catch (e) { aviso2 = ` A devolução automática falhou (${e.message}); a loja pode concluir em “Devolver pelo Mercado Pago”.`; }
        } else aviso2 = ' Pedido pago fora do Mercado Pago: a devolução é direta.';
      } else {
        await update(ref(db, `pedidos/${p.key}/relato`), patch);
      }
      fecharRelatoMaster();
      aviso(devolvido ? 'Reembolso aprovado e devolvido pelo Mercado Pago.' : `Reembolso aprovado.${aviso2}`, aviso2 && !devolvido && !pagoNaEntrega(p) ? 'erro' : 'ok');
      await logar('relato.decidir', `#${p.numeroPedido || p.key}`, `reembolso ${moeda(valor)}`);
    } else {
      const patch = montarRespostaRelato(p.relato, { decisao: modo === 'recusar' ? RELATO.RECUSADO : RELATO.RESOLVIDO, resposta: $('mrl-resposta').value, por, porTipo: 'master' });
      await update(ref(db, `pedidos/${p.key}/relato`), patch);
      fecharRelatoMaster();
      aviso('Decisão registrada. O cliente e a loja já veem a resposta.');
      await logar('relato.decidir', `#${p.numeroPedido || p.key}`, modo === 'recusar' ? 'não procede' : 'resolvido');
    }
  } catch (e) {
    console.warn('Relato:', e);
    erro.textContent = e?.message && !/permission/i.test(e.message) ? e.message : traduzirErro(e);
    erro.hidden = false;
  } finally { botoes.forEach((b) => { b.disabled = false; }); }
}
$('mrl-fechar').addEventListener('click', fecharRelatoMaster);
$('m-relato').addEventListener('click', (e) => { if (e.target === $('m-relato')) fecharRelatoMaster(); });
$('mrl-recusar').addEventListener('click', () => decidirRelatoMaster('recusar'));
$('mrl-resolver').addEventListener('click', () => decidirRelatoMaster('resolver'));
$('mrl-reembolsar').addEventListener('click', () => decidirRelatoMaster('reembolsar'));
$('rel-filtro').addEventListener('change', renderRelatos);

// --- Lojas ---
function renderLojas() {
  const todas = U.filtrarLojas(S.lojas, S.suspensas, { busca: '', estado: 'todas' });
  const cont = { todas: todas.length, ativa: 0, inativa: 0, suspensa: 0 };
  todas.forEach((l) => { cont[l.estado]++; });
  $('loja-chips').innerHTML = [['todas', 'Todas'], ['ativa', 'Ativas'], ['inativa', 'Desativadas'], ['suspensa', 'Suspensas']].map(([k, n]) => `<button type="button" class="m-chip${S.lojaFiltro === k ? ' ativo' : ''}" data-chip-loja="${k}" aria-pressed="${S.lojaFiltro === k}">${n} <b>${cont[k]}</b></button>`).join('');
  const lista = U.filtrarLojas(S.lojas, S.suspensas, { busca: $('loja-busca').value, estado: S.lojaFiltro });
  const desde = U.inicioPeriodo(30);
  const desemp = new Map(U.desempenhoPorLoja(S.pedidos, S.lojas, desde).map((d) => [d.lojaId, d]));
  const rotulo = { ativa: ['ok', 'Ativa'], inativa: ['off', 'Desativada'], suspensa: ['erro', 'Suspensa'] };
  $('lojas-lista').innerHTML = lista.length
    ? `<table class="m-tabela"><thead><tr><th>Loja</th><th>Estado</th><th class="num">Pedidos · 30d</th><th class="num">Vendas · 30d</th><th class="num">Comissão · 30d</th><th></th></tr></thead><tbody>${lista.map((l) => {
      const d = desemp.get(l.id) || { pedidos: 0, gmv: 0, comissao: 0 };
      const logo = l.logo || l.foto;
      return `<tr data-acao="ver-loja" data-id="${esc(l.id)}"><td data-label="Loja"><span class="m-id">${logo ? `<img src="${esc(logo)}" alt="" data-oculta>` : '<i class="fa-solid fa-store" aria-hidden="true"></i>'}<span><b>${esc(l.nombre || l.nome || 'Sem nome')}</b><small>${esc(nomeCategoria(l))}</small></span></span></td><td data-label="Estado">${selo(...rotulo[l.estado])}</td><td data-label="Pedidos · 30d" class="num">${d.pedidos}</td><td data-label="Vendas · 30d" class="num">${moeda(d.gmv)}</td><td data-label="Comissão · 30d" class="num">${moeda(d.comissao)}</td><td class="acoes"><button type="button" class="m-btn m-btn-leve m-btn-mini" data-acao="ver-loja" data-id="${esc(l.id)}">Gerenciar</button></td></tr>`;
    }).join('')}</tbody></table>`
    : vazio('fa-store', Object.keys(S.lojas).length ? 'Nenhuma loja com esses filtros.' : 'Não há lojas cadastradas.');
}
function nomeCategoria(l) { const id = l.categoria || l.categoriaId; return S.categorias[id]?.nombre || id || 'Sem categoria'; }

// --- Usuários ---
function listaUsuarios() { return U.listarUsuarios(S.usuarios, S.pedidos, { bloqueados: S.bloqueados, lojas: S.lojas, admins: S.admins }); }
function renderUsuarios() {
  const todos = listaUsuarios();
  const cont = { todos: todos.length, clientes: todos.filter((u) => !u.dono).length, donos: todos.filter((u) => u.dono).length, bloqueados: todos.filter((u) => u.bloqueado).length, masters: todos.filter((u) => u.master).length };
  $('usr-chips').innerHTML = [['todos', 'Todos'], ['clientes', 'Clientes'], ['donos', 'Donos de loja'], ['bloqueados', 'Bloqueados'], ['masters', 'Masters']].map(([k, n]) => `<button type="button" class="m-chip${S.usrFiltro === k ? ' ativo' : ''}" data-chip-usr="${k}" aria-pressed="${S.usrFiltro === k}">${n} <b>${cont[k]}</b></button>`).join('');
  const lista = U.filtrarUsuarios(todos, { busca: $('usr-busca').value, filtro: S.usrFiltro });
  const mostra = lista.slice(0, S.vis.usr);
  $('usuarios-lista').innerHTML = !S.usuariosOk ? vazio('fa-spinner fa-spin', 'Carregando usuários…')
    : mostra.length ? `<table class="m-tabela"><thead><tr><th>Usuário</th><th>Perfil</th><th class="num">Pedidos*</th><th class="num">Gasto*</th><th>Último pedido*</th><th></th></tr></thead><tbody>${mostra.map((u) => `<tr data-acao="ver-usuario" data-id="${esc(u.uid)}"><td data-label="Usuário"><span class="m-id">${u.foto ? `<img src="${esc(u.foto)}" alt="" data-oculta referrerpolicy="no-referrer">` : '<i class="fa-solid fa-circle-user" aria-hidden="true"></i>'}<span><b>${esc(u.nome || 'Sem nome')}</b><small>${esc(u.email || curto(u.uid))}</small></span></span></td><td data-label="Perfil" class="selos">${u.master ? selo('azul', 'Master') : ''}${u.dono ? selo('info', 'Dono de loja') : ''}${u.bloqueado ? selo('erro', 'Bloqueado') : ''}${!u.master && !u.dono && !u.bloqueado ? selo('off', 'Cliente') : ''}</td><td data-label="Pedidos*" class="num">${u.pedidos}</td><td data-label="Gasto*" class="num">${moeda(u.gasto)}</td><td data-label="Último pedido*">${u.ultimo ? esc(quando(u.ultimo)) : '—'}</td><td class="acoes"><button type="button" class="m-btn m-btn-leve m-btn-mini" data-acao="ver-usuario" data-id="${esc(u.uid)}">Gerenciar</button></td></tr>`).join('')}</tbody></table><p class="m-nota">* Considera só os pedidos carregados em “Pedidos”.</p>`
      : vazio('fa-users', 'Nenhum usuário encontrado.');
  $('usuarios-contagem').textContent = S.usuariosOk ? `${mostra.length} de ${lista.length} usuário(s)` : '';
  $('usr-mais').hidden = lista.length <= mostra.length;
}

// --- Financeiro ---
function linhasFinanceiro() {
  const dias = Number($('fin-periodo').value) || 0;
  return U.desempenhoPorLoja(S.pedidos, S.lojas, U.inicioPeriodo(dias), { incluirVazias: true }).sort((a, b) => b.gmv - a.gmv || a.nome.localeCompare(b.nome, 'pt-BR'));
}
const dataBR = (d) => (/^\d{4}-\d{2}-\d{2}$/.test(String(d || '')) ? String(d).split('-').reverse().join('/') : '—');
const hojeISO = () => new Date(Date.now() - 3 * 3600000).toISOString().slice(0, 10);
function periodoFin() {
  const dias = Number($('fin-periodo').value) || 0;
  const ini = U.inicioPeriodo(dias);
  return { dias, desde: ini ? ini.slice(0, 10) : '' };
}
function renderFinanceiro() {
  const linhas = linhasFinanceiro();
  const t = U.totaisFinanceiro(linhas);
  const { desde } = periodoFin();
  const pub = resumoPublicidade(registrosDePublicidade(S.publicidade), { desde });
  const rec = receitaYapood({ comissao: t.comissao, publicidadePaga: pub.pago });
  const semPct = S.comissao?.percentual == null || Number(S.comissao.percentual) === 0;
  $('fin-aviso').hidden = !semPct;
  $('fin-aviso').innerHTML = S.comissao?.percentual == null ? '<i class="fa-solid fa-circle-info" aria-hidden="true"></i> A comissão da plataforma ainda não foi definida (0%). Defina em <b>Configuração</b>: ela só vale para pedidos feitos depois, os anteriores continuam com comissão zero.' : '<i class="fa-solid fa-circle-info" aria-hidden="true"></i> A comissão está em 0%.';
  $('fin-kpis-vendas').innerHTML = [
    kpi('Vendas das lojas', moeda(t.gmv), `${t.pedidos} pedido(s) · ${t.cancelados} cancelado(s)`, 'fa-sack-dollar', 'k-verde'),
    kpi('Ticket médio', moeda(t.pedidos ? t.gmv / t.pedidos : 0), 'por pedido', 'fa-receipt')
  ].join('');
  $('fin-kpis').innerHTML = [
    kpi('Comissão já separada', moeda(t.comissaoSplit), 'repassada pelo Mercado Pago', 'fa-circle-check'),
    kpi('Comissão a acertar', moeda(t.comissaoAcertar), 'pagamentos na entrega', 'fa-hand-holding-dollar', t.comissaoAcertar > 0 ? 'k-alerta' : ''),
    kpi('Publicidade paga', moeda(pub.pago), `${pub.qtd} anúncio(s) no período`, 'fa-bullhorn', 'k-azul'),
    kpi('Publicidade a receber', moeda(pub.pendente), 'vendida e ainda não paga', 'fa-clock', pub.pendente > 0 ? 'k-alerta' : ''),
    kpi('Receita do YAPOOD', moeda(rec.total), `comissão ${moeda(rec.comissao)} + publicidade paga ${moeda(rec.publicidade)}`, 'fa-coins', 'k-verde')
  ].join('');
  $('fin-lista').innerHTML = !S.pedidosOk ? vazio('fa-spinner fa-spin', 'Carregando pedidos…')
    : `<table class="m-tabela"><thead><tr><th>Loja</th><th class="num">Pedidos</th><th class="num">Vendas</th><th class="num">Ticket</th><th class="num">Já separada</th><th class="num">A acertar</th><th class="num">Comissão</th></tr></thead><tbody>${linhas.map((l) => `<tr data-acao="ver-loja" data-id="${esc(l.lojaId)}"><td data-label="Loja"><b>${esc(l.nome)}</b></td><td data-label="Pedidos" class="num">${l.pedidos}</td><td data-label="Vendas" class="num">${moeda(l.gmv)}</td><td data-label="Ticket" class="num">${moeda(l.ticket)}</td><td data-label="Já separada" class="num">${moeda(l.comissaoSplit)}</td><td data-label="A acertar" class="num">${moeda(l.comissaoAcertar)}</td><td data-label="Comissão" class="num"><b>${moeda(l.comissao)}</b></td></tr>`).join('')}</tbody><tfoot><tr><td>Total</td><td class="num">${t.pedidos}</td><td class="num">${moeda(t.gmv)}</td><td class="num">${moeda(t.pedidos ? t.gmv / t.pedidos : 0)}</td><td class="num">${moeda(t.comissaoSplit)}</td><td class="num">${moeda(t.comissaoAcertar)}</td><td class="num"><b>${moeda(t.comissao)}</b></td></tr></tfoot></table>`;
  renderPublicidade();
}

// --- Publicidade vendida pelo YAPOOD (receita à parte) ---
function preencherLojasPublicidade() {
  const sel = $('pub-loja');
  const atual = sel.value;
  const opcoes = Object.entries(S.lojas).map(([id, l]) => [id, l?.nombre || l?.nome || id]).sort((a, b) => a[1].localeCompare(b[1], 'pt-BR'));
  const html = '<option value="">Não é uma loja cadastrada</option>' + opcoes.map(([id, n]) => `<option value="${esc(id)}">${esc(n)}</option>`).join('');
  if (sel.dataset.html !== html) { sel.innerHTML = html; sel.dataset.html = html; sel.value = atual; }
}
function renderPublicidade() {
  preencherLojasPublicidade();
  if (!$('pub-data').value) $('pub-data').value = hojeISO();
  const lista = registrosDePublicidade(S.publicidade);
  const cls = { [PUB.PAGO]: 'ok', [PUB.PENDENTE]: 'aviso', [PUB.CANCELADO]: 'off' };
  $('pub-lista').innerHTML = !lista.length
    ? (S.falhas.has('publicidade') ? vazio('fa-lock', 'Sem permissão para ler a publicidade. Publique as regras (regras/database.rules.RASCUNHO-V75.73.json).') : vazio('fa-bullhorn', 'Nenhum anúncio registrado ainda.'))
    : `<table class="m-tabela"><thead><tr><th>Anunciante</th><th>Período</th><th class="num">Valor</th><th>Situação</th><th></th></tr></thead><tbody>${lista.map((a) => {
      const per = a.inicioEm || a.fimEm ? `${dataBR(a.inicioEm)} a ${dataBR(a.fimEm)}` : `vendido em ${dataBR(a.data)}`;
      const lj = a.lojaId && S.lojas[a.lojaId] ? ` · loja ${esc(S.lojas[a.lojaId].nombre || S.lojas[a.lojaId].nome || a.lojaId)}` : '';
      const acoes = [
        a.status !== PUB.PAGO ? `<button type="button" class="m-btn m-btn-leve m-btn-mini" data-pub="pago" data-id="${esc(a.id)}">Marcar como pago</button>` : '',
        a.status === PUB.PAGO ? `<button type="button" class="m-btn m-btn-leve m-btn-mini" data-pub="pendente" data-id="${esc(a.id)}">Voltar p/ a receber</button>` : '',
        a.status !== PUB.CANCELADO ? `<button type="button" class="m-btn m-btn-leve m-btn-mini" data-pub="cancelado" data-id="${esc(a.id)}">Cancelar</button>` : '',
        `<button type="button" class="m-btn m-btn-perigo m-btn-mini" data-pub="excluir" data-id="${esc(a.id)}"><i class="fa-solid fa-trash" aria-hidden="true"></i> Excluir</button>`
      ].join('');
      return `<tr><td data-label="Anunciante"><b>${esc(a.anunciante)}</b><small>${esc(a.descricao || '')}${lj}</small></td><td data-label="Período">${esc(per)}</td><td data-label="Valor" class="num"><b>${moeda(a.valor)}</b></td><td data-label="Situação">${selo(cls[a.status] || 'aviso', ROTULO_PUB[a.status] || 'A receber')}</td><td class="acoes"><span class="m-camp-acoes">${acoes}</span></td></tr>`;
    }).join('')}</tbody></table>`;
}
$('form-publicidade').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = $('pub-status-msg');
  let reg;
  try {
    reg = montarPublicidade({ anunciante: $('pub-anunciante').value, lojaId: $('pub-loja').value, descricao: $('pub-descricao').value, valor: $('pub-valor').value, status: $('pub-status').value, data: $('pub-data').value, inicioEm: $('pub-inicio').value, fimEm: $('pub-fim').value });
  } catch (err) { msg.dataset.fixo = '1'; msg.textContent = err.message; return; }
  delete msg.dataset.fixo; msg.textContent = '';
  const c = await confirmar({ titulo: 'Registrar este anúncio?', texto: `${reg.anunciante} · ${moeda(reg.valor)} · ${ROTULO_PUB[reg.status]}. Entra na receita de publicidade do YAPOOD, separada da comissão e das vendas das lojas.`, rotulo: 'Registrar' });
  if (!c.ok) return;
  const agora = agoraIso();
  const dado = { ...reg, criadoEm: agora, criadoPor: S.user?.uid || '', ...(reg.status === PUB.PAGO ? { pagoEm: agora } : {}) };
  if (await executar(() => set(push(ref(db, 'publicidade')), dado), 'Anúncio registrado.')) {
    await logar('publicidade.criar', reg.anunciante, `${moeda(reg.valor)} · ${ROTULO_PUB[reg.status]}`);
    ['pub-anunciante', 'pub-descricao', 'pub-valor', 'pub-inicio', 'pub-fim'].forEach((i) => { $(i).value = ''; });
    $('pub-loja').value = ''; $('pub-status').value = PUB.PENDENTE;
  }
});
$('pub-lista').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-pub]');
  if (!b) return;
  const a = S.publicidade[b.dataset.id];
  if (!a) return;
  const acao = b.dataset.pub;
  if (acao === 'excluir') {
    const c = await confirmar({ titulo: 'Excluir este anúncio?', texto: `${a.anunciante} · ${moeda(a.valor)} some da receita e do painel da loja. Se foi só um engano de status, prefira “Cancelar”.`, rotulo: 'Excluir', perigo: true });
    if (!c.ok) return;
    if (await executar(() => remove(ref(db, `publicidade/${b.dataset.id}`)), 'Anúncio excluído.')) await logar('publicidade.excluir', a.anunciante, moeda(a.valor));
    return;
  }
  const texto = { pago: 'Confirma que o pagamento deste anúncio foi recebido?', pendente: 'O anúncio volta a ficar “a receber”.', cancelado: 'O anúncio deixa de contar na receita.' }[acao];
  const c = await confirmar({ titulo: `${a.anunciante} · ${moeda(a.valor)}`, texto, rotulo: acao === 'pago' ? 'Marcar como pago' : acao === 'pendente' ? 'Voltar para a receber' : 'Cancelar anúncio', perigo: acao === 'cancelado' });
  if (!c.ok) return;
  const agora = agoraIso();
  if (await executar(() => update(ref(db, `publicidade/${b.dataset.id}`), { status: acao, atualizadoEm: agora, pagoEm: acao === 'pago' ? agora : null }), 'Anúncio atualizado.')) await logar('publicidade.status', a.anunciante, `${ROTULO_PUB[acao]} · ${moeda(a.valor)}`);
});
$('fin-csv').addEventListener('click', () => {
  const csv = U.csvFinanceiro(linhasFinanceiro());
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url; a.download = `financeiro-yapood-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
});

// --- Atividade / Campanhas / Equipe ---
function renderAtividade() {
  $('atividade-lista').innerHTML = S.log.length
    ? `<ul class="m-linha-tempo">${S.log.map((l) => `<li><i class="fa-solid fa-circle" aria-hidden="true"></i><div><b>${esc(U.ROTULO_ACAO[l.acao] || l.acao)}</b>${l.alvo ? ` · <span>${esc(l.alvo)}</span>` : ''}${l.detalhe ? `<small>${esc(l.detalhe)}</small>` : ''}<small>${esc(l.porEmail || quemEh(l.por))} · ${esc(fmtData(l.em, true))}</small></div></li>`).join('')}</ul>`
    : vazio('fa-clipboard-list', S.falhas.has('master_log') ? 'Sem permissão para ler a atividade.' : 'Nenhuma ação registrada ainda.');
}
function renderCampanhas() {
  $('campanhas-lista').innerHTML = S.campanhas.length
    ? `<ul class="m-linha-tempo">${S.campanhas.map((c) => `<li><i class="fa-solid fa-paper-plane" aria-hidden="true"></i><div><b>${esc(c.titulo)}</b><span>${esc(c.corpo)}</span><small>${esc(fmtData(c.em, true))} · ${c.enviados != null ? `${Number(c.enviados) || 0} aparelho(s)` : 'enviada'} · ${esc(c.porEmail || quemEh(c.por))}</small><span class="m-camp-acoes"><button type="button" class="m-btn m-btn-leve m-btn-mini" data-camp-reenviar="${esc(c.id)}"><i class="fa-solid fa-rotate-right" aria-hidden="true"></i> Reenviar</button><button type="button" class="m-btn m-btn-perigo m-btn-mini" data-camp-excluir="${esc(c.id)}"><i class="fa-solid fa-trash" aria-hidden="true"></i> Remover do histórico</button></span></div></li>`).join('')}</ul>`
    : vazio('fa-paper-plane', 'Nenhuma campanha enviada ainda.');
}
function renderEquipe() {
  const itens = Object.entries(S.admins).filter(([, a]) => a?.role === 'master');
  $('equipe-lista').innerHTML = itens.length
    ? `<table class="m-tabela"><thead><tr><th>Master</th><th>UID</th><th>Adicionado</th><th></th></tr></thead><tbody>${itens.map(([uid, a]) => {
      const eu = uid === S.user?.uid;
      const u = S.usuarios[uid] || {};
      return `<tr><td data-label="Master"><b>${esc(a.nome || u.nome || a.email || u.email || 'Master')}</b>${eu ? ' ' + selo('azul', 'Você') : ''}<small>${esc(a.email || u.email || '')}</small></td><td data-label="UID" class="m-mono">${esc(uid)}</td><td data-label="Adicionado">${a.addedAt ? esc(fmtData(a.addedAt, true)) : 'Cadastro inicial'}</td><td class="acoes">${eu ? '' : `<button type="button" class="m-btn m-btn-perigo m-btn-mini" data-acao="master-remover" data-id="${esc(uid)}">Remover</button>`}</td></tr>`;
    }).join('')}</tbody></table>`
    : vazio('fa-user-shield', S.falhas.has('admins') ? 'Sem permissão para ler a equipe.' : 'Nenhum Master listado.');
}

// --- Configuração ---
function renderConfig() {
  const u = S.user;
  $('cfg-google').textContent = u?.email || '—';
  $('cfg-uid').textContent = u?.uid || '—';
  $('cfg-auth').textContent = u ? 'Autenticado' : '—';
  const c = S.comissao || {};
  const i = $('comissao-percentual');
  if (i && document.activeElement !== i) i.value = c.percentual ?? '';
  const s = $('comissao-status');
  if (s && !s.dataset.fixo) s.textContent = c.percentual != null ? `Valendo: ${c.percentual}%${c.atualizadoEm ? ` · desde ${fmtData(c.atualizadoEm, true)}` : ''}` : 'Ainda não definida (comissão 0%).';
  const cd = $('contato-dados-email'), cs = $('contato-dados-status');
  if (cd && document.activeElement !== cd && !cd.dataset.sujo) cd.value = S.contatoDados?.email || '';
  if (cs && !cs.dataset.fixo) cs.textContent = S.contatoDados?.email ? `Valendo desde ${fmtData(S.contatoDados.atualizadoEm, true)}.` : 'Ainda não definido: as telas apontam para o suporte.';
  const pc = S.pushCupom || {};
  const pa = $('push-cupom-ativo'), pl = $('push-cupom-limite'), ps = $('push-cupom-status');
  if (pa && document.activeElement !== pa) pa.checked = pc.ativo !== false;
  if (pl && document.activeElement !== pl) pl.value = pc.limiteDiario ?? 5000;
  if (ps && !ps.dataset.fixo) ps.textContent = pc.ativo === false ? 'Desligado.' : `Ligado · teto de ${pc.limiteDiario ?? 5000} aparelhos por dia.`;
  const an = S.anuncie || {};
  const aa = $('anuncie-ativo'), aw = $('anuncie-whatsapp'), as = $('anuncie-suporte'), at = $('anuncie-status');
  if (aa && document.activeElement !== aa) aa.checked = an.ativo !== false;
  if (aw && document.activeElement !== aw) aw.value = an.whatsapp ? formatarWhatsApp(an.whatsapp) : '';
  if (as && document.activeElement !== as) as.value = an.suporte ? formatarWhatsApp(an.suporte) : '';
  if (at && !at.dataset.fixo) at.textContent = !an.whatsapp ? 'Sem WhatsApp cadastrado: o convite e o rodapé não aparecem para as lojas.' : an.ativo === false ? 'Desligado.' : `Ligado · comercial ${formatarWhatsApp(an.whatsapp)}${an.suporte ? ` · suporte ${formatarWhatsApp(an.suporte)}` : ''}.`;
  renderTema();
  renderSacola();
  renderEquipe();
}

// --- Marketing ---
// V75.138: "Levar para" uma loja no aviso principal e na notificação push
function atualizarDestino(q) { const loja = $(`${q}-destino`).value === 'loja'; $(`${q}-loja-wrap`).hidden = !loja; $(`${q}-link-wrap`).hidden = loja; (q === 'aviso' ? selAviso : selPush).atualizar(); }
const selAviso = seletorLoja($('aviso-loja-wrap'), { lojas: () => S.lojas, dica: (n) => `Ao tocar no aviso, o cliente abre a página da ${n}.` });
const selPush = seletorLoja($('notify-loja-wrap'), { lojas: () => S.lojas, dica: (n) => `Ao tocar na notificação, o cliente abre a página da ${n}.` });
$('aviso-destino').addEventListener('change', () => atualizarDestino('aviso'));
$('notify-destino').addEventListener('change', () => atualizarDestino('notify'));
function renderAviso() {
  const a = S.aviso || {};
  const ativo = a.ativo === true;
  const est = $('aviso-estado');
  est.textContent = ativo ? 'Ativo' : 'Inativo';
  est.className = `m-selo m-selo-${ativo ? 'ok' : 'off'}`;
  const campos = [['aviso-titulo', a.titulo], ['aviso-descripcion', a.descripcion], ['aviso-link', a.link]];
  if (!$('aviso-form').contains(document.activeElement)) {
    campos.forEach(([id, v]) => { $(id).value = v || ''; });
    $('aviso-activo').checked = ativo;
    const lj = lojaDoLink(a.link); // V75.138: aviso que leva a uma loja abre com a loja escolhida
    $('aviso-destino').value = lj && S.lojas[lj] ? 'loja' : 'link'; selAviso.definir(lj); atualizarDestino('aviso');
  }
  $('aviso-preview').innerHTML = a.img ? tagMidia(a.img, { alt: 'Prévia do aviso', extra: 'data-oculta controls' }) : '<small>Sem imagem configurada.</small>';
}
function renderBanners() {
  const rows = Object.entries(S.banners).map(([id, b]) => ({ id, ...(b || {}) })).sort((a, b) => (Number(a.orden) || 0) - (Number(b.orden) || 0));
  $('banners-lista').innerHTML = rows.length
    ? `<table class="m-tabela"><thead><tr><th>Banner</th><th>Período</th><th>Estado</th><th class="num">Ordem</th><th></th></tr></thead><tbody>${rows.map((b) => {
      const periodo = [b.inicio, b.fim].filter(Boolean).map((d) => fmtData(d, true)).join(' → ') || 'Sem limite';
      const no = U.bannerDentroDoPeriodo(b);
      return `<tr><td data-label="Banner"><span class="m-id">${b.img ? tagMidia(b.img, { classe: 'm-id-largo', tocar: false, extra: 'data-oculta' }) : ''}<span><b>${esc(b.titulo || 'Só imagem')}</b>${b.descripcion ? `<small>${esc(b.descripcion)}</small>` : ''}</span></span></td><td data-label="Período">${esc(periodo)}</td><td data-label="Estado">${b.activo === false ? selo('off', 'Inativo') : no ? selo('ok', 'No ar') : selo('aviso', 'Fora do período')}</td><td data-label="Ordem" class="num">${Number(b.orden) || 0}</td><td class="acoes"><button type="button" class="m-btn m-btn-leve m-btn-mini" data-banner-edit="${esc(b.id)}">Editar</button><button type="button" class="m-btn m-btn-leve m-btn-mini" data-banner-toggle="${esc(b.id)}">${b.activo === false ? 'Ativar' : 'Desativar'}</button><button type="button" class="m-btn m-btn-perigo m-btn-mini" data-banner-delete="${esc(b.id)}">Excluir</button></td></tr>`;
    }).join('')}</tbody></table>`
    : vazio('fa-images', 'Não há banners criados ainda.');
}
// --- Ícones por data (V75.68) ---
const RASC_ICONE = {}; // imagem enviada mas ainda não salva, por app
let iconesSujo = false; // há algo digitado e não salvo: não redesenhar por cima
const ROTULO_SIT = { 'no-ar': ['ok', 'No ar'], agendada: ['info', 'Agendada'], encerrada: ['off', 'Encerrada'], nenhuma: ['off', 'Padrão'] };
function cartaoIcone(a) {
  const c = S.icones?.[a.id] || {};
  const sit = situacaoCampanha(c);
  const [cls, txt] = ROTULO_SIT[sit];
  const url = RASC_ICONE[a.id] || (urlIconeValida(c.url) ? c.url : '');
  return `<div class="icone-app" data-icone-app="${esc(a.id)}">
    <div class="icone-app-topo"><b>${esc(a.nome)}</b>${selo(cls, txt)}</div>
    <div class="icone-par"><figure><img src="${esc(a.padrao)}" alt="Ícone padrão"><span>Padrão</span></figure><figure><img data-icone-previa src="${esc(url || a.padrao)}" alt="Ícone da data"${url ? '' : ' style="opacity:.35"'}><span>${url ? 'Da data' : 'Sem imagem'}</span></figure></div>
    <label>Imagem (quadrada)<input type="file" accept="image/png,image/jpeg,image/webp" data-icone-arquivo></label>
    <small class="icone-aviso" data-icone-avisos hidden></small>
    <label>Nome da data<input type="text" maxlength="40" placeholder="Ex.: Dia das Crianças" value="${esc(c.rotulo || '')}" data-icone-rotulo></label>
    <div class="icone-datas"><label>De<input type="date" value="${esc(c.de || '')}" data-icone-de></label><label>Até<input type="date" value="${esc(c.ate || '')}" data-icone-ate></label></div>
    <div class="icone-acoes"><button type="button" class="m-btn m-btn-principal m-btn-mini" data-icone-salvar="${esc(a.id)}"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar</button><button type="button" class="m-btn m-btn-leve m-btn-mini" data-icone-voltar="${esc(a.id)}"${c.url ? '' : ' disabled'}><i class="fa-solid fa-rotate-left" aria-hidden="true"></i> Voltar ao padrão</button></div>
  </div>`;
}
function renderIcones() {
  const lista = $('icones-data-lista');
  if (!lista || iconesSujo || lista.contains(document.activeElement)) return;
  lista.innerHTML = APPS_ICONE.map(cartaoIcone).join('');
}
/** Corta no centro em quadrado (até 512 px) e devolve PNG: o ícone nunca fica esticado nem pesado. */
async function quadrarImagem(file) {
  const bmp = await createImageBitmap(file);
  const lado = ladoQuadrado(bmp.width, bmp.height);
  const menor = Math.min(bmp.width, bmp.height);
  const cv = document.createElement('canvas'); cv.width = cv.height = lado;
  cv.getContext('2d').drawImage(bmp, (bmp.width - menor) / 2, (bmp.height - menor) / 2, menor, menor, 0, 0, lado, lado);
  const blob = await new Promise((ok, no) => cv.toBlob((b) => (b ? ok(b) : no(new Error('Não foi possível preparar a imagem.'))), 'image/png'));
  return { arquivo: new File([blob], 'icone.png', { type: 'image/png' }), avisos: avisosDoIcone(bmp.width, bmp.height) };
}
$('icones-data-lista').addEventListener('input', () => { iconesSujo = true; });
$('icones-data-lista').addEventListener('change', async (e) => {
  iconesSujo = true;
  const inp = e.target.closest('[data-icone-arquivo]');
  const cartao = e.target.closest('[data-icone-app]');
  if (!inp || !cartao || !inp.files?.[0]) return;
  const id = cartao.dataset.iconeApp;
  const dica = cartao.querySelector('[data-icone-avisos]');
  try {
    dica.hidden = false; dica.textContent = 'Enviando a imagem…';
    const { arquivo, avisos } = await quadrarImagem(inp.files[0]);
    RASC_ICONE[id] = await enviarImagem(arquivo);
    const prev = cartao.querySelector('[data-icone-previa]'); prev.src = RASC_ICONE[id]; prev.style.opacity = '';
    dica.textContent = avisos.length ? avisos.join(' ') + ' Clique em Salvar para valer.' : 'Imagem enviada. Clique em Salvar para valer.';
  } catch (err) { console.error(err); dica.textContent = ''; dica.hidden = true; aviso(traduzirErro(err), 'erro'); }
});
$('icones-data-lista').addEventListener('click', async (e) => {
  const salvar = e.target.closest('[data-icone-salvar]'), voltar = e.target.closest('[data-icone-voltar]');
  if (salvar) {
    const id = salvar.dataset.iconeSalvar, cartao = salvar.closest('[data-icone-app]');
    const atual = S.icones?.[id] || {};
    const v = validarCampanha({ app: id, url: RASC_ICONE[id] || atual.url, de: cartao.querySelector('[data-icone-de]').value, ate: cartao.querySelector('[data-icone-ate]').value, rotulo: cartao.querySelector('[data-icone-rotulo]').value });
    if (!v.ok) { aviso(v.erro, 'erro'); return; }
    if (await executar(() => set(ref(db, `config_icones/${id}`), v.dados), 'Ícone salvo.')) {
      delete RASC_ICONE[id];
      await logar('icone.salvar', APPS_ICONE.find((a) => a.id === id)?.nome || id, `${v.dados.rotulo || 'sem nome'} · ${v.dados.de} a ${v.dados.ate}`);
      S.icones = { ...S.icones, [id]: v.dados };
      cartao.outerHTML = cartaoIcone(APPS_ICONE.find((a) => a.id === id));
    }
  } else if (voltar) {
    const id = voltar.dataset.iconeVoltar, nome = APPS_ICONE.find((a) => a.id === id)?.nome || id;
    const c = await confirmar({ titulo: `Voltar ao ícone padrão (${nome})?`, texto: 'A imagem da data deixa de ser usada agora. Você pode configurar outra depois.', rotulo: 'Voltar ao padrão' });
    if (!c.ok) return;
    if (await executar(() => remove(ref(db, `config_icones/${id}`)), 'Ícone padrão restaurado.')) { delete RASC_ICONE[id]; const { [id]: _fora, ...resto } = S.icones || {}; S.icones = resto; await logar('icone.remover', nome); voltar.closest('[data-icone-app]').outerHTML = cartaoIcone(APPS_ICONE.find((a) => a.id === id)); }
  }
});
function renderMarketing() { renderAviso(); renderBanners(); renderCampanhas(); renderIcones(); }

// --- Categorias ---
function renderCategorias() {
  const rows = Object.entries(S.categorias).map(([id, c]) => ({ id, ...(c || {}) })).sort((a, b) => (Number(a.orden) || 0) - (Number(b.orden) || 0));
  $('categorias-lista').innerHTML = rows.length
    ? `<table class="m-tabela"><thead><tr><th>Categoria</th><th>ID</th><th class="num">Ordem</th><th>Estado</th><th></th></tr></thead><tbody>${rows.map((c) => `<tr><td data-label="Categoria"><span class="m-id">${c.img ? `<img src="${esc(c.img)}" alt="" data-oculta>` : '<i class="fa-solid fa-layer-group" aria-hidden="true"></i>'}<b>${esc(c.nombre)}</b></span></td><td data-label="ID" class="m-mono">${esc(c.id)}</td><td data-label="Ordem" class="num">${Number(c.orden) || 0}</td><td data-label="Estado">${c.activa === false ? selo('off', 'Inativa') : selo('ok', 'Ativa')}</td><td class="acoes"><button type="button" class="m-btn m-btn-leve m-btn-mini" data-edit="${esc(c.id)}">Editar</button><button type="button" class="m-btn m-btn-leve m-btn-mini" data-toggle="${esc(c.id)}">${c.activa === false ? 'Ativar' : 'Desativar'}</button></td></tr>`).join('')}</tbody></table>`
    : vazio('fa-layer-group', 'Não há categorias criadas ainda.');
}

// --- Gaveta: loja / pedido / usuário ---
const linhaDado = (k, v) => (v ? `<div><dt>${esc(k)}</dt><dd>${v}</dd></div>` : '');
function renderGaveta() {
  const g = S.gaveta;
  if (!g) return;
  let titulo = 'Detalhes', html = '';
  if (g.tipo === 'loja') ({ titulo, html } = gavetaLoja(g.id));
  else if (g.tipo === 'pedido') ({ titulo, html } = gavetaPedido(g.id));
  else if (g.tipo === 'usuario') ({ titulo, html } = gavetaUsuario(g.id));
  $('m-gaveta-titulo').textContent = titulo;
  const corpo = $('m-gaveta-corpo');
  const scroll = corpo.scrollTop;
  corpo.innerHTML = html;
  corpo.scrollTop = scroll;
}
function gavetaLoja(id) {
  const l = S.lojas[id];
  if (!l) return { titulo: 'Loja', html: vazio('fa-store-slash', 'Esta loja não existe mais.') };
  const sus = S.suspensas[id];
  const estado = U.estadoLoja(l, sus);
  const d = U.desempenhoPorLoja(S.pedidos, S.lojas, U.inicioPeriodo(30)).find((x) => x.lojaId === id) || { pedidos: 0, gmv: 0, comissao: 0, cancelados: 0, ticket: 0 };
  const dono = S.usuarios[l.ownerUid] || {};
  const tel = l.telefono || l.telefone || l.whatsapp || '';
  const end = l.direccion || l.endereco || '';
  const botoes = [
    `<a class="m-btn m-btn-leve" href="restaurante.html?id=${encodeURIComponent(id)}" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Abrir página da loja</a>`,
    `<button type="button" class="m-btn m-btn-leve" data-acao="loja-pedidos" data-id="${esc(id)}"><i class="fa-solid fa-receipt" aria-hidden="true"></i> Ver pedidos</button>`,
    sus ? '' : `<button type="button" class="m-btn m-btn-leve" data-acao="loja-toggle" data-id="${esc(id)}"><i class="fa-solid ${l.activo === false ? 'fa-toggle-on' : 'fa-toggle-off'}" aria-hidden="true"></i> ${l.activo === false ? 'Ativar loja' : 'Desativar loja'}</button>`,
    sus ? `<button type="button" class="m-btn m-btn-principal" data-acao="loja-reativar" data-id="${esc(id)}"><i class="fa-solid fa-unlock" aria-hidden="true"></i> Reativar loja</button>`
      : `<button type="button" class="m-btn m-btn-perigo" data-acao="loja-suspender" data-id="${esc(id)}"><i class="fa-solid fa-ban" aria-hidden="true"></i> Suspender loja</button>`
  ].join('');
  return {
    titulo: l.nombre || l.nome || 'Loja',
    html: `<div class="m-g-topo">${(l.logo || l.foto) ? `<img src="${esc(l.logo || l.foto)}" alt="" data-oculta>` : '<i class="fa-solid fa-store" aria-hidden="true"></i>'}<div>${selo({ ativa: 'ok', inativa: 'off', suspensa: 'erro' }[estado], { ativa: 'Ativa', inativa: 'Desativada', suspensa: 'Suspensa' }[estado])}<small>${esc(nomeCategoria(l))}</small></div></div>
    ${sus ? `<p class="m-faixa m-faixa-erro"><i class="fa-solid fa-ban" aria-hidden="true"></i> Suspensa em ${esc(fmtData(sus.em, true))} por ${esc(quemEh(sus.por))}${sus.motivo ? ` — “${esc(sus.motivo)}”` : ''}. Enquanto estiver suspensa, não recebe pedidos e o dono não consegue reativar.</p>` : ''}
    <div class="m-kpis m-kpis-peq">${kpi('Pedidos · 30d', String(d.pedidos), `${d.cancelados} cancelado(s)`, 'fa-receipt')}${kpi('Vendas · 30d', moeda(d.gmv), `ticket ${moeda(d.ticket)}`, 'fa-sack-dollar')}${kpi('Comissão · 30d', moeda(d.comissao), '', 'fa-percent')}</div>
    <dl class="m-dados">${linhaDado('Telefone', esc(tel))}${linhaDado('Endereço', esc(end))}${linhaDado('Dono', l.ownerUid ? `${esc(dono.nome || dono.email || 'Sem nome')}${dono.email ? `<small>${esc(dono.email)}</small>` : ''}<small class="m-mono">${esc(l.ownerUid)}</small>` : '')}${linhaDado('Taxa de entrega', l.precioEnvio != null ? moeda(l.precioEnvio) : '')}${linhaDado('Cadastro', l.criadoEm ? esc(fmtData(l.criadoEm, true)) : '')}${linhaDado('ID', `<span class="m-mono">${esc(id)}</span>`)}</dl>
    <div class="m-g-acoes">${botoes}</div>`
  };
}
function gavetaPedido(key) {
  const p = S.pedidos.find((x) => x.key === key);
  if (!p) return { titulo: 'Pedido', html: vazio('fa-receipt', 'Pedido não encontrado entre os carregados.') };
  const c = comissaoDoPedido(p);
  const itens = Array.isArray(p.itens) ? p.itens : Object.values(p.itens || {});
  const cl = p.cliente || {};
  const cm = p.cancelamentoMaster;
  const modoCom = { split: 'já separada pelo Mercado Pago', a_acertar: 'a acertar com a loja', nenhum: '' }[c.modo];
  const aviso = U.avisoCancelamento(p);
  return {
    titulo: `Pedido #${p.numeroPedido || key.slice(-6)}`,
    html: `<div class="m-g-topo"><div>${seloStatus(p.status)}<small>${esc(fmtData(p.criadoEm, true))} · ${p.tipoEntrega === 'retirada' ? 'Retirada na loja' : 'Delivery'}</small></div><strong class="m-g-total">${moeda(p.total)}</strong></div>
    ${cm ? `<p class="m-faixa m-faixa-aviso"><i class="fa-solid fa-user-shield" aria-hidden="true"></i> Cancelado pelo Master (${esc(quemEh(cm.por))}) em ${esc(fmtData(cm.em, true))}${cm.motivo ? ` — “${esc(cm.motivo)}”` : ''}.</p>` : ''}
    ${p.reembolso ? `<p class="m-faixa m-faixa-aviso"><i class="fa-solid fa-rotate-left" aria-hidden="true"></i> Reembolso: <b>${esc({ solicitado: 'solicitado', aprovado: 'aprovado', recusado: 'recusado' }[p.reembolso.status] || p.reembolso.status)}</b>${p.reembolso.valor != null ? ` · ${moeda(p.reembolso.valor)}` : ''}${p.reembolso.motivo ? ` · ${esc(p.reembolso.motivo)}` : ''}</p>` : ''}
    ${p.relato ? `<p class="m-faixa ${precisaDoMaster(p) ? 'm-faixa-erro' : 'm-faixa-aviso'}"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Problema relatado: <b>${esc(rotuloRelato(p.relato))}</b> · ${esc(p.relato.motivo || '')}${precisaDoMaster(p) ? ` — ${esc(motivoMasterAlerta(p))}` : ''} <button type="button" class="m-link" data-acao="ver-relato" data-id="${esc(key)}">Analisar</button></p>` : ''}
    <h3 class="m-h3">Loja e cliente</h3>
    <dl class="m-dados">${linhaDado('Loja', `<button type="button" class="m-link" data-acao="ver-loja" data-id="${esc(p.lojaId)}">${esc(nomeLoja(p.lojaId, p))}</button>`)}${linhaDado('Cliente', `${esc(nomeDoCliente(p))}${cl.email ? `<small>${esc(cl.email)}</small>` : ''}`)}${linhaDado('Telefone', esc(cl.telefono || cl.telefone || ''))}${linhaDado('Endereço', esc([cl.direccion || cl.endereco, p.bairro || cl.bairro].filter(Boolean).join(' · ')))}${linhaDado('Pagamento', `${esc(p.formaPagamento || '')} · ${esc(rotuloPagamento(p.pagoStatus))}`)}</dl>
    <h3 class="m-h3">Itens</h3>
    <ul class="m-itens">${itens.map((i) => `<li><span>${Number(i.qtd) || 1}× ${esc(i.nombre || i.nome || 'Item')}</span><b>${moeda((Number(i.precio) || 0) * (Number(i.qtd) || 1))}</b></li>`).join('') || '<li>Sem itens</li>'}</ul>
    <dl class="m-dados m-totais">${linhaDado('Subtotal', moeda(p.subtotal))}${linhaDado('Entrega', moeda(p.precioEnvio))}${Number(p.desconto) ? linhaDado('Desconto', '−' + moeda(p.desconto) + (p.cupomCodigo ? ` (${esc(p.cupomCodigo)})` : '')) : ''}${linhaDado('Total', `<b>${moeda(p.total)}</b>`)}${c.valor > 0 ? linhaDado('Comissão da plataforma', `${moeda(c.valor)}<small>${esc(modoCom)}</small>`) : ''}</dl>
    ${U.podeCancelarPedido(p) ? `<div class="m-g-acoes"><button type="button" class="m-btn m-btn-perigo" data-acao="cancelar-pedido" data-id="${esc(key)}"><i class="fa-solid fa-ban" aria-hidden="true"></i> Cancelar pedido</button></div>${aviso ? `<p class="m-nota">${esc(aviso)}</p>` : ''}` : ''}`
  };
}
function gavetaUsuario(uid) {
  const u = listaUsuarios().find((x) => x.uid === uid);
  if (!u) return { titulo: 'Usuário', html: vazio('fa-user-slash', 'Usuário não encontrado.') };
  const eu = uid === S.user?.uid;
  const bl = S.bloqueados[uid];
  return {
    titulo: u.nome || 'Usuário',
    html: `<div class="m-g-topo">${u.foto ? `<img src="${esc(u.foto)}" alt="" data-oculta referrerpolicy="no-referrer">` : '<i class="fa-solid fa-circle-user" aria-hidden="true"></i>'}<div class="selos">${u.master ? selo('azul', 'Master') : ''}${u.dono ? selo('info', 'Dono de loja') : ''}${u.bloqueado ? selo('erro', 'Bloqueado') : ''}${!u.master && !u.dono && !u.bloqueado ? selo('off', 'Cliente') : ''}</div></div>
    ${bl ? `<p class="m-faixa m-faixa-erro"><i class="fa-solid fa-ban" aria-hidden="true"></i> Bloqueado em ${esc(fmtData(bl.em, true))} por ${esc(quemEh(bl.por))}${bl.motivo ? ` — “${esc(bl.motivo)}”` : ''}. Não consegue enviar novos pedidos.</p>` : ''}
    <div class="m-kpis m-kpis-peq">${kpi('Pedidos*', String(u.pedidos), '', 'fa-receipt')}${kpi('Gasto*', moeda(u.gasto), '', 'fa-sack-dollar')}</div>
    <dl class="m-dados">${linhaDado('E-mail', esc(u.email))}${linhaDado('Telefone', esc(u.telefone))}${linhaDado('Último pedido*', u.ultimo ? esc(fmtData(u.ultimo, true)) : '')}${linhaDado('Cadastro', u.criadoEm ? esc(fmtData(u.criadoEm, true)) : '')}${linhaDado('UID', `<span class="m-mono">${esc(uid)}</span>`)}</dl>
    <p class="m-nota">* Considera só os pedidos carregados em “Pedidos”.</p>
    <div class="m-g-acoes">
      <button type="button" class="m-btn m-btn-leve" data-acao="usr-pedidos" data-id="${esc(uid)}"><i class="fa-solid fa-receipt" aria-hidden="true"></i> Ver pedidos</button>
      ${eu ? '' : bl ? `<button type="button" class="m-btn m-btn-principal" data-acao="usr-desbloquear" data-id="${esc(uid)}"><i class="fa-solid fa-unlock" aria-hidden="true"></i> Desbloquear</button>` : `<button type="button" class="m-btn m-btn-perigo" data-acao="usr-bloquear" data-id="${esc(uid)}"><i class="fa-solid fa-ban" aria-hidden="true"></i> Bloquear conta</button>`}
      ${eu ? '' : u.master ? `<button type="button" class="m-btn m-btn-leve" data-acao="master-remover" data-id="${esc(uid)}"><i class="fa-solid fa-user-minus" aria-hidden="true"></i> Remover Master</button>` : `<button type="button" class="m-btn m-btn-leve" data-acao="usr-master" data-id="${esc(uid)}"><i class="fa-solid fa-user-shield" aria-hidden="true"></i> Tornar Master</button>`}
    </div>`
  };
}

// ---------- ações do Master ----------
const agoraIso = () => new Date().toISOString();
async function acaoLojaToggle(id) {
  const l = S.lojas[id]; if (!l) return;
  const desativar = l.activo !== false;
  const c = await confirmar({ titulo: desativar ? 'Desativar loja?' : 'Ativar loja?', texto: desativar ? `“${l.nombre || id}” deixa de aparecer para os clientes. O dono ainda pode reativá-la.` : `“${l.nombre || id}” volta a aparecer para os clientes.`, rotulo: desativar ? 'Desativar' : 'Ativar', perigo: desativar });
  if (!c.ok) return;
  if (await executar(() => update(ref(db, `restaurantes/${id}`), { activo: !desativar }), desativar ? 'Loja desativada.' : 'Loja ativada.')) await logar(desativar ? 'loja.desativar' : 'loja.ativar', l.nombre || id);
}
async function acaoLojaSuspender(id) {
  const l = S.lojas[id]; if (!l) return;
  const c = await confirmar({ titulo: 'Suspender loja?', texto: `“${l.nombre || id}” sai do ar, não recebe pedidos e o dono não consegue reativar sozinho. Só você pode reverter.`, motivo: true, rotulo: 'Suspender', perigo: true });
  if (!c.ok) return;
  const ok = await executar(async () => {
    await set(ref(db, `lojas_suspensas/${id}`), { em: agoraIso(), por: S.user.uid, ...(c.motivo ? { motivo: c.motivo } : {}) });
    await update(ref(db, `restaurantes/${id}`), { activo: false });
  }, 'Loja suspensa.');
  if (ok) await logar('loja.suspender', l.nombre || id, c.motivo);
}
async function acaoLojaReativar(id) {
  const l = S.lojas[id]; if (!l) return;
  const c = await confirmar({ titulo: 'Reativar loja?', texto: `“${l.nombre || id}” volta a aparecer e a receber pedidos.`, rotulo: 'Reativar' });
  if (!c.ok) return;
  const ok = await executar(async () => {
    await remove(ref(db, `lojas_suspensas/${id}`));
    await update(ref(db, `restaurantes/${id}`), { activo: true });
  }, 'Loja reativada.');
  if (ok) await logar('loja.reativar', l.nombre || id);
}
async function acaoCancelarPedido(key) {
  const p = S.pedidos.find((x) => x.key === key);
  if (!p || !U.podeCancelarPedido(p)) { aviso('Este pedido não pode mais ser cancelado.', 'erro'); return; }
  const c = await confirmar({ titulo: `Cancelar pedido #${p.numeroPedido || key.slice(-6)}?`, texto: `${nomeLoja(p.lojaId, p)} · ${nomeDoCliente(p)} · ${moeda(p.total)}. O cliente e a loja verão o pedido como cancelado.`, aviso: U.avisoCancelamento(p), motivo: true, rotulo: 'Cancelar pedido', perigo: true });
  if (!c.ok) return;
  const ok = await executar(async () => {
    await update(ref(db, `pedidos/${key}`), { status: STATUS.CANCELADO, atualizadoEm: agoraIso() });
    await set(ref(db, `pedidos/${key}/cancelamentoMaster`), { por: S.user.uid, em: agoraIso(), ...(c.motivo ? { motivo: c.motivo } : {}) });
  }, 'Pedido cancelado.');
  if (ok) await logar('pedido.cancelar', `#${p.numeroPedido || key}`, c.motivo);
}
async function acaoBloquear(uid) {
  const nome = quemEh(uid);
  const c = await confirmar({ titulo: 'Bloquear conta?', texto: `${nome} não conseguirá enviar novos pedidos. Pedidos já feitos continuam normais.`, motivo: true, rotulo: 'Bloquear', perigo: true });
  if (!c.ok) return;
  if (await executar(() => set(ref(db, `usuarios_bloqueados/${uid}`), { em: agoraIso(), por: S.user.uid, ...(c.motivo ? { motivo: c.motivo } : {}) }), 'Conta bloqueada.')) await logar('usuario.bloquear', nome, c.motivo);
}
async function acaoDesbloquear(uid) {
  const nome = quemEh(uid);
  const c = await confirmar({ titulo: 'Desbloquear conta?', texto: `${nome} volta a poder fazer pedidos.`, rotulo: 'Desbloquear' });
  if (!c.ok) return;
  if (await executar(() => remove(ref(db, `usuarios_bloqueados/${uid}`)), 'Conta desbloqueada.')) await logar('usuario.desbloquear', nome);
}
async function adicionarMaster(uid) {
  uid = String(uid || '').trim();
  if (!U.uidValido(uid)) { aviso('UID inválido. Copie o UID completo da pessoa (letras e números).', 'erro'); return false; }
  if (S.admins[uid]?.role === 'master') { aviso('Esta pessoa já é Master.', 'erro'); return false; }
  const u = S.usuarios[uid] || {};
  const c = await confirmar({ titulo: 'Adicionar Master?', texto: `${u.nome || u.email || uid} terá o mesmo controle total que você: lojas, pedidos, usuários, comissão e equipe.`, rotulo: 'Adicionar Master' });
  if (!c.ok) return false;
  const reg = { role: 'master', addedBy: S.user.uid, addedAt: agoraIso(), ...(u.email ? { email: u.email } : {}), ...(u.nome ? { nome: u.nome } : {}) };
  const ok = await executar(() => set(ref(db, `admins/${uid}`), reg), 'Master adicionado.');
  if (ok) await logar('equipe.adicionar', u.nome || u.email || uid);
  return ok;
}
async function removerMaster(uid) {
  if (uid === S.user.uid) { aviso('Você não pode remover a si mesmo.', 'erro'); return; }
  const nome = quemEh(uid);
  const c = await confirmar({ titulo: 'Remover Master?', texto: `${nome} perde o acesso a este painel.`, rotulo: 'Remover', perigo: true });
  if (!c.ok) return;
  if (await executar(() => remove(ref(db, `admins/${uid}`)), 'Master removido.')) await logar('equipe.remover', nome);
}

// ---------- eventos (delegação) ----------
const ACOES = {
  'ver-pedido': (id) => abrirGaveta('pedido', id),
  'ver-loja': (id) => abrirGaveta('loja', id),
  'ver-usuario': (id) => abrirGaveta('usuario', id),
  'cancelar-pedido': acaoCancelarPedido,
  'ver-relato': abrirRelatoMaster,
  'loja-toggle': acaoLojaToggle, 'loja-suspender': acaoLojaSuspender, 'loja-reativar': acaoLojaReativar,
  'loja-pedidos': (id) => { fecharGaveta(); $('ped-busca').value = ''; $('ped-status').value = 'todos'; $('ped-periodo').value = '0'; preencherSelectLojas(); $('ped-loja').value = id; S.vis.ped = 50; setView('pedidos'); },
  'usr-pedidos': (uid) => { const u = S.usuarios[uid] || {}; fecharGaveta(); $('ped-loja').value = ''; $('ped-status').value = 'todos'; $('ped-periodo').value = '0'; $('ped-busca').value = u.email || u.nome || ''; S.vis.ped = 50; setView('pedidos'); },
  'usr-bloquear': acaoBloquear, 'usr-desbloquear': acaoDesbloquear,
  'usr-master': adicionarMaster, 'master-remover': removerMaster
};
document.addEventListener('click', (e) => {
  const alvo = e.target.closest('[data-acao]');
  if (alvo) {
    if (alvo.dataset.acao === 'alerta') {
      const { ir, filtro, status } = alvo.dataset;
      if (ir === 'lojas' && filtro) S.lojaFiltro = filtro;
      if (ir === 'pedidos') { $('ped-status').value = status || 'todos'; $('ped-periodo').value = '0'; $('ped-loja').value = ''; $('ped-busca').value = ''; }
      return setView(ir);
    }
    const fn = ACOES[alvo.dataset.acao];
    if (fn) return void fn(alvo.dataset.id);
  }
  const ir = e.target.closest('[data-ir]');
  if (ir) return setView(ir.dataset.ir);
  const serie = e.target.closest('[data-serie]');
  if (serie) { S.serie = serie.dataset.serie; return renderResumo(); }
  const cl = e.target.closest('[data-chip-loja]');
  if (cl) { S.lojaFiltro = cl.dataset.chipLoja; return renderLojas(); }
  const cu = e.target.closest('[data-chip-usr]');
  if (cu) { S.usrFiltro = cu.dataset.chipUsr; S.vis.usr = 50; return renderUsuarios(); }
});
document.addEventListener('error', (e) => { if ((e.target?.tagName === 'IMG' || e.target?.tagName === 'VIDEO') && e.target.hasAttribute('data-oculta')) e.target.style.display = 'none'; }, true);
['ped-busca', 'ped-status', 'ped-loja', 'ped-periodo'].forEach((id) => $(id).addEventListener('input', () => { S.vis.ped = 50; renderPedidos(); }));
$('ped-mais').addEventListener('click', () => { S.vis.ped += 50; renderPedidos(); });
$('ped-limite').addEventListener('change', () => { S.limite = Number($('ped-limite').value) || 600; S.pedidosOk = false; ouvirPedidos(); renderPedidos(); });
$('loja-busca').addEventListener('input', renderLojas);
$('usr-busca').addEventListener('input', () => { S.vis.usr = 50; renderUsuarios(); });
$('usr-mais').addEventListener('click', () => { S.vis.usr += 50; renderUsuarios(); });
$('fin-periodo').addEventListener('change', renderFinanceiro);
$('m-atualizar').addEventListener('click', async () => { $('m-atualizar').disabled = true; await carregarUsuarios(); $('m-atualizar').disabled = false; aviso('Dados atualizados.'); });
$('equipe-form').addEventListener('submit', async (e) => { e.preventDefault(); if (await adicionarMaster($('equipe-uid').value)) $('equipe-uid').value = ''; });

// ---------- Marketing: aviso, banners, push ----------
async function enviarImagem(file, { gif = false, midia = false } = {}) {
  if (midia && typeof window.uploadMidiaCloudinary === 'function') { // V75.148: banner e popup aceitam GIF e vídeo curto
    const m = await window.uploadMidiaCloudinary(file);
    if (!m?.url) throw new Error('O Cloudinary não devolveu uma URL válida.');
    return m.url;
  }
  if (gif && typeof window.uploadImagemCloudinaryGif === 'function') { // V75.147: banner animado; o erro real (formato/tamanho/Cloudinary) sobe até o aviso
    const g = await window.uploadImagemCloudinaryGif(file);
    if (!g?.url) throw new Error('O Cloudinary não devolveu uma URL válida.');
    return g.url;
  }
  const fn = window.uploadImagemCloudinaryPub || window.uploadImagemCloudinary;
  if (typeof fn !== 'function') throw new Error('O envio de imagens (Cloudinary) não está disponível.');
  const r = await fn(file);
  if (!r?.url) throw new Error('O Cloudinary não devolveu uma URL válida.');
  return r.url;
}
async function saveAviso(e) {
  e.preventDefault();
  const titulo = $('aviso-titulo').value.trim();
  const descripcion = $('aviso-descripcion').value.trim();
  if ($('aviso-destino').value === 'loja' && !selAviso.valor()) throw new Error('Escolha a loja do aviso.');
  const link = $('aviso-destino').value === 'loja' ? linkDaLoja(selAviso.valor()) : U.linkValido($('aviso-link').value);
  if ($('aviso-destino').value !== 'loja' && $('aviso-link').value.trim() && !link) throw new Error('Link inválido. Use https:// ou um caminho interno (ex.: restaurante.html?id=…).');
  let img = S.aviso?.img || '';
  const file = $('aviso-imagen-file').files?.[0];
  if (file) img = await enviarImagem(file, { midia: true });
  if (!img) throw new Error('Selecione uma imagem para o aviso.');
  const dados = { ativo: $('aviso-activo').checked, titulo, descripcion, img, link, updatedAt: Date.now() };
  await set(ref(db, 'aviso_app'), dados);
  $('aviso-imagen-file').value = '';
  aviso('Aviso salvo.');
  await logar('aviso.salvar', titulo || 'Só imagem', dados.ativo ? 'ativo' : 'inativo'); // V75.150: título opcional
}
$('aviso-form').addEventListener('submit', async (e) => { try { await saveAviso(e); } catch (err) { console.error(err); aviso(traduzirErro(err), 'erro'); } });
$('btn-excluir-aviso').addEventListener('click', async () => {
  if (!S.aviso?.img && !S.aviso?.titulo) return;
  const c = await confirmar({ titulo: 'Excluir o aviso principal?', texto: 'O popup deixa de aparecer para os clientes. Não dá para desfazer.', rotulo: 'Excluir', perigo: true });
  if (!c.ok) return;
  if (await executar(() => remove(ref(db, 'aviso_app')), 'Aviso excluído.')) await logar('aviso.excluir', S.aviso?.titulo || '');
});

function preencherCategoriasBanner(sel = '') {
  const el = $('banner-category');
  el.innerHTML = '<option value="">Selecione uma categoria</option>' + Object.entries(S.categorias).filter(([, c]) => c?.nombre && c?.activa !== false).map(([id, c]) => `<option value="${esc(id)}">${esc(c.nombre)}</option>`).join('');
  el.value = sel || '';
}
// V75.138: destino "Uma loja" (o link é montado sozinho) e, opcionalmente, registrar como publicidade vendida
const selBanner = seletorLoja($('banner-loja-wrap'), { lojas: () => S.lojas, aoMudar: () => atualizarDestinoBanner(), dica: (n) => `Ao tocar no banner, o cliente abre a página da ${n}.` });
function atualizarDestinoBanner() {
  const t = $('banner-target-type').value || 'link';
  $('banner-link-wrap').hidden = t !== 'link'; $('banner-category-wrap').hidden = t !== 'categoria'; $('banner-loja-wrap').hidden = t !== 'loja';
  if (t === 'loja' && !selBanner.valor()) selBanner.atualizar();
  const b = S.banners[$('banner-id').value] || {};
  const ja = b.publicidadeId && S.publicidade[b.publicidadeId];
  $('banner-pub-wrap').hidden = t !== 'loja' || !selBanner.valor();
  { const dica = $('banner-titulo').closest('label')?.querySelector('small'); if (dica) dica.textContent = t === 'loja' ? '(opcional — aparece ao lado da logo da loja, sem fundo. Ex.: 50% off em todos os itens)' : '(opcional — se a imagem já diz tudo, deixe vazio)'; } // V75.154
  $('banner-pub-ja').hidden = !ja; $('banner-pub-ja').textContent = ja ? `Já registrado em Publicidade vendida: ${moeda(ja.valor)} · ${ROTULO_PUB[ja.status] || ja.status}.` : '';
  $('banner-pub-registrar').closest('label').hidden = !!ja;
  $('banner-pub-campos').hidden = !!ja || !$('banner-pub-registrar').checked;
}
$('banner-pub-registrar').addEventListener('change', atualizarDestinoBanner);
function openBannerModal(b = null) {
  $('banner-modal').hidden = false;
  $('banner-id').value = b?.id || '';
  $('banner-titulo').value = b?.titulo || '';
  $('banner-descripcion').value = b?.descripcion || '';
  $('banner-link').value = b?.link || '';
  $('banner-target-type').value = b?.targetType || 'link';
  preencherCategoriasBanner(b?.targetCategoryId || '');
  selBanner.definir(b?.targetType === 'loja' ? (b.lojaId || lojaDoLink(b.link)) : '');
  $('banner-pub-registrar').checked = false; $('banner-pub-valor').value = ''; $('banner-pub-status').value = PUB.PENDENTE;
  atualizarDestinoBanner();
  $('banner-orden').value = Number(b?.orden) || 0;
  $('banner-inicio').value = b?.inicio || '';
  $('banner-fin').value = b?.fim || '';
  $('banner-activo').checked = b?.activo !== false;
  $('banner-imagen-file').value = '';
  previaBanner(b?.img || '', b?.img ? ehVideo(b.img) : false);
  $('banner-modal-title').textContent = b ? 'Editar banner' : 'Novo banner';
  $('banner-titulo').focus();
}
// V75.148: a prévia do banner mostra imagem/GIF no <img> e vídeo no <video> (mudo, em loop).
function previaBanner(url, video) {
  const img = $('banner-preview-img'), vid = $('banner-preview-video');
  img.hidden = !url || video; vid.hidden = !url || !video;
  if (url && video) { img.removeAttribute('src'); vid.src = url; vid.play?.().catch(() => {}); } else { vid.removeAttribute('src'); vid.load?.(); img.src = url || ''; }
  $('banner-preview-placeholder').hidden = !!url;
}
function closeBannerModal() { $('banner-modal').hidden = true; }
async function saveBanner(e) {
  e.preventDefault();
  const idOld = $('banner-id').value.trim();
  const titulo = $('banner-titulo').value.trim();
  let img = S.banners[idOld]?.img || '';
  const file = $('banner-imagen-file').files?.[0];
  if (file) img = await enviarImagem(file, { midia: true });
  if (!img) throw new Error('Selecione uma imagem para o banner.');
  const targetType = $('banner-target-type').value || 'link';
  const targetCategoryId = $('banner-category').value || '';
  const lojaBanner = targetType === 'loja' ? selBanner.valor() : '';
  if (targetType === 'loja' && !lojaBanner) throw new Error('Escolha a loja do banner.');
  const link = targetType === 'link' ? U.linkValido($('banner-link').value) : targetType === 'loja' ? linkDaLoja(lojaBanner) : '';
  // V75.138: publicidade vendida (opcional; desligado = promoção grátis). Confere antes de gravar o banner.
  const jaPub = S.banners[idOld]?.publicidadeId;
  let pub = null;
  if (targetType === 'loja' && !jaPub && $('banner-pub-registrar').checked) {
    pub = montarPublicidade({ anunciante: S.lojas[lojaBanner]?.nombre || S.lojas[lojaBanner]?.nome || lojaBanner, lojaId: lojaBanner, descricao: `Banner: ${titulo || 'só imagem'}`, valor: $('banner-pub-valor').value, status: $('banner-pub-status').value, data: hojeISO(),
      inicioEm: ($('banner-inicio').value || '').slice(0, 10), fimEm: ($('banner-fin').value || '').slice(0, 10) });
  }
  if (targetType === 'link' && $('banner-link').value.trim() && !link) throw new Error('Link inválido. Use https:// ou um caminho interno.');
  if (targetType === 'categoria' && !targetCategoryId) throw new Error('Selecione uma categoria para o banner.');
  const inicio = $('banner-inicio').value, fim = $('banner-fin').value;
  if (inicio && fim && Date.parse(fim) < Date.parse(inicio)) throw new Error('A data final não pode ser anterior à inicial.');
  const id = idOld || push(ref(db, 'banners')).key;
  await set(ref(db, `banners/${id}`), { titulo, descripcion: $('banner-descripcion').value.trim(), img, link, targetType, targetCategoryId, ...(lojaBanner ? { lojaId: lojaBanner } : {}), ...(jaPub ? { publicidadeId: jaPub } : {}), orden: Number($('banner-orden').value) || 0, activo: $('banner-activo').checked, inicio, fim, updatedAt: Date.now(), ...(idOld ? { createdAt: S.banners[idOld]?.createdAt || Date.now() } : { createdAt: Date.now() }) });
  if (pub) { // registra a venda e liga ao banner (aparece em Financeiro → Publicidade vendida e no painel da loja)
    const pref = push(ref(db, 'publicidade')); const agora = agoraIso();
    await set(pref, { ...pub, criadoEm: agora, criadoPor: S.user?.uid || '', ...(pub.status === PUB.PAGO ? { pagoEm: agora } : {}) });
    await update(ref(db, `banners/${id}`), { publicidadeId: pref.key });
    await logar('publicidade.criar', pub.anunciante, `${moeda(pub.valor)} · banner`);
  }
  closeBannerModal();
  aviso('Banner salvo.');
  await logar('banner.salvar', titulo || 'só imagem');
}
$('btn-nuevo-banner').addEventListener('click', () => openBannerModal());
$('banner-modal-close').addEventListener('click', closeBannerModal);
$('banner-modal-cancel').addEventListener('click', closeBannerModal);
$('banner-form').addEventListener('submit', async (e) => { try { await saveBanner(e); } catch (err) { console.error(err); aviso(traduzirErro(err), 'erro'); } });
$('banner-target-type').addEventListener('change', atualizarDestinoBanner);
$('banner-imagen-file').addEventListener('change', () => { const f = $('banner-imagen-file').files?.[0]; if (!f) return; previaBanner(URL.createObjectURL(f), /^video\//.test(f.type) || /\.(mp4|webm)$/i.test(f.name)); });
$('banners-lista').addEventListener('click', async (e) => {
  const edit = e.target.closest('[data-banner-edit]'), tog = e.target.closest('[data-banner-toggle]'), del = e.target.closest('[data-banner-delete]');
  if (edit) openBannerModal({ id: edit.dataset.bannerEdit, ...S.banners[edit.dataset.bannerEdit] });
  if (tog) { const id = tog.dataset.bannerToggle; await executar(() => update(ref(db, `banners/${id}`), { activo: S.banners[id]?.activo === false }), 'Banner atualizado.'); }
  if (del) {
    const id = del.dataset.bannerDelete;
    const c = await confirmar({ titulo: 'Excluir este banner?', texto: S.banners[id]?.titulo || 'Banner só de imagem', rotulo: 'Excluir', perigo: true });
    if (c.ok && await executar(() => remove(ref(db, `banners/${id}`)), 'Banner excluído.')) await logar('banner.excluir', S.banners[id]?.titulo || id);
  }
});

async function enviarNotificacaoMaster(e) {
  e.preventDefault();
  const titulo = $('master-notify-title').value.trim();
  const corpo = $('master-notify-body').value.trim();
  if ($('notify-destino').value === 'loja' && !selPush.valor()) throw new Error('Escolha a loja da notificação.');
  const linkRaw = $('notify-destino').value === 'loja' ? linkDaLoja(selPush.valor(), window.location.origin) : $('master-notify-link').value.trim();
  const status = $('master-notify-status'), btn = $('btn-master-notify');
  if (!titulo) throw new Error('Informe o título da notificação.');
  if (!corpo) throw new Error('Informe a mensagem.');
  if ($('notify-destino').value !== 'loja' && linkRaw && !U.linkValido(linkRaw)) throw new Error('Link inválido. Use https:// ou um caminho interno.');
  if (!auth.currentUser) throw new Error('Sessão Master não encontrada. Entre novamente.');
  const link = linkRaw || window.location.origin + '/index.html';
  const c = await confirmar({ titulo: 'Enviar para todos os clientes?', texto: `“${titulo}” será enviada agora a todos que ativaram as notificações. Não dá para desfazer.`, rotulo: 'Enviar agora' });
  if (!c.ok) return;
  btn.disabled = true;
  status.textContent = 'Enviando…';
  status.className = 'master-notify-status is-loading';
  try {
    const idToken = await auth.currentUser.getIdToken(true);
    const r = await fetch(`${NOTPUSH_API}/notificar-master`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` }, body: JSON.stringify({ titulo, corpo, link }) });
    const data = await r.json().catch(() => ({}));
    const res = U.resultadoEnvioMaster(r.ok, data);
    if (!res.entregou) {
      if (!res.semToken) throw new Error(res.erro || `HTTP ${r.status}`);
      status.textContent = res.erro;
      status.className = 'master-notify-status is-error';
      aviso('Nenhum aparelho registrado para receber notificações.', 'erro');
      return;
    }
    status.textContent = `Enviada para ${res.enviados} aparelho(s)${res.aviso ? ` · ${res.aviso}` : ''}`;
    status.className = 'master-notify-status is-ok';
    $('master-notify-form').reset();
    let salvou = true;
    // Reenvio do mesmo texto: o aviso sai de novo, mas o histórico mantém a linha que já existe (sem repetir). A Atividade registra cada envio.
    const jaExiste = U.acharCampanhaIgual(S.campanhas, { titulo, corpo, link });
    if (jaExiste) status.textContent += ' · Já estava no histórico: mantida a mesma linha.';
    else try { await set(push(ref(db, 'master_campanhas')), { ...U.registroLog(S.user, 'push.enviar'), titulo, corpo, link, enviados: res.enviados, tokens: res.tokens }); } catch (err) { salvou = false; console.warn('campanha', err); }
    if (!salvou) { status.textContent += ' · Atenção: não foi salva no histórico. Republique as regras do Firebase (regras/database.rules.RASCUNHO-V75.73.json).'; status.className = 'master-notify-status is-error'; aviso('Enviada, mas não salva no histórico.', 'erro'); }
    await logar('push.enviar', titulo, `${res.enviados} aparelho(s)`);
  } finally { btn.disabled = false; }
}
$('master-notify-form').addEventListener('submit', async (e) => {
  try { await enviarNotificacaoMaster(e); } catch (err) {
    console.error(err);
    $('master-notify-status').textContent = err.message || 'Não foi possível enviar.';
    $('master-notify-status').className = 'master-notify-status is-error';
  }
});

$('campanhas-lista').addEventListener('click', async (e) => {
  const re = e.target.closest('[data-camp-reenviar]'), ex = e.target.closest('[data-camp-excluir]');
  if (re) {
    const c = S.campanhas.find((x) => x.id === re.dataset.campReenviar); if (!c) return;
    $('master-notify-title').value = c.titulo || ''; $('master-notify-body').value = c.corpo || ''; $('master-notify-link').value = c.link && c.link !== window.location.origin + '/index.html' ? c.link : '';
    $('master-notify-status').textContent = 'Texto copiado. Revise e clique em “Enviar notificação”.'; $('master-notify-status').className = 'master-notify-status';
    $('master-notify-form').scrollIntoView({ behavior: 'smooth', block: 'center' }); $('master-notify-title').focus();
  }
  if (ex) {
    const c = S.campanhas.find((x) => x.id === ex.dataset.campExcluir); if (!c) return;
    const ok = await confirmar({ titulo: 'Remover do histórico?', texto: `“${c.titulo}” sai da lista. Quem já recebeu a notificação continua com ela no aparelho — não dá para recolher.`, rotulo: 'Remover', perigo: true });
    if (ok.ok && await executar(() => remove(ref(db, `master_campanhas/${c.id}`)), 'Removida do histórico.')) await logar('push.excluir', c.titulo);
  }
});

// ---------- Categorias ----------
function openModal(c = null) {
  $('categoria-modal').hidden = false;
  $('cat-id').value = c?.id || ''; $('cat-nombre').value = c?.nombre || ''; $('cat-orden').value = Number(c?.orden) || 0; $('cat-activa').checked = c?.activa !== false;
  $('cat-imagen-file').value = '';
  $('cat-preview-img').hidden = !c?.img; $('cat-preview-img').src = c?.img || ''; $('cat-preview-placeholder').hidden = !!c?.img;
  $('modal-title').textContent = c ? 'Editar categoria' : 'Nova categoria';
  $('cat-nombre').focus();
}
function closeModal() { $('categoria-modal').hidden = true; }
async function saveCategoria(e) {
  e.preventDefault();
  const idOld = $('cat-id').value.trim();
  const nombre = $('cat-nombre').value.trim();
  if (!nombre) return;
  let id = idOld || U.slugify(nombre);
  if (!id) throw new Error('Nome inválido.');
  if (!idOld && S.categorias[id]) { let n = 2; while (S.categorias[`${id}-${n}`]) n++; id = `${id}-${n}`; }
  let img = S.categorias[id]?.img || '';
  const file = $('cat-imagen-file').files?.[0];
  if (file) img = await enviarImagem(file);
  await set(ref(db, `categorias_loja/${id}`), { nombre, orden: Number($('cat-orden').value) || 0, activa: $('cat-activa').checked, img });
  closeModal();
  aviso('Categoria salva.');
  await logar('categoria.salvar', nombre);
}
$('btn-nueva-categoria').addEventListener('click', () => openModal());
$('modal-close').addEventListener('click', closeModal);
$('modal-cancel').addEventListener('click', closeModal);
$('categoria-form').addEventListener('submit', async (e) => { try { await saveCategoria(e); } catch (err) { console.error(err); aviso(traduzirErro(err), 'erro'); } });
$('cat-imagen-file').addEventListener('change', () => { const f = $('cat-imagen-file').files?.[0]; if (!f) return; $('cat-preview-img').src = URL.createObjectURL(f); $('cat-preview-img').hidden = false; $('cat-preview-placeholder').hidden = true; });
$('btn-base').addEventListener('click', async () => {
  await executar(async () => { for (const [id, nombre] of BASE) if (!S.categorias[id]) await set(ref(db, `categorias_loja/${id}`), { nombre, orden: BASE.findIndex((x) => x[0] === id) + 1, activa: true, img: '' }); }, 'Categorias base criadas.');
});
$('categorias-lista').addEventListener('click', async (e) => {
  const edit = e.target.closest('[data-edit]'), tog = e.target.closest('[data-toggle]');
  if (edit) openModal({ id: edit.dataset.edit, ...S.categorias[edit.dataset.edit] });
  if (tog) { const id = tog.dataset.toggle; await executar(() => update(ref(db, `categorias_loja/${id}`), { activa: S.categorias[id]?.activa === false }), 'Categoria atualizada.'); }
});

// ---------- Comissão ----------
$('form-comissao').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = $('comissao-status');
  const v = Number(String($('comissao-percentual').value).replace(',', '.'));
  if (!Number.isFinite(v) || v < 0 || v > 50) { s.dataset.fixo = '1'; s.textContent = 'Informe um valor entre 0 e 50.'; return; }
  const percentual = Math.round(v * 100) / 100;
  const c = await confirmar({ titulo: 'Alterar a comissão?', texto: `A comissão passa a ser ${percentual}% sobre os produtos. Vale para os próximos pedidos de todas as lojas.`, rotulo: 'Salvar comissão' });
  if (!c.ok) return;
  delete s.dataset.fixo;
  if (await executar(() => set(ref(db, 'config_plataforma/comissao'), { percentual, atualizadoEm: agoraIso(), atualizadoPor: S.user?.uid || '' }), `Comissão salva: ${percentual}%.`)) await logar('comissao.alterar', `${percentual}%`, `antes: ${S.comissao?.percentual ?? 'não definida'}`);
});


// ---------- V75.116: contato para dados pessoais (LGPD) ----------
$('contato-dados-email').addEventListener('input', (e) => { e.target.dataset.sujo = '1'; });
$('form-contato-dados').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = $('contato-dados-status'), i = $('contato-dados-email');
  const email = U.normalizarEmailContato(i.value);
  if (email === null) { s.dataset.fixo = '1'; s.textContent = 'E-mail inválido. Confira e tente de novo.'; i.focus(); return; }
  const atual = S.contatoDados?.email || '';
  if (email === atual) { delete i.dataset.sujo; delete s.dataset.fixo; aviso('Nada mudou.'); return; }
  const c = await confirmar({ titulo: email ? 'Salvar o e-mail de contato?' : 'Tirar o e-mail de contato?', texto: email ? `Lojistas e entregadores passam a ver ${email} para pedidos sobre os próprios dados.` : 'As telas passam a dizer para falar com o suporte do YAPOOD.', rotulo: 'Salvar' });
  if (!c.ok) return;
  delete s.dataset.fixo;
  const ok = await executar(() => (email ? set(ref(db, 'config_plataforma/contato_dados'), { email, atualizadoEm: agoraIso(), atualizadoPor: S.user?.uid || '' }) : remove(ref(db, 'config_plataforma/contato_dados'))), email ? 'E-mail de contato salvo.' : 'E-mail de contato removido.');
  if (ok) { delete i.dataset.sujo; await logar('contato_dados.alterar', email || '(vazio)', `antes: ${atual || '(vazio)'}`); }
});

// ---------- Cor do app (tema) ----------
const corOficial = () => normalizarHex(S.tema?.primaria);
const corEmTeste = () => { try { return normalizarHex(JSON.parse(localStorage.getItem(CHAVE_TESTE) || 'null')?.primaria); } catch { return null; } };
const sobreEscolhido = () => normalizarSobre($('tema-sobre').value);
function pintarPrevia(hex) {
  const t = derivarTema(hex, sobreEscolhido());
  for (const [k, nome] of Object.entries(VARIAVEIS)) $('tema-previa').style.setProperty(nome, t[k]);
  $('tema-cor').value = t.primaria;
  document.querySelectorAll('.tema-sw').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.hex === t.primaria)));
  const c = contraste(t.primaria, t.sobre);
  const s = $('tema-status');
  if (s && !s.dataset.fixo) {
    const sobre = t.sobre === '#ffffff' ? 'branco' : 'escuro';
    s.textContent = `Texto dentro dos botões: ${sobre} (contraste ${c.toFixed(1).replace('.', ',')}:1)${c < 3 ? '. Abaixo do recomendado (3:1): o texto pode ficar difícil de ler.' : '.'}`;
  }
  // texto branco numa cor clara: oferece a versão mais escura da mesma cor, em que o branco lê bem
  const aj = $('tema-ajustar');
  const alvo = t.sobre === '#ffffff' && c < 3.5 ? corParaTextoBranco(t.primaria) : null;
  aj.hidden = !alvo || alvo === t.primaria;
  if (!aj.hidden) { aj.dataset.hex = alvo; aj.textContent = `Escurecer um pouco para o branco ler bem (${alvo.toUpperCase()})`; }
  return t;
}
function renderTema() {
  if (!$('tema-hex')) return;
  const of = corOficial(), teste = corEmTeste();
  const est = $('tema-estado');
  est.textContent = of ? `Oficial ${of.toUpperCase()}` : 'Padrão';
  est.className = `m-selo m-selo-${of ? 'ok' : 'off'}`;
  $('tema-parar').hidden = !teste;
  if (!$('form-tema').dataset.sujo && document.activeElement !== $('tema-sobre')) $('tema-sobre').value = normalizarSobre(S.tema?.sobre);
  if (!$('tema-sugestoes').children.length) {
    $('tema-sugestoes').innerHTML = SUGESTOES.map(([n, h]) => `<button type="button" class="tema-sw" data-hex="${h}" aria-pressed="false" title="${esc(n)}"><i style="background:${h}"></i>${esc(n)}</button>`).join('');
  }
  if (!$('form-tema').dataset.sujo && document.activeElement !== $('tema-hex')) {
    const base = teste || of || COR_PADRAO;
    $('tema-hex').value = base.toUpperCase();
    pintarPrevia(base);
  }
}
function definirCor(valor, { sujo = true } = {}) {
  const hex = normalizarHex(valor);
  if (sujo) $('form-tema').dataset.sujo = '1';
  const s = $('tema-status'); delete s.dataset.fixo;
  if (!hex) { $('tema-hex').setAttribute('aria-invalid', 'true'); return null; }
  $('tema-hex').removeAttribute('aria-invalid');
  pintarPrevia(hex);
  return hex;
}
$('tema-cor').addEventListener('input', (e) => { $('tema-hex').value = e.target.value.toUpperCase(); definirCor(e.target.value); });
$('tema-hex').addEventListener('input', (e) => { definirCor(e.target.value); });
$('tema-sobre').addEventListener('change', () => { definirCor($('tema-hex').value); });
$('tema-ajustar').addEventListener('click', (e) => { const h = e.currentTarget.dataset.hex; if (h) { $('tema-hex').value = h.toUpperCase(); definirCor(h); } });
$('tema-sugestoes').addEventListener('click', (e) => { const b = e.target.closest('.tema-sw'); if (!b) return; $('tema-hex').value = b.dataset.hex.toUpperCase(); definirCor(b.dataset.hex); });
const corValida = () => {
  const hex = normalizarHex($('tema-hex').value);
  if (!hex) { const s = $('tema-status'); s.dataset.fixo = '1'; s.textContent = 'Código de cor inválido. Use o seletor ou algo como #EFB638.'; }
  return hex;
};
$('tema-testar').addEventListener('click', () => {
  const hex = corValida(); if (!hex) return;
  try { localStorage.setItem(CHAVE_TESTE, JSON.stringify(derivarTema(hex, sobreEscolhido()))); } catch { aviso('Este navegador não deixa guardar o teste (modo privado?).', 'erro'); return; }
  const s = $('tema-status'); s.dataset.fixo = '1'; s.textContent = `Cor ${hex.toUpperCase()} em teste só neste aparelho. Toque em “Abrir o app para ver”.`;
  $('tema-parar').hidden = false;
  aviso('Cor em teste neste aparelho.');
});
$('tema-parar').addEventListener('click', () => {
  try { localStorage.removeItem(CHAVE_TESTE); } catch { /* sem armazenamento */ }
  const s = $('tema-status'); s.dataset.fixo = '1'; s.textContent = 'Teste encerrado: este aparelho voltou a usar a cor oficial.';
  delete $('form-tema').dataset.sujo; renderTema(); aviso('Teste encerrado.');
});
$('tema-publicar').addEventListener('click', async () => {
  const hex = corValida(); if (!hex) return;
  const c = await confirmar({ titulo: 'Publicar esta cor?', texto: `A cor ${hex.toUpperCase()} (texto dentro dos botões: ${({ auto: 'automático', branco: 'branco', escuro: 'escuro' })[sobreEscolhido()]}) passa a valer para todos os clientes e lojas na próxima vez que abrirem o app.`, rotulo: 'Publicar para todos' });
  if (!c.ok) return;
  if (await executar(() => set(ref(db, 'config_plataforma/tema'), { primaria: hex, ...(sobreEscolhido() !== 'auto' ? { sobre: sobreEscolhido() } : {}), atualizadoEm: agoraIso(), atualizadoPor: S.user?.uid || '' }), `Cor publicada: ${hex.toUpperCase()}.`)) {
    try { localStorage.removeItem(CHAVE_TESTE); } catch { /* sem armazenamento */ }
    delete $('form-tema').dataset.sujo;
    const s = $('tema-status'); delete s.dataset.fixo;
    await logar('tema.alterar', hex.toUpperCase(), `antes: ${corOficial()?.toUpperCase() || 'padrão'}`);
    renderTema();
  }
});
$('tema-padrao').addEventListener('click', async () => {
  const c = await confirmar({ titulo: 'Voltar à cor padrão?', texto: `O app volta ao amarelo-mostarda do logo (${COR_PADRAO.toUpperCase()}) para todos.`, rotulo: 'Voltar ao padrão' });
  if (!c.ok) return;
  if (await executar(() => remove(ref(db, 'config_plataforma/tema')), 'Cor padrão restaurada.')) {
    try { localStorage.removeItem(CHAVE_TESTE); } catch { /* sem armazenamento */ }
    delete $('form-tema').dataset.sujo;
    await logar('tema.restaurar', COR_PADRAO.toUpperCase());
    renderTema();
  }
});
$('form-tema').addEventListener('submit', (e) => e.preventDefault());

// ---------- V75.131: barra do carrinho (cor da barra e da sacola com olhos) ----------
const SACOLA_PADRAO = { barra: '#1d1d1d', sacola: '#b85c00' };
const hexSacola = (v) => { const s = String(v || '').trim().toLowerCase(); const h = s.startsWith('#') ? s : `#${s}`; return /^#[0-9a-f]{6}$/.test(h) ? h : null; };
function pintarSacola(barra, sacola) {
  const p = $('sacola-previa'); if (!p) return;
  p.style.setProperty('--barra-carrinho', barra); p.style.setProperty('--sacola-cor', sacola);
  $('sacola-barra-cor').value = barra; $('sacola-cor').value = sacola;
  const s = $('sacola-status');
  if (s && !s.dataset.fixo) {
    const c = contraste(barra, '#ffffff'), cs = contraste(sacola, barra);
    s.textContent = c < 4.5 ? `O texto branco fica difícil de ler nesta barra (contraste ${c.toFixed(1).replace('.', ',')}:1). Prefira uma cor mais escura.`
      : cs < 1.5 ? 'A sacola quase some na barra: escolha cores mais diferentes entre si.' : 'Prévia abaixo. Publique quando gostar.';
  }
}
function renderSacola() {
  if (!$('form-sacola')) return;
  const v = S.sacola || {};
  const oficial = hexSacola(v.barra) && hexSacola(v.sacola);
  const est = $('sacola-estado');
  est.textContent = oficial ? 'Personalizada' : 'Padrão'; est.className = `m-selo m-selo-${oficial ? 'ok' : 'off'}`;
  if ($('form-sacola').dataset.sujo) return;
  const barra = hexSacola(v.barra) || SACOLA_PADRAO.barra, sacola = hexSacola(v.sacola) || SACOLA_PADRAO.sacola;
  if (document.activeElement !== $('sacola-barra-hex')) $('sacola-barra-hex').value = barra.toUpperCase();
  if (document.activeElement !== $('sacola-hex')) $('sacola-hex').value = sacola.toUpperCase();
  pintarSacola(barra, sacola);
}
function lerSacola() {
  const barra = hexSacola($('sacola-barra-hex').value), sacola = hexSacola($('sacola-hex').value);
  $('sacola-barra-hex').toggleAttribute('aria-invalid', !barra); $('sacola-hex').toggleAttribute('aria-invalid', !sacola);
  return barra && sacola ? { barra, sacola } : null;
}
function mudouSacola() { $('form-sacola').dataset.sujo = '1'; delete $('sacola-status').dataset.fixo; const c = lerSacola(); if (c) pintarSacola(c.barra, c.sacola); }
$('sacola-barra-cor')?.addEventListener('input', (e) => { $('sacola-barra-hex').value = e.target.value.toUpperCase(); mudouSacola(); });
$('sacola-cor')?.addEventListener('input', (e) => { $('sacola-hex').value = e.target.value.toUpperCase(); mudouSacola(); });
$('sacola-barra-hex')?.addEventListener('input', mudouSacola);
$('sacola-hex')?.addEventListener('input', mudouSacola);
$('sacola-piscar')?.addEventListener('click', () => { const p = $('sacola-previa'); p.classList.remove('pisca'); void p.offsetWidth; p.classList.add('pisca'); setTimeout(() => p.classList.remove('pisca'), 1000); });
$('sacola-publicar')?.addEventListener('click', async () => {
  const c = lerSacola();
  if (!c) { const s = $('sacola-status'); s.dataset.fixo = '1'; s.textContent = 'Código de cor inválido. Use o seletor ou algo como #1D1D1D.'; return; }
  const ok = await confirmar({ titulo: 'Publicar estas cores?', texto: `Barra ${c.barra.toUpperCase()} e sacola ${c.sacola.toUpperCase()} passam a valer para todos os clientes na próxima vez que abrirem o app.`, rotulo: 'Publicar para todos' });
  if (!ok.ok) return;
  if (await executar(() => set(ref(db, 'config_plataforma/sacola'), { barra: c.barra, sacola: c.sacola, atualizadoEm: agoraIso(), atualizadoPor: S.user?.uid || '' }), 'Cores da barra publicadas.')) {
    delete $('form-sacola').dataset.sujo;
    await logar('sacola.alterar', `${c.barra.toUpperCase()} / ${c.sacola.toUpperCase()}`);
    renderSacola();
  }
});
$('sacola-padrao')?.addEventListener('click', async () => {
  const ok = await confirmar({ titulo: 'Voltar ao padrão?', texto: 'A barra volta a grafite (#1D1D1D) e a sacola ao marrom queimado da logomarca (#B85C00) para todos.', rotulo: 'Voltar ao padrão' });
  if (!ok.ok) return;
  if (await executar(() => remove(ref(db, 'config_plataforma/sacola')), 'Cores padrão restauradas.')) {
    delete $('form-sacola').dataset.sujo;
    await logar('sacola.restaurar', 'padrão');
    renderSacola();
  }
});
$('form-sacola')?.addEventListener('submit', (e) => e.preventDefault());

// ---------- Anuncie no YAPOOD (convite e rodapé no painel das lojas) ----------
$('form-anuncie').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = $('anuncie-status');
  const ativo = $('anuncie-ativo').checked;
  const whatsapp = normalizarWhatsApp($('anuncie-whatsapp').value);
  const suporteBruto = $('anuncie-suporte').value.trim();
  const suporte = suporteBruto ? normalizarWhatsApp(suporteBruto) : '';
  if (!whatsapp) { s.dataset.fixo = '1'; s.textContent = 'Informe um WhatsApp comercial válido, com DDD. Ex.: (34) 99999-0000.'; return; }
  if (suporteBruto && !suporte) { s.dataset.fixo = '1'; s.textContent = 'O WhatsApp de suporte não é válido. Deixe em branco para usar o comercial.'; return; }
  delete s.dataset.fixo;
  const c = await confirmar({ titulo: 'Salvar “Anuncie no YAPOOD”?', texto: ativo ? `As lojas passam a ver o convite e o rodapé, com o WhatsApp ${formatarWhatsApp(whatsapp)}.` : 'O convite e o rodapé deixam de aparecer para as lojas.', rotulo: 'Salvar' });
  if (!c.ok) return;
  if (await executar(() => set(ref(db, 'config_plataforma/anuncie'), { ativo, whatsapp, ...(suporte ? { suporte } : {}), atualizadoEm: agoraIso(), atualizadoPor: S.user?.uid || '' }), 'Configuração salva.')) await logar('anuncie.alterar', ativo ? `ligado · ${formatarWhatsApp(whatsapp)}` : 'desligado');
});

// ---------- Aviso automático de cupom ----------
$('form-push-cupom').addEventListener('submit', async (e) => {
  e.preventDefault();
  const s = $('push-cupom-status');
  const ativo = $('push-cupom-ativo').checked;
  const limiteDiario = Math.floor(Number($('push-cupom-limite').value));
  if (!Number.isFinite(limiteDiario) || limiteDiario < 0 || limiteDiario > 100000) { s.dataset.fixo = '1'; s.textContent = 'Informe um teto entre 0 e 100000.'; return; }
  delete s.dataset.fixo;
  const c = await confirmar({ titulo: 'Salvar aviso de cupom?', texto: ativo ? `O aviso automático fica ligado, com teto de ${limiteDiario} aparelhos por dia.` : 'O aviso automático fica desligado: nenhuma loja consegue avisar clientes sobre cupons.', rotulo: 'Salvar' });
  if (!c.ok) return;
  if (await executar(() => set(ref(db, 'config_plataforma/push_cupom'), { ativo, limiteDiario, atualizadoEm: agoraIso(), atualizadoPor: S.user?.uid || '' }), 'Configuração salva.')) await logar('pushcupom.alterar', ativo ? `ligado · teto ${limiteDiario}` : 'desligado');
});

painelAcertos = iniciarAcertosMaster({ S, $, esc, aviso, executar, confirmar, logar, fmtData, vazio, selo, db, ref, set, update, push, suspender: acaoLojaSuspender });
painelCidades = iniciarCidadesMaster({ S, $, esc, aviso, executar, confirmar, logar, vazio, selo, db, ref, set, update, remove, liberarCidade });
painelRede = iniciarRedeMaster({ S, $, esc, aviso, executar, confirmar, logar, db, ref, get, set, auth });
iniciarFaxinaMaster({ $, esc, aviso, executar, confirmar, logar, auth }); // V75.117: faxina das imagens (Configuração)
// V75.151: Limites e planos (semáforo dos planos grátis). Números digitados ficam em config_plataforma/limites; sem a regra publicada, ficam só neste aparelho.
const CHAVE_LIMITES = 'yapood_limites_master';
const premissasLimites = () => { let local = {}; try { local = JSON.parse(localStorage.getItem(CHAVE_LIMITES) || '{}') || {}; } catch { /* sem armazenamento */ } return { ...local, ...(S.limites || {}) }; };
async function salvarLimites(obj) {
  const dados = { ...obj, atualizadoEm: Date.now() };
  try { localStorage.setItem(CHAVE_LIMITES, JSON.stringify(dados)); } catch { /* sem armazenamento */ }
  try { await set(ref(db, 'config_plataforma/limites'), dados); S.limites = dados; }
  catch (e) { S.limites = dados; throw new Error('Salvei só neste aparelho. Para guardar no servidor, publique as regras V75.151 do Firebase (regras/database.rules.RASCUNHO-V75.151.json).'); }
}
painelLimites = iniciarLimitesMaster({ $, esc, aviso, executar, logar, auth, dados: () => ({ base: { lojas: S.lojas, pedidos: S.pedidos, usuarios: S.usuarios, usuariosOk: S.usuariosOk }, prem: premissasLimites() }), salvar: salvarLimites });
painelCadastros = iniciarCadastrosMaster({ S, $, esc, aviso, executar, confirmar, logar, fmtData, quando, vazio, selo, db, ref, get, update, remove, auth, NOTPUSH_API });

// ---------- Acesso ----------
const isMaster = async (uid) => (await get(ref(db, `admins/${uid}/role`))).val() === 'master';
function mostrarLogin(msg = '') { $('master-login').hidden = false; $('master-app').hidden = true; $('master-login-status').textContent = msg; }
async function entrar(u) {
  if (S.entrou && S.user?.uid === u.uid) return;
  S.user = u; S.entrou = true;
  $('master-login').hidden = true; $('master-app').hidden = false;
  $('master-account-name').textContent = u.displayName || u.email || 'Master';
  const inicial = (location.hash || '').slice(1);
  iniciarDados();
  setView(TITULOS[inicial] ? inicial : 'resumen');
}
$('btn-master-login').addEventListener('click', async () => {
  try {
    $('master-login-status').textContent = 'Entrando…';
    const r = await signInWithPopup(auth, googleProvider);
    if (!(await isMaster(r.user.uid))) { await signOut(auth); mostrarLogin('Esta conta não tem permissão Master.'); return; }
    await entrar(r.user);
  } catch (e) { console.error(e); mostrarLogin(e.message || 'Não foi possível entrar.'); }
});
$('btn-master-logout').addEventListener('click', () => signOut(auth));
onAuthStateChanged(auth, async (u) => {
  if (!u) { encerrarDados(); S.entrou = false; S.user = null; fecharGaveta(); mostrarLogin(); return; }
  try {
    if (!(await isMaster(u.uid))) { await signOut(auth); mostrarLogin('Esta conta não tem permissão Master.'); return; }
    await entrar(u);
  } catch (e) { console.error(e); mostrarLogin(e.message || 'Não foi possível validar o acesso Master.'); }
});
let tRedim = 0;
window.addEventListener('resize', () => { clearTimeout(tRedim); tRedim = setTimeout(() => { if (S.entrou && S.view === 'resumen') renderResumo(); }, 150); });
window.addEventListener('hashchange', () => { const v = (location.hash || '').slice(1); if (S.entrou && TITULOS[v] && v !== S.view) setView(v); });
