// js/cadastro-analise.js — V75.47: regras puras da aba "Solicitações" do Master (fila, duplicados, leitura da consulta de CNPJ).
// Testadas em tests/cadastro-analise.test.mjs.
import { CADASTRO, somenteDigitos, idadeEm } from './cadastro-lojista.js';

export const FILTROS_CADASTRO = Object.freeze({ PENDENTES: 'pendentes', RECUSADOS: 'recusados', APROVADOS: 'aprovados', TODOS: 'todos' });

/** Lista da aba: pendentes primeiro (o mais antigo no topo, para ninguém ficar esperando); o resto, do mais recente para o mais antigo. */
export function filtrarCadastros(mapa, filtro = FILTROS_CADASTRO.PENDENTES, busca = '') {
  const alvo = { pendentes: CADASTRO.PENDENTE, recusados: CADASTRO.RECUSADO, aprovados: CADASTRO.APROVADO }[filtro] || null;
  const q = semAcento(busca);
  const lista = Object.entries(mapa || {})
    .filter(([, c]) => c && typeof c === 'object')
    .map(([uid, c]) => ({ ...c, uid }))
    .filter((c) => (!alvo || c.status === alvo) && (!q || semAcento(`${c.nomeCompleto} ${c.nomeLoja} ${c.email} ${c.doc}`).includes(q) || (somenteDigitos(busca) && String(c.doc || '').includes(somenteDigitos(busca)))));
  const t = (c) => String(c.enviadoEm || '');
  const pend = lista.filter((c) => c.status === CADASTRO.PENDENTE).sort((a, b) => t(a).localeCompare(t(b)));
  const resto = lista.filter((c) => c.status !== CADASTRO.PENDENTE).sort((a, b) => t(b).localeCompare(t(a)));
  return [...pend, ...resto];
}

export const contarPendentes = (mapa) => Object.values(mapa || {}).filter((c) => c?.status === CADASTRO.PENDENTE).length;

/** Outros cadastros (de outras contas) com o mesmo CPF/CNPJ — sinal de alerta para o Master. */
export function outrosComMesmoDocumento(mapa, uid) {
  const meu = mapa?.[uid]?.doc;
  if (!meu) return [];
  return Object.entries(mapa).filter(([u, c]) => u !== uid && c?.doc === meu).map(([u, c]) => ({ uid: u, nomeCompleto: c.nomeCompleto, status: c.status }));
}

export const urlConsultaCnpj = (doc) => {
  const d = somenteDigitos(doc);
  return d.length === 14 ? `https://brasilapi.com.br/api/cnpj/v1/${d}` : '';
};

export const semAcento = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

/** Todas as palavras do nome mais curto aparecem no mais longo (ignora acento, caixa e "da/de/dos"). */
export function nomesParecidos(a, b) {
  const ruido = new Set(['da', 'de', 'do', 'das', 'dos', 'e']);
  const tok = (s) => semAcento(s).split(' ').filter((t) => t && !ruido.has(t));
  const ta = tok(a), tb = tok(b);
  if (!ta.length || !tb.length) return false;
  const [menor, maior] = ta.length <= tb.length ? [ta, tb] : [tb, ta];
  return menor.length >= 2 && menor.every((t) => maior.includes(t));
}

/** Resume a resposta da BrasilAPI e aponta o que merece atenção. */
export function interpretarCnpj(api, cadastro) {
  if (!api || typeof api !== 'object') return null;
  const situacao = String(api.descricao_situacao_cadastral || '').trim();
  const socios = (Array.isArray(api.qsa) ? api.qsa : []).map((s) => String(s?.nome_socio || '').trim()).filter(Boolean);
  const avisos = [];
  if (situacao && semAcento(situacao) !== 'ativa') avisos.push(`A situação do CNPJ na Receita é "${situacao}".`);
  if (socios.length && cadastro?.nomeCompleto && !socios.some((s) => nomesParecidos(s, cadastro.nomeCompleto))) avisos.push('O nome informado não aparece entre os sócios do CNPJ.');
  if (!socios.length) avisos.push('A consulta não trouxe os sócios; confira o responsável pelo documento enviado.');
  return {
    razaoSocial: String(api.razao_social || ''), fantasia: String(api.nome_fantasia || ''), situacao,
    abertura: String(api.data_inicio_atividade || ''), cidade: [api.municipio, api.uf].filter(Boolean).join('/'),
    atividade: String(api.cnae_fiscal_descricao || ''), socios, avisos
  };
}

/** Alertas sobre o próprio cadastro (além do CNPJ). */
export function alertasDoCadastro(c, mapa, hoje = new Date()) {
  const a = [];
  if (!c) return a;
  const dup = outrosComMesmoDocumento(mapa, c.uid);
  if (dup.length) a.push(`Este ${String(c.docTipo || 'documento').toUpperCase()} também aparece em ${dup.length} outro(s) cadastro(s): ${dup.map((d) => d.nomeCompleto).join(', ')}.`);
  const idade = idadeEm(c.nascimento, hoje);
  if (idade !== null && idade < 18) a.push(`A data de nascimento informada indica ${idade} anos.`);
  return a;
}
