// js/admin-produto-extras.js — V75.127: no painel da loja, cadastro das opções (escolha uma) e dos adicionais (− 0 +) de cada produto.
// Partes puras (extrasDoBanco / extrasParaBanco) testadas em tests/admin-produto-extras.test.mjs; o editor só desenha e lê o formulário.
import { LIMITES } from './produto-opcoes.js?v=75.127';

const txt = (v, max) => String(v ?? '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, max);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ordenados = (obj) => Object.entries(obj && typeof obj === 'object' ? obj : {}).filter(([, v]) => v && typeof v === 'object')
  .sort((a, b) => (Number(a[1].ordem) || 0) - (Number(b[1].ordem) || 0) || a[0].localeCompare(b[0]));
let seq = 0;
export const novoId = (p) => `${p}_${Date.now().toString(36)}${(seq++).toString(36)}${Math.random().toString(36).slice(2, 5)}`;
const idValido = (id) => /^[A-Za-z0-9_-]{1,40}$/.test(String(id || ''));

/** Produto do banco → estado do editor. */
export function extrasDoBanco(item) {
  return {
    grupos: ordenados(item?.opcoes).map(([id, g]) => ({ id, nome: txt(g.nome, LIMITES.nome), obrigatorio: g.obrigatorio !== false,
      opcoes: ordenados(g.itens).map(([oid, o]) => ({ id: oid, nome: txt(o.nome, LIMITES.nome), preco: Number(o.preco) > 0 ? String(o.preco) : '' })) })),
    adicionais: ordenados(item?.adicionais).map(([id, a]) => ({ id, nome: txt(a.nome, LIMITES.nome), preco: Number(a.preco) > 0 ? String(a.preco) : '', max: String(parseInt(a.max, 10) || LIMITES.maxPadrao) }))
  };
}

function lerPreco(v) {
  const s = String(v ?? '').trim().replace(',', '.');
  if (!s) return 0;
  const n = Number(s);
  return Number.isFinite(n) && n >= 0 && n <= 10000 ? Math.round(n * 100) / 100 : null;
}

/**
 * Estado do editor → campos do produto. Linhas totalmente vazias são ignoradas.
 * → { ok: true, opcoes: {..}|null, adicionais: {..}|null } (null apaga do banco) ou { ok: false, erro }
 */
export function extrasParaBanco(estado) {
  const grupos = (estado?.grupos || []).map((g) => ({ ...g, nome: txt(g.nome, LIMITES.nome), opcoes: (g.opcoes || []).filter((o) => txt(o.nome, 99) || String(o.preco ?? '').trim()) }))
    .filter((g) => g.nome || g.opcoes.length);
  if (grupos.length > LIMITES.grupos) return { ok: false, erro: `No máximo ${LIMITES.grupos} grupos de opções por produto.` };
  const opcoes = {};
  for (const [gi, g] of grupos.entries()) {
    if (!g.nome) return { ok: false, erro: 'Dê um nome ao grupo de opções (ex.: Ponto da carne).' };
    if (!g.opcoes.length) return { ok: false, erro: `O grupo "${g.nome}" precisa de pelo menos uma opção.` };
    if (g.opcoes.length > LIMITES.opcoesPorGrupo) return { ok: false, erro: `O grupo "${g.nome}" pode ter até ${LIMITES.opcoesPorGrupo} opções.` };
    const itens = {};
    for (const [oi, o] of g.opcoes.entries()) {
      const nome = txt(o.nome, LIMITES.nome);
      if (!nome) return { ok: false, erro: `Falta o nome de uma opção em "${g.nome}".` };
      const preco = lerPreco(o.preco);
      if (preco === null) return { ok: false, erro: `Preço inválido em "${nome}".` };
      itens[idValido(o.id) ? o.id : novoId('o')] = { nome, preco, ordem: oi };
    }
    opcoes[idValido(g.id) ? g.id : novoId('g')] = { nome: g.nome, obrigatorio: g.obrigatorio !== false, ordem: gi, itens };
  }
  const lista = (estado?.adicionais || []).filter((a) => txt(a.nome, 99) || String(a.preco ?? '').trim());
  if (lista.length > LIMITES.adicionais) return { ok: false, erro: `No máximo ${LIMITES.adicionais} adicionais por produto.` };
  const adicionais = {};
  for (const [ai, a] of lista.entries()) {
    const nome = txt(a.nome, LIMITES.nome);
    if (!nome) return { ok: false, erro: 'Falta o nome de um adicional.' };
    const preco = lerPreco(a.preco);
    if (preco === null) return { ok: false, erro: `Preço inválido em "${nome}".` };
    const max = String(a.max ?? '').trim() === '' ? LIMITES.maxPadrao : parseInt(a.max, 10);
    if (!Number.isInteger(max) || max < 1 || max > LIMITES.maxPorAdicional) return { ok: false, erro: `A quantidade máxima de "${nome}" deve ser de 1 a ${LIMITES.maxPorAdicional}.` };
    adicionais[idValido(a.id) ? a.id : novoId('a')] = { nome, preco, max, ordem: ai };
  }
  return { ok: true, opcoes: Object.keys(opcoes).length ? opcoes : null, adicionais: Object.keys(adicionais).length ? adicionais : null };
}

// ---------- Editor (DOM) ----------
const htmlOpcao = (o) => `<div class="ext-op" data-o="${esc(o.id)}">
  <input class="ext-o-nome" maxlength="${LIMITES.nome}" placeholder="Ex.: Ao ponto" value="${esc(o.nome)}" aria-label="Nome da opção">
  <input class="ext-o-preco" inputmode="decimal" placeholder="+ R$ 0,00" value="${esc(o.preco)}" aria-label="Preço a mais da opção">
  <button type="button" class="ext-x" data-rem-op aria-label="Remover opção"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button></div>`;
const htmlGrupo = (g) => `<div class="ext-grupo" data-g="${esc(g.id)}">
  <div class="ext-grupo-topo">
    <input class="ext-g-nome" maxlength="${LIMITES.nome}" placeholder="Grupo (ex.: Ponto da carne)" value="${esc(g.nome)}" aria-label="Nome do grupo">
    <label class="ext-check"><input type="checkbox" class="ext-g-obrig"${g.obrigatorio !== false ? ' checked' : ''}> Obrigatório</label>
    <button type="button" class="ext-x" data-rem-grupo aria-label="Remover grupo"><i class="fa-solid fa-trash-can" aria-hidden="true"></i></button>
  </div>
  <div class="ext-ops">${(g.opcoes || []).map(htmlOpcao).join('')}</div>
  <button type="button" class="ext-add" data-add-op><i class="fa-solid fa-plus" aria-hidden="true"></i> Opção</button></div>`;
const htmlAdicional = (a) => `<div class="ext-ad" data-a="${esc(a.id)}">
  <input class="ext-a-nome" maxlength="${LIMITES.nome}" placeholder="Ex.: Queijo" value="${esc(a.nome)}" aria-label="Nome do adicional">
  <input class="ext-a-preco" inputmode="decimal" placeholder="R$ 0,00" value="${esc(a.preco)}" aria-label="Preço do adicional">
  <input class="ext-a-max" inputmode="numeric" placeholder="Máx. 5" value="${esc(a.max)}" aria-label="Quantidade máxima" title="Quantidade máxima por item">
  <button type="button" class="ext-x" data-rem-ad aria-label="Remover adicional"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button></div>`;

/** Desenha o editor dentro de `caixa` com os dados do produto (ou vazio para produto novo). */
export function montarEditorExtras(caixa, item = null) {
  if (!caixa) return;
  const e = extrasDoBanco(item);
  caixa.innerHTML = `<section class="ext-bloco">
      <div class="ext-cab"><strong>Opções de escolha</strong><small>Ex.: Ponto da carne, Tamanho, Sabor. O cliente escolhe uma de cada grupo. Preço a mais é opcional.</small></div>
      <div class="ext-grupos">${e.grupos.map(htmlGrupo).join('')}</div>
      <button type="button" class="ext-add" data-add-grupo><i class="fa-solid fa-plus" aria-hidden="true"></i> Grupo de opções</button>
    </section>
    <section class="ext-bloco">
      <div class="ext-cab"><strong>Adicionais</strong><small>O cliente escolhe a quantidade com − 0 +. Ex.: Queijo + R$ 3,00 (máximo 5).</small></div>
      <div class="ext-ads">${e.adicionais.map(htmlAdicional).join('')}</div>
      <button type="button" class="ext-add" data-add-ad><i class="fa-solid fa-plus" aria-hidden="true"></i> Adicional</button>
    </section>`;
  if (caixa.dataset.ligado) return;
  caixa.dataset.ligado = '1';
  caixa.addEventListener('click', (ev) => {
    const b = ev.target.closest('button'); if (!b) return;
    if (b.hasAttribute('data-add-grupo')) {
      caixa.querySelector('.ext-grupos').insertAdjacentHTML('beforeend', htmlGrupo({ id: novoId('g'), nome: '', obrigatorio: true, opcoes: [{ id: novoId('o'), nome: '', preco: '' }, { id: novoId('o'), nome: '', preco: '' }] }));
      caixa.querySelector('.ext-grupo:last-child .ext-g-nome')?.focus();
    } else if (b.hasAttribute('data-add-op')) {
      const ops = b.closest('.ext-grupo').querySelector('.ext-ops');
      ops.insertAdjacentHTML('beforeend', htmlOpcao({ id: novoId('o'), nome: '', preco: '' }));
      ops.lastElementChild.querySelector('input')?.focus();
    } else if (b.hasAttribute('data-add-ad')) {
      const ads = caixa.querySelector('.ext-ads');
      ads.insertAdjacentHTML('beforeend', htmlAdicional({ id: novoId('a'), nome: '', preco: '', max: '' }));
      ads.lastElementChild.querySelector('input')?.focus();
    } else if (b.hasAttribute('data-rem-grupo')) b.closest('.ext-grupo').remove();
    else if (b.hasAttribute('data-rem-op')) b.closest('.ext-op').remove();
    else if (b.hasAttribute('data-rem-ad')) b.closest('.ext-ad').remove();
  });
}

/** Lê o editor → { ok, opcoes, adicionais } | { ok:false, erro } */
export function lerEditorExtras(caixa) {
  if (!caixa) return { ok: true, opcoes: null, adicionais: null };
  const v = (el, sel) => el.querySelector(sel)?.value ?? '';
  return extrasParaBanco({
    grupos: [...caixa.querySelectorAll('.ext-grupo')].map((g) => ({ id: g.dataset.g, nome: v(g, '.ext-g-nome'), obrigatorio: !!g.querySelector('.ext-g-obrig')?.checked,
      opcoes: [...g.querySelectorAll('.ext-op')].map((o) => ({ id: o.dataset.o, nome: v(o, '.ext-o-nome'), preco: v(o, '.ext-o-preco') })) })),
    adicionais: [...caixa.querySelectorAll('.ext-ad')].map((a) => ({ id: a.dataset.a, nome: v(a, '.ext-a-nome'), preco: v(a, '.ext-a-preco'), max: v(a, '.ext-a-max') }))
  });
}
