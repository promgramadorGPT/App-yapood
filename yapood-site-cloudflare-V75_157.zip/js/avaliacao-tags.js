// js/avaliacao-tags.js — V75.139: comentários prontos da avaliação sem contradição.
// Em cada etapa (comida / entrega), marcar um positivo bloqueia os negativos e vice-versa; desmarcando tudo, todos voltam.
// Etapas diferentes não se bloqueiam (comida boa + entrega demorada continua possível).

/** Qual tipo fica bloqueado, pelos tipos já marcados na etapa: 'ruim', 'bom' ou null. */
export function tipoBloqueado(tiposMarcados) {
  const t = tiposMarcados || [];
  if (t.includes('bom')) return 'ruim';
  if (t.includes('ruim')) return 'bom';
  return null;
}
/** Aplica o bloqueio num .tags-container (botões .tag-opainter com data-tipo) e mostra a dica. */
export function aplicarBloqueio(container) {
  if (!container) return;
  const tags = [...container.querySelectorAll('.tag-opainter')];
  const bloq = tipoBloqueado(tags.filter((t) => t.classList.contains('ativa')).map((t) => t.dataset.tipo));
  tags.forEach((t) => {
    const b = !!bloq && t.dataset.tipo === bloq;
    t.classList.toggle('bloqueada', b); t.disabled = b;
    if (b) t.setAttribute('aria-disabled', 'true'); else t.removeAttribute('aria-disabled');
  });
  let dica = container.nextElementSibling?.classList?.contains('tags-dica') ? container.nextElementSibling : null;
  if (!dica) { dica = document.createElement('p'); dica.className = 'tags-dica'; container.after(dica); }
  dica.hidden = !bloq;
  dica.textContent = bloq === 'ruim' ? 'Para marcar um ponto negativo, desmarque os positivos.' : bloq === 'bom' ? 'Para marcar um ponto positivo, desmarque os negativos.' : '';
}
