// js/cupom-produtos.js — V75.49: escolha dos produtos participantes do cupom (busca + categorias + seleção).
// Funções puras (testadas). A tela fica em admin-loja.js.

export const SEM_CATEGORIA = 'Sem categoria';

const semAcento = (v) => String(v ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

export const categoriaDoProduto = (p) => String(p?.categoria ?? '').trim() || SEM_CATEGORIA;

/** Lista ordenada por nome: [{id, nome, preco, categoria}] (ignora entradas inválidas). */
export function listarProdutos(menu) {
  return Object.entries(menu || {})
    .filter(([, p]) => p && typeof p === 'object')
    .map(([id, p]) => ({ id, nome: String(p.nombre || 'Produto'), preco: Number(p.precio) || 0, categoria: categoriaDoProduto(p) }))
    .sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
}

/** Categorias existentes, em ordem alfabética, com quantos produtos e quantos já estão ligados. */
export function categoriasDoMenu(menu, selecionados) {
  const sel = selecionados instanceof Set ? selecionados : new Set(selecionados || []);
  const mapa = new Map();
  for (const p of listarProdutos(menu)) {
    const c = mapa.get(p.categoria) || { nome: p.categoria, total: 0, ligados: 0 };
    c.total++; if (sel.has(p.id)) c.ligados++;
    mapa.set(p.categoria, c);
  }
  return [...mapa.values()].sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
}

/** Produtos visíveis para a busca (nome ou categoria, sem acento/caixa) e a categoria escolhida ('todas' = sem filtro). */
export function filtrarProdutos(menu, { busca = '', categoria = 'todas' } = {}) {
  const q = semAcento(busca);
  return listarProdutos(menu).filter((p) =>
    (categoria === 'todas' || p.categoria === categoria) &&
    (!q || semAcento(p.nome).includes(q) || semAcento(p.categoria).includes(q)));
}

/** Mantém só ids que ainda existem no cardápio (um produto apagado não pode ficar no cupom). */
export function selecaoValida(menu, selecionados) {
  return [...(selecionados || [])].filter((id) => menu && Object.prototype.hasOwnProperty.call(menu, id) && menu[id]);
}

/** Liga ou desliga vários de uma vez (ex.: "marcar os que aparecem"). Devolve um novo Set. */
export function alternarVarios(selecionados, ids, ligar) {
  const novo = new Set(selecionados || []);
  for (const id of ids) ligar ? novo.add(id) : novo.delete(id);
  return novo;
}

export function resumoSelecao(n) {
  const q = Number(n) || 0;
  return q ? `${q} produto${q > 1 ? 's' : ''} selecionado${q > 1 ? 's' : ''}` : 'Todos os produtos';
}

/** Valor gravado no cupom: {idDoProduto: true} ou nada (sem seleção = vale para o pedido todo). */
export function produtosParaCupom(menu, selecionados) {
  const ids = selecaoValida(menu, selecionados);
  return ids.length ? Object.fromEntries(ids.map((id) => [id, true])) : null;
}
