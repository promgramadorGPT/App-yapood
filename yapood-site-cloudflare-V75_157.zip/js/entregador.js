import './icones-app.js';
// js/entregador.js — app do entregador (V75.23). Regras puras em entregador-util.js e rota.js.
import { auth, googleProvider, signInWithPopup, onAuthStateChanged, signOut } from './firebase.js';
import './ui-mensagens.js';
import { ordenarParadas, moverParada, urlRota, MAX_PARADAS } from './rota.js';
import { avisarEvento } from './notpush-evento.js';
import './aviso-google.js?v=75.102';
import { entregasParaRastrear, devePublicarPosicao, precisaBatimento, textoLocalizacaoEntregador } from './rastreio.js';
import { resumoGanhos, rotuloTaxa, mensagemChegada, assinatura, novasEntregas, textoTentativas, linkWhatsApp, FORMAS, estadoAvisos, canceladasParaAviso, acabaramCanceladas } from './entregador-util.js?v=75.105';

const API = 'https://api-mp-yapoodbr.onrender.com';
const POLL_MS = 30000;
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const moeda = v => (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dataHora = t => t ? new Date(t).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '';
const pl = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;

let timer = null;
let dados = null;            // última resposta de /entregador/minhas
let assinaturaAtual = null;  // para só redesenhar quando algo mudou
let paradasAtuais = [];
let abaAtual = 'entregas';
let carregando = false;
let tituloOriginal = document.title;

async function chamar(rota, corpo = {}) {
  const token = await auth.currentUser.getIdToken();
  const r = await fetch(API + rota, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(corpo) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'Não foi possível concluir.'), { status: r.status, dados: d });
  return d;
}

function tela(qual) {
  $('ent-carregando').hidden = qual !== 'carregando';
  $('ent-login').hidden = qual !== 'login';
  $('ent-painel').hidden = qual !== 'painel';
}
function mostrarAviso(msg) { const el = $('ent-aviso'); el.textContent = msg || ''; el.hidden = !msg; }

// ---- Conexão ----
function atualizarConexao() {
  const on = navigator.onLine !== false;
  const el = $('ent-conexao');
  el.textContent = on ? 'Online' : 'Sem internet';
  el.classList.toggle('off', !on);
}

// ---- Abas ----
function trocarAba(aba) {
  abaAtual = aba;
  for (const b of document.querySelectorAll('.ent-nav-btn')) {
    const ativa = b.dataset.aba === aba;
    b.classList.toggle('ativa', ativa);
    if (ativa) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
  }
  for (const a of ['entregas', 'historico', 'ganhos']) $('ent-aba-' + a).hidden = a !== aba;
  window.scrollTo({ top: 0 });
}

// ---- Rota única (V75.18) ----
const rotaUrl = endereco => 'https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=' + encodeURIComponent(endereco);
const chaveOrdem = () => 'yapood_rota_' + (auth.currentUser?.uid || '');
function lerOrdem() { try { return JSON.parse(localStorage.getItem(chaveOrdem()) || '[]'); } catch { return []; } }
function salvarOrdem(ids) { try { localStorage.setItem(chaveOrdem(), JSON.stringify(ids)); } catch { /* noop */ } }

// ---- V75.90: mapa dentro do app (rota pronta com as entregas da loja; Google Maps continua como alternativa) ----
let mapaMod = null;
const botaoMapaCartao = () => '<button type="button" class="ent-btn ent-btn-principal ent-btn-mapa" data-abrir-mapa><i class="fa-solid fa-map-location-dot" aria-hidden="true"></i> Abrir mapa</button>';
const botaoMapa = () => '<button type="button" class="ent-btn ent-btn-principal ent-rota-abrir" data-abrir-mapa><i class="fa-solid fa-map-location-dot" aria-hidden="true"></i> Abrir mapa com a rota</button>';
function irParaCartao(id) {
  trocarAba('entregas');
  const card = [...document.querySelectorAll('#ent-aba-entregas [data-pedido]')].find(c => c.dataset.pedido === id);
  if (!card) return;
  card.scrollIntoView({ block: 'center' });
  card.querySelector('.ent-codigo input')?.focus();
}
async function abrirMapaEntregador() {
  const btns = document.querySelectorAll('[data-abrir-mapa]');
  btns.forEach(b => { b.disabled = true; });
  try {
    mapaMod = mapaMod || await import('./mapa-ui.js?v=75.153');
    await mapaMod.abrirMapa({
      chamar,
      paradas: paradasAtuais.slice(),
      paradasAtuais: () => paradasAtuais.slice(),
      ordemSalva: lerOrdem(), ordemAtual: lerOrdem,
      salvarOrdem: ids => { salvarOrdem(ids); renderRota(); },
      irParaCartao,
      aoFechar: () => renderRota(),
      urlGoogle: () => urlRota(ordenarParadas(paradasAtuais, lerOrdem()).map(p => p.endereco))?.url
    });
  } catch (err) { mostrarAviso(err.message || 'Não consegui abrir o mapa.'); }
  finally { btns.forEach(b => { b.disabled = false; }); }
}

// V75.100: com 2 ou mais entregas ativas, TUDO fica num card só (a rota com cada pedido dentro, na ordem). Com 1, o card do pedido sozinho.
const chaveDispensadas = () => 'yapood_cancel_' + (auth.currentUser?.uid || '');
function lerDispensadas() { try { return JSON.parse(localStorage.getItem(chaveDispensadas()) || '[]'); } catch { return []; } }
function dispensarCancelada(k) { try { localStorage.setItem(chaveDispensadas(), JSON.stringify([...new Set([...lerDispensadas(), k])].slice(-100))); } catch { /* noop */ } }

function cartaoCancelado(e) {
  const k = esc(e.pedidoKey);
  return `<article class="ent-card ent-card-aviso-cancel" data-cancelado="${k}" role="alert">
    <div class="ent-card-topo"><strong>Pedido #${esc(e.numeroPedido)}</strong><span class="ent-selo-cancel"><i class="fa-solid fa-ban" aria-hidden="true"></i> Cancelado</span></div>
    <p class="ent-cliente">${esc(e.cliente.nome)}</p>
    ${e.cliente.endereco ? `<p class="ent-endereco">${esc(e.cliente.endereco)}</p>` : ''}
    <p class="ent-erro ent-cancel-texto"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Este pedido foi cancelado. Não leve ao cliente. Se você já saiu com ele, volte à loja ou fale com ela.</p>
    <button type="button" class="ent-btn ent-btn-leve" data-remover-cancelado="${k}"><i class="fa-solid fa-xmark" aria-hidden="true"></i> Remover da tela</button>
  </article>`;
}

function desenharEntregas() {
  if (!dados) return;
  const entregas = dados.entregas || [];
  const ativas = entregas.filter(e => !e.confirmada && !e.cancelado);
  const canceladas = canceladasParaAviso(entregas, lerDispensadas());
  paradasAtuais = ativas.filter(e => e.cliente.endereco).map(e => ({ id: e.pedidoKey, endereco: e.cliente.endereco, numero: e.numeroPedido }));
  mapaMod?.atualizarEntregas(paradasAtuais, entregas.filter(e => e.cancelado && !e.confirmada).map(e => e.pedidoKey));
  $('ent-cancel').innerHTML = canceladas.map(cartaoCancelado).join('');
  const box = $('ent-rota'), lista = $('ent-lista');
  if (ativas.length < 2) {   // uma entrega só (ou nenhuma): card do pedido, com o botão do mapa dentro
    box.innerHTML = '';
    lista.innerHTML = ativas.length ? ativas.map(e => cartao(e)).join('') : (canceladas.length ? '' : '<p class="ent-vazio">Nenhuma entrega agora.<br>Quando a loja atribuir uma, ela aparece aqui.</p>');
    return;
  }
  const ordenadas = ordenarParadas(paradasAtuais, lerOrdem());
  const porId = new Map(ativas.map(e => [e.pedidoKey, e]));
  const naOrdem = ordenadas.map(p => porId.get(p.id)).concat(ativas.filter(e => !e.cliente.endereco));   // sem endereço vai para o fim
  const r = urlRota(ordenadas.map(p => p.endereco));
  lista.innerHTML = '';
  box.innerHTML = `<section class="ent-rota-card">
    <h3>Rota com ${naOrdem.length} entregas</h3>
    <p class="ent-rota-ajuda">Os pedidos estão na ordem da rota, a partir de onde você está. Use as setas para mudar a ordem.</p>
    ${r && r.ignoradas ? `<p class="ent-erro">O Google Maps aceita ${MAX_PARADAS} paradas por rota. As ${r.ignoradas} últimas ficam para a próxima rota.</p>` : ''}
    ${paradasAtuais.length ? botaoMapa() : ''}
    ${r ? `<a class="ent-btn ent-btn-leve ent-rota-abrir" data-google target="_blank" rel="noopener" href="${r.url}"><i class="fa-solid fa-route" aria-hidden="true"></i> Ver rota no Google Maps</a>` : ''}
    <div class="ent-grupo-lista">${naOrdem.map((e, i) => cartao(e, { pos: i + 1, total: naOrdem.length })).join('')}</div>
  </section>`;
}
/** Redesenha só as entregas (ordem mudou, mapa fechou) sem apagar o código que está sendo digitado. */
function renderRota() { if (!dados) return; const est = capturarEstado(); desenharEntregas(); restaurarEstado(est); }

// ---- Cartões ----
const ehDinheiro = e => /dinheiro/i.test(e.pagamento) || /entrega/i.test(e.pagoStatus);

function cartao(e, grupo = null) {
  const dinheiro = ehDinheiro(e);
  const fone = String(e.cliente.telefone).replace(/\D/g, '');
  const lojaNome = dados?.loja?.nome || '';
  const zap = linkWhatsApp(fone, mensagemChegada({ loja: lojaNome, numero: e.numeroPedido, entregador: dados?.entregador?.nome || '' }));
  const lojaFone = String(dados?.loja?.telefone || '').replace(/\D/g, '');
  const restantes = e.tentativasRestantes;
  const bloqueado = Number.isFinite(restantes) && restantes <= 0;
  const qtdItens = e.itens.reduce((s, i) => s + (Number(i.qtd) || 0), 0);
  const k = esc(e.pedidoKey);
  const mover = grupo ? `<span class="ent-parada-mover">
      <button type="button" class="ent-btn ent-btn-leve" data-rota-mover="${k}" data-delta="-1" aria-label="Subir parada" ${grupo.pos === 1 || !e.cliente.endereco ? 'disabled' : ''}><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></button>
      <button type="button" class="ent-btn ent-btn-leve" data-rota-mover="${k}" data-delta="1" aria-label="Descer parada" ${grupo.pos === grupo.total || !e.cliente.endereco ? 'disabled' : ''}><i class="fa-solid fa-arrow-down" aria-hidden="true"></i></button></span>` : '';
  return `<article class="ent-card${dinheiro ? ' ent-card-cobrar' : ''}${grupo ? ' ent-card-parada' : ''}" data-pedido="${k}">
    ${grupo ? `<div class="ent-parada-topo"><span class="ent-parada-num">${grupo.pos}</span><span class="ent-parada-rot">Parada ${grupo.pos} de ${grupo.total}</span>${mover}</div>` : ''}
    <div class="ent-card-topo"><strong>Pedido #${esc(e.numeroPedido)}</strong>${e.bairro ? `<span class="ent-bairro">${esc(e.bairro)}</span>` : ''}</div>
    <p class="ent-cliente">${esc(e.cliente.nome)}</p>
    <p class="ent-endereco">${esc(e.cliente.endereco) || 'Endereço não informado'}</p>
    ${e.cliente.observacao ? `<p class="ent-obs"><i class="fa-solid fa-note-sticky" aria-hidden="true"></i> ${esc(e.cliente.observacao)}</p>` : ''}
    ${dinheiro
      ? `<p class="ent-cobrar" role="note"><span><i class="fa-solid fa-money-bill-wave" aria-hidden="true"></i> Cobrar do cliente</span><strong>${moeda(e.aCobrar ?? e.total)}</strong></p>${e.saldoUsado > 0 ? `<p class="ent-troco" role="note"><i class="fa-solid fa-wallet" aria-hidden="true"></i> Total ${moeda(e.total)} · <strong>${moeda(e.saldoUsado)}</strong> já pagos com saldo da loja</p>` : ''}${e.troco && e.troco.precisa ? `<p class="ent-troco" role="note"><i class="fa-solid fa-coins" aria-hidden="true"></i> Cliente paga com <strong>${moeda(e.troco.paraValor)}</strong> · leve <strong>${moeda(e.troco.devolver)}</strong> de troco</p>` : ''}`
      : `<p class="ent-pago" role="note"><span><i class="fa-solid fa-circle-check" aria-hidden="true"></i> ${esc(e.pagamento) || 'Pagamento'} · já pago</span><strong>${moeda(e.total)}</strong></p>`}
    <details class="ent-itens-box" data-det="itens-${k}"><summary>${pl(qtdItens, 'item', 'itens')} do pedido</summary>
      <ul class="ent-itens">${e.itens.map(i => `<li>${i.qtd}× ${esc(i.nome)}</li>`).join('')}</ul></details>
    <p class="ent-linha"><span>Sua taxa</span><strong>${moeda(e.taxaEntregador)}</strong></p>
    <div class="ent-acoes">
      ${e.cliente.endereco && !grupo ? botaoMapaCartao() : ''}
      ${e.cliente.endereco ? `<a class="ent-btn ent-btn-rota" data-google target="_blank" rel="noopener" href="${rotaUrl(e.cliente.endereco)}">${grupo ? '<i class="fa-solid fa-route" aria-hidden="true"></i> Só este pedido no Google Maps' : '<i class="fa-solid fa-route" aria-hidden="true"></i> Ver rota no Google Maps'}</a>` : ''}
      ${fone ? `<a class="ent-btn ent-btn-leve" href="tel:${fone}"><i class="fa-solid fa-phone" aria-hidden="true"></i> Cliente</a>` : ''}
      ${zap ? `<a class="ent-btn ent-btn-leve" target="_blank" rel="noopener" href="${esc(zap)}"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> Avisar</a>` : ''}
      ${lojaFone ? `<a class="ent-btn ent-btn-leve" href="tel:${lojaFone}"><i class="fa-solid fa-store" aria-hidden="true"></i> Loja</a>` : ''}
    </div>
    <form class="ent-codigo" data-form="${k}">
      <label for="cod-${k}">Código que o cliente informa na porta</label>
      <div><input id="cod-${k}" inputmode="numeric" pattern="\\d{4}" maxlength="4" autocomplete="off" placeholder="0000" required ${bloqueado ? 'disabled' : ''}>
      <button type="submit" class="ent-btn ent-btn-principal" ${bloqueado ? 'disabled' : ''}>Confirmar entrega</button></div>
      <p class="ent-tentativas${bloqueado ? ' ent-erro' : ''}" data-tentativas>${esc(textoTentativas(restantes))}</p>
      <p class="ent-erro" role="alert" data-erro hidden></p>
    </form>
  </article>`;
}

function linhaHistorico(e, taxaPorPedido) {
  const t = rotuloTaxa(e.confirmada ? taxaPorPedido.get(e.pedidoKey) : null);
  const rotulo = e.cancelado ? 'Cancelado' : e.confirmada ? 'Entregue ' + dataHora(e.confirmadaEm) : 'Em andamento';
  return `<article class="ent-card ent-card-hist${e.cancelado ? ' ent-card-cancelada' : ''}">
    <div class="ent-card-topo"><strong>Pedido #${esc(e.numeroPedido)}</strong><span>${esc(rotulo)}</span></div>
    <p class="ent-linha"><span>${esc(e.cliente.nome)}${e.bairro ? ' · ' + esc(e.bairro) : ''}</span>
    ${e.confirmada ? `<strong>${moeda(e.taxaEntregador)}</strong>` : '<strong>—</strong>'}</p>
    ${e.confirmada ? `<p class="ent-chip ent-chip-${t.classe}">${esc(t.texto)}</p>` : ''}
  </article>`;
}

function linhaAcerto(a) {
  return `<article class="ent-card ent-card-hist">
    <div class="ent-card-topo"><strong>${moeda(a.valorTotal)}</strong><span>${esc(dataHora(a.criadoEm))}</span></div>
    <p class="ent-linha"><span>${pl(a.qtd, 'entrega', 'entregas')} · ${esc(FORMAS[a.forma] || a.forma || '')}</span></p>
    ${a.obs ? `<p class="ent-obs">${esc(a.obs)}</p>` : ''}
  </article>`;
}

function renderGanhos(d) {
  const g = resumoGanhos(d.taxas);
  const bloco = (rot, x, extra = '') => `<div class="ent-ganho ${extra}"><span>${rot}</span><strong>${moeda(x.valor)}</strong><small>${pl(x.qtd, 'entrega', 'entregas')}</small></div>`;
  $('ent-ganhos').innerHTML = `
    ${bloco('A receber da loja', g.pendente, 'destaque')}
    <div class="ent-ganhos-grade">${bloco('Hoje', g.hoje)}${bloco('7 dias', g.semana)}${bloco('Este mês', g.mes)}${bloco('Já recebido', g.recebido)}</div>`;
  const acertos = d.acertos || [];
  $('ent-acertos').innerHTML = acertos.length ? acertos.map(linhaAcerto).join('') : '<p class="ent-vazio">Quando a loja registrar um pagamento, ele aparece aqui.</p>';
  return g;
}

// ---- Estado da tela (para o redesenho não apagar o que está sendo digitado) ----
function capturarEstado() {
  const codigos = {};
  for (const i of document.querySelectorAll('#ent-aba-entregas .ent-codigo input')) if (i.value) codigos[i.closest('[data-form]').dataset.form] = i.value;
  const foco = document.activeElement;
  const focoKey = foco && foco.matches?.('.ent-codigo input') ? foco.closest('[data-form]').dataset.form : null;
  const abertos = [...document.querySelectorAll('#ent-aba-entregas details[open]')].map(d => d.dataset.det);
  return { codigos, focoKey, abertos, rolagem: window.scrollY };
}
function restaurarEstado(est) {
  for (const f of document.querySelectorAll('#ent-aba-entregas [data-form]')) {
    const i = f.querySelector('input'); const v = est.codigos[f.dataset.form];
    if (v && i && !i.disabled) i.value = v;
    if (est.focoKey === f.dataset.form && i && !i.disabled) { i.focus(); try { i.setSelectionRange(i.value.length, i.value.length); } catch { /* noop */ } }
  }
  for (const d of document.querySelectorAll('#ent-aba-entregas details')) if (est.abertos.includes(d.dataset.det)) d.open = true;
  window.scrollTo({ top: est.rolagem });
}

function desenhar(d) {
  const est = capturarEstado();
  $('ent-nome').textContent = d.entregador.nome;
  $('ent-loja').textContent = d.loja?.nome ? `· ${d.loja.nome}` : '';
  const ativas = d.entregas.filter(e => !e.confirmada && !e.cancelado);
  const feitas = d.entregas.filter(e => e.confirmada || e.cancelado);
  dados = d;
  desenharEntregas();
  const taxaPorPedido = new Map((d.taxas || []).map(t => [t.pedidoKey, t]));
  $('ent-historico').innerHTML = feitas.length ? feitas.map(e => linhaHistorico(e, taxaPorPedido)).join('') : '<p class="ent-vazio">Suas entregas concluídas aparecem aqui.</p>';
  const g = renderGanhos(d);
  $('ent-resumo').textContent = ativas.length ? pl(ativas.length, 'entrega para fazer', 'entregas para fazer') : 'Sem entregas agora';
  if (g.pendente.valor > 0) $('ent-resumo').textContent += ` · a receber ${moeda(g.pendente.valor)}`;
  const badge = $('ent-badge'); badge.textContent = String(ativas.length); badge.hidden = !ativas.length;
  restaurarEstado(est);
}

function avisarNovas(novas) {
  if (!novas.length) return;
  const el = $('ent-nova');
  el.innerHTML = '<i class="fa-solid fa-bell" aria-hidden="true"></i> ' + (novas.length === 1 ? `Nova entrega: pedido #${esc(novas[0].numeroPedido)}` : `${novas.length} novas entregas`);
  el.hidden = false;
  document.title = `(${novas.length}) Nova entrega`;
  try { navigator.vibrate?.([200, 100, 200]); } catch { /* noop */ }
}
function avisarCanceladas(lista) {   // V75.100: pedido cancelado com o entregador a caminho — aviso na hora, o card fica na tela até ele remover
  if (!lista.length) return;
  const el = $('ent-nova');
  el.innerHTML = '<i class="fa-solid fa-ban" aria-hidden="true"></i> ' + (lista.length === 1 ? `Pedido #${esc(lista[0].numeroPedido)} foi cancelado` : `${lista.length} pedidos foram cancelados`);
  el.hidden = false;
  document.title = `(${lista.length}) Pedido cancelado`;
  try { navigator.vibrate?.([400, 150, 400]); } catch { /* noop */ }
}
function limparNova() { $('ent-nova').hidden = true; document.title = tituloOriginal; }

async function carregar(forcar = false) {
  if (carregando || !auth.currentUser) return;
  carregando = true;
  try {
    const d = await chamar('/entregador/minhas');
    mostrarAviso('');
    const antes = dados;
    dados = d;
    const sig = assinatura(d) + '|' + (d.loja?.nome || '') + '|' + (d.entregador?.nome || '');
    if (forcar || sig !== assinaturaAtual) {
      desenhar(d);
      assinaturaAtual = sig;
      if (antes) avisarNovas(novasEntregas(antes.entregas, d.entregas));
      if (antes) avisarCanceladas(acabaramCanceladas(antes.entregas, d.entregas));
    }
    sincronizarGps();
  } catch (err) {
    mostrarAviso(navigator.onLine === false ? 'Sem internet. Vamos tentar de novo quando voltar.' : err.message);
  } finally { carregando = false; }
}

// ---- Eventos ----
document.addEventListener('click', ev => {
  if (ev.target.closest('[data-abrir-mapa]')) { abrirMapaEntregador(); return; }
  const rm = ev.target.closest('[data-remover-cancelado]');
  if (rm) { dispensarCancelada(rm.dataset.removerCancelado); renderRota(); return; }
  const m = ev.target.closest('[data-rota-mover]');
  if (m) {
    const ids = ordenarParadas(paradasAtuais, lerOrdem()).map(p => p.id);
    salvarOrdem(moverParada(ids, m.dataset.rotaMover, Number(m.dataset.delta)));
    renderRota();
    return;
  }
  const t = ev.target.closest('.ent-nav-btn');
  if (t) { trocarAba(t.dataset.aba); if (t.dataset.aba === 'entregas') limparNova(); }
});

document.addEventListener('submit', async ev => {
  const form = ev.target.closest('[data-form]'); if (!form) return;
  ev.preventDefault();
  const erro = form.querySelector('[data-erro]'), dica = form.querySelector('[data-tentativas]');
  const btn = form.querySelector('button'), input = form.querySelector('input');
  if (btn.disabled) return;
  erro.hidden = true; btn.disabled = true;
  try {
    await chamar('/entregador/validar-codigo', { pedidoKey: form.dataset.form, codigo: input.value });
    avisarEvento({ pedidoKey: form.dataset.form, evento: 'entregue' }); // push para o cliente (não espera)
    await carregar(true);
  } catch (err) {
    erro.textContent = err.message; erro.hidden = false;
    const r = err.dados?.restantes;
    if (Number.isFinite(r)) {
      dica.textContent = textoTentativas(r);
      dica.classList.toggle('ent-erro', r <= 0);
      if (r <= 0) { input.disabled = true; return; }
    }
    btn.disabled = false; input.select?.();
  }
});

function agendar() {
  clearInterval(timer);
  timer = setInterval(() => { if (document.visibilityState === 'visible') carregar(); }, POLL_MS);
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && auth.currentUser) { carregar(); limparNovaSeVisivel(); } });
function limparNovaSeVisivel() { if (abaAtual === 'entregas') document.title = tituloOriginal; }
window.addEventListener('online', () => { atualizarConexao(); carregar(true); });
window.addEventListener('offline', atualizarConexao);

// Avisos push (nova entrega com o app fechado). Carregado à parte para o app abrir mesmo sem acesso ao serviço de push do Google.
const carregarPush = () => import('./notificaciones.js').catch((e) => { console.warn('[NotPush] indisponível:', e); return null; });

// Situação dos avisos de nova entrega, sempre à vista: o entregador precisa ativar neste aparelho, e antes ninguém via se tinha dado certo.
let avisosRegistrado = false, avisosErro = '';
const appInstalado = () => { try { return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true; } catch { return false; } };
function desenharAvisos() {
  const box = $('ent-push'), btn = $('ent-push-btn');
  const e = estadoAvisos({ suporte: 'Notification' in window, permissao: 'Notification' in window ? Notification.permission : 'denied', registrado: avisosRegistrado, erro: avisosErro, instalado: appInstalado() });
  box.hidden = false; box.className = `ent-push ent-push-${e.tipo}`;
  $('ent-push-texto').textContent = e.texto;
  btn.hidden = !e.botao; btn.textContent = e.botao;
}
async function ativarAvisos() {
  avisosErro = '';
  try {
    const push = await carregarPush();
    if (!push?.ativarNotificacoes) throw new Error('serviço de avisos indisponível agora');
    avisosRegistrado = !!(await push.ativarNotificacoes());
  } catch (err) { avisosRegistrado = false; avisosErro = err?.message || 'erro desconhecido'; console.warn('[NotPush]', err); }
  desenharAvisos();
}
$('ent-push-btn').addEventListener('click', async () => { $('ent-push-btn').disabled = true; await ativarAvisos(); $('ent-push-btn').disabled = false; });
// Já permitido: registra o aparelho sem perguntar nada. Senão mostra o botão (o navegador só deixa pedir a permissão num toque).
// V75.105: a pessoa libera nas configurações do celular e volta: ativa sozinha, sem precisar achar o botão.
const religarSePermitido = () => { if (auth.currentUser && !avisosRegistrado && 'Notification' in window && Notification.permission === 'granted') ativarAvisos(); };
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') religarSePermitido(); });
try { navigator.permissions?.query({ name: 'notifications' }).then((st) => { st.onchange = religarSePermitido; }).catch(() => {}); } catch { /* sem Permissions API: vale o retorno ao app */ }
function iniciarAvisos() { avisosRegistrado = false; avisosErro = ''; if ('Notification' in window && Notification.permission === 'granted') ativarAvisos(); else desenharAvisos(); }

// ---- V75.86: rastreio por distância ----
// Enquanto há entrega "a caminho", o aparelho manda a posição à API (a cada 10 s) e mantém a tela ligada.
// A API calcula a distância até o endereço do cliente e grava só ela; a posição do entregador não é guardada.
let gpsWatch = null, gpsEstado = 'inativo', gpsPrecisao = null, gpsEnviadoEm = null, gpsUltimoEnvio = 0, gpsEnviando = false, wakeLock = null, gpsRelogio = null;
function desenharGps() {
  const box = $('ent-gps'); if (!box) return;
  const t = textoLocalizacaoEntregador({ estado: gpsEstado, precisao: gpsPrecisao, enviadoEm: gpsEnviadoEm });
  box.hidden = gpsEstado === 'inativo';
  box.className = `ent-gps ent-gps-${t.tom}`;
  $('ent-gps-titulo').textContent = t.titulo; $('ent-gps-detalhe').textContent = t.detalhe;
  $('ent-gps-btn').hidden = gpsEstado !== 'negado' && gpsEstado !== 'erro';
}
async function pedirWakeLock() {
  try { if ('wakeLock' in navigator && !wakeLock && document.visibilityState === 'visible') { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener?.('release', () => { wakeLock = null; }); } } catch { wakeLock = null; }
}
async function enviarPosicao(pos) {
  const { latitude: lat, longitude: lng, accuracy } = pos.coords;
  gpsPrecisao = Number.isFinite(accuracy) ? accuracy : null;
  if (!devePublicarPosicao(gpsUltimoEnvio, Date.now(), gpsPrecisao) || gpsEnviando) { if (gpsPrecisao > 300) { gpsEstado = 'erro'; desenharGps(); } return; }
  gpsEnviando = true; gpsUltimoEnvio = Date.now();
  try {
    await chamar('/entregador/rastreio', { lat, lng, precisao: gpsPrecisao === null ? undefined : Math.round(gpsPrecisao) });
    gpsEnviadoEm = Date.now(); gpsEstado = 'ativo';
  } catch (err) { if (err.status === 403) pararGps(); else gpsEstado = 'erro'; }
  finally { gpsEnviando = false; desenharGps(); }
}
function iniciarGps() {
  if (gpsWatch !== null) return;
  if (!('geolocation' in navigator)) { gpsEstado = 'indisponivel'; desenharGps(); return; }
  gpsEstado = 'pedindo'; desenharGps();
  gpsWatch = navigator.geolocation.watchPosition(enviarPosicao, (err) => {
    gpsEstado = err?.code === 1 ? 'negado' : 'erro';
    if (err?.code === 1) { navigator.geolocation.clearWatch(gpsWatch); gpsWatch = null; }
    desenharGps();
  }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 });
  pedirWakeLock();
  clearInterval(gpsRelogio);
  gpsRelogio = setInterval(() => {
    desenharGps();
    // Parado no sinal, o navegador pode ficar sem avisar posição nova: pede uma leitura para o cliente não ver "sem sinal".
    if (gpsWatch !== null && !gpsEnviando && precisaBatimento(gpsEnviadoEm || gpsUltimoEnvio, Date.now())) {
      navigator.geolocation.getCurrentPosition(enviarPosicao, () => {}, { enableHighAccuracy: true, maximumAge: 20000, timeout: 15000 });
    }
  }, 10000);
}
function pararGps() {
  if (gpsWatch !== null) { try { navigator.geolocation.clearWatch(gpsWatch); } catch { /* noop */ } gpsWatch = null; }
  clearInterval(gpsRelogio); gpsRelogio = null;
  try { wakeLock?.release?.(); } catch { /* noop */ } wakeLock = null;
  gpsEstado = 'inativo'; gpsPrecisao = null; gpsEnviadoEm = null; gpsUltimoEnvio = 0; desenharGps();
}
function sincronizarGps() { if (dados && entregasParaRastrear(dados.entregas).length) iniciarGps(); else if (gpsWatch !== null || gpsEstado !== 'inativo') pararGps(); }
$('ent-gps-btn')?.addEventListener('click', () => { if (gpsWatch !== null) { navigator.geolocation.clearWatch(gpsWatch); gpsWatch = null; } iniciarGps(); });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && gpsWatch !== null) pedirWakeLock(); }); // o sistema solta a trava ao esconder o app

async function iniciar(user) {
  if (!user) { clearInterval(timer); dados = null; assinaturaAtual = null; pararGps(); tela('login'); return; }
  tela('carregando');
  try {
    const d = await chamar('/entregador/entrar');
    $('ent-nome').textContent = d.nome;
    atualizarConexao();
    tela('painel');
    iniciarAvisos();
    await carregar(true);
    agendar();
  } catch (err) {
    await signOut(auth).catch(() => {});
    $('ent-login-erro').textContent = err.message; $('ent-login-erro').hidden = false;
    tela('login');
  }
}
$('ent-btn-entrar').addEventListener('click', () => { $('ent-login-erro').hidden = true; signInWithPopup(auth, googleProvider).catch(err => { if (err.code !== 'auth/popup-closed-by-user') { $('ent-login-erro').textContent = 'Não foi possível entrar com o Google.'; $('ent-login-erro').hidden = false; } }); });
$('ent-btn-atualizar').addEventListener('click', () => { limparNova(); carregar(true); });
$('ent-btn-sair').addEventListener('click', async () => { clearInterval(timer); const push = await carregarPush(); await push?.desativarNotificacoes?.().catch(() => {}); signOut(auth); });
onAuthStateChanged(auth, iniciar);
