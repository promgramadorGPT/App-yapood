// V75.25 — Regras PURAS do painel Master (sem DOM, sem Firebase). Testadas em tests/master.test.mjs.
import { STATUS, normalizarStatus, normalizarPagamento, PAGO, normalizarTexto } from './regras.js';
import { comissaoDoPedido } from './comissao.js';

const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;
const OFFSET_BR = -180; // Brasília (sem horário de verão)

// ---------- Datas ----------
/** 'YYYY-MM-DD' do instante ISO no fuso indicado (padrão Brasília). Vazio se a data for inválida. */
export function diaChave(iso, offsetMin = OFFSET_BR) {
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return '';
  return new Date(t + offsetMin * 60000).toISOString().slice(0, 10);
}
/** ISO do começo do período (dias=1 → hoje desde 00:00 de Brasília). dias<=0 → null (sem limite). */
export function inicioPeriodo(dias, agora = new Date(), offsetMin = OFFSET_BR) {
  const n = Number(dias);
  if (!(n > 0)) return null;
  const hoje = diaChave(new Date(agora).toISOString(), offsetMin);
  const base = Date.parse(hoje + 'T00:00:00.000Z') - offsetMin * 60000;
  return new Date(base - (Math.floor(n) - 1) * 86400000).toISOString();
}
export function pedidosDesde(pedidos, desdeIso) {
  const lista = Array.isArray(pedidos) ? pedidos : [];
  if (!desdeIso) return lista;
  const d = Date.parse(desdeIso);
  return lista.filter((p) => Date.parse(p?.criadoEm) >= d);
}

// ---------- Valores ----------
/** Receita do pedido: total pago pelo cliente menos reembolso aprovado; cancelado não conta. */
export function receitaDoPedido(p) {
  if (!p || normalizarStatus(p.status) === STATUS.CANCELADO) return 0;
  const total = Number(p.total) || 0;
  const r = p.reembolso;
  const devolvido = r?.status === 'aprovado' ? Math.min(Number(r.valor) || 0, total) : 0;
  return arred(Math.max(0, total - devolvido));
}
const contaPedido = (p) => !!p && normalizarStatus(p.status) !== STATUS.CANCELADO;
const comissaoValida = (p) => (contaPedido(p) ? comissaoDoPedido(p) : { valor: 0, modo: 'nenhum' });

function somar(lista) {
  const ativos = lista.filter(contaPedido);
  const gmv = arred(ativos.reduce((s, p) => s + receitaDoPedido(p), 0));
  let comissao = 0;
  for (const p of ativos) comissao += comissaoValida(p).valor;
  return { pedidos: ativos.length, gmv, ticket: ativos.length ? arred(gmv / ativos.length) : 0, comissao: arred(comissao) };
}

/** Indicadores do topo do Resumo: hoje, 7 dias, 30 dias, pendências e distribuição por status. */
export function resumoGeral(pedidos, agora = new Date()) {
  const lista = Array.isArray(pedidos) ? pedidos : [];
  const por = { [STATUS.PENDENTE]: 0, [STATUS.PREPARANDO]: 0, [STATUS.ENTREGA]: 0, [STATUS.ENTREGUE]: 0, [STATUS.CANCELADO]: 0 };
  for (const p of lista) por[normalizarStatus(p?.status)]++;
  const aguardandoReembolso = lista.filter((p) => p?.reembolso?.status === 'solicitado').length;
  return {
    hoje: somar(pedidosDesde(lista, inicioPeriodo(1, agora))),
    d7: somar(pedidosDesde(lista, inicioPeriodo(7, agora))),
    d30: somar(pedidosDesde(lista, inicioPeriodo(30, agora))),
    porStatus: por,
    emAndamento: por[STATUS.PENDENTE] + por[STATUS.PREPARANDO] + por[STATUS.ENTREGA],
    aguardandoReembolso
  };
}

/** Série diária (do mais antigo para hoje), com zeros nos dias sem pedido. */
export function serieDiaria(pedidos, dias = 14, agora = new Date(), offsetMin = OFFSET_BR) {
  const n = Math.max(1, Math.floor(Number(dias) || 14));
  const mapa = new Map();
  const hoje = Date.parse(diaChave(new Date(agora).toISOString(), offsetMin) + 'T00:00:00.000Z');
  for (let i = n - 1; i >= 0; i--) mapa.set(new Date(hoje - i * 86400000).toISOString().slice(0, 10), { dia: '', pedidos: 0, gmv: 0 });
  for (const p of Array.isArray(pedidos) ? pedidos : []) {
    if (!contaPedido(p)) continue;
    const e = mapa.get(diaChave(p.criadoEm, offsetMin));
    if (e) { e.pedidos++; e.gmv = arred(e.gmv + receitaDoPedido(p)); }
  }
  return [...mapa.entries()].map(([dia, v]) => ({ ...v, dia }));
}

export function nomeDaLoja(lojas, id, pedido) {
  const l = lojas?.[id];
  return (l && (l.nombre || l.nome)) || pedido?.lojaNome || 'Loja removida';
}

/** Desempenho por loja no período (inclui lojas sem vendas quando incluirVazias). */
export function desempenhoPorLoja(pedidos, lojas, desdeIso = null, { incluirVazias = false } = {}) {
  const linhas = new Map();
  const get = (id, p) => {
    if (!linhas.has(id)) linhas.set(id, { lojaId: id, nome: nomeDaLoja(lojas, id, p), pedidos: 0, entregues: 0, cancelados: 0, gmv: 0, comissaoSplit: 0, comissaoAcertar: 0 });
    return linhas.get(id);
  };
  if (incluirVazias) for (const id of Object.keys(lojas || {})) get(id);
  for (const p of pedidosDesde(pedidos, desdeIso)) {
    if (!p?.lojaId) continue;
    const l = get(p.lojaId, p);
    const st = normalizarStatus(p.status);
    if (st === STATUS.CANCELADO) { l.cancelados++; continue; }
    l.pedidos++;
    if (st === STATUS.ENTREGUE) l.entregues++;
    l.gmv = arred(l.gmv + receitaDoPedido(p));
    const c = comissaoDoPedido(p);
    if (c.modo === 'split') l.comissaoSplit = arred(l.comissaoSplit + c.valor);
    else if (c.modo === 'a_acertar') l.comissaoAcertar = arred(l.comissaoAcertar + c.valor);
  }
  return [...linhas.values()].map((l) => ({ ...l, comissao: arred(l.comissaoSplit + l.comissaoAcertar), ticket: l.pedidos ? arred(l.gmv / l.pedidos) : 0 }));
}
export function rankingLojas(pedidos, lojas, dias = 30, agora = new Date(), limite = 5) {
  return desempenhoPorLoja(pedidos, lojas, inicioPeriodo(dias, agora)).filter((l) => l.pedidos > 0).sort((a, b) => b.gmv - a.gmv || b.pedidos - a.pedidos).slice(0, limite);
}
export function totaisFinanceiro(linhas) {
  return (linhas || []).reduce((t, l) => ({
    pedidos: t.pedidos + l.pedidos, gmv: arred(t.gmv + l.gmv), comissaoSplit: arred(t.comissaoSplit + l.comissaoSplit),
    comissaoAcertar: arred(t.comissaoAcertar + l.comissaoAcertar), comissao: arred(t.comissao + l.comissao), cancelados: t.cancelados + l.cancelados
  }), { pedidos: 0, gmv: 0, comissaoSplit: 0, comissaoAcertar: 0, comissao: 0, cancelados: 0 });
}

// ---------- CSV (separador ';', vírgula decimal, BOM; neutraliza fórmulas =,+,-,@) ----------
const celula = (v) => {
  let s = typeof v === 'number' ? String(v).replace('.', ',') : String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+([.,]\d+)?$/.test(s)) s = "'" + s;
  return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
export function toCsv(cabecalho, linhas) {
  return '﻿' + [cabecalho, ...linhas].map((l) => l.map(celula).join(';')).join('\r\n');
}
export function csvFinanceiro(linhas) {
  return toCsv(
    ['Loja', 'Pedidos', 'Entregues', 'Cancelados', 'Vendas (R$)', 'Ticket médio (R$)', 'Comissão já separada (R$)', 'Comissão a acertar (R$)', 'Comissão total (R$)'],
    (linhas || []).map((l) => [l.nome, l.pedidos, l.entregues, l.cancelados, l.gmv, l.ticket, l.comissaoSplit, l.comissaoAcertar, l.comissao])
  );
}

// ---------- Lojas ----------
export function estadoLoja(loja, suspensa) {
  if (suspensa) return 'suspensa';
  return loja?.activo === false ? 'inativa' : 'ativa';
}
export function filtrarLojas(lojas, suspensas, { busca = '', estado = 'todas' } = {}) {
  const q = normalizarTexto(busca);
  return Object.entries(lojas || {})
    .map(([id, l]) => ({ id, ...(l || {}), estado: estadoLoja(l, suspensas?.[id]) }))
    .filter((l) => (estado === 'todas' || l.estado === estado))
    .filter((l) => !q || normalizarTexto([l.nombre, l.nome, l.categoria, l.categoriaId, l.ownerUid, l.email, l.id].join(' ')).includes(q))
    .sort((a, b) => String(a.nombre || a.nome || '').localeCompare(String(b.nombre || b.nome || ''), 'pt-BR'));
}

// ---------- Pedidos ----------
export const STATUS_CANCELAVEIS = [STATUS.PENDENTE, STATUS.PREPARANDO, STATUS.ENTREGA];
export const podeCancelarPedido = (p) => !!p && STATUS_CANCELAVEIS.includes(normalizarStatus(p.status));
/** Aviso mostrado antes de cancelar. Reembolso online não é devolvido pelo painel Master. */
export function avisoCancelamento(p) {
  if (normalizarPagamento(p?.pagoStatus) === PAGO.APROVADO) return 'Este pedido foi pago online. Cancelar aqui NÃO devolve o dinheiro: o reembolso continua sendo feito pela loja, na tela de reembolso do pedido.';
  return '';
}
export function filtrarPedidos(pedidos, { status = 'todos', lojaId = '', busca = '', desde = null } = {}) {
  const q = normalizarTexto(busca);
  return pedidosDesde(pedidos, desde)
    .filter((p) => status === 'todos' || normalizarStatus(p.status) === status)
    .filter((p) => !lojaId || p.lojaId === lojaId)
    .filter((p) => !q || normalizarTexto([p.numeroPedido, p.cliente?.nombre, p.cliente?.nome, p.cliente?.email, p.cliente?.telefono, p.lojaNome, p.id].join(' ')).includes(q))
    .sort((a, b) => String(b.criadoEm || '').localeCompare(String(a.criadoEm || '')));
}

// ---------- Usuários ----------
export function listarUsuarios(usuarios, pedidos, { bloqueados = {}, lojas = {}, admins = {} } = {}) {
  const donos = new Set(Object.values(lojas || {}).map((l) => l?.ownerUid).filter(Boolean));
  const stats = new Map();
  for (const p of Array.isArray(pedidos) ? pedidos : []) {
    if (!p?.clienteUid) continue;
    const s = stats.get(p.clienteUid) || { pedidos: 0, gasto: 0, ultimo: '' };
    if (contaPedido(p)) { s.pedidos++; s.gasto = arred(s.gasto + receitaDoPedido(p)); }
    if (String(p.criadoEm || '') > s.ultimo) s.ultimo = p.criadoEm;
    stats.set(p.clienteUid, s);
  }
  return Object.entries(usuarios || {}).map(([uid, u]) => {
    const s = stats.get(uid) || { pedidos: 0, gasto: 0, ultimo: '' };
    return {
      uid, nome: u?.nome || u?.nombre || '', email: u?.email || '', foto: u?.foto || '', telefone: u?.telefono || u?.telefone || '', criadoEm: u?.criadoEm || '',
      pedidos: s.pedidos, gasto: s.gasto, ultimo: s.ultimo,
      bloqueado: !!bloqueados?.[uid], motivoBloqueio: bloqueados?.[uid]?.motivo || '',
      dono: donos.has(uid), master: admins?.[uid]?.role === 'master'
    };
  });
}
export function filtrarUsuarios(lista, { busca = '', filtro = 'todos' } = {}) {
  const q = normalizarTexto(busca);
  return (lista || [])
    .filter((u) => filtro === 'todos' || (filtro === 'bloqueados' && u.bloqueado) || (filtro === 'donos' && u.dono) || (filtro === 'clientes' && !u.dono) || (filtro === 'masters' && u.master))
    .filter((u) => !q || normalizarTexto([u.nome, u.email, u.uid, u.telefone].join(' ')).includes(q))
    .sort((a, b) => String(b.ultimo || b.criadoEm || '').localeCompare(String(a.ultimo || a.criadoEm || '')));
}
/** UID do Firebase Auth: 20 a 40 letras/números. */
export const uidValido = (v) => /^[A-Za-z0-9]{20,40}$/.test(String(v || '').trim());

// ---------- Auditoria ----------
export function registroLog(user, acao, alvo = '', detalhe = '', agora = new Date()) {
  return {
    em: new Date(agora).toISOString(), por: String(user?.uid || '').slice(0, 128), acao: String(acao).slice(0, 60),
    ...(alvo ? { alvo: String(alvo).slice(0, 200) } : {}), ...(detalhe ? { detalhe: String(detalhe).slice(0, 400) } : {}),
    ...(user?.email ? { porEmail: String(user.email).slice(0, 120) } : {})
  };
}
export const ROTULO_ACAO = {
  'loja.suspender': 'Loja suspensa', 'loja.reativar': 'Loja reativada', 'loja.ativar': 'Loja ativada', 'loja.desativar': 'Loja desativada',
  'usuario.bloquear': 'Usuário bloqueado', 'usuario.desbloquear': 'Usuário desbloqueado',
  'pedido.cancelar': 'Pedido cancelado', 'relato.decidir': 'Relato decidido', 'equipe.adicionar': 'Master adicionado', 'equipe.remover': 'Master removido',
  'comissao.alterar': 'Comissão alterada', 'pushcupom.alterar': 'Aviso de cupom alterado', 'anuncie.alterar': 'Anuncie no YAPOOD alterado', 'tema.alterar': 'Cor do app alterada', 'tema.restaurar': 'Cor do app restaurada', 'publicidade.criar': 'Anúncio registrado', 'publicidade.status': 'Anúncio atualizado', 'publicidade.excluir': 'Anúncio excluído', 'push.enviar': 'Notificação enviada', 'push.excluir': 'Notificação removida do histórico', 'aviso.salvar': 'Aviso principal salvo', 'aviso.excluir': 'Aviso principal excluído', 'icone.salvar': 'Ícone por data salvo', 'icone.remover': 'Ícone por data removido',
  'cidade.criar': 'Cidade cadastrada', 'cidade.editar': 'Cidade ajustada', 'cidade.remover': 'Cidade excluída', 'cidade.liberar': 'Cidade liberada', 'cidade.lista': 'Lista de interessados limpa', 'cidade.demo': 'Modo demonstração', 'testador.add': 'Testador adicionado', 'testador.remover': 'Testador removido', 'loja.cidade': 'Cidade da loja definida',
  'limites.salvar': 'Limites e planos salvos', 'limites.medir-fotos': 'Fotos do Cloudinary medidas', 'banner.salvar': 'Banner salvo', 'banner.excluir': 'Banner excluído', 'categoria.salvar': 'Categoria salva'
};

// ---------- Marketing ----------
export function bannerDentroDoPeriodo(b, agora = Date.now()) {
  const inicio = b?.inicio ? Date.parse(b.inicio) : NaN;
  const fim = b?.fim ? Date.parse(b.fim) : NaN;
  return (!Number.isFinite(inicio) || agora >= inicio) && (!Number.isFinite(fim) || agora <= fim);
}
export function linkValido(v) {
  const s = String(v || '').trim();
  if (!s) return '';
  if (/^https:\/\//i.test(s)) return s;
  if (/^(?:\.\/)?(?:[a-z0-9_-]+\/)*[a-z0-9_.-]+(?:\?[^ ]*)?$/i.test(s) && !/^[a-z][a-z0-9+.-]*:/i.test(s)) return s;
  return '';
}
export const slugify = (v) => String(v || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);

// ---------- Resumo: alertas e gráfico ----------
/** Pontos de atenção do Resumo. `ir` é a aba para onde o botão leva. */
export function alertas({ pedidos = [], lojas = {}, suspensas = {} } = {}, agora = new Date(), minutosAtraso = 20) {
  const lista = [];
  const limite = new Date(agora).getTime() - minutosAtraso * 60000;
  const atrasados = pedidos.filter((p) => normalizarStatus(p?.status) === STATUS.PENDENTE && Date.parse(p.criadoEm) < limite && Date.parse(p.criadoEm) > limite - 86400000).length;
  if (atrasados) lista.push({ nivel: 'alto', icone: 'fa-hourglass-half', texto: `${atrasados} pedido(s) pendente(s) há mais de ${minutosAtraso} min sem resposta da loja`, ir: 'pedidos', status: STATUS.PENDENTE });
  const reemb = pedidos.filter((p) => p?.reembolso?.status === 'solicitado').length;
  if (reemb) lista.push({ nivel: 'alto', icone: 'fa-rotate-left', texto: `${reemb} pedido(s) com reembolso solicitado aguardando a loja`, ir: 'pedidos' });
  const sus = Object.keys(suspensas || {}).filter((id) => lojas?.[id]).length;
  if (sus) lista.push({ nivel: 'medio', icone: 'fa-ban', texto: `${sus} loja(s) suspensa(s)`, ir: 'lojas', filtro: 'suspensa' });
  const inativas = Object.entries(lojas || {}).filter(([id, l]) => l?.activo === false && !suspensas?.[id]).length;
  if (inativas) lista.push({ nivel: 'info', icone: 'fa-store-slash', texto: `${inativas} loja(s) desativada(s)`, ir: 'lojas', filtro: 'inativa' });
  return lista;
}

const fmtInt = (n) => Math.round(n).toLocaleString('pt-BR');
/** Gráfico de barras em SVG. campo: 'pedidos' | 'gmv'. Devolve string segura (só números e rótulos fixos). */
export function svgSerie(serie, campo = 'pedidos', { largura = 640, altura = 220 } = {}) {
  const dados = Array.isArray(serie) ? serie : [];
  const n = dados.length || 1;
  const esq = 44, dir = 8, topo = 14, base = 28;
  const w = largura - esq - dir, h = altura - topo - base;
  const maxReal = Math.max(0, ...dados.map((d) => Number(d[campo]) || 0));
  const max = maxReal > 0 ? maxReal : 1;
  const passo = w / n, larg = Math.max(4, passo * 0.62);
  const moeda = (v) => 'R$ ' + (v >= 1000 ? (v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil' : fmtInt(v));
  const rotulo = (v) => (campo === 'gmv' ? moeda(v) : fmtInt(v));
  const grade = [0, 0.5, 1].map((f) => {
    const y = topo + h - h * f;
    return `<line x1="${esq}" y1="${y.toFixed(1)}" x2="${largura - dir}" y2="${y.toFixed(1)}" class="g-grade"/><text x="${esq - 6}" y="${(y + 4).toFixed(1)}" text-anchor="end" class="g-eixo">${rotulo(max * f)}</text>`;
  }).join('');
  const barras = dados.map((d, i) => {
    const v = Number(d[campo]) || 0;
    const bh = v > 0 ? Math.max(2, (v / max) * h) : 0;
    const x = esq + passo * i + (passo - larg) / 2;
    const dia = String(d.dia || '').slice(8, 10) + '/' + String(d.dia || '').slice(5, 7);
    const eixo = (i % 2 === (n - 1) % 2) ? `<text x="${(x + larg / 2).toFixed(1)}" y="${altura - 8}" text-anchor="middle" class="g-eixo">${dia}</text>` : '';
    return `<g><title>${dia}: ${fmtInt(d.pedidos || 0)} pedido(s), ${moeda(d.gmv || 0)}</title><rect x="${x.toFixed(1)}" y="${(topo + h - bh).toFixed(1)}" width="${larg.toFixed(1)}" height="${bh.toFixed(1)}" rx="3" class="g-barra"/>${eixo}</g>`;
  }).join('');
  const total = dados.reduce((s, d) => s + (Number(d[campo]) || 0), 0);
  return `<svg viewBox="0 0 ${largura} ${altura}" role="img" aria-label="Gráfico de ${campo === 'gmv' ? 'vendas' : 'pedidos'} por dia, total ${campo === 'gmv' ? moeda(total) : fmtInt(total)}" class="m-svg">${grade}${barras}</svg>`;
}

/**
 * V75.51 — interpreta a resposta do NotPush ao enviar uma notificação do Master.
 * O servidor responde `ok:false` quando QUALQUER aparelho falha (token velho, por exemplo), mesmo que os outros tenham recebido.
 * Antes, isso era tratado como erro total: a notificação chegava, mas o histórico não era salvo. Agora, se ao menos um aparelho recebeu, vale como enviada.
 */
/** V75.69 — procura no histórico uma campanha com o mesmo título, mensagem e link (ignora espaços e maiúsculas/minúsculas nas pontas). */
export function acharCampanhaIgual(lista, { titulo, corpo, link } = {}) {
  const n = (v) => String(v ?? '').replace(/\s+/g, ' ').trim();
  return (Array.isArray(lista) ? lista : []).find((c) => c && n(c.titulo) === n(titulo) && n(c.corpo) === n(corpo) && n(c.link) === n(link)) || null;
}
export function resultadoEnvioMaster(httpOk, data) {
  const d = data && typeof data === 'object' ? data : {};
  const enviados = Number(d.enviados) || 0, falhas = Number(d.falhas) || 0, tokens = Number(d.tokens) || 0;
  const codigos = [...new Set((Array.isArray(d.erros) ? d.erros : []).map((e) => String(e?.code || '').replace(/^messaging\//, '')).filter(Boolean))].slice(0, 3);
  if (enviados > 0) {
    return { entregou: true, enviados, falhas, tokens, aviso: falhas > 0 ? `${falhas} aparelho(s) não receberam${codigos.length ? ` (${codigos.join(', ')})` : ''}; tokens vencidos saem da lista sozinhos.` : '' };
  }
  if (!httpOk && d.error) return { entregou: false, enviados: 0, falhas, tokens, erro: String(d.error) };
  if (d.semToken || (httpOk && tokens === 0)) return { entregou: false, enviados: 0, falhas: 0, tokens: 0, semToken: true, erro: 'Nenhum aparelho com notificação registrado — nada foi enviado. Abra o app logado como cliente, permita as notificações e tente de novo.' };
  if (falhas > 0) return { entregou: false, enviados: 0, falhas, tokens, erro: `Nenhum aparelho recebeu: ${falhas} falha(s)${codigos.length ? ` (${codigos.join(', ')})` : ''}.` };
  return { entregou: false, enviados: 0, falhas, tokens, erro: String(d.error || 'O servidor não confirmou o envio.') };
}

/** V75.116: e-mail de contato para dados pessoais (LGPD). '' = vazio (tirar); null = inválido; senão o e-mail limpo, em minúsculas. */
export function normalizarEmailContato(v) {
  const e = String(v ?? '').trim().toLowerCase();
  if (!e) return '';
  return e.length <= 120 && /^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}$/.test(e) ? e : null;
}
