import { db, ref, onValue, query, orderByChild, equalTo, limitToLast } from './firebase.js';
import { calcularDistanciaKm, obterLocalizacao } from './geo.js';
import { escapeHtml, lojaAberta, avaliarSuper, textoTempo } from './regras.js';
import { resumoTaxaLoja, textoTaxaLoja } from './bairros.js';
import { splashConfigurar, splashExigir, splashPronto, splashAguardar } from './splash.js';
import { bloqueioDaLojaAgora } from './cidades-bloqueio.js';
import { abrirProdutoTela } from './produto-tela.js?v=75.128';
import { chaveLinha, configDoProduto } from './produto-opcoes.js?v=75.127';
import { ehCombo, resumoCombo } from './combo.js?v=75.128';
import { atualizarSacola, anunciarItem } from './sacola.js?v=75.131';
import { formatarMoeda, obterCarrinho, salvarCarrinho, toast, confirmar, urlSegura, imgOtimizada, IMG_LOJA_PADRAO, normalizarMoeda, definirMoedaAtual } from './utils.js';

const lojaId = new URLSearchParams(window.location.search).get('id');
const $ = (id) => document.getElementById(id);

const imgPratoPadrao = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300';
const capaPadrao = 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800';

let loja = null;
let statusLoja = { aberta: true };
let bloqueioCidade = null; // V75.73: loja numa cidade ainda em espera
const statusAtual = () => (bloqueioCidade ? { aberta: false, motivo: bloqueioCidade.motivo } : lojaAberta(loja));
let posUsuário = null;

if (!lojaId) {
  window.location.replace('index.html');
} else {
  iniciar();
}

function iniciar() {
  splashConfigurar({ imagens: '#capa-loja, #logo-loja, .container-restaurante img, main img' });
  ['loja', 'agregado', 'comentarios', 'pedidos'].forEach((n) => splashExigir(n));
  // O cardápio carrega IMEDIATAMENTE; a localização só complementa a distância
  // (antes o menu ficava esperando a permissão de GPS).
  onValue(ref(db, `restaurantes/${lojaId}`), (snap) => {
    loja = snap.val();
    if (loja) definirMoedaAtual(normalizarMoeda(loja.moeda || 'BRL'));
    if (!loja) { $('lista-menu').innerHTML = '<p class="msg-vazio">Restaurante não disponível.</p>'; splashPronto('loja'); return; }
    statusLoja = statusAtual();
    renderizarLoja();
    renderizarMenu();
    irParaItemBuscado();
    atualizarBarraCarrinho();
    splashPronto('loja');
    const lojaVerificada = loja;
    bloqueioDaLojaAgora(loja).then((b) => {
      if (loja !== lojaVerificada || !!bloqueioCidade === b.bloqueada) return;
      bloqueioCidade = b.bloqueada ? b : null;
      statusLoja = statusAtual(); renderizarLoja(); renderizarMenu();
    });
  }, () => { $('lista-menu').innerHTML = '<p class="msg-vazio">Não foi possível carregar o cardápio.</p>'; splashPronto('loja'); });

  obterLocalizacao((lat, lng, info) => { if (!info.estimada) { posUsuário = { lat, lng }; renderizarDistancia(); } });
  carregarAvaliacoes();
  carregarDadosSuper();
  splashAguardar();
  window.addEventListener('pageshow', atualizarBarraCarrinho);
  window.addEventListener('storage', atualizarBarraCarrinho);
  setInterval(() => { if (loja) { const novo = statusAtual(); if (novo.aberta !== statusLoja.aberta) { statusLoja = novo; renderizarLoja(); renderizarMenu(); } } }, 60_000);
}

// V75.42: taxa de entrega visível ao entrar na loja ("Entrega grátis" em verde; com taxa por bairro, mostra a faixa).
function renderizarTaxa() {
  const el = $('taxa-loja'); if (!el || !loja) return;
  const r = resumoTaxaLoja(loja);
  el.classList.toggle('gratis', r.gratis);
  el.innerHTML = `<i class="fa-solid fa-tag" aria-hidden="true"></i> ${escapeHtml(textoTaxaLoja(loja, formatarMoeda))}`;
}

function renderizarDistancia() {
  const el = $('distancia-loja'); if (!el) return;
  el.innerHTML = (loja && posUsuário && loja.lat != null)
    ? `<i class="fa-solid fa-motorcycle" aria-hidden="true"></i> ${calcularDistanciaKm(posUsuário.lat, posUsuário.lng, loja.lat, loja.lng)} km`
    : '<i class="fa-solid fa-motorcycle" aria-hidden="true"></i> -- km';
}


function cuponsAtivosDaLoja() {
  return Object.entries(loja?.cupones || {})
    .map(([id, c]) => ({ id, ...(c || {}) }))
    .filter(c => c && c.ativo !== false && String(c.codigo || '').trim());
}

function descricaoCupom(c) {
  if (c.tipo === 'porcentagem') return `${Number(c.valor) || 0}% de desconto`;
  if (c.tipo === 'fixo') return `${formatarMoeda(Number(c.valor) || 0, loja?.moeda)} de desconto`;
  if (c.tipo === 'frete_gratis') return 'Entrega grátis';
  return c.titulo || 'Promoção disponível';
}
function destaqueCupom(c) {
  if (c.tipo === 'porcentagem') return `${Number(c.valor) || 0}%`;
  if (c.tipo === 'fixo') return formatarMoeda(Number(c.valor) || 0, loja?.moeda);
  if (c.tipo === 'frete_gratis') return 'Entrega';
  return 'Cupom';
}
function rotuloCupom(c) {
  if (c.tipo === 'porcentagem') return 'de desconto';
  if (c.tipo === 'fixo') return 'de desconto';
  if (c.tipo === 'frete_gratis') return 'gratis';
  return 'especial';
}

function renderizarCuponsLoja() {
  const sec = $('seccion-cupones-loja');
  const lista = $('lista-cupones-loja');
  if (!sec || !lista) return;
  const cupons = cuponsAtivosDaLoja();
  sec.hidden = !cupons.length;
  if (!cupons.length) { lista.innerHTML = ''; return; }
  lista.innerHTML = cupons.map(c => {
    const minimo = Number(c.minimo) || 0;
    const principal = destaqueCupom(c);
    return `<article class="card-cupom-loja">
      <div class="cupom-icone"><i class="fa-solid fa-ticket" aria-hidden="true"></i></div>
      <div class="cupom-loja-info">
        <span class="cupom-label">Cupom</span>
        <strong class="cupom-principal">${escapeHtml(principal)}</strong>
        <span class="cupom-beneficio">${escapeHtml(rotuloCupom(c))}</span>
        ${minimo > 0 ? `<span class="cupom-minimo">Mínimo ${escapeHtml(formatarMoeda(minimo, loja?.moeda))}</span>` : '<span class="cupom-minimo">Sem compra mínima</span>'}
        ${c.titulo ? `<small class="cupom-titulo">${escapeHtml(c.titulo)}</small>` : ''}
      </div>
      <div class="cupom-codigo-loja"><span>Código</span><b>${escapeHtml(String(c.codigo).toUpperCase())}</b></div>
    </article>`;
  }).join('');
}

function renderizarLoja() {
  $('nome-loja').textContent = loja.nombre || loja.nome || 'Restaurante';
  document.title = `${loja.nombre || 'Cardápio'} - Delivery`;
  $('categoria-loja').textContent = loja.categoria || 'Restaurante';
  $('logo-loja').src = imgOtimizada(urlSegura(loja.logo || loja.foto, IMG_LOJA_PADRAO), 300);
  $('capa-loja').src = imgOtimizada(urlSegura(loja.capa, capaPadrao), 1000);
  renderizarCuponsLoja();
  if ($('tempo-loja')) $('tempo-loja').innerHTML = `<i class="fa-regular fa-clock" aria-hidden="true"></i> ${escapeHtml(textoTempo(loja.tiempoEntrega))}`;
  renderizarDistancia();
  renderizarTaxa();
  const banner = $('banner-fechada');
  if (banner) {
    banner.hidden = statusLoja.aberta;
    banner.innerHTML = statusLoja.aberta ? '' : `<i class="fa-solid fa-clock"></i> ${escapeHtml(statusLoja.motivo)}. Você pode ver o cardápio, mas não pode fazer pedidos agora.`;
  }
}

const esgotado = (i) => i?.controlaEstoque === true && (Number(i.estoque) || 0) <= 0;
// V75.128: combo fica indisponível quando falta algum produto dele
const indisponivel = (i) => esgotado(i) || (ehCombo(i) && !resumoCombo(i, loja?.menu).disponivel);
const seloIndisp = (i) => (esgotado(i) ? 'Esgotado' : 'Indisponível');
function precoCartao(i) {
  if (!ehCombo(i)) return `<strong class="preco-prato">${formatarMoeda(i.precio)}</strong>`;
  const c = resumoCombo(i, loja?.menu);
  return `<span class="selo-combo">Combo</span><strong class="preco-prato">${formatarMoeda(i.precio)}${c.economia > 0 ? ` <s class="preco-de">${formatarMoeda(c.de)}</s>` : ''}</strong>${c.economia > 0 ? `<span class="economia">Economize ${formatarMoeda(c.economia)}</span>` : ''}`;
}
const personalizavel = (i) => { const c = configDoProduto(i); return c.grupos.length > 0 || c.adicionais.length > 0; };

// V75.142: vindo da busca da home (restaurante.html?id=…&item=…), rola até o prato e dá um destaque nele (uma vez só)
let itemBuscado = new URLSearchParams(window.location.search).get('item') || '';
function irParaItemBuscado() {
  if (!itemBuscado) return;
  const el = [...document.querySelectorAll('[data-abrir]')].find((x) => x.dataset.abrir === itemBuscado);
  itemBuscado = '';
  if (!el) return;
  setTimeout(() => {
    const reduzir = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    el.scrollIntoView({ block: 'center', behavior: reduzir ? 'auto' : 'smooth' });
    el.classList.add('item-buscado');
    setTimeout(() => el.classList.remove('item-buscado'), 3200);
  }, 350);
}

function renderizarMenu() {
  const el = $('lista-menu');
  const itens = Object.entries(loja.menu || {}).filter(([, i]) => i && i.disponible !== false);
  if (!itens.length) { el.innerHTML = '<p class="msg-vazio">Este restaurante ainda não tem produtos disponíveis.</p>'; return; }

  const grupos = {};
  itens.forEach(([id, i]) => (grupos[i.categoria?.trim() || 'Sem categoria'] ??= []).push([id, i]));
  const categorias = Object.keys(grupos);
  const populares = [...itens].sort((a,b)=>(Number(b[1].vendas)||0)-(Number(a[1].vendas)||0)).filter(([,i]) => Number(i.vendas)>0).slice(0,5);

  let html = '';
  if (populares.length) {
    html += `<section class="popular-section"><div class="popular-head"><div><span class="eyebrow-popular">MAIS PEDIDOS</span><h3>Pratos mais pedidos</h3><p>Os favoritos de acordo com as vendas.</p></div><i class="fa-solid fa-fire-flame-curved"></i></div><div class="popular-grid">${populares.map(([id,i],idx)=>`<article class="popular-card" data-popular="${escapeHtml(id)}" role="button" tabindex="0" aria-label="${escapeHtml(i.nombre||'Produto')}: ver detalhes"><span class="popular-rank">${idx+1}</span><img src="${escapeHtml(imgOtimizada(urlSegura(i.imagen||i.imagem,imgPratoPadrao),300))}" alt="" loading="lazy"><div><strong>${escapeHtml(i.nombre||'Produto')}</strong><span>${Number(i.vendas)||0} vendidos</span></div></article>`).join('')}</div></section>`;
  }

  html += `<nav class="categorias-menu-scroll" aria-label="Categorias do menu"><button type="button" class="categoria-menu-btn active" data-cat-target="menu-inicio">Todos</button>${categorias.map((cat)=>`<button type="button" class="categoria-menu-btn" data-cat-target="cat-${encodeURIComponent(cat)}">${escapeHtml(cat)}</button>`).join('')}</nav>`;
  html += categorias.map((cat) => `<section class="menu-categoria" id="cat-${encodeURIComponent(cat)}"><h3 class="titulo-categoria-menu">${escapeHtml(cat)}</h3>${grupos[cat].map(([id,i]) => `<div class="item-cartao${indisponivel(i) ? ' item-esgotado' : ''}" data-abrir="${escapeHtml(id)}" role="button" tabindex="0" aria-label="${escapeHtml(i.nombre)}: ver detalhes"><div class="info-prato"><h4>${escapeHtml(i.nombre)}</h4><p class="descricao-prato">${escapeHtml(i.descripcion || '')}</p>${precoCartao(i)}${personalizavel(i) ? '<span class="tem-opcoes">＋ Opções e adicionais</span>' : ''}</div><div class="foto-prato-container"><img src="${escapeHtml(imgOtimizada(urlSegura(i.imagen || i.imagem, imgPratoPadrao),300))}" alt="" class="img-prato" loading="lazy">${indisponivel(i) ? `<span class="selo-esgotado">${seloIndisp(i)}</span>` : `<button type="button" class="btn-adicionar-item" data-add="${escapeHtml(id)}" aria-label="Adicionar ${escapeHtml(i.nombre)}" ${statusLoja.aberta ? '' : 'disabled'}>+</button>`}</div></div>`).join('')}</section>`).join('');
  el.innerHTML = html;
  document.querySelectorAll('[data-cat-target]').forEach(btn=>btn.addEventListener('click',()=>{
    document.querySelectorAll('.categoria-menu-btn').forEach(b=>b.classList.toggle('active',b===btn));
    const target=btn.dataset.catTarget;
    if(target==='menu-inicio'){window.scrollTo({top:el.offsetTop-12,behavior:'smooth'});return;}
    const section=document.getElementById(target); if(section) section.scrollIntoView({behavior:'smooth',block:'start'});
  }));
}

// V75.127: tocar no produto, no "+" ou num dos mais pedidos abre a tela do produto (foto, opções, sugestão e adicionais).
// O preço vem sempre do cardápio carregado (nunca de atributo do HTML).
function abrirProduto(itemId) {
  const item = loja?.menu?.[itemId];
  if (!item || item.disponible === false) { toast('Produto indisponível.', 'error'); return; }
  abrirProdutoTela({ menu: loja.menu, itemId, aberta: statusLoja.aberta, motivo: statusLoja.motivo, loja: infoLojaParaTela(), aoAdicionar: adicionarLinhas });
}
$('lista-menu').addEventListener('click', (e) => {
  const alvo = e.target.closest('[data-popular], [data-add], [data-abrir]'); if (!alvo) return;
  abrirProduto(alvo.dataset.popular || alvo.dataset.add || alvo.dataset.abrir);
});
$('lista-menu').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const alvo = e.target.closest('[data-popular], [data-abrir]');
  if (!alvo || e.target.closest('button')) return;
  e.preventDefault();
  abrirProduto(alvo.dataset.popular || alvo.dataset.abrir);
});

// V75.128: cartão da loja sobre a foto do produto (logo, nome, selo, nota, tempo, taxa e km)
function infoLojaParaTela() {
  const total = Number(agregado?.totalAvaliacoes) || comentarios.length;
  const nota = total ? (agregado ? Number(agregado.avaliacaoMedia) : media(comentarios, 'notaMedia')) : null;
  const r = resumoTaxaLoja(loja);
  const taxa = r.gratis ? 'Grátis' : !r.variavel ? formatarMoeda(r.min) : r.min === 0 ? `Grátis a ${formatarMoeda(r.max)}` : `${formatarMoeda(r.min)} a ${formatarMoeda(r.max)}`;
  const km = posUsuário && loja.lat != null ? calcularDistanciaKm(posUsuário.lat, posUsuário.lng, loja.lat, loja.lng) : null;
  const selo = !!$('selo-super-loja') && !$('selo-super-loja').hidden;
  return { nome: loja.nombre || loja.nome || 'Restaurante', logo: urlSegura(loja.logo || loja.foto, IMG_LOJA_PADRAO), nota: Number.isFinite(nota) ? nota : null, total, tempo: textoTempo(loja.tiempoEntrega), taxa, gratis: r.gratis, km, selo };
}

/** Põe as linhas da tela do produto no carrinho. Mesma escolha soma na linha que já existe. */
async function adicionarLinhas(linhas) {
  if (!statusLoja.aberta) { toast(statusLoja.motivo, 'error'); return false; }
  for (const l of linhas) {
    const item = loja?.menu?.[l.id];
    if (!item || item.disponible === false) { toast(`"${l.nombre}" está indisponível.`, 'error'); return false; }
    if (indisponivel(item)) { toast(esgotado(item) ? `"${item.nombre}" está esgotado.` : `"${item.nombre}" está indisponível agora.`, 'error'); return false; }
  }
  let carrinho = obterCarrinho();
  if (carrinho.lojaId && carrinho.lojaId !== lojaId && carrinho.itens.length) {
    if (!await confirmar({ titulo: 'Começar um novo carrinho?', texto: 'Você tem produtos de outro restaurante. Esvaziar o carrinho e começar de novo?', rotulo: 'Esvaziar e continuar', cancelar: 'Manter carrinho' })) return false;
    carrinho = { lojaId, itens: [] };
  }
  carrinho.lojaId = lojaId;
  // estoque: soma todas as linhas do mesmo produto (as que já estão no carrinho + as novas)
  const porProduto = {};
  for (const l of [...carrinho.itens, ...linhas]) porProduto[l.id] = (porProduto[l.id] || 0) + (Number(l.qtd) || 0);
  for (const l of linhas) {
    const item = loja.menu[l.id];
    if (item?.controlaEstoque === true && porProduto[l.id] > (Number(item.estoque) || 0)) { toast(`Só há ${Number(item.estoque) || 0} unidade(s) de "${item.nombre}" em estoque.`, 'error'); return false; }
  }
  for (const l of linhas) {
    const existente = carrinho.itens.find((i) => chaveLinha(i) === chaveLinha(l));
    if (existente) existente.qtd = Math.min(99, (Number(existente.qtd) || 0) + l.qtd);
    else carrinho.itens.push(l);
  }
  const barraAntes = $('barra-carrinho');
  const apareceu = !!barraAntes && barraAntes.hidden;
  salvarCarrinho(carrinho);
  atualizarBarraCarrinho();
  anunciarItem(barraAntes, apareceu); // V75.131: a tela desce, a barra sobe e os olhos da sacola piscam
  if (navigator.vibrate) navigator.vibrate(15);
  // V75.131: a confirmação é a barra com a sacola piscando (sem aviso por cima da tela)
  return true;
}

function atualizarBarraCarrinho() {
  const c = obterCarrinho();
  const barra = $('barra-carrinho'); if (!barra) return;
  const qtd = c.itens.reduce((a, i) => a + i.qtd, 0);
  const total = c.itens.reduce((a, i) => a + i.precio * i.qtd, 0);
  const mostrar = qtd > 0 && c.lojaId === lojaId;
  barra.hidden = !mostrar;
  if (mostrar) { $('qtd-carrinho').textContent = qtd; $('total-carrinho').textContent = formatarMoeda(total); atualizarSacola(barra, qtd); }
}

// ---------- Avaliações ----------
// Médias vêm do agregado `lojas/{id}` (barato). A lista de comentários é limitada aos 30 mais recentes.
let agregado = null, comentarios = [], pedidosSuper = [];

function carregarDadosSuper() {
  onValue(query(ref(db, 'pedidos'), orderByChild('lojaId'), equalTo(lojaId)), (s) => {
    pedidosSuper = s.exists() ? Object.values(s.val() || {}) : [];
    desenharAvaliacoes();
    splashPronto('pedidos');
  }, (err) => {
    console.warn('Super/restaurante:', err);
    pedidosSuper = [];
    desenharAvaliacoes();
    splashPronto('pedidos');
  });
}
function carregarAvaliacoes() {
  onValue(ref(db, `lojas/${lojaId}`), (s) => { agregado = s.val(); desenharAvaliacoes(); splashPronto('agregado'); }, () => { splashPronto('agregado'); });
  onValue(query(ref(db, `avaliacoes/${lojaId}`), limitToLast(30)), (s) => {
    comentarios = s.exists() ? Object.values(s.val()) : [];
    desenharAvaliacoes();
    splashPronto('comentarios');
  }, () => { $('lista-comentarios-restaurante').innerHTML = '<p class="msg-vazio">Não foi possível carregar as avaliações.</p>'; splashPronto('comentarios'); });
}

const media = (arr, campo) => arr.reduce((a, x) => a + (Number(x[campo]) || 0), 0) / (arr.length || 1);
const estrelas = (n) => { const r = Math.max(0, Math.min(5, Math.round(Number(n) || 0))); return '★'.repeat(r) + '☆'.repeat(5 - r); };

function desenharAvaliacoes() {
  const total = Number(agregado?.totalAvaliacoes) || comentarios.length;
  const set = (id, txt) => { const e = $(id); if (e) e.textContent = txt; };
  const setHtml = (id, html) => { const e = $(id); if (e) e.innerHTML = html; };
  if (!total) {
    setHtml('avaliacao-loja', '<i class="fa-solid fa-star" aria-hidden="true"></i> Novo'); set('restaurante-nota-geral', '0.0');
    set('restaurante-total-avaluaciones', '(0 avaliações)'); set('restaurante-nota-comida', '0.0 ★'); set('restaurante-nota-entrega', '0.0 ★');
    $('lista-comentarios-restaurante').innerHTML = '<p class="msg-vazio">Este restaurante ainda não tem avaliações.</p>';
    const superBadge = $('selo-super-loja');
    if (superBadge) superBadge.hidden = true;
    return;
  }
  const geral = agregado ? Number(agregado.avaliacaoMedia) : media(comentarios, 'notaMedia');
  const comida = agregado ? Number(agregado.avaliacaoComida) : media(comentarios, 'notaComida');
  const entrega = agregado ? Number(agregado.avaliacaoEntrega) : media(comentarios, 'notaEntrega');
  setHtml('avaliacao-loja', `<i class="fa-solid fa-star" aria-hidden="true"></i> ${geral.toFixed(1)}`);
  set('restaurante-nota-geral', geral.toFixed(1));
  set('restaurante-total-avaliacoes', `(${total} ${total === 1 ? 'avaliação' : 'avaliações'})`);
  set('restaurante-nota-comida', `${comida.toFixed(1)} ★`);
  set('restaurante-nota-entrega', `${entrega.toFixed(1)} ★`);
  set('restaurante-estrelas-geral', estrelas(geral));

  const lista = [...comentarios].filter(i => i && (!String(i.comentario || '').trim() || i.respostaLoja || i.respuestaTienda)).sort((a, b) => String(b.criadoEm || '').localeCompare(String(a.criadoEm || '')));
  $('lista-comentarios-restaurante').innerHTML = lista.length ? lista.slice(0,3).map((i) => {
    const primeiro = escapeHtml(String(i.clienteNome || 'Cliente').trim().split(' ')[0]);
    const tags = [...(i.tagsComida || []).map((t) => ['comida', t]), ...(i.tagsEntrega || []).map((t) => ['entrega', t])]
      .map(([k, t]) => `<span class="tag-review ${k}">${escapeHtml(t)}</span>`).join('');
    return `<div class="card-comentario-item">
      <div class="comentario-header">
        <div class="cliente-info"><strong>${primeiro}</strong><span class="comentario-data">${i.criadoEm ? new Date(i.criadoEm).toLocaleDateString('es') : ''}</span></div>
        <div class="estrelas-comentario" aria-label="${Math.round(i.notaMedia || 0)} de 5">${estrelas(i.notaMedia)}</div>
      </div>
      <div class="detalhes-subnotas"><small>Comida: <strong>${Number(i.notaComida) || 0}★</strong></small> • <small>Entrega: <strong>${Number(i.notaEntrega) || 0}★</strong></small></div>
      ${i.comentario ? `<p class="texto-comentario">"${escapeHtml(i.comentario)}"</p>` : '<p class="texto-comentario texto-sin-comentario">O cliente deixou sua avaliação sem comentário.</p>'}
      ${i.respostaLoja || i.respuestaTienda ? `<div class="respuesta-tienda"><strong><i class="fa-solid fa-store"></i> Resposta da loja</strong><p>${escapeHtml(i.respostaLoja || i.respuestaTienda)}</p></div>` : ''}
      <div class="tags-container">${tags}</div>
    </div>`;
  }).join('') : '<p class="msg-vazio">As avaliações com comentários aparecerão aqui depois que a loja responder.</p>';
  const irAvaliacoes = () => { window.location.href = `avaliaciones.html?id=${encodeURIComponent(lojaId)}`; };
  const badge = $('avaliacao-loja');
  if (badge) { badge.style.cursor='pointer'; badge.title='Ver todas as avaliações'; badge.onclick=irAvaliacoes; }
  const resumo = document.querySelector('.card-resumo-notas');
  if (resumo) { resumo.setAttribute('role','link'); resumo.setAttribute('tabindex','0'); resumo.title='Ver todas as avaliações'; resumo.onclick=irAvaliacoes; resumo.onkeydown=(e)=>{ if(e.key==='Enter'||e.key===' '){e.preventDefault();irAvaliacoes();} }; }
  const superBadge=$('selo-super-loja');
  if(superBadge){ superBadge.hidden=!avaliarSuper({ ...loja, ...(agregado || {}) }, pedidosSuper).elegivel; }
}
