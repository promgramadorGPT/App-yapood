// V75.36 — Presente fidelidade como SURPRESA: o que a loja deu só aparece quando o cliente chega na caixa de presente.
// Aqui ficam (1) o registro de quais presentes ele já abriu neste aparelho e (2) o overlay com a explosão de confetes.
import { escapeHtml } from './regras.js';

const CHAVE = 'yapood_presentes_abertos_v1';
const CHAVE_USAR = 'yapood_presente_usar';

const ler = () => { try { const v = JSON.parse(localStorage.getItem(CHAVE)); return v && typeof v === 'object' ? v : {}; } catch { return {}; } };

export function lerReveladas(uid) {
  const m = ler()[uid];
  return m && typeof m === 'object' ? m : {};
}
export function marcarReveladas(uid, lojaId, ganhos) {
  try {
    const t = ler(); t[uid] = { ...(t[uid] || {}), [lojaId]: Math.max(Number(ganhos) || 0, Number(t[uid]?.[lojaId]) || 0) };
    localStorage.setItem(CHAVE, JSON.stringify(t));
  } catch { /* modo privado: o overlay só reaparece na próxima visita */ }
}
// "Usar neste pedido" na tela de Cupons deixa um recado para o carrinho aplicar o presente sozinho.
export function pedirUsoNoCarrinho(lojaId) { try { localStorage.setItem(CHAVE_USAR, lojaId); } catch { /* noop */ } }
export function consumirUsoNoCarrinho() {
  try { const v = localStorage.getItem(CHAVE_USAR); if (v) localStorage.removeItem(CHAVE_USAR); return v || ''; } catch { return ''; }
}

// ---------- confetes (canvas, sem biblioteca) ----------
const corDaMarca = () => { try { return getComputedStyle(document.documentElement).getPropertyValue('--cor-primaria').trim() || '#efb638'; } catch { return '#efb638'; } };
const cores = () => [corDaMarca(), '#e0a100', '#2e9e5b', '#2f7de1', '#f06fa6', '#ffffff', '#8e44ad'];
export function explodirConfetes(canvas, { reduzirMovimento = false } = {}) {
  const ctx = canvas.getContext('2d');
  if (!ctx || reduzirMovimento) return () => {};
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = (canvas.width = Math.floor(innerWidth * dpr)), h = (canvas.height = Math.floor(innerHeight * dpr));
  canvas.style.width = '100%'; canvas.style.height = '100%';
  const origem = () => ({ x: w / 2, y: h * 0.36 });
  const CORES = cores();
  const ps = [];
  const rajada = (n, forca) => {
    const o = origem();
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2, v = (Math.random() * 0.6 + 0.4) * forca * dpr;
      ps.push({ x: o.x, y: o.y, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v - 5 * dpr, g: (0.16 + Math.random() * 0.08) * dpr,
        r: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.4, w: (6 + Math.random() * 6) * dpr, h: (3 + Math.random() * 4) * dpr,
        c: CORES[(Math.random() * CORES.length) | 0], vida: 0, max: 120 + Math.random() * 80, forma: Math.random() < 0.25 ? 'c' : 'r' });
    }
  };
  rajada(130, 15);
  const t2 = setTimeout(() => rajada(90, 12), 450);
  let raf = 0, parado = false;
  const quadro = () => {
    ctx.clearRect(0, 0, w, h);
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.vx *= 0.985; p.vy += p.g; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.vida++;
      if (p.vida > p.max || p.y > h + 40) { ps.splice(i, 1); continue; }
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.globalAlpha = Math.max(0, 1 - p.vida / p.max);
      ctx.fillStyle = p.c;
      if (p.forma === 'c') { ctx.beginPath(); ctx.arc(0, 0, p.h, 0, Math.PI * 2); ctx.fill(); } else ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }
    if (!parado && (ps.length || performance.now() < fim)) raf = requestAnimationFrame(quadro);
  };
  const fim = performance.now() + 700;
  raf = requestAnimationFrame(quadro);
  return () => { parado = true; clearTimeout(t2); cancelAnimationFrame(raf); ctx.clearRect(0, 0, w, h); };
}

// ---------- overlay "Você ganhou um presente!" ----------
// aoPegar() roda quando o cliente toca em "Pegar presente" (marca como aberto e leva para Cupons).
export function mostrarPresente({ lojaNome, titulo, quantidade = 1, aoPegar }) {
  if (document.getElementById('fid-overlay')) return;
  const el = document.createElement('div');
  el.id = 'fid-overlay';
  el.className = 'fid-overlay';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-modal', 'true');
  el.setAttribute('aria-labelledby', 'fid-ov-titulo');
  el.innerHTML = `<canvas class="fid-confete" aria-hidden="true"></canvas>
    <div class="fid-ov-card">
      <div class="fid-ov-icone" aria-hidden="true"><i class="fa-solid fa-gift"></i></div>
      <p class="fid-ov-eyebrow">Presente fidelidade${lojaNome ? ` · ${escapeHtml(lojaNome)}` : ''}</p>
      <h2 id="fid-ov-titulo">${quantidade > 1 ? `Você ganhou ${quantidade} presentes!` : 'Você ganhou um presente!'}</h2>
      <p class="fid-ov-sub">${quantidade > 1 ? 'Seu primeiro presente:' : 'Seu presente é:'}</p>
      <p class="fid-ov-premio">${escapeHtml(titulo)}</p>
      <p class="fid-ov-nota">Ele fica guardado em <strong>Cupons</strong> para você usar quando quiser.</p>
      <button type="button" class="fid-ov-btn" data-pegar>Pegar presente</button>
      <button type="button" class="fid-ov-depois" data-depois>Ver depois</button>
    </div>`;
  document.body.appendChild(el);
  document.body.classList.add('fid-travado');
  const parar = explodirConfetes(el.querySelector('canvas'), { reduzirMovimento: matchMedia('(prefers-reduced-motion: reduce)').matches });
  const fechar = () => { parar(); el.remove(); document.body.classList.remove('fid-travado'); document.removeEventListener('keydown', esc); };
  const esc = (e) => { if (e.key === 'Escape') fechar(); };
  document.addEventListener('keydown', esc);
  el.addEventListener('click', (e) => {
    if (e.target.closest('[data-pegar]')) { fechar(); aoPegar?.(); }
    else if (e.target.closest('[data-depois]')) fechar();
  });
  el.querySelector('[data-pegar]').focus();
}
