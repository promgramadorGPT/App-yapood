// V75.92 — texto e estado do bloco "avisos de aprovação" na tela de cadastro do lojista.
// Antes o lojista só recebia o pedido de permissão por conta própria do navegador (que muitas vezes não aparece sem um toque),
// então o token do aparelho nunca era criado e o push de "cadastro aprovado" não saía. Aqui o botão dá o toque que o navegador exige.
export function estadoAvisosLojista({ suporte = true, permissao = 'default', registrado = false, erro = '' } = {}) {
  if (!suporte) return { tipo: 'info', texto: 'Este aparelho não recebe avisos do app. Você será avisado por e-mail e WhatsApp quando o cadastro for analisado.', botao: '' };
  if (registrado) return { tipo: 'ok', texto: 'Avisos ativados neste aparelho. Você será avisado na hora em que o cadastro for analisado.', botao: '' };
  if (permissao === 'denied') return { tipo: 'erro', texto: 'Os avisos estão bloqueados neste aparelho. No Chrome: ⋮ → Configurações do site → Notificações → Permitir. Depois toque em “Tentar de novo”.', botao: 'Tentar de novo' };
  if (erro) return { tipo: 'erro', texto: `Não foi possível ativar os avisos: ${erro}`, botao: 'Tentar de novo' };
  return { tipo: 'aviso', texto: 'Ative os avisos para saber na hora quando o seu cadastro for aprovado, mesmo com o app fechado.', botao: 'Ativar avisos' };
}
