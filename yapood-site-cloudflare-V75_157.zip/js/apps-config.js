// V75.55 — Endereço de cada app. Deixe '' enquanto os três apps usam o MESMO endereço (como hoje).
// Para o Android tratar painel e entregador como apps separados do app do cliente, publique o mesmo projeto
// em outros endereços (ex.: https://yapood-painel.vercel.app) e preencha aqui, SEM barra no final.
export const APPS = {
  cliente: '',
  painel: '',
  entregador: '',
  master: ''
};

/** URL absoluta de um arquivo de um app. Sem endereço configurado, usa o endereço desta página. */
export function urlApp(qual, arquivo = '', local = (typeof location !== 'undefined' ? location : null)) {
  const base = String(APPS[qual] || '').trim().replace(/\/+$/, '');
  if (base) return `${base}/${arquivo}`;
  if (!local) return arquivo;
  return `${local.origin}${String(local.pathname || '/').replace(/[^/]*$/, '')}${arquivo}`;
}
