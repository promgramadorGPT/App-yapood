// js/master-cadastros.js — V75.47: aba "Solicitações" do Master (cadastro de lojistas). Regras puras em cadastro-analise.js e cadastro-lojista.js.
import { CADASTRO, formatarDocumento, mascararDocumento, formatarTelefoneParcial, idadeEm, decisaoDoMaster, mensagemWhatsApp, linkWhatsApp, rotuloCadastro, fotoValida } from './cadastro-lojista.js';
import { urlApp } from './apps-config.js';
import { filtrarCadastros, contarPendentes, alertasDoCadastro, urlConsultaCnpj, interpretarCnpj } from './cadastro-analise.js';

/**
 * ctx: { S, $, esc, aviso, executar, confirmar, logar, fmtData, quando, vazio, selo, db, ref, get, update, remove, auth, NOTPUSH_API }
 * Devolve { render, pendentes }.
 */
export function iniciarCadastrosMaster(ctx) {
  const { S, $, esc, aviso, executar, confirmar, logar, fmtData, quando, vazio, selo, db, ref, get, update, remove, auth, NOTPUSH_API } = ctx;
  let abertoUid = null;

  const seloStatus = (c) => selo({ pendente: 'aviso', aprovado: 'ok', recusado: 'off' }[c.status] || 'off', rotuloCadastro(c));
  const linhaDado = (k, v) => (v ? `<div><dt>${esc(k)}</dt><dd>${v}</dd></div>` : '');

  function render() {
    const lista = $('cadastros-lista');
    if (!lista) return;
    if (!S.cadastrosOk) { lista.innerHTML = vazio('fa-spinner fa-spin', 'Carregando…'); return; }
    const itens = filtrarCadastros(S.cadastros, $('mc-filtro').value, $('mc-busca').value);
    lista.innerHTML = itens.length
      ? `<table class="m-tabela"><thead><tr><th>Lojista</th><th>Documento</th><th>Loja</th><th>Enviado</th><th>Situação</th><th></th></tr></thead><tbody>${itens.map((c) => `<tr data-acao="ver-cadastro" data-id="${esc(c.uid)}"><td data-rotulo="Lojista"><b>${esc(c.nomeCompleto || '—')}</b><small>${esc(c.email || '')}</small></td><td data-rotulo="Documento">${esc((c.docTipo || '').toUpperCase())} ${esc(mascararDocumento(c.doc))}</td><td data-rotulo="Loja">${esc(c.nomeLoja || '—')}</td><td data-rotulo="Enviado">${esc(quando(c.enviadoEm))}</td><td data-rotulo="Situação">${seloStatus(c)}</td><td><button type="button" class="m-btn m-btn-leve" data-acao="ver-cadastro" data-id="${esc(c.uid)}">${c.status === CADASTRO.PENDENTE ? 'Analisar' : 'Ver'}</button></td></tr>`).join('')}</tbody></table>`
      : vazio('fa-circle-check', $('mc-filtro').value === 'pendentes' ? 'Nenhuma solicitação esperando análise.' : 'Nenhuma solicitação encontrada.');
  }

  function erro(msg) { const e = $('mc-erro'); e.hidden = !msg; e.textContent = msg || ''; }

  async function carregarFoto(uid) {
    const alvo = $('mc-foto');
    alvo.innerHTML = '<p class="m-nota"><i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> Carregando a foto do documento…</p>';
    try {
      const v = (await get(ref(db, `lojistas_documentos/${uid}`))).val();
      if (abertoUid !== uid) return;
      alvo.innerHTML = v && fotoValida(v.foto)
        ? `<div class="mc-foto-quadro"><img id="mc-foto-img" src="${v.foto}" alt="Foto do documento enviada pelo lojista"></div><small class="m-nota">Toque na imagem para ampliar. Enviada em ${esc(fmtData(v.enviadoEm, true))}.</small>`
        : `<p class="m-faixa m-faixa-aviso">${S.cadastros[uid]?.status && S.cadastros[uid].status !== CADASTRO.PENDENTE ? 'Foto do documento apagada depois da análise (LGPD).' : 'Sem foto do documento (ainda não enviada).'}</p>`;
      $('mc-apagar-foto').hidden = !(v && S.cadastros[uid]?.status !== CADASTRO.PENDENTE);
    } catch (e) {
      console.error(e);
      if (abertoUid === uid) alvo.innerHTML = '<p class="m-faixa m-faixa-erro">Não foi possível carregar a foto. Confirme se as regras do Firebase foram publicadas.</p>';
    }
  }

  async function consultarCnpj(uid) {
    const c = S.cadastros[uid];
    const url = urlConsultaCnpj(c?.doc);
    const alvo = $('mc-cnpj');
    if (!url) return;
    alvo.innerHTML = '<p class="m-nota"><i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> Consultando a Receita…</p>';
    const ctrl = new AbortController(), t = setTimeout(() => ctrl.abort(), 9000);
    try {
      const r = await fetch(url, { signal: ctrl.signal, headers: { Accept: 'application/json' } });
      if (!r.ok) throw new Error(r.status === 404 ? 'CNPJ não encontrado na base da Receita.' : `A consulta falhou (${r.status}).`);
      const i = interpretarCnpj(await r.json(), c);
      if (abertoUid !== uid) return;
      alvo.innerHTML = `<dl class="m-dados">${linhaDado('Razão social', esc(i.razaoSocial))}${linhaDado('Nome fantasia', esc(i.fantasia))}${linhaDado('Situação na Receita', esc(i.situacao))}${linhaDado('Início da atividade', esc(i.abertura))}${linhaDado('Cidade', esc(i.cidade))}${linhaDado('Atividade', esc(i.atividade))}${linhaDado('Sócios', esc(i.socios.join(', ')))}</dl>${i.avisos.map((a) => `<p class="m-faixa m-faixa-aviso"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> ${esc(a)}</p>`).join('')}`;
    } catch (e) {
      alvo.innerHTML = `<p class="m-faixa m-faixa-erro">${esc(e.name === 'AbortError' ? 'A consulta demorou demais. Tente de novo.' : e.message || 'Não foi possível consultar.')}</p>`;
    } finally { clearTimeout(t); }
  }

  function abrir(uid) {
    const c = S.cadastros[uid];
    if (!c) { aviso('Solicitação não encontrada.', 'erro'); return; }
    abertoUid = uid;
    const idade = idadeEm(c.nascimento);
    const alertas = alertasDoCadastro({ ...c, uid }, S.cadastros);
    $('mc-titulo').textContent = `Solicitação · ${c.nomeLoja || c.nomeCompleto || ''}`;
    $('mc-corpo').innerHTML = `
      <div>${seloStatus(c)}</div>
      ${alertas.map((a) => `<p class="m-faixa m-faixa-aviso"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> ${esc(a)}</p>`).join('')}
      <dl class="m-dados">
        ${linhaDado('Nome completo', esc(c.nomeCompleto))}
        ${linhaDado((c.docTipo || 'Documento').toUpperCase(), esc(formatarDocumento(c.doc)))}
        ${linhaDado('Nascimento', `${esc(String(c.nascimento || '').split('-').reverse().join('/'))}${idade !== null ? ` <small>${idade} anos</small>` : ''}`)}
        ${linhaDado('WhatsApp', esc(formatarTelefoneParcial(c.whatsapp)))}
        ${linhaDado('E-mail da conta Google', esc(c.email))}
        ${linhaDado('Nome da loja', esc(c.nomeLoja))}
        ${linhaDado('Enviado em', esc(fmtData(c.enviadoEm, true)))}
        ${linhaDado('Aceite dos termos', c.aceite ? `${esc(fmtData(c.aceite.em, true))} <small>versão ${esc(c.aceite.versao)}</small>` : '')}
        ${c.analisadoEm ? linhaDado('Analisado em', `${esc(fmtData(c.analisadoEm, true))}${c.motivoRecusa ? ` <small>${esc(c.motivoRecusa)}</small>` : ''}`) : ''}
      </dl>
      <div id="mc-foto"></div>
      ${c.docTipo === 'cnpj' ? '<div><button type="button" id="mc-consultar" class="m-btn m-btn-leve"><i class="fa-solid fa-building-circle-check" aria-hidden="true"></i> Consultar CNPJ na Receita</button><div id="mc-cnpj"></div></div>' : ''}
      <p class="m-nota">Compare o nome e o número do documento da foto com os dados acima. Conferir se o CPF/CNPJ é mesmo da pessoa é a sua função: o sistema só confere se os números são válidos.</p>`;
    const decidido = c.status !== CADASTRO.PENDENTE;
    $('mc-motivo').value = '';
    $('mc-motivo-wrap').hidden = c.status === CADASTRO.APROVADO;
    $('mc-aprovar').hidden = c.status === CADASTRO.APROVADO;
    $('mc-recusar').hidden = c.status !== CADASTRO.PENDENTE;
    $('mc-apagar-foto').hidden = true;
    const w = $('mc-whats');
    const link = decidido ? linkDoAviso(c) : '';
    w.hidden = !link; if (link) w.href = link;
    erro('');
    $('m-cadastro').hidden = false;
    carregarFoto(uid);
    $('mc-consultar')?.addEventListener('click', () => consultarCnpj(uid));
  }

  /** Link do WhatsApp com a mensagem pronta (aprovado ou recusado com o motivo). '' se o cadastro ainda não foi decidido. */
  function linkDoAviso(c) {
    return linkWhatsApp(c.whatsapp, mensagemWhatsApp(c, { url: urlApp('painel', 'admin-loja.html', { origin: location.origin, pathname: '/' }) }));
  }

  /** V75.66 — logo depois de decidir, oferece abrir o WhatsApp com a mensagem pronta (o e-mail não está em uso). */
  async function oferecerWhatsApp(uid) {
    const c = S.cadastros[uid];
    const link = c && c.status !== CADASTRO.PENDENTE ? linkDoAviso(c) : '';
    if (!link) return;
    const primeiro = String(c.nomeCompleto || '').trim().split(' ')[0] || 'o lojista';
    const aprovado = c.status === CADASTRO.APROVADO;
    const r = await confirmar({
      titulo: `Avisar ${primeiro} no WhatsApp?`,
      texto: aprovado ? 'Abre o WhatsApp com a mensagem de aprovação pronta e o link para criar a loja. Você só toca em enviar.' : 'Abre o WhatsApp com a mensagem pronta, com o motivo da recusa. Você só toca em enviar.',
      rotulo: 'Abrir WhatsApp'
    });
    if (!r.ok) return;
    const janela = window.open(link, '_blank');   // (com 'noopener' o navegador sempre devolve null e não dá para saber se abriu)
    if (janela) { try { janela.opener = null; } catch { /* sem acesso */ } }
    else aviso('Não consegui abrir o WhatsApp. Use o botão de WhatsApp dentro do cadastro.', 'erro');
  }

  function fechar() { abertoUid = null; $('m-cadastro').hidden = true; }

  async function avisarLojista(uid) {
    try {
      const idToken = await auth.currentUser.getIdToken(true);
      const r = await fetch(`${NOTPUSH_API}/notificar-cadastro`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` }, body: JSON.stringify({ evento: 'analisado', uid }) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || `HTTP ${r.status}`);
      const push = d.push?.enviados ? `push enviado (${d.push.enviados})` : 'sem push (o lojista ainda não ativou os avisos)';
      const email = d.email?.enviado ? 'e-mail enviado' : `e-mail não enviado${d.email?.motivo ? ` (${d.email.motivo})` : ''}`;
      aviso(`Lojista avisado: ${push}; ${email}. O aviso pelo WhatsApp vem a seguir.`, d.email?.enviado || d.push?.enviados ? 'ok' : 'erro');
    } catch (e) {
      console.warn('[cadastro] aviso ao lojista:', e);
      aviso('Decisão salva, mas o aviso automático não saiu. Avise o lojista pelo botão de WhatsApp.', 'erro');
    }
  }

  async function decidir(status) {
    const uid = abertoUid, c = S.cadastros[uid];
    if (!c) return;
    let mudanca;
    try { mudanca = decisaoDoMaster(status, { motivo: $('mc-motivo').value, uid: S.user?.uid || auth.currentUser?.uid || '' }); }
    catch (e) { erro(e.message); return; }
    erro('');
    if (status === CADASTRO.APROVADO) {
      const r = await confirmar({ titulo: `Aprovar ${c.nomeCompleto}?`, texto: 'O lojista será avisado e poderá criar a loja. A foto do documento é apagada em seguida (LGPD).', rotulo: 'Aprovar' });
      if (!r.ok) return;
    } else {
      const r = await confirmar({ titulo: `Recusar ${c.nomeCompleto}?`, texto: `Motivo que o lojista vai ver: ${mudanca.motivoRecusa}. A foto do documento é apagada em seguida (LGPD); se ele corrigir, envia outra.`, rotulo: 'Recusar', perigo: true });
      if (!r.ok) return;
    }
    const gravou = await executar(() => update(ref(db, `lojistas_cadastro/${uid}`), mudanca));
    if (!gravou) return;
    S.cadastros[uid] = { ...c, ...mudanca };
    if (mudanca.motivoRecusa === null) delete S.cadastros[uid].motivoRecusa;
    logar(status === CADASTRO.APROVADO ? 'cadastro_aprovado' : 'cadastro_recusado', uid, c.nomeLoja || '');
    // V75.116 (LGPD): decidiu, apaga a foto do documento. Se falhar, o botão "Apagar foto" continua disponível.
    try { await remove(ref(db, `lojistas_documentos/${uid}`)); logar('cadastro_foto_apagada', uid, 'automático, depois da decisão'); }
    catch (e) { console.warn('Foto do documento não apagada:', e); aviso('Decisão salva, mas a foto do documento não foi apagada. Use "Apagar foto".', 'erro'); }
    abrir(uid);
    render();
    await avisarLojista(uid);
    await oferecerWhatsApp(uid);
  }

  async function apagarFoto() {
    const uid = abertoUid;
    const r = await confirmar({ titulo: 'Apagar a foto do documento?', texto: 'A imagem será removida do banco. Os dados do cadastro continuam. Isso não pode ser desfeito.', rotulo: 'Apagar', perigo: true });
    if (!r.ok) return;
    const ok = await executar(() => remove(ref(db, `lojistas_documentos/${uid}`)), 'Foto apagada.');
    if (ok) { logar('cadastro_foto_apagada', uid, ''); carregarFoto(uid); $('mc-apagar-foto').hidden = true; }
  }

  // ---- eventos ----
  $('mc-filtro').addEventListener('change', render);
  $('mc-busca').addEventListener('input', render);
  $('cadastros-lista').addEventListener('click', (e) => { const el = e.target.closest('[data-acao="ver-cadastro"]'); if (el) abrir(el.dataset.id); });
  $('mc-fechar').addEventListener('click', fechar);
  $('m-cadastro').addEventListener('click', (e) => { if (e.target === $('m-cadastro')) fechar(); });
  $('mc-aprovar').addEventListener('click', () => decidir(CADASTRO.APROVADO));
  $('mc-recusar').addEventListener('click', () => decidir(CADASTRO.RECUSADO));
  $('mc-apagar-foto').addEventListener('click', apagarFoto);
  $('mc-corpo').addEventListener('click', (e) => { if (e.target.id === 'mc-foto-img') e.target.closest('.mc-foto-quadro').classList.toggle('mc-zoom'); });

  return { render, pendentes: () => contarPendentes(S.cadastros), fechar, aberto: () => abertoUid };
}
