// V75.83 — Kit de divulgação por cidade: desenha as imagens (PNG) no navegador, sem servidor e sem bibliotecas.
// Cores do tema do app, logo do YAPOOD, contador de vagas e QR Code (js/qr.js) com o link da cidade.
// Os textos vêm de kit-textos.js (testados); aqui só o desenho.
import { qrMatriz } from './qr.js';
import { LOGO_YAPOOD } from './logo-yapood.js';
import { derivarTema } from './tema-cores.js';
import { textosDivulgacao, textosCarrossel, quebrarLinhas, quebrarEquilibrado, juntarNumeros } from './kit-textos.js';

export const PECAS = [
  { id: 'lojista-story', grupo: 'chamada', publico: 'lojista', rotulo: 'Story / Status', formato: '1080 × 1920', w: 1080, h: 1920, layout: 'vertical' },
  { id: 'lojista-feed', grupo: 'chamada', publico: 'lojista', rotulo: 'Feed (4:5)', formato: '1080 × 1350', w: 1080, h: 1350, layout: 'lateral' },
  { id: 'lojista-a4', grupo: 'chamada', publico: 'lojista', rotulo: 'Folheto A4 para imprimir', formato: '2480 × 3508', w: 2480, h: 3508, layout: 'vertical' },
  { id: 'cliente-story', grupo: 'chamada', publico: 'cliente', rotulo: 'Story / Status', formato: '1080 × 1920', w: 1080, h: 1920, layout: 'vertical' },
  { id: 'cliente-feed', grupo: 'chamada', publico: 'cliente', rotulo: 'Feed (4:5)', formato: '1080 × 1350', w: 1080, h: 1350, layout: 'lateral' }
];
// Carrossel "Como funciona": 5 telas 1080 × 1350 por público (Instagram aceita até 10 imagens por post).
export const TELAS_CARROSSEL = 5;
for (const publico of ['lojista', 'cliente']) {
  for (let i = 1; i <= TELAS_CARROSSEL; i++) PECAS.push({ id: `${publico}-carrossel-${i}`, grupo: 'carrossel', publico, tela: i, rotulo: `Tela ${i} de ${TELAS_CARROSSEL}`, formato: '1080 × 1350', w: 1080, h: 1350, layout: 'carrossel' });
}

const FONTE = 'system-ui, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
const fonte = (peso, tam) => `${peso} ${Math.round(tam)}px ${FONTE}`;

function caminhoArredondado(c, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}

/** A logo do app como imagem, com as cores do tema (no app elas vêm do CSS; aqui vão dentro do SVG). */
function carregarLogo(cores) {
  const svg = LOGO_YAPOOD
    .replace('class="lg-logo" aria-hidden="true" focusable="false"', 'width="700" height="350"')
    .replace(/class="lg-letras"/g, `fill="${cores.letras}"`)
    .replace(/class="lg-acento"/g, `fill="${cores.acento}"`)
    .replace(/class="lg-sorriso"/g, `stroke="${cores.acento}"`);
  return new Promise((ok, erro) => {
    const img = new Image();
    img.onload = () => ok(img); img.onerror = () => erro(new Error('Não foi possível desenhar a logo.'));
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  });
}

function desenharQr(c, texto, x, y, tam) {
  const m = qrMatriz(texto), n = m.length, mod = Math.max(1, Math.floor(tam / n)), real = mod * n, ox = x + (tam - real) / 2, oy = y + (tam - real) / 2;
  c.fillStyle = '#111111';
  m.forEach((lin, j) => lin.forEach((on, i) => { if (on) c.fillRect(ox + i * mod, oy + j * mod, mod, mod); }));
}

function hostDe(link) { try { return new URL(link).host; } catch { return String(link || '').replace(/^https?:\/\//, '').split('/')[0]; } }

/**
 * Desenha uma peça. dados: { cidade, vagas, links, tema:{primaria,sobre}, origem }.
 * Devolve o <canvas>. Lança erro se a logo ou o QR não puderem ser desenhados.
 */
export async function desenharPeca(pecaOuId, dados) {
  const peca = typeof pecaOuId === 'string' ? PECAS.find((p) => p.id === pecaOuId) : pecaOuId;
  if (!peca) throw new Error('Peça desconhecida.');
  const t = derivarTema(dados.tema?.primaria, dados.tema?.sobre);
  const cores = { fundo: t.primaria, letras: t.sobre, acento: '#ffffff' };
  if (peca.grupo === 'carrossel') return desenharTela(peca, dados);
  const bruto = textosDivulgacao({ cidade: dados.cidade, vagas: dados.vagas, links: dados.links })[peca.publico];
  const tx = { ...bruto, titulo: juntarNumeros(bruto.titulo), sub: juntarNumeros(bruto.sub), contagem: juntarNumeros(bruto.contagem), bullets: bruto.bullets.map(juntarNumeros) };
  const logo = await carregarLogo(cores);
  try { await Promise.all(['900 40px', '800 30px', '700 30px', '600 30px'].map((f) => document.fonts?.load(`${f} ${FONTE}`))); } catch { /* usa a fonte do sistema */ }

  const s = peca.w / 1080, W = 1080, H = peca.h / s;
  const cv = document.createElement('canvas'); cv.width = peca.w; cv.height = peca.h;
  const c = cv.getContext('2d'); c.scale(s, s);
  const medir = (f, txt) => { c.font = f; return c.measureText(txt).width; };
  const rgba = (a) => (t.sobre === '#ffffff' ? `rgba(255,255,255,${a})` : `rgba(27,27,27,${a})`);

  // fundo: cor do app, brilho no alto e círculos suaves
  c.fillStyle = cores.fundo; c.fillRect(0, 0, W, H);
  let g = c.createRadialGradient(W / 2, 0, 0, W / 2, 0, W * 1.05); g.addColorStop(0, 'rgba(255,255,255,.34)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, W, H);
  c.fillStyle = 'rgba(255,255,255,.12)'; c.beginPath(); c.arc(-80, H - 120, 420, 0, Math.PI * 2); c.fill();
  c.fillStyle = 'rgba(0,0,0,.06)'; c.beginPath(); c.arc(W + 60, H * 0.62, 360, 0, Math.PI * 2); c.fill();

  const centro = (txt, y, f, cor) => { c.font = f; c.fillStyle = cor; c.textAlign = 'center'; c.textBaseline = 'alphabetic'; c.fillText(txt, W / 2, y); };
  const linhasCentradas = (linhas, y, f, cor, alt) => { linhas.forEach((l, i) => centro(l, y + alt * i + alt * 0.78, f, cor)); return y + alt * linhas.length; };

  function selo(yTopo, k = 1) {
    const f = fonte(800, 30 * k), txt = tx.selo.toUpperCase(), w = medir(f, txt) + 64 * k, h = 64 * k;
    c.fillStyle = t.sobre; caminhoArredondado(c, (W - w) / 2, yTopo, w, h, h / 2); c.fill();
    centro(txt, yTopo + h / 2 + 10 * k, f, cores.fundo);
    return yTopo + h;
  }
  function titulo(yTopo, larg, tam, centrado = true) {
    let size = tam, linhas;
    for (; size >= 52; size -= 4) { linhas = quebrarEquilibrado((x) => medir(fonte(900, size), x), tx.titulo, larg); if (linhas.length <= 3) break; }
    const alt = size * 1.08;
    return { fim: linhasCentradas(linhas, yTopo, fonte(900, size), t.sobre, alt), size };
  }
  function barra(x, y, larg, k = 1) {
    const h = 30 * k; c.fillStyle = 'rgba(0,0,0,.2)'; caminhoArredondado(c, x, y, larg, h, h / 2); c.fill();
    c.fillStyle = '#ffffff'; caminhoArredondado(c, x, y, Math.max(h, larg * tx.pct / 100), h, h / 2); c.fill();
    return y + h;
  }
  function cartaoBullet(x, y, larg, txt, k = 1) {
    const h = 84 * k;
    c.fillStyle = '#ffffff'; caminhoArredondado(c, x, y, larg, h, 26 * k); c.fill();
    c.fillStyle = cores.fundo; c.beginPath(); c.arc(x + 20 * k + 22 * k, y + h / 2, 22 * k, 0, Math.PI * 2); c.fill();
    c.strokeStyle = t.sobre; c.lineWidth = 5 * k; c.lineCap = 'round'; c.lineJoin = 'round';
    const cx = x + 42 * k, cy = y + h / 2; c.beginPath(); c.moveTo(cx - 10 * k, cy + 1 * k); c.lineTo(cx - 3 * k, cy + 8 * k); c.lineTo(cx + 11 * k, cy - 8 * k); c.stroke();
    let size = 33 * k; while (size > 20 && medir(fonte(700, size), txt) > larg - 100 * k) size -= 1;
    c.font = fonte(700, size); c.fillStyle = '#1b1b1b'; c.textAlign = 'left'; c.textBaseline = 'alphabetic'; c.fillText(txt, x + 78 * k, y + h / 2 + size * 0.35);
    return y + h;
  }
  function cartaoQr(x, y, tam) {
    const pad = tam * 0.07, total = tam + pad * 2;
    c.fillStyle = '#ffffff'; caminhoArredondado(c, x, y, total, total, 36); c.fill();
    desenharQr(c, tx.link, x + pad, y + pad, tam);
    return { total, fim: y + total };
  }

  if (peca.layout === 'vertical') {
    // Sobe/desce o tamanho de tudo (k) até caber na altura da peça, sem deixar o QR pequeno demais.
    const alturaBase = (k) => {
      const q = 400 * k;
      return 56 * k /*topo*/ + 240 * k + 36 * k + 64 * k + 30 * k + 3 * 96 * k /*título*/ + 24 * k + 2 * 56 * k + 32 * k + (tx.bullets.length ? tx.bullets.length * 98 * k + 30 * k : 0) + 30 * k + 90 * k + 34 * k + q + 28 * k + 2 * 46 * k + 24 * k + 56 * k;
    };
    let k = 1; while (k > 0.55 && alturaBase(k) > H) k -= 0.02;
    const larg = 920 * 1, x0 = (W - larg) / 2;
    let y = 56 * k;
    const lw = 480 * k; c.drawImage(logo, (W - lw) / 2, y, lw, lw / 2); y += lw / 2 + 30 * k;
    y = selo(y, k) + 30 * k;
    const tt = titulo(y, larg, 104 * k); y = tt.fim + 22 * k;
    const fsub = fonte(600, 40 * k);
    y = linhasCentradas(quebrarEquilibrado((x) => medir(fsub, x), tx.sub, 860), y, fsub, rgba(0.88), 52 * k) + 30 * k;
    tx.bullets.forEach((b) => { y = cartaoBullet(x0, y, larg, b, k) + 14 * k; });
    if (tx.bullets.length) y += 16 * k;
    y = barra(x0, y, larg, k) + 16 * k;
    centro(tx.contagem, y + 34 * k, fonte(800, 34 * k), t.sobre); y += 34 * k + 30 * k;
    // QR ocupa o que sobrou, até 440
    const rodape = 56 * k, legenda = 2 * 46 * k + 24 * k;
    const tam = Math.max(240, Math.min(520, H - y - rodape - legenda - 60 * k));
    const q = cartaoQr((W - (tam + tam * 0.14)) / 2, y, tam); y = q.fim + 26 * k;
    const fc = fonte(800, 38 * k); y = linhasCentradas(quebrarLinhas((x) => medir(fc, x), tx.cta, 860), y, fc, t.sobre, 46 * k);
    centro(hostDe(tx.link), y + 28 * k, fonte(600, 28 * k), rgba(0.75));
  } else {
    // lateral (feed 4:5): texto à esquerda, QR à direita
    const mx = 70;
    let y = 60; const lw = 400; c.drawImage(logo, (W - lw) / 2, y, lw, lw / 2); y += lw / 2 + 22;
    y = selo(y) + 26;
    const tt = titulo(y, W - 2 * mx, 92); y = tt.fim + 18;
    const fsub = fonte(600, 36);
    y = linhasCentradas(quebrarEquilibrado((x) => medir(fsub, x), tx.sub, 900), y, fsub, rgba(0.88), 46) + 34;
    const colL = 580, xq = mx + colL + 40, tamQr = W - mx - xq - W * 0.0 - 0; // QR à direita
    const tam = Math.min(300, tamQr - 40);
    const q = cartaoQr(xq + (tamQr - (tam + tam * 0.14)) / 2, y, tam);
    let yl = y;
    tx.bullets.forEach((b) => { yl = cartaoBullet(mx, yl, colL, b, 0.84) + 12; });
    if (tx.bullets.length) yl += 14;
    else if (tx.chamada) {
      const fch = fonte(800, 36), lin = quebrarEquilibrado((x) => medir(fch, x), tx.chamada, colL - 64), ch = lin.length * 46 + 50;
      c.fillStyle = '#ffffff'; caminhoArredondado(c, mx, yl, colL, ch, 30); c.fill();
      lin.forEach((l, i) => { c.font = fch; c.fillStyle = '#1b1b1b'; c.textAlign = 'left'; c.fillText(l, mx + 32, yl + 25 + 36 + i * 46); });
      yl += ch + 28;
    }
    yl = barra(mx, yl + (tx.bullets.length || tx.chamada ? 0 : 20), colL, 0.9) + 14;
    c.font = fonte(800, 30); c.fillStyle = t.sobre; c.textAlign = 'left'; c.textBaseline = 'alphabetic';
    quebrarLinhas((x) => medir(fonte(800, 30), x), tx.contagem, colL).forEach((l, i) => c.fillText(l, mx, yl + 30 + i * 38));
    const fc = fonte(800, 28); c.textAlign = 'center';
    const xc = xq + tamQr / 2;
    quebrarLinhas((x) => medir(fc, x), tx.cta, tamQr).forEach((l, i) => { c.font = fc; c.fillStyle = t.sobre; c.fillText(l, xc, q.fim + 40 + i * 34); });
    c.font = fonte(600, 24); c.fillStyle = rgba(0.75); c.fillText(hostDe(tx.link), xc, q.fim + 40 + 3 * 34);
  }
  return cv;
}

// ---------- Carrossel "Como funciona" ----------
/** Ícones simples desenhados em traço (cx, cy = centro; r = meia largura). */
function desenharIcone(c, nome, cx, cy, r, cor) {
  c.save(); c.strokeStyle = cor; c.fillStyle = cor; c.lineWidth = r * 0.12; c.lineCap = 'round'; c.lineJoin = 'round';
  if (nome === 'loja') { // fachada com toldo
    const w = r * 1.7, h = r * 1.5, x = cx - w / 2, y = cy - h / 2 + r * 0.1;
    c.beginPath(); c.moveTo(x, y + h * 0.38); c.lineTo(x, y + h); c.lineTo(x + w, y + h); c.lineTo(x + w, y + h * 0.38); c.stroke();
    c.beginPath(); c.moveTo(x - w * 0.06, y + h * 0.38); c.lineTo(x + w * 0.1, y); c.lineTo(x + w * 0.9, y); c.lineTo(x + w * 1.06, y + h * 0.38); c.closePath(); c.stroke();
    for (let i = 1; i < 4; i++) { c.beginPath(); c.moveTo(x + (w * i) / 4 + (i - 2) * w * 0.02, y + h * 0.38); c.lineTo(x + w * (0.1 + 0.2 * i), y); c.stroke(); }
    c.strokeRect(cx - w * 0.14, y + h * 0.58, w * 0.28, h * 0.42);
  } else if (nome === 'celular') { // celular com aviso
    const w = r * 1.05, h = r * 1.9;
    caminhoArredondado(c, cx - w / 2, cy - h / 2, w, h, r * 0.2); c.stroke();
    c.beginPath(); c.moveTo(cx - w * 0.14, cy + h * 0.38); c.lineTo(cx + w * 0.14, cy + h * 0.38); c.stroke();
    caminhoArredondado(c, cx - w * 0.34, cy - h * 0.28, w * 0.68, h * 0.17, r * 0.06); c.stroke();
    caminhoArredondado(c, cx - w * 0.34, cy - h * 0.05, w * 0.68, h * 0.17, r * 0.06); c.stroke();
    c.beginPath(); c.arc(cx + w * 0.5, cy - h * 0.5, r * 0.2, 0, Math.PI * 2); c.fill();
  } else if (nome === 'moeda') { // moeda com R$
    c.beginPath(); c.arc(cx, cy, r * 0.95, 0, Math.PI * 2); c.stroke();
    c.font = fonte(900, r * 0.95); c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('R$', cx, cy + r * 0.04);
  } else if (nome === 'pino') { // pino de mapa
    const rr = r * 0.62, top = cy - r * 0.55;
    c.beginPath(); c.arc(cx, top, rr, Math.PI * 0.82, Math.PI * 0.18, false); c.lineTo(cx, cy + r * 1.1); c.closePath(); c.stroke();
    c.beginPath(); c.arc(cx, top, rr * 0.38, 0, Math.PI * 2); c.fill();
  }
  c.restore();
}

async function desenharTela(peca, dados) {
  const t = derivarTema(dados.tema?.primaria, dados.tema?.sobre);
  const cores = { fundo: t.primaria, letras: t.sobre, acento: '#ffffff' };
  const serie = textosCarrossel({ cidade: dados.cidade, vagas: dados.vagas, links: dados.links })[peca.publico].telas;
  const bruto = serie[peca.tela - 1]; if (!bruto) throw new Error('Tela desconhecida.');
  const tx = { ...bruto, titulo: juntarNumeros(bruto.titulo), sub: juntarNumeros(bruto.sub), contagem: juntarNumeros(bruto.contagem || '') };
  const logo = await carregarLogo(cores);
  try { await Promise.all(['900 40px', '800 30px', '700 30px', '600 30px'].map((f) => document.fonts?.load(`${f} ${FONTE}`))); } catch { /* usa a fonte do sistema */ }
  const W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const c = cv.getContext('2d');
  const medir = (f, txt) => { c.font = f; return c.measureText(txt).width; };
  const rgba = (a) => (t.sobre === '#ffffff' ? `rgba(255,255,255,${a})` : `rgba(27,27,27,${a})`);
  const centro = (txt, y, f, cor, x = W / 2) => { c.font = f; c.fillStyle = cor; c.textAlign = 'center'; c.textBaseline = 'alphabetic'; c.fillText(txt, x, y); };
  const linhas = (lst, y, f, cor, alt, x = W / 2) => { lst.forEach((l, i) => centro(l, y + alt * i + alt * 0.78, f, cor, x)); return y + alt * lst.length; };
  const titulo = (txt, y, larg, tam, cor, max = 3) => { let size = tam, l; for (; size >= 48; size -= 4) { l = quebrarEquilibrado((x) => medir(fonte(900, size), x), txt, larg); if (l.length <= max) break; } return { fim: linhas(l, y, fonte(900, size), cor, size * 1.08), size }; };

  // fundo
  c.fillStyle = cores.fundo; c.fillRect(0, 0, W, H);
  let g = c.createRadialGradient(W / 2, 0, 0, W / 2, 0, W * 1.05); g.addColorStop(0, 'rgba(255,255,255,.34)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, W, H);
  c.fillStyle = 'rgba(255,255,255,.12)'; c.beginPath(); c.arc(-80, H - 100, 420, 0, Math.PI * 2); c.fill();
  c.fillStyle = 'rgba(0,0,0,.06)'; c.beginPath(); c.arc(W + 60, H * 0.55, 360, 0, Math.PI * 2); c.fill();

  const selo = (txt, y) => { const f = fonte(800, 30), u = txt.toUpperCase(), w = medir(f, u) + 64, h = 64; c.fillStyle = t.sobre; caminhoArredondado(c, (W - w) / 2, y, w, h, h / 2); c.fill(); centro(u, y + h / 2 + 10, f, cores.fundo); return y + h; };
  // pontinhos de progresso + "deslize"
  const rodape = () => {
    const total = TELAS_CARROSSEL, gap = 34, x0 = W / 2 - ((total - 1) * gap) / 2, y = H - 70;
    for (let i = 0; i < total; i++) { c.fillStyle = i + 1 === peca.tela ? t.sobre : rgba(0.35); c.beginPath(); c.arc(x0 + i * gap, y, i + 1 === peca.tela ? 11 : 8, 0, Math.PI * 2); c.fill(); }
    if (peca.tela < total) { centro('Deslize  →', y + 10, fonte(800, 30), rgba(0.9), W - 150); }
  };

  const lw = peca.tela === 1 ? 560 : 360;
  if (tx.tipo === 'capa') {
    let y = 120; c.drawImage(logo, (W - lw) / 2, y, lw, lw / 2); y += lw / 2 + 50;
    y = selo(tx.selo, y) + 44;
    const tt = titulo(tx.titulo, y, 900, 118, t.sobre); y = tt.fim + 30;
    const fs = fonte(600, 44); linhas(quebrarEquilibrado((x) => medir(fs, x), tx.sub, 820), y, fs, rgba(0.9), 58);
  } else if (tx.tipo === 'passo') {
    let y = 70; c.drawImage(logo, (W - lw) / 2, y, lw, lw / 2); y += lw / 2 + 30;
    const cx0 = 90, cw = W - 180, ch = 900;
    c.fillStyle = 'rgba(0,0,0,.16)'; caminhoArredondado(c, cx0, y + 12, cw, ch, 60); c.fill();
    c.fillStyle = '#ffffff'; caminhoArredondado(c, cx0, y, cw, ch, 60); c.fill();
    // número grande no canto + bolha com o ícone
    const bx = W / 2, by = y + 215, br = 150;
    c.fillStyle = cores.fundo; c.beginPath(); c.arc(bx, by, br, 0, Math.PI * 2); c.fill();
    desenharIcone(c, tx.icone, bx, by, br * 0.62, t.sobre);
    const nr = 46, nx = bx + br * 0.78, ny = by - br * 0.78;
    c.fillStyle = '#1b1b1b'; c.beginPath(); c.arc(nx, ny, nr, 0, Math.PI * 2); c.fill();
    centro(String(tx.n), ny + 17, fonte(900, 52), '#ffffff', nx);
    centro(`PASSO ${tx.n} DE ${TELAS_CARROSSEL - 2}`, by + br + 64, fonte(800, 28), '#6b6b6b');
    const tt = titulo(tx.titulo, by + br + 100, cw - 100, 84, '#1b1b1b', 2);
    const fs = fonte(600, 42); linhas(quebrarEquilibrado((x) => medir(fs, x), tx.sub, cw - 130), tt.fim + 18, fs, '#444444', 56);
  } else { // fim: oferta + contador + QR
    let y = 70; c.drawImage(logo, (W - 340) / 2, y, 340, 170); y += 170 + 14;
    y = selo(tx.selo, y) + 30;
    const tt = titulo(tx.titulo, y, 900, 100, t.sobre, 2); y = tt.fim + 14;
    const fs = fonte(600, 38); y = linhas(quebrarEquilibrado((x) => medir(fs, x), tx.sub, 820), y, fs, rgba(0.9), 48) + 22;
    const bw = 780, bx = (W - bw) / 2, bh = 28;
    c.fillStyle = 'rgba(0,0,0,.2)'; caminhoArredondado(c, bx, y, bw, bh, bh / 2); c.fill();
    c.fillStyle = '#ffffff'; caminhoArredondado(c, bx, y, Math.max(bh, bw * tx.pct / 100), bh, bh / 2); c.fill(); y += bh + 14;
    const fc = fonte(800, 30); y = linhas(quebrarLinhas((x) => medir(fc, x), tx.contagem, 900), y, fc, t.sobre, 38) + 22;
    const tam = Math.max(220, Math.min(380, H - y - 70 - 150 - 54)), total = tam + tam * 0.14;
    c.fillStyle = '#ffffff'; caminhoArredondado(c, (W - total) / 2, y, total, total, 34); c.fill();
    desenharQr(c, tx.link, (W - total) / 2 + tam * 0.07, y + tam * 0.07, tam); y += total + 22;
    const fk = fonte(800, 34); linhas(quebrarLinhas((x) => medir(fk, x), tx.cta, 860), y, fk, t.sobre, 42);
  }
  rodape();
  return cv;
}

export const paraBlob = (cv) => new Promise((ok, erro) => cv.toBlob((b) => (b ? ok(b) : erro(new Error('Não foi possível gerar a imagem.'))), 'image/png'));
export const nomeDoArquivo = (peca, cidadeId) => `yapood-${cidadeId || 'cidade'}-${peca.id}.png`;

/** Miniatura (data URL) para a tela do Master; o arquivo para baixar é sempre desenhado de novo, com os números do momento. */
export function miniatura(cv, larg = 240) {
  const m = document.createElement('canvas'); m.width = larg; m.height = Math.round(cv.height * larg / cv.width);
  const c = m.getContext('2d'); c.imageSmoothingQuality = 'high'; c.drawImage(cv, 0, 0, m.width, m.height);
  return m.toDataURL('image/jpeg', 0.85);
}
