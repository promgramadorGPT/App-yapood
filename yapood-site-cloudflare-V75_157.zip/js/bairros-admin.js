// V75.22 — Bairros e taxas no ADM. Módulo isolado: se algo falhar aqui, pedidos e demais abas seguem normais.
// Lê/escreve só restaurantes/{lojaId}/bairros, restaurantes/{lojaId}/bairrosConfig e bairros_sugeridos/{lojaId}.
import { db, ref, get, set, update, remove } from './firebase.js';
import { confirmar } from './ui-mensagens.js';
import { configBairros, listarBairros, parseListaBairros, montarBairro, taxaValida, contarPedidosPorBairro, kmValido, textoKm } from './bairros.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const moeda = (v) => (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const decimal = (v) => String(Number(v) || 0).replace('.', ',');
const lojaId = () => window.__yapood?.lojaId || null;

const estado = { loja: {}, sug: {}, carregado: false, aba: null, sigSug: '' };
const ORIGEM_KM = { endereco: 'pelo endereço do cliente', bairro: 'pelo centro do bairro', gps: 'pela localização do aparelho' };
const kmTexto = (v) => (kmValido(v) ? String(Number(v)).replace('.', ',') : '');
const dataCurta = (t) => (t ? new Date(t).toLocaleDateString('pt-BR') : '—');

function msg(texto, erro = false) {
  const el = $('bai-msg'); if (!el) return;
  el.textContent = texto || ''; el.className = 'bai-msg' + (erro ? ' erro' : ' ok'); el.hidden = !texto;
}
const padrao = () => Math.max(0, Number(estado.loja?.precioEnvio) || 0);
const pendentes = () => Object.entries(estado.sug || {})
  .filter(([id, s]) => s && s.status === 'pendente' && !estado.loja?.bairros?.[id])
  .map(([id, s]) => ({ id, ...s }))
  .sort((a, b) => String(a.criadoEm).localeCompare(String(b.criadoEm)));
const ids = (l) => l.map((x) => x.id).sort().join('|');
const assinaturaSug = () => ids(pendentes()) + '#' + ids(ignorados());
const ignorados = () => Object.entries(estado.sug || {})
  .filter(([id, s]) => s && s.status === 'ignorado' && !estado.loja?.bairros?.[id])
  .map(([id, s]) => ({ id, ...s }));

async function carregar() {
  const id = lojaId(); if (!id) return false;
  const [l, s] = await Promise.all([get(ref(db, `restaurantes/${id}`)), get(ref(db, `bairros_sugeridos/${id}`)).catch(() => null)]);
  estado.loja = l.exists() ? l.val() : {};
  estado.sug = s && s.exists() ? s.val() : {};
  estado.carregado = true;
  return true;
}

// ---------- Render ----------
function renderConfig() {
  const cfg = configBairros(estado.loja);
  $('bai-ativo').checked = cfg.ativo;
  $('bai-nao-cad').value = cfg.naoCadastrado;
  $('bai-nao-cad-box').hidden = !cfg.ativo;
  $('bai-padrao-txt').textContent = cfg.ativo
    ? `Ligado: cada bairro tem a sua taxa. Taxa padrão da loja: ${moeda(padrao())} (Minha loja → taxa de entrega).`
    : `Desligado: vale a taxa padrão da loja (${moeda(padrao())}) para todos os bairros.`;
  const e = $('bai-cfg-estado'); if (e) { e.textContent = cfg.ativo ? 'Ligado' : 'Desligado'; e.classList.toggle('on', cfg.ativo); }
}

function renderSugestoes() {
  const cont = contarPedidosPorBairro(window.__yapood?.pedidos || [], [...pendentes(), ...ignorados()].map((x) => x.id));
  const lista = pendentes().sort((x, y) => ((cont[y.id]?.qtd || 0) - (cont[x.id]?.qtd || 0)) || String(x.criadoEm).localeCompare(String(y.criadoEm)));
  const ign = ignorados();
  estado.sigSug = assinaturaSug();
  const q = $('bai-sug-qtd'); q.textContent = String(lista.length); q.classList.toggle('alerta', lista.length > 0);
  atualizarBadge(lista.length);
  atualizarAviso(lista.length);
  $('bai-sug-vazio').hidden = lista.length > 0;
  $('bai-sug-todos').hidden = lista.length < 2;
  const meta = (s) => {
    const c = cont[s.id];
    const pedidos = c ? `<strong>${c.qtd} pedido${c.qtd === 1 ? '' : 's'}</strong> · último em ${esc(dataCurta(c.ultimo))}` : 'ainda sem pedidos no painel';
    const dist = kmValido(s.distanciaKm) ? `<strong>${esc(textoKm(s.distanciaKm))}</strong> da sua loja (em linha reta, ${esc(ORIGEM_KM[s.distanciaFonte] || 'estimado')}) · ` : '';
    return `${dist}${pedidos} · sugerido em ${esc(dataCurta(s.criadoEm))}`;
  };
  $('bai-sug-lista').innerHTML = lista.map((s) => `
    <div class="bai-item" data-sug="${esc(s.id)}">
      <div class="bai-nome">${esc(s.nome)}<span class="bai-meta">${meta(s)}</span></div>
      <div class="bai-campos">
        <label>R$ <input type="text" inputmode="decimal" data-sug-taxa value="${esc(decimal(padrao()))}" aria-label="Taxa para ${esc(s.nome)}"></label>
        <label>km <input type="text" inputmode="decimal" data-sug-km value="${esc(kmTexto(s.distanciaKm))}" placeholder="—" aria-label="Distância até ${esc(s.nome)} em km"></label>
        <button type="button" class="btn-primary" data-sug-aprovar>Aprovar</button>
        <button type="button" class="btn-secondary" data-sug-ignorar>Ignorar</button>
      </div>
    </div>`).join('');
  $('bai-ign-box').hidden = !ign.length;
  $('bai-ign-qtd').textContent = String(ign.length);
  $('bai-ign-lista').innerHTML = ign.map((s) => `
    <div class="bai-item" data-sug="${esc(s.id)}">
      <div class="bai-nome">${esc(s.nome)}<span class="bai-meta">${meta(s)}</span></div>
      <div class="bai-campos"><button type="button" class="btn-secondary" data-sug-restaurar>Voltar para a lista</button></div>
    </div>`).join('');
}

// Aviso no topo da aba Pedidos, para o lojista perceber bairros novos sem abrir esta aba.
function atualizarAviso(n) {
  const pedidos = document.getElementById('modulo-pedidos'); if (!pedidos) return;
  let el = $('bai-aviso');
  if (!n) { if (el) el.hidden = true; return; }
  if (!el) {
    el = document.createElement('div'); el.id = 'bai-aviso'; el.className = 'bai-aviso'; el.setAttribute('role', 'status');
    el.innerHTML = '<i class="fa-solid fa-location-dot" aria-hidden="true"></i><span></span><button type="button" class="btn-secondary">Revisar</button>';
    el.querySelector('button').addEventListener('click', () => document.querySelector('.nav-btn[data-tab="modulo-bairros"]')?.click());
    pedidos.prepend(el);
  }
  el.querySelector('span').textContent = n === 1 ? '1 bairro novo de cliente esperando a sua taxa.' : `${n} bairros novos de clientes esperando a sua taxa.`;
  el.hidden = false;
}

// ---------- Abas internas ----------
function mostrarAba(nome) {
  estado.aba = nome;
  document.querySelectorAll('[data-bai-aba]').forEach((b) => { const on = b.dataset.baiAba === nome; b.classList.toggle('ativa', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
  for (const n of ['novos', 'lista', 'add']) { const el = $('bai-painel-' + n); if (el) el.hidden = n !== nome; }
}
document.querySelectorAll('[data-bai-aba]').forEach((b) => b.addEventListener('click', () => mostrarAba(b.dataset.baiAba)));

const pedidosPorBairro = () => contarPedidosPorBairro(window.__yapood?.pedidos || [], Object.keys(estado.loja?.bairros || {}));

function renderLista() {
  const todos = listarBairros(estado.loja);
  $('bai-qtd').textContent = String(todos.length);
  const termo = ($('bai-busca').value || '').trim().toLowerCase();
  const vistos = termo ? todos.filter((b) => b.nome.toLowerCase().includes(termo)) : todos;
  const cont = pedidosPorBairro();
  const box = $('bai-lista');
  if (!todos.length) { box.innerHTML = '<p class="bai-vazio">Nenhum bairro cadastrado ainda. Use a aba Cadastrar ou aprove os bairros novos dos clientes.</p>'; return; }
  if (!vistos.length) { box.innerHTML = '<p class="bai-vazio">Nenhum bairro encontrado para essa busca.</p>'; return; }
  box.innerHTML = vistos.map((b) => `
    <div class="bai-item${b.ativo ? '' : ' inativo'}" data-bairro="${esc(b.id)}">
      <div class="bai-nome">${esc(b.nome)}${b.origem === 'cliente' ? '<span class="bai-etiqueta">pedido do cliente</span>' : ''}
        <span class="bai-meta">${cont[b.id] ? `${cont[b.id].qtd} pedido(s)` : 'sem pedidos ainda'}</span></div>
      <div class="bai-campos">
        <label>R$ <input type="text" inputmode="decimal" data-campo="taxa" value="${esc(decimal(b.taxa))}" aria-label="Taxa de ${esc(b.nome)}"></label>
        <label>km <input type="text" inputmode="decimal" data-campo="km" value="${esc(kmTexto(b.distanciaKm))}" placeholder="—" aria-label="Distância de ${esc(b.nome)} em km"></label>
        <label>min <input type="text" inputmode="numeric" data-campo="prazo" value="${b.prazo ?? ''}" placeholder="—" aria-label="Prazo de ${esc(b.nome)}"></label>
        <label><input type="checkbox" data-campo="ativo" ${b.ativo ? 'checked' : ''}> Atende</label>
        <button type="button" class="bai-icone" data-remover aria-label="Remover ${esc(b.nome)}"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>`).join('');
}

function renderTudo() { renderConfig(); renderSugestoes(); renderLista(); }

function atualizarBadge(n) {
  document.querySelectorAll('.nav-btn[data-tab="modulo-bairros"]').forEach((b) => {
    let el = b.querySelector('.bai-badge');
    if (!n) { el?.remove(); return; }
    if (!el) { el = document.createElement('span'); el.className = 'bai-badge'; b.appendChild(el); }
    el.textContent = String(n);
  });
}

// ---------- Ações ----------
async function guardar(fn, ok) {
  try { await fn(); if (ok) msg(ok); }
  catch (e) { console.warn('Bairros:', e); msg(e?.code === 'PERMISSION_DENIED' || /permission/i.test(String(e?.message)) ? 'Sem permissão para salvar. Entre novamente como dono da loja.' : (e.message || 'Não foi possível salvar.'), true); }
}

$('bai-config')?.addEventListener('submit', (e) => {
  e.preventDefault();
  guardar(async () => {
    const id = lojaId(); if (!id) throw new Error('Sessão expirada. Entre novamente.');
    const cfg = { ativo: $('bai-ativo').checked, naoCadastrado: $('bai-nao-cad').value === 'bloquear' ? 'bloquear' : 'padrao' };
    await update(ref(db, `restaurantes/${id}`), { bairrosConfig: cfg });
    estado.loja.bairrosConfig = cfg; renderConfig();
  }, 'Forma de cobrança salva.');
});
$('bai-ativo')?.addEventListener('change', () => { $('bai-nao-cad-box').hidden = !$('bai-ativo').checked; });

$('bai-form')?.addEventListener('submit', (e) => {
  e.preventDefault();
  const f = e.target;
  guardar(async () => {
    const id = lojaId(); if (!id) throw new Error('Sessão expirada. Entre novamente.');
    const novos = parseListaBairros(f.nomes.value);
    if (!novos.length) throw new Error('Digite ao menos um nome de bairro válido.');
    if (!taxaValida(f.taxa.value)) throw new Error('Informe a taxa de entrega (0 a R$ 1.000).');
    const existentes = estado.loja.bairros || {};
    const lote = {}; let pulados = 0;
    for (const n of novos) {
      if (existentes[n.id]) { pulados++; continue; }
      lote[n.id] = montarBairro({ nome: n.nome, taxa: f.taxa.value, prazo: f.prazo.value, origem: 'adm' });
    }
    const qtd = Object.keys(lote).length;
    if (!qtd) throw new Error('Esses bairros já estão cadastrados.');
    await update(ref(db, `restaurantes/${id}/bairros`), lote);
    estado.loja.bairros = { ...existentes, ...lote };
    f.reset(); renderTudo();
    msg(`${qtd} bairro(s) adicionado(s)${pulados ? ` · ${pulados} já existia(m)` : ''}.`);
  });
});

$('bai-sug-lista')?.addEventListener('click', (e) => {
  const linha = e.target.closest('[data-sug]'); if (!linha) return;
  const bid = linha.dataset.sug, s = estado.sug[bid]; if (!s) return;
  const id = lojaId();
  if (e.target.closest('[data-sug-aprovar]')) {
    guardar(async () => {
      const reg = montarBairro({ nome: s.nome, taxa: linha.querySelector('[data-sug-taxa]').value, origem: 'cliente', distanciaKm: linha.querySelector('[data-sug-km]')?.value });
      await set(ref(db, `restaurantes/${id}/bairros/${bid}`), reg);
      await update(ref(db, `bairros_sugeridos/${id}/${bid}`), { status: 'aprovado' });
      estado.loja.bairros = { ...(estado.loja.bairros || {}), [bid]: reg }; estado.sug[bid] = { ...s, status: 'aprovado' };
      renderTudo();
    }, `${s.nome} aprovado.`);
  } else if (e.target.closest('[data-sug-ignorar]')) {
    guardar(async () => {
      await update(ref(db, `bairros_sugeridos/${id}/${bid}`), { status: 'ignorado' });
      estado.sug[bid] = { ...s, status: 'ignorado' }; renderTudo();
    }, `${s.nome} ignorado.`);
  }
});

$('bai-ign-lista')?.addEventListener('click', (e) => {
  const linha = e.target.closest('[data-sug]'); if (!linha || !e.target.closest('[data-sug-restaurar]')) return;
  const bid = linha.dataset.sug, s = estado.sug[bid]; if (!s) return;
  guardar(async () => {
    await update(ref(db, `bairros_sugeridos/${lojaId()}/${bid}`), { status: 'pendente' });
    estado.sug[bid] = { ...s, status: 'pendente' }; renderTudo();
  }, `${s.nome} voltou para a lista.`);
});

$('bai-sug-todos')?.addEventListener('click', async () => {
  const lista = pendentes(); if (!lista.length) return;
  if (!await confirmar({ titulo: 'Aprovar bairros?', texto: `Aprovar ${lista.length} bairro(s) com a taxa padrão de ${moeda(padrao())}?`, rotulo: 'Aprovar' })) return;
  guardar(async () => {
    const id = lojaId();
    const lote = {}, status = {};
    for (const s of lista) { lote[s.id] = montarBairro({ nome: s.nome, taxa: padrao(), origem: 'cliente', distanciaKm: s.distanciaKm }); status[`${s.id}/status`] = 'aprovado'; }
    await update(ref(db, `restaurantes/${id}/bairros`), lote);
    await update(ref(db, `bairros_sugeridos/${id}`), status);
    estado.loja.bairros = { ...(estado.loja.bairros || {}), ...lote };
    for (const s of lista) estado.sug[s.id] = { ...estado.sug[s.id], status: 'aprovado' };
    renderTudo();
  }, `${lista.length} bairro(s) aprovado(s). Ajuste as taxas na lista abaixo.`);
});

$('bai-lista')?.addEventListener('change', (e) => {
  const campo = e.target.closest('[data-campo]'); const linha = e.target.closest('[data-bairro]'); if (!campo || !linha) return;
  const bid = linha.dataset.bairro, atual = estado.loja.bairros?.[bid]; if (!atual) return;
  guardar(async () => {
    const get_ = (c) => linha.querySelector(`[data-campo="${c}"]`);
    try {
      const reg = montarBairro({ nome: atual.nome, taxa: get_('taxa').value, prazo: get_('prazo').value, distanciaKm: get_('km')?.value, ativo: get_('ativo').checked, origem: atual.origem });
      await set(ref(db, `restaurantes/${lojaId()}/bairros/${bid}`), reg);
      estado.loja.bairros[bid] = reg;
      linha.classList.toggle('inativo', !reg.ativo);
      campo.classList.remove('erro'); if (campo.type === 'text') campo.classList.add('salvo');
      setTimeout(() => campo.classList.remove('salvo'), 1500);
    } catch (err) { campo.classList.add('erro'); throw err; }
  }, `${atual.nome} atualizado.`);
});

$('bai-lista')?.addEventListener('click', async (e) => {
  if (!e.target.closest('[data-remover]')) return;
  const linha = e.target.closest('[data-bairro]'); const bid = linha?.dataset.bairro, atual = estado.loja.bairros?.[bid]; if (!atual) return;
  if (!await confirmar({ titulo: 'Remover bairro?', texto: `"${atual.nome}": pedidos novos para ele passam a seguir a regra de bairro não cadastrado.`, rotulo: 'Remover', perigo: true })) return;
  guardar(async () => {
    const id = lojaId();
    await remove(ref(db, `restaurantes/${id}/bairros/${bid}`));
    await remove(ref(db, `bairros_sugeridos/${id}/${bid}`)).catch(() => {});
    delete estado.loja.bairros[bid]; delete estado.sug[bid]; renderTudo();
  }, `${atual.nome} removido.`);
});

$('bai-busca')?.addEventListener('input', renderLista);

$('bai-todos-btn')?.addEventListener('click', async () => {
  const todos = listarBairros(estado.loja); const v = $('bai-todos-taxa').value;
  if (!todos.length) return msg('Não há bairros cadastrados.', true);
  if (!taxaValida(v)) return msg('Informe uma taxa válida (0 a R$ 1.000) para aplicar a todos.', true);
  const taxa = Math.round(Number(String(v).replace(',', '.')) * 100) / 100;
  if (!await confirmar({ titulo: 'Mudar a taxa de todos?', texto: `A taxa de ${todos.length} bairro(s) passa para ${moeda(taxa)}.`, rotulo: 'Mudar taxa' })) return;
  guardar(async () => {
    const lote = {}; todos.forEach((b) => { lote[`${b.id}/taxa`] = taxa; });
    await update(ref(db, `restaurantes/${lojaId()}/bairros`), lote);
    todos.forEach((b) => { estado.loja.bairros[b.id].taxa = taxa; });
    $('bai-todos-taxa').value = ''; renderLista();
  }, `Taxa de ${moeda(taxa)} aplicada a ${todos.length} bairro(s).`);
});

// ---------- Abertura da aba / selo de sugestões ----------
async function abrir() {
  try { msg(''); await carregar(); renderTudo(); if (!estado.aba) mostrarAba(pendentes().length ? 'novos' : 'lista'); }
  catch (e) { console.warn('Bairros:', e); msg('Não foi possível carregar os bairros. Verifique a conexão.', true); }
}
document.querySelectorAll('[data-tab="modulo-bairros"],[data-tab-link="modulo-bairros"]').forEach((b) => b.addEventListener('click', abrir));

// Depois do login, carrega uma vez para mostrar o selo; depois confere a cada 60 s (com a tela visível)
// para o aviso de bairro novo aparecer sem recarregar a página. Só redesenha se a lista de sugestões mudou (não apaga taxa digitada).
async function conferir(primeira = false) {
  if (!lojaId() || (!primeira && document.visibilityState !== 'visible')) return;
  try {
    const antes = estado.sigSug;
    await carregar();
    if (primeira) renderTudo(); else if (assinaturaSug() !== antes) renderSugestoes();
    if (primeira && !estado.aba) mostrarAba(pendentes().length ? 'novos' : 'lista');
  } catch (e) { console.warn('Bairros:', e); }
}
let tentativas = 0;
const espera = setInterval(async () => {
  if (++tentativas > 40) return clearInterval(espera);
  if (!lojaId()) return;
  clearInterval(espera);
  await conferir(true);
  setInterval(() => conferir(false), 60000);
}, 750);
