// js/carrossel-util.js — avanço automático do carrossel de banners (V75.91).
// scrollIntoView rola TODAS as áreas roláveis até o elemento, inclusive a página: com o cliente já lá embaixo, vendo as lojas,
// o banner (no topo) trazia a tela de volta para cima a cada troca. Aqui só o próprio carrossel anda, na horizontal.

/** Posição (scrollLeft) em que o card fica alinhado ao início do carrossel. */
export function esquerdaDoCard(carrossel, card) {
  const c = carrossel.getBoundingClientRect(), k = card.getBoundingClientRect();
  return Math.max(0, Math.round(carrossel.scrollLeft + (k.left - c.left)));
}

/** O carrossel aparece (mesmo que em parte) na janela? Fora da tela não vale a pena animar. */
export function carrosselVisivel(carrossel, alturaJanela = window.innerHeight) {
  const r = carrossel.getBoundingClientRect();
  return r.bottom > 0 && r.top < alturaJanela;
}

/** Anda o carrossel até o card, só na horizontal. Devolve false se não andou (carrossel fora da tela). */
export function irParaCard(carrossel, card, opcoes = {}) {
  if (!carrossel || !card || (opcoes.soSeVisivel !== false && !carrosselVisivel(carrossel))) return false;
  carrossel.scrollTo({ left: esquerdaDoCard(carrossel, card), behavior: opcoes.behavior || 'smooth' });
  return true;
}
