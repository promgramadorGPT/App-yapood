// V75.35 — Meus pedidos: atalho "Relatar problema" (até 24 h após a entrega) e situação do relato em cada pedido.
import { auth } from './firebase.js';
import { escapeHtml } from './regras.js';
import { podeRelatar, rotuloRelato } from './relato.js';

const lista = document.getElementById('lista-pedidos-historico');

function complementar() {
  const cache = window.__yapoodPedidos?.cache || {};
  lista?.querySelectorAll('.card-pedido').forEach((card) => {
    const chave = card.querySelector('[data-key]')?.dataset.key;
    const num = card.querySelector('[data-num]')?.dataset.num;
    const p = chave ? cache[chave] : Object.values(cache).find((x) => x.numeroPedido === num);
    if (!p) return;
    const assin = p.relato ? `r:${p.relato.status}` : (podeRelatar(p, auth.currentUser?.uid) ? 'pode' : 'nao');
    if (card.dataset.rl === assin) return;
    card.dataset.rl = assin;
    card.querySelectorAll('.rl-tag,.rl-link-pedido').forEach((n) => n.remove());
    const acoes = card.querySelector('.acoes-card-pedido');
    if (p.relato) {
      const tag = document.createElement('div');
      tag.className = `rb-tag rl-tag rb-${p.relato.status === 'recusado' ? 'recusado' : p.relato.status === 'aberto' ? 'solicitado' : 'aprovado'}`;
      tag.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Problema relatado: ${escapeHtml(rotuloRelato(p.relato))}`;
      acoes?.before(tag);
    } else if (assin === 'pode' && acoes) {
      const a = document.createElement('a');
      a.className = 'btn-status rl-link-pedido';
      a.href = `status.html?num=${encodeURIComponent(p.numeroPedido)}&relato=1`;
      a.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Relatar problema';
      acoes.appendChild(a);
    }
  });
}
if (lista) new MutationObserver(() => { try { complementar(); } catch (e) { console.warn('Relato:', e); } }).observe(lista, { childList: true, subtree: true });
