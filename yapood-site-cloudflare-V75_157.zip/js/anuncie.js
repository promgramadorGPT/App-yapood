// V75.39 — "Anuncie no YAPOOD": regras puras (sem DOM/Firebase).
// O Master cadastra o WhatsApp comercial em config_plataforma/anuncie; o painel da loja mostra um convite discreto e um link no rodapé.

export const DIAS_SILENCIO = 7;          // depois de "Agora não", o convite só volta em 7 dias
export const ATRASO_POPUP_MS = 25000;    // só aparece depois de a loja já estar usando o painel
const DIA = 24 * 3600 * 1000;

// Número do Brasil: aceita (34) 99999-0000, +55 34 99999-0000, 5534999990000. Devolve só dígitos com 55, ou '' se inválido.
export function normalizarWhatsApp(raw) {
  let d = String(raw ?? '').replace(/\D/g, '');
  if (!d) return '';
  if (d.length === 10 || d.length === 11) d = `55${d}`;
  if (!/^55\d{10,11}$/.test(d)) return '';
  const ddd = Number(d.slice(2, 4));
  if (ddd < 11 || ddd > 99) return '';
  if (d.length === 13 && d[4] !== '9') return '';   // celular com 9 dígitos começa em 9
  return d;
}

export function formatarWhatsApp(d) {
  const n = normalizarWhatsApp(d);
  if (!n) return '';
  const l = n.slice(4);
  return `+55 (${n.slice(2, 4)}) ${l.slice(0, l.length - 4)}-${l.slice(-4)}`;
}

// Lê config_plataforma/anuncie. Sem número válido (ou desligado) o convite e o rodapé não aparecem.
export function configAnuncie(raw) {
  if (!raw || raw.ativo === false) return null;
  const comercial = normalizarWhatsApp(raw.whatsapp);
  if (!comercial) return null;
  return { comercial, suporte: normalizarWhatsApp(raw.suporte) || comercial };
}

export const urlWhatsApp = (numero, texto) => `https://wa.me/${numero}?text=${encodeURIComponent(texto)}`;

const nomeOuPadrao = (n) => String(n || '').trim().slice(0, 60) || 'minha loja';
export const mensagemAnuncie = (lojaNome) => `Olá! Sou da loja ${nomeOuPadrao(lojaNome)} e quero anunciar no YAPOOD (banners, destaques e promoções). Pode me passar as opções e valores?`;
export const mensagemSuporte = (lojaNome) => `Olá! Sou da loja ${nomeOuPadrao(lojaNome)} e preciso de ajuda com o painel do YAPOOD.`;

// O convite nunca atrapalha: só aparece se está configurado, passou o atraso, não há alerta/diálogo aberto
// e a loja não pediu para ser lembrada depois (silêncio de 7 dias).
export function deveMostrarConvite({ cfg, ultimoFechadoEm = 0, agora = Date.now(), abertoDesdeMs = Infinity, alertaVisivel = false }) {
  if (!cfg) return false;
  if (alertaVisivel) return false;
  if (abertoDesdeMs < ATRASO_POPUP_MS) return false;
  const t = Number(ultimoFechadoEm) || 0;
  if (t && agora - t < DIAS_SILENCIO * DIA) return false;
  return true;
}
