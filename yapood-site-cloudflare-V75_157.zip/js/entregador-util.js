// js/entregador-util.js — regras puras do app do entregador (sem DOM, sem Firebase). Testadas em tests/entregador-app.test.mjs.
import { arred, linkWhatsApp } from './entregadores-util.js';

export { linkWhatsApp };
const DIA = 24 * 60 * 60 * 1000;
export const FORMAS = { pix: 'PIX', dinheiro: 'Dinheiro', outro: 'Outro' };

const soma = (lista) => ({ valor: arred(lista.reduce((s, t) => s + (Number(t.valor) || 0), 0)), qtd: lista.length });

/** Ganhos do entregador: hoje, 7 dias, mês corrente, a receber da loja e já recebido (pela data em que a entrega foi confirmada). */
export function resumoGanhos(taxas, agora = new Date()) {
  const lista = taxas || [];
  const hoje0 = new Date(agora); hoje0.setHours(0, 0, 0, 0);
  const mes0 = new Date(agora.getFullYear(), agora.getMonth(), 1);
  const desde = (ini) => lista.filter((t) => (Number(t.criadoEm) || 0) >= ini);
  return {
    hoje: soma(desde(hoje0.getTime())),
    semana: soma(desde(agora.getTime() - 7 * DIA)),
    mes: soma(desde(mes0.getTime())),
    pendente: soma(lista.filter((t) => t.statusPagamento !== 'pago')),
    recebido: soma(lista.filter((t) => t.statusPagamento === 'pago'))
  };
}

/** Situação da taxa de uma entrega concluída. */
export function rotuloTaxa(taxa) {
  if (!taxa) return { texto: 'Sem taxa', classe: 'nenhuma' };
  if (taxa.statusPagamento === 'pago') return { texto: 'Paga' + (taxa.pagoEm ? ' em ' + new Date(taxa.pagoEm).toLocaleDateString('pt-BR') : ''), classe: 'paga' };
  return { texto: 'A receber', classe: 'receber' };
}

/** Mensagem pronta de WhatsApp para avisar o cliente. */
export function mensagemChegada({ loja = '', numero = '', entregador = '' } = {}) {
  const quem = entregador ? `Aqui é ${entregador}, entregador${loja ? ' da ' + loja : ''}` : `Sou o entregador${loja ? ' da ' + loja : ''}`;
  return `Olá! ${quem}. Estou a caminho com o seu pedido${numero ? ' #' + numero : ''}. Pode me ajudar com algum ponto de referência?`;
}

/** Assinatura dos dados: se não mudou, não precisa redesenhar a tela (evita apagar o código que está sendo digitado). */
export function assinatura(d) {
  const e = (d?.entregas || []).map((x) => [x.pedidoKey, x.confirmada ? 1 : 0, x.cancelado ? 1 : 0, x.tentativasRestantes, x.taxaEntregador].join(':')).join('|');
  const t = (d?.taxas || []).map((x) => [x.pedidoKey, x.statusPagamento, x.valor].join(':')).join('|');
  const a = (d?.acertos || []).map((x) => x.id).join('|');
  return `${e}#${t}#${a}`;
}

/** Entregas ativas que não existiam na leitura anterior (para avisar "Nova entrega"). */
export function novasEntregas(antes, depois) {
  const ativa = (x) => !x.confirmada && !x.cancelado;
  const ja = new Set((antes || []).map((x) => x.pedidoKey));
  return (depois || []).filter((x) => ativa(x) && !ja.has(x.pedidoKey));
}

/** V75.100 — entregas que o cliente/loja cancelou antes de o entregador concluir e que o entregador ainda não tirou da tela. */
export function canceladasParaAviso(entregas, dispensadas = []) {
  const fora = new Set(dispensadas || []);
  return (entregas || []).filter((x) => x.cancelado && !x.confirmada && !fora.has(x.pedidoKey));
}
/** Entregas que estavam ativas na leitura anterior e agora estão canceladas (para avisar na hora). */
export function acabaramCanceladas(antes, depois) {
  const ativa = new Map((antes || []).filter((x) => !x.confirmada && !x.cancelado).map((x) => [x.pedidoKey, x]));
  return (depois || []).filter((x) => x.cancelado && !x.confirmada && ativa.has(x.pedidoKey));
}

/** Frase das tentativas do código. */
export function textoTentativas(restantes) {
  if (!Number.isFinite(restantes)) return '';
  if (restantes <= 0) return 'Limite de tentativas atingido. Peça ajuda à loja.';
  return `Restam ${restantes} tentativa${restantes === 1 ? '' : 's'}.`;
}

/**
 * V75.71/105 — situação dos avisos de nova entrega neste aparelho: o texto, o tipo (cor) e o botão a mostrar.
 * `instalado` = aberto pelo ícone do app (sem barra do Chrome): o caminho para liberar é outro. Uma vez bloqueado, o site NÃO consegue
 * reabrir o pedido de permissão (regra do navegador) — por isso o texto ensina o caminho e o app ativa sozinho quando a pessoa volta.
 */
export function estadoAvisos({ suporte = true, permissao = 'default', registrado = false, erro = '', instalado = false } = {}) {
  if (!suporte) return { tipo: 'info', texto: 'Este aparelho não recebe avisos de nova entrega. Abra pelo Chrome ou instale o app.', botao: '' };
  if (registrado) return { tipo: 'ok', texto: 'Avisos de nova entrega ativados neste aparelho.', botao: '' };
  if (permissao === 'denied') {
    const caminho = instalado
      ? 'Segure o ícone do app na tela inicial → Informações do app → Notificações → Permitir.'
      : 'Toque no cadeado ao lado do endereço → Permissões → Notificações → Permitir.';
    return { tipo: 'erro', texto: `Os avisos estão bloqueados neste celular. ${caminho} Ao voltar para o app, os avisos ativam sozinhos.`, botao: 'Tentar de novo' };
  }
  if (erro) return { tipo: 'erro', texto: `Não foi possível ativar os avisos: ${erro}`, botao: 'Tentar de novo' };
  return { tipo: 'aviso', texto: 'Ative os avisos para saber de uma nova entrega mesmo com o app fechado. O celular vai perguntar: toque em “Permitir”.', botao: 'Ativar avisos' };
}
