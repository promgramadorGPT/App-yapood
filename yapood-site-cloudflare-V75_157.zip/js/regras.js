// js/regras.js
// Regras de negócio PURAS (sem DOM, sem Firebase). Testáveis com `node --test`.
import { montarEscolha, escolhaDaLinha, linhaDoCarrinho } from './produto-opcoes.js';
import { ehCombo, resumoCombo, comboParaLinha } from './combo.js';
import { aberturaSegurada } from './abertura-loja.js';

// ---------- Texto / segurança ----------
const MAPA_HTML = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export function escapeHtml(v = '') {
  return String(v ?? '').replace(/[&<>"']/g, (c) => MAPA_HTML[c]);
}

export function normalizarTexto(v = '') {
  return String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

// ---------- Status do pedido / pagamento ----------
export const STATUS = {
  PENDENTE: 'Pendiente',
  PREPARANDO: 'En preparación',
  ENTREGA: 'En camino',
  ENTREGUE: 'Entregado',
  CANCELADO: 'Cancelado'
};
export const FLUXO_STATUS = [STATUS.PENDENTE, STATUS.PREPARANDO, STATUS.ENTREGA, STATUS.ENTREGUE];

const ALIAS_STATUS = {
  pendiente: STATUS.PENDENTE, pendientes: STATUS.PENDENTE, pendente: STATUS.PENDENTE, novo: STATUS.PENDENTE, aguardando: STATUS.PENDENTE,
  'en preparación': STATUS.PREPARANDO, 'en preparacion': STATUS.PREPARANDO, preparando: STATUS.PREPARANDO, preparo: STATUS.PREPARANDO, 'em preparo': STATUS.PREPARANDO, aceito: STATUS.PREPARANDO, aceite: STATUS.PREPARANDO, aceptado: STATUS.PREPARANDO, aceptada: STATUS.PREPARANDO, accepted: STATUS.PREPARANDO,
  'a caminho': STATUS.ENTREGA, 'en camino': STATUS.ENTREGA, entrega: STATUS.ENTREGA, em_entrega: STATUS.ENTREGA, 'em entrega': STATUS.ENTREGA,
  entregado: STATUS.ENTREGUE, concluido: STATUS.ENTREGUE, 'concluído': STATUS.ENTREGUE, finalizado: STATUS.ENTREGUE, entregue: STATUS.ENTREGUE, completado: STATUS.ENTREGUE,
  cancelado: STATUS.CANCELADO, cancelada: STATUS.CANCELADO
};
export function normalizarStatus(s) {
  return ALIAS_STATUS[String(s || '').trim().toLowerCase()] || STATUS.PENDENTE;
}

// Texto exibido ao usuário. O valor salvo no Firebase continua compatível com as regras atuais.
export function rotuloStatus(s) {
  const n = normalizarStatus(s);
  return {
    [STATUS.PENDENTE]: 'Pendente',
    [STATUS.PREPARANDO]: 'Em preparo',
    [STATUS.ENTREGA]: 'Em entrega',
    [STATUS.ENTREGUE]: 'Entregue',
    [STATUS.CANCELADO]: 'Cancelado'
  }[n] || 'Pendente';
}
export function proximoStatus(s) {
  const i = FLUXO_STATUS.indexOf(normalizarStatus(s));
  return i >= 0 && i < FLUXO_STATUS.length - 1 ? FLUXO_STATUS[i + 1] : null;
}

export const PAGO = { NA_ENTREGA: 'Pagar en entrega', APROVADO: 'Aprobado', PENDENTE: 'Pendente de pago' };
export function normalizarPagamento(p) {
  const s = String(p || '').toLowerCase();
  if (s.startsWith('aprob') || s.startsWith('aprov') || s === 'approved' || s === 'pago') return PAGO.APROVADO;
  if (s.startsWith('pagar')) return PAGO.NA_ENTREGA;
  return PAGO.PENDENTE;
}

export function normalizarPago(p) { return normalizarPagamento(p); }

export function rotuloPagamento(p) {
  const n = normalizarPagamento(p);
  if (n === PAGO.APROVADO) return 'Aprovado';
  if (n === PAGO.NA_ENTREGA) return 'Pagar na entrega';
  return 'Pendente de pagamento';
}

// ---------- Dinheiro ----------
export const arredondar = (n) => Math.round((Number(n) || 0) * 100) / 100;

// ---------- Cupons ----------
// O cliente guarda APENAS o código; o desconto é sempre recalculado com os dados da loja.
// V75.37: validade (inicioEm/fimEm, datas AAAA-MM-DD, fim inclusivo) e produtos participantes (produtos: {idDoProduto: true}).
const dataLocalISO = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const ISO_DATA = /^\d{4}-\d{2}-\d{2}$/;
export const dataBR = (iso) => (ISO_DATA.test(String(iso || '')) ? String(iso).split('-').reverse().join('/') : '');
const reaisBR = (n) => `R$ ${Number(n).toFixed(2).replace('.', ',')}`;

// 'ativo' | 'agendado' (ainda não começou) | 'expirado'
export function estadoValidadeCupom(c, agora = new Date()) {
  const hoje = dataLocalISO(agora);
  const ini = ISO_DATA.test(String(c?.inicioEm || '')) ? c.inicioEm : '';
  const fim = ISO_DATA.test(String(c?.fimEm || '')) ? c.fimEm : '';
  if (ini && hoje < ini) return 'agendado';
  if (fim && hoje > fim) return 'expirado';
  return 'ativo';
}
export const produtosDoCupom = (c) => Object.entries(c?.produtos || {}).filter(([, v]) => v === true).map(([k]) => k);

// V75.38 — Limite de usos. Pedido que "gasta" um uso: tem o cupom, não foi cancelado e não é pagamento online abandonado (30 min).
const PRAZO_ABANDONO_CUPOM_MS = 30 * 60 * 1000;
export function cupomConsomeUso(p, agora = new Date()) {
  if (!p?.cupomCodigo) return false;
  if (normalizarStatus(p.status) === STATUS.CANCELADO) return false;
  if (p.pagoStatus && normalizarPagamento(p.pagoStatus) === PAGO.PENDENTE) {
    const t = Date.parse(p.criadoEm || '');
    if (Number.isFinite(t) && agora.getTime() - t > PRAZO_ABANDONO_CUPOM_MS) return false;
  }
  return true;
}
// Quantos usos o cupom já teve na loja (total) e quantos desses são deste cliente (porCliente).
export function contarUsoCupom(pedidos, codigo, lojaId, uid, agora = new Date()) {
  const cod = String(codigo || '').toUpperCase();
  let total = 0, porCliente = 0;
  for (const p of pedidos || []) {
    if (!p || p.lojaId !== lojaId || String(p.cupomCodigo || '').toUpperCase() !== cod || !cupomConsomeUso(p, agora)) continue;
    total++; if (uid && p.clienteUid === uid) porCliente++;
  }
  return { total, porCliente };
}
export const limitesDoCupom = (c) => ({
  maxUsos: Number.isInteger(c?.maxUsos) && c.maxUsos > 0 ? c.maxUsos : 0,
  maxPorCliente: Number.isInteger(c?.maxPorCliente) && c.maxPorCliente > 0 ? c.maxPorCliente : 0
});

// `uso` = { CODIGO: { total, porCliente } } (opcional). Sem ele o limite não é conferido (ex.: telas que só listam cupons).
export function resolverCupom(codigo, cupons, subtotal, precioEnvio, itens = null, agora = new Date(), uso = null) {
  const cod = String(codigo || '').trim().toUpperCase();
  if (!cod) return { cupom: null, valorDesconto: 0, erro: null };
  const lista = Array.isArray(cupons) ? cupons : Object.values(cupons || {});
  const cupom = lista.find((c) => String(c.codigo || '').toUpperCase() === cod && c.ativo !== false);
  if (!cupom) return { cupom: null, valorDesconto: 0, erro: 'Cupom inválido ou expirado.' };
  const estado = estadoValidadeCupom(cupom, agora);
  if (estado === 'agendado') return { cupom: null, valorDesconto: 0, erro: `Este cupom ainda não começou. Vale a partir de ${dataBR(cupom.inicioEm)}.` };
  if (estado === 'expirado') return { cupom: null, valorDesconto: 0, erro: `Este cupom expirou em ${dataBR(cupom.fimEm)}.` };
  const lim = limitesDoCupom(cupom), u = uso?.[String(cupom.codigo).toUpperCase()];
  if (u && lim.maxPorCliente && (Number(u.porCliente) || 0) >= lim.maxPorCliente) {
    return { cupom: null, valorDesconto: 0, erro: lim.maxPorCliente === 1 ? 'Você já usou este cupom.' : `Você já usou este cupom ${lim.maxPorCliente} vezes (o limite por cliente).` };
  }
  if (u && lim.maxUsos && (Number(u.total) || 0) >= lim.maxUsos) return { cupom: null, valorDesconto: 0, erro: 'Este cupom esgotou.' };
  // Produtos participantes: o desconto e o mínimo contam só os itens elegíveis (sem lista = vale para o pedido todo).
  const ids = produtosDoCupom(cupom);
  let base = subtotal;
  if (ids.length && Array.isArray(itens)) {
    base = arredondar(itens.filter((i) => ids.includes(i.id)).reduce((t, i) => t + (Number(i.precio) || 0) * (Number(i.qtd) || 0), 0));
    if (!(base > 0)) return { cupom: null, valorDesconto: 0, erro: 'Este cupom vale só para produtos selecionados da loja e nenhum deles está no seu carrinho.' };
  }
  if (cupom.minimo && base < Number(cupom.minimo)) {
    return { cupom: null, valorDesconto: 0, erro: ids.length && Array.isArray(itens)
      ? `Este cupom exige ao menos ${reaisBR(cupom.minimo)} em produtos participantes.`
      : `Pedido mínimo para este cupom: ${reaisBR(cupom.minimo)}.` };
  }
  let d = 0;
  if (cupom.tipo === 'porcentagem') d = (base * Math.min(Number(cupom.valor) || 0, 100)) / 100;
  else if (cupom.tipo === 'fixo') d = Math.min(Number(cupom.valor) || 0, base);
  else if (cupom.tipo === 'frete_gratis') d = precioEnvio;
  d = arredondar(Math.max(0, Math.min(d, subtotal + precioEnvio)));
  return { cupom, valorDesconto: d, erro: null };
}

// Fonte ÚNICA de verdade para totais (carrinho, checkout, cartão e pedido usam isto).
export function calcularTotais(itens, precioEnvio, cupons, codigoCupom, agora = new Date(), uso = null) {
  const subtotal = arredondar((itens || []).reduce((s, i) => s + (Number(i.precio) || 0) * (Number(i.qtd) || 0), 0));
  const envio = arredondar(precioEnvio);
  const { cupom, valorDesconto, erro } = resolverCupom(codigoCupom, cupons, subtotal, envio, itens || [], agora, uso);
  const total = arredondar(Math.max(0, subtotal + envio - valorDesconto));
  return { subtotal, envio, desconto: valorDesconto, total, cupom, erroCupom: erro };
}

// Reconcilia o carrinho (localStorage, editável pelo usuário) com o cardápio atual da loja.
// V75.127: o preço unitário de cada linha é refeito com as opções e os adicionais do cardápio atual (produto-opcoes.js).
// Opção ou adicional que sumiu, ou escolha obrigatória que passou a existir: a linha sai com aviso (o cliente escolhe de novo).
// O estoque conta todas as linhas do mesmo produto juntas.
export function reconciliarItensComMenu(itens, menu) {
  const avisos = [];
  const validos = [];
  const usadoDoEstoque = {};
  for (const it of itens || []) {
    const atual = menu?.[it?.id];
    const qtd = Math.min(99, Math.max(0, parseInt(it?.qtd, 10) || 0));
    if (!atual || atual.disponible === false) { avisos.push(`"${it?.nombre || 'Um produto'}" não está mais disponível e foi removido.`); continue; }
    if (qtd === 0) continue;
    const r = montarEscolha(atual, escolhaDaLinha(it));
    if (!r.ok) { avisos.push(`As opções de "${atual.nombre}" mudaram. Escolha de novo.`); continue; }
    // V75.128: combo só vale com todos os produtos dele disponíveis agora
    const combo = ehCombo(atual) ? resumoCombo(atual, menu) : null;
    if (combo && !combo.disponivel) { avisos.push(`O combo "${atual.nombre}" está indisponível agora${combo.falta.length ? ` (sem ${combo.falta.join(', ')})` : ''} e foi removido.`); continue; }
    // Controle de estoque opcional (V75.14): só vale quando o produto tem controlaEstoque === true.
    let qtdFinal = qtd;
    if (atual.controlaEstoque === true) {
      const disp = Math.max(0, Math.floor(Number(atual.estoque) || 0)) - (usadoDoEstoque[it.id] || 0);
      if (disp <= 0) { avisos.push(`"${atual.nombre}" está esgotado e foi removido.`); continue; }
      if (qtd > disp) { qtdFinal = disp; avisos.push(`Só há ${Math.max(0, Math.floor(Number(atual.estoque) || 0))} unidade(s) de "${atual.nombre}" em estoque.`); }
      usadoDoEstoque[it.id] = (usadoDoEstoque[it.id] || 0) + qtdFinal;
    }
    if (r.precio !== Number(it.precio)) avisos.push(`O preço de "${atual.nombre}" mudou para R$ ${r.precio.toFixed(2).replace('.', ',')}.`);
    const linha = linhaDoCarrinho(it.id, { nombre: atual.nombre }, r, qtdFinal, it.obs);
    validos.push(combo ? { ...linha, combo: comboParaLinha(atual, menu) } : linha);
  }
  return { itens: validos, avisos };
}

// V75.129 — tempo de entrega sempre com a unidade: "20-50" → "20-50 min"; "40" → "40 min"; texto do lojista com unidade fica como está.
export function textoTempo(v, padrao = '30-45 min') {
  const t = String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, 30);
  if (!t) return padrao;
  return /^\d+( ?(-|–|a|até) ?\d+)?$/i.test(t) ? `${t} min` : t;
}

// ---------- Código público do pedido ----------
// 6 caracteres sem ambíguos (sem 0/O/1/I). ~1 bilhão de combinações: não é enumerável como os 4 dígitos antigos.
const ALFABETO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function gerarCodigoPedido(rand = (n) => {
  const buf = new Uint32Array(n); (globalThis.crypto || {}).getRandomValues?.(buf);
  return Array.from(buf, (v) => v || Math.floor(Math.random() * 2 ** 32));
}) {
  return rand(6).map((v) => ALFABETO[v % ALFABETO.length]).join('');
}


// ---------- Selo Super ----------
// O selo é calculado a partir dos dados atuais da loja e dos pedidos.
// Não existe campo manual `super`: qualquer alteração nos critérios reflete automaticamente no público.
export const CRITERIOS_SUPER = Object.freeze({
  diasMinimos: 30,
  pedidosEntreguesMinimos: 30,
  avaliacoesMinimas: 10,
  notaMinima: 4.8,
  cancelamentoMaximo: 0.05
});

export function avaliarSuper(loja, pedidos = [], agora = new Date()) {
  if (!loja || loja.activo === false) return { elegivel: false, motivo: 'loja_inativa' };

  const criado = new Date(loja.criadoEm || 0);
  if (Number.isNaN(criado.getTime())) return { elegivel: false, motivo: 'data_criacao_invalida' };
  const idadeDias = Math.floor((agora.getTime() - criado.getTime()) / 86400000);

  const entregues = (pedidos || []).filter((p) => normalizarStatus(p?.status) === STATUS.ENTREGUE).length;
  const cancelados = (pedidos || []).filter((p) => normalizarStatus(p?.status) === STATUS.CANCELADO).length;
  const baseCancelamento = entregues + cancelados;
  const taxaCancelamento = baseCancelamento ? cancelados / baseCancelamento : 0;
  const totalAvaliacoes = Number(loja.totalAvaliacoes) || 0;
  const notaMedia = Number(loja.avaliacaoMedia) || 0;

  const criterios = {
    lojaAtiva: loja.activo !== false,
    diasMinimos: idadeDias >= CRITERIOS_SUPER.diasMinimos,
    pedidosEntreguesMinimos: entregues >= CRITERIOS_SUPER.pedidosEntreguesMinimos,
    avaliacoesMinimas: totalAvaliacoes >= CRITERIOS_SUPER.avaliacoesMinimas,
    notaMinima: notaMedia >= CRITERIOS_SUPER.notaMinima,
    cancelamentoMaximo: taxaCancelamento <= CRITERIOS_SUPER.cancelamentoMaximo
  };

  return {
    elegivel: Object.values(criterios).every(Boolean),
    criterios,
    idadeDias,
    pedidosEntregues: entregues,
    pedidosCancelados: cancelados,
    taxaCancelamento,
    totalAvaliacoes,
    notaMedia
  };
}

// ---------- Horário de funcionamento ----------
const DIAS = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado'];
const minutos = (hhmm) => { const m = /^(\d{1,2}):(\d{2})/.exec(String(hhmm || '')); return m ? Number(m[1]) * 60 + Number(m[2]) : null; };

export function lojaAberta(loja, agora = new Date()) {
  if (!loja || loja.activo === false) return { aberta: false, motivo: 'Fechado temporariamente' };
  // V75.138: a loja disse "Não estou pronto" no aviso de abertura: fechada até o novo horário (ou o resto do dia)
  const segurada = aberturaSegurada(loja.abertura, agora.getTime());
  if (segurada) return { aberta: false, motivo: segurada.motivo };
  const horarios = loja.horarios;
  if (!horarios || typeof horarios !== 'object') return { aberta: true };
  const t = agora.getHours() * 60 + agora.getMinutes();
  const hoje = horarios[DIAS[agora.getDay()]];
  const ontem = horarios[DIAS[(agora.getDay() + 6) % 7]];

  // Turno de ontem que atravessa a meia-noite (ex.: 18:00 -> 02:00)
  if (ontem && ontem.aberto !== false) {
    const a = minutos(ontem.abre), f = minutos(ontem.fecha);
    if (a !== null && f !== null && f <= a && t < f) return { aberta: true };
  }
  if (!hoje) return { aberta: true }; // dia não configurado: não bloqueia
  if (hoje.aberto === false) return { aberta: false, motivo: 'Fechado hoje' };
  const a = minutos(hoje.abre), f = minutos(hoje.fecha);
  if (a === null || f === null) return { aberta: true };
  const dentro = f > a ? (t >= a && t < f) : (t >= a || t < f);
  if (dentro) return { aberta: true };
  return { aberta: false, motivo: t < a ? `Abre às ${hoje.abre}` : 'Fechado hoje' };
}

// ---------- Avaliações ----------
// Soma incremental usada na transação do agregado `lojas/{id}`.
export function somarAvaliacao(atual, { notaComida, notaEntrega }) {
  const c = atual || {};
  const total = Number(c.totalAvaliacoes) || 0;
  const base = (campoMedia, campoSoma) => Number(c[campoSoma]) || (Number(c[campoMedia]) || 0) * total;
  const somaComida = base('avaliacaoComida', 'somaComida') + notaComida;
  const somaEntrega = base('avaliacaoEntrega', 'somaEntrega') + notaEntrega;
  const somaGeral = base('avaliacaoMedia', 'somaGeral') + (notaComida + notaEntrega) / 2;
  const n = total + 1;
  const r1 = (x) => Math.round(x * 10) / 10;
  return { ...c, totalAvaliacoes: n, somaComida, somaEntrega, somaGeral,
    avaliacaoComida: r1(somaComida / n), avaliacaoEntrega: r1(somaEntrega / n), avaliacaoMedia: r1(somaGeral / n) };
}
