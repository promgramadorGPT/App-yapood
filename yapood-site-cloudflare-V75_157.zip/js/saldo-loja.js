// js/saldo-loja.js — V75.145: saldo do cliente na loja. Funções puras (sem DOM, sem Firebase); a API (2.29) é quem grava o saldo.
//   • A loja liga "Oferecer saldo no reembolso" e escolhe o bônus (0–20%) → restaurantes/{id}/saldoReembolso = { ativo, bonusPct }.
//   • Com reembolso aprovado, o CLIENTE escolhe: dinheiro de volta ou saldo na loja com o bônus. O saldo não vence e só vale nessa loja.
//   • No carrinho, o saldo é usado sozinho (dá para desmarcar); o Pix/cartão/entregador cobra só o resto.
// Banco: saldos/{uid}/{lojaId} = { valor, lojaNome, atualizadoEm } · saldos_mov/{lojaId}/{id} · pedidos/{k}/saldo = { usado, aPagar, em, devolvido }

export const BONUS_OPCOES = Object.freeze([0, 5, 10, 15, 20]);
export const BONUS_MAX = 20;
export const arred = (n) => Math.round((Number(n) || 0) * 100) / 100;
const moedaPadrao = (v) => 'R$ ' + arred(v).toFixed(2).replace('.', ',');

/** Configuração da loja → { ativo, bonusPct } (igual à da API). */
export function configSaldoLoja(loja) {
  const c = loja && loja.saldoReembolso;
  const b = Math.round(Number(c?.bonusPct) || 0);
  return { ativo: c?.ativo === true, bonusPct: Math.min(BONUS_MAX, Math.max(0, b)) };
}
/** O que o ADM grava (só valores permitidos). */
export function montarConfigSaldo({ ativo, bonusPct }) {
  const b = Math.round(Number(bonusPct) || 0);
  return { ativo: ativo === true, bonusPct: BONUS_OPCOES.includes(b) ? b : 0 };
}

/** Saldo guardado (saldos/{uid}/{lojaId}) → número. */
export const valorSaldo = (reg) => Math.max(0, arred(reg?.valor));

/** Prévia no carrinho: { usado, aPagar, cobreTudo }. */
export function previsaoUso(total, saldo, usar = true) {
  const t = arred(total), s = usar ? valorSaldo({ valor: saldo }) : 0;
  const usado = Math.min(s, t);
  return { usado: arred(usado), aPagar: arred(Math.max(0, t - usado)), cobreTudo: usado > 0 && t - usado <= 0.009 };
}

/** Quanto do pedido é cobrado em dinheiro (Pix, cartão ou na entrega). */
export function valorACobrar(p) {
  const total = arred(p?.total), usado = arred(p?.saldo?.usado);
  return usado > 0 ? Math.max(0, arred(total - usado)) : total;
}
export const saldoUsado = (p) => arred(p?.saldo?.usado);
const saldoADevolver = (p) => Math.max(0, arred(arred(p?.saldo?.usado) - arred(p?.saldo?.devolvido)));

/** Linhas para totais, comprovante e cartão do pedido: [] sem saldo; senão "Saldo da loja" e "A pagar"/"Pago com saldo". */
export function linhasSaldo(p, moeda = moedaPadrao) {
  const u = saldoUsado(p);
  if (!(u > 0)) return [];
  const resto = valorACobrar(p);
  return [{ rotulo: 'Saldo da loja', valor: `-${moeda(u)}` }, resto > 0 ? { rotulo: 'A pagar', valor: moeda(resto), forte: true } : { rotulo: 'Pago com saldo', valor: moeda(0), forte: true }];
}

/**
 * O cliente pode escolher receber o reembolso em saldo? (espelho da API) →
 *   { mostrar:false } | { mostrar:true, valor, base, bonusPct, bonus, deSaldo, credito, mp }
 *   valor = reembolso aprovado; credito = o que vira saldo (com bônus); mp = quanto volta em dinheiro na outra opção.
 */
export function opcaoReembolsoEmSaldo(p, loja, uid) {
  const nao = { mostrar: false };
  if (!p || !uid || p.clienteUid !== uid) return nao;
  const cfg = configSaldoLoja(loja);
  const r = p.reembolso;
  if (!cfg.ativo || !r || r.status !== 'aprovado' || r.escolha || r.devolvidoDiretoEm) return nao;
  const ex = r.execucao?.status;
  if (ex === 'processando' || ex === 'concluido') return nao;
  const valor = Math.min(arred(r.valor), arred(p.total));
  if (!(valor > 0)) return nao;
  const base = Math.min(valor, valorACobrar(p));
  const deSaldo = Math.min(arred(valor - base), saldoADevolver(p));
  if (!(base > 0)) return nao; // pago só com saldo: volta como saldo, sem escolha
  const bonus = arred(base * cfg.bonusPct / 100);
  return { mostrar: true, direta: r.devolucaoDireta === true, valor, base: arred(base), bonusPct: cfg.bonusPct, bonus, deSaldo: arred(deSaldo), credito: arred(base + bonus + deSaldo), mp: arred(base) };
}

/** Prazo para o cliente escolher (a loja só devolve pelo Mercado Pago depois disso). Igual ao da API 2.29. */
export const PRAZO_ESCOLHA_MS = 48 * 3600000;
const inicioEscolha = (r) => Date.parse(r?.respondidoEm || r?.solicitadoEm || '') || 0;
export const fimEscolha = (p) => { const t0 = inicioEscolha(p?.reembolso); return t0 ? t0 + PRAZO_ESCOLHA_MS : 0; };
/** A loja ainda espera o cliente escolher? (loja com saldo ligado, reembolso pelo Mercado Pago, parte paga em dinheiro, dentro do prazo) */
export function aguardandoEscolha(p, loja, agora = Date.now()) {
  const r = p?.reembolso;
  if (!configSaldoLoja(loja).ativo || !r || r.status !== 'aprovado' || r.escolha || r.devolucaoDireta) return false;
  const ex = r.execucao?.status;
  if (ex === 'processando' || ex === 'concluido') return false;
  if (!(valorACobrar(p) > 0)) return false;
  const t0 = inicioEscolha(r);
  return !t0 || agora - t0 < PRAZO_ESCOLHA_MS;
}

/** Texto para o cliente depois da escolha (ou vazio). */
export function textoEscolhaSaldo(r, moeda = moedaPadrao) {
  const e = r?.escolha;
  if (!e || e.tipo !== 'saldo') return '';
  return `Você escolheu receber em saldo na loja: ${moeda(e.valor)}${e.bonus > 0 ? ` (com ${moeda(e.bonus)} de bônus)` : ''}. Use no próximo pedido; o saldo não vence.`;
}

/** Na loja: a devolução deste reembolso vai pelo saldo (pedido pago só com saldo) → botão "Devolver em saldo". */
export const devolveSoEmSaldo = (p) => p?.pagoComSaldo === true && !p?.paymentIdMP;

/** Lista de saldos do cliente (Perfil): [{ lojaId, lojaNome, valor, atualizadoEm }] com valor > 0, maior primeiro. */
export function listaSaldos(obj) {
  return Object.entries(obj && typeof obj === 'object' ? obj : {})
    .map(([lojaId, v]) => ({ lojaId, lojaNome: String(v?.lojaNome || 'Loja').slice(0, 80), valor: valorSaldo(v), atualizadoEm: Number(v?.atualizadoEm) || 0 }))
    .filter((x) => x.valor > 0).sort((a, b) => b.valor - a.valor || b.atualizadoEm - a.atualizadoEm);
}

/**
 * Resumo para as Finanças da loja (saldos_mov/{lojaId}): { emitido, bonus, usado, devolvido, emAberto, clientes, movimentos }.
 * emitido = créditos de reembolso (com bônus); devolvido = saldo que voltou (cancelamento/estorno); emAberto = emitido + devolvido − usado.
 * `desde` (ms) limita emitido/usado/devolvido ao período; emAberto é sempre o total.
 */
export function resumoSaldos(movs, desde = 0) {
  const r = { emitido: 0, bonus: 0, usado: 0, devolvido: 0, emAberto: 0, clientes: 0, movimentos: 0 };
  const porCliente = new Map();
  for (const m of Object.values(movs && typeof movs === 'object' ? movs : {})) {
    if (!m || !['credito', 'uso', 'devolucao'].includes(m.tipo)) continue;
    const v = arred(m.valor), sinal = m.tipo === 'uso' ? -1 : 1;
    r.emAberto += sinal * v;
    porCliente.set(m.clienteUid, arred((porCliente.get(m.clienteUid) || 0) + sinal * v));
    if ((Number(m.em) || 0) < desde) continue;
    r.movimentos++;
    if (m.tipo === 'credito') { r.emitido += v; r.bonus += arred(m.bonus); } else if (m.tipo === 'uso') r.usado += v; else r.devolvido += v;
  }
  for (const k of ['emitido', 'bonus', 'usado', 'devolvido']) r[k] = arred(r[k]);
  r.emAberto = Math.max(0, arred(r.emAberto));
  r.clientes = [...porCliente.values()].filter((v) => v > 0.009).length;
  return r;
}
