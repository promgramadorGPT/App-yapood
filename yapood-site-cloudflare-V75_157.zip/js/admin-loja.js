import { db, auth, googleProvider, onAuthStateChanged, signInWithPopup, signOut, ref, get, set, update, push, remove, onValue, query, orderByChild, equalTo, runTransaction } from './firebase.js';
import { STATUS, FLUXO_STATUS, PAGO, normalizarStatus, normalizarPagamento, normalizarTexto, estadoValidadeCupom, produtosDoCupom, limitesDoCupom, contarUsoCupom, dataBR, rotuloStatus, rotuloPagamento as rotuloPagamentoStatus, proximoStatus } from './regras.js';
import { formatarMoeda, normalizarMoeda, definirMoedaAtual, MOEDAS_SUPORTADAS, toast, confirmar } from './utils.js';
import { NOTPUSH_API } from './notificaciones-config.js';
import { abrirCadastro, fecharCadastro } from './cadastro-lojista-ui.js?v=75.116';
import { categoriasDoMenu, filtrarProdutos, selecaoValida, alternarVarios, resumoSelecao, produtosParaCupom } from './cupom-produtos.js';
import { devolverPeloMercadoPago, devolucaoPossivel, textoDevolucao } from './reembolso-api.js?v=75.145';
import { resumoComissao } from './comissao.js';
import { textoTroco, trocoSeguro } from './troco.js';
import { montarComanda } from './comanda.js?v=75.145';
import { configSaldoLoja, montarConfigSaldo, linhasSaldo, saldoUsado, valorACobrar, devolveSoEmSaldo, aguardandoEscolha, resumoSaldos, arred as arredSaldo } from './saldo-loja.js?v=75.145';
import { devolverSaldoDoPedido } from './saldo-api.js?v=75.145';
import { detalhesDaLinha } from './combo.js?v=75.128';
import { montarEditorExtras, lerEditorExtras } from './admin-produto-extras.js?v=75.127';
import { montarEditorCombo, lerEditorCombo } from './admin-combo.js?v=75.128';
import { cicloAtual, noCiclo, rotuloCiclo } from './ciclo-comissao.js';
import { iniciarAcertoLoja, atualizarAcertoPedidos } from './acerto-loja.js';
import { resumoDinheiro, resumoPublicidade, registrosDePublicidade, ROTULO_PUB } from './financeiro.js';
import { configFidelidade, TIPOS_PREMIO, tituloPremio, conferePremioPedido } from './fidelidade.js';
import { RELATO, lojaDeveResponder, rotuloRelato, montarRespostaRelato, montarReembolsoDoRelato } from './relato.js';
import { planejarSeletorCidade, rotuloCidade } from './cidades.js';
import { iniciarParceira } from './loja-parceira.js?v=75.115';
import { REEMBOLSO, montarReembolsoLoja, montarReembolsoLojaManual, deveCancelarNoReembolso, historicoCliente, lojaPodeReembolsar, rotuloReembolso, pagoNaEntrega, devolucaoDiretaPendente } from './reembolso.js?v=75.145';

const MP_API='https://api-mp-yapoodbr.onrender.com';
const DAYS = [['segunda','Segunda-feira'],['terca','Terça-feira'],['quarta','Quarta-feira'],['quinta','Quinta-feira'],['sexta','Sexta-feira'],['sabado','Sábado'],['domingo','Domingo']];
let lojaId=null, lojaDados=null, itemEditandoId=null, usuarioAtual=null, pedidosDaLoja=[];
let categoriasLoja=[];
let contextoAudio=null, audioLiberado=false, sonsPendentes=0, sonsAutomaticosPendentes=0, somLoopTimer=null, somLoopAtivo=false, somTresSegTimer=null, pedidosEmAlerta=new Set(), pedidosEstadosConhecidos=new Map();
const CHAVE_SOM_ATIVADO='10app_som_pedidos_ativado';
const SOM_LOOP_INTERVALO=3200;
const $=id=>document.getElementById(id);
const cancelamentosLocais=new Set(); // pedidos cancelados por esta loja (não tocar o aviso de cancelamento do cliente)
const cancelamentosEmAlerta=new Map(); // V75.34: pedidos cancelados por OUTRA pessoa e ainda não vistos (alarme em loop até "Parar alarme")
let somCancelTimer=null;
const SOM_CANCEL_INTERVALO=2400;
async function notificarClientePedido(pedidoKey, status) {
  const evento = status === STATUS.PREPARANDO ? 'aceptado' : (status === STATUS.ENTREGA ? 'despachado' : null);
  if (!evento || !auth.currentUser) return;
  try {
    const idToken = await auth.currentUser.getIdToken(true);
    const r = await fetch(`${NOTPUSH_API}/notificar-pedido`, {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${idToken}`},
      body:JSON.stringify({pedidoKey, evento})
    });
    const data = await r.json().catch(()=>({}));
    if (!r.ok || !data.ok) console.warn('[NotPush] cliente:', data.error || `HTTP ${r.status}`);
    else console.log('[NotPush] cliente notificado:', data);
  } catch(e) { console.warn('[NotPush] não foi possível notificar o cliente:', e); }
}


/** Avisa por push os clientes que já pediram na loja (o NotPush confere dono, cupom, 1/dia e teto do Master). */
async function avisarClientesCupom(cupomId){
  if(!auth.currentUser||!lojaId||!cupomId) return {ok:false,mensagem:'Entre novamente para avisar os clientes.'};
  try{
    const idToken=await auth.currentUser.getIdToken(true);
    const r=await fetch(`${NOTPUSH_API}/notificar-cupom`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${idToken}`},body:JSON.stringify({lojaId,cupomId})});
    const data=await r.json().catch(()=>({}));
    if(!r.ok||!data.ok) return {ok:false,mensagem:data.error||`Não foi possível avisar os clientes (HTTP ${r.status}).`};
    return {ok:true,enviados:Number(data.enviados)||0,mensagem:data.mensagem||''};
  }catch(e){console.warn('[NotPush] cupom:',e);return {ok:false,mensagem:'Não foi possível falar com o serviço de notificações agora. Tente de novo em instantes.'}}
}
function mostrarResultadoAviso(r){toast(r.mensagem||(r.ok?'Aviso enviado.':'Não foi possível avisar os clientes.'),r.ok&&r.enviados>0?'success':(r.ok?'info':'error'))}

const painel=$('painel-loja'), loading=$('store-loading'), errorBox=$('store-error');

let moedaLoja = 'BRL';
function moeda(v){return formatarMoeda(v, moedaLoja)}
function escapeHtml(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]))}
function showOnly(id){['auth-gate','cadastro-gate','create-store-gate','admin-app'].forEach(x=>$(x).hidden=x!==id)}
function mostrarErro(t,d=''){errorBox.hidden=false;errorBox.innerHTML=`<strong>${escapeHtml(t)}</strong><span>${escapeHtml(d)}</span>`;loading.hidden=true;painel.hidden=true}
function limparErro(){errorBox.hidden=true;errorBox.innerHTML=''}
function obterLojaIdDoPerfil(p){return p?.lojaId||p?.lojaID||p?.restauranteId||p?.restauranteID||p?.storeId||null}

// Antes: baixava TODAS as lojas (incluindo mp_token alheios) para achar a do usuário. Agora: perfil -> consulta indexada por ownerUid.
async function descobrirLoja(user){
  const perfil=(await get(ref(db,`usuarios/${user.uid}`))).val()||{};
  const idPerfil=obterLojaIdDoPerfil(perfil);
  if(idPerfil){const s=await get(ref(db,`restaurantes/${idPerfil}`));if(s.exists()&&s.val().ownerUid===user.uid)return idPerfil}
  const q=await get(query(ref(db,'restaurantes'),orderByChild('ownerUid'),equalTo(user.uid)));
  return q.exists()?Object.keys(q.val())[0]:null;
}

function prepararUsuário(user){
  usuarioAtual=user;
  $('sidebar-user-name').textContent=user.displayName||'Usuário';
  $('sidebar-user-email').textContent=user.email||'';
  if(user.photoURL){$('sidebar-user-email').title=user.email||''}
}


function normalizarCategoriaNome(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();}
async function carregarCategoriasLoja(){
  try{
    const snap=await get(ref(db,'categorias_loja'));
    categoriasLoja=Object.entries(snap.val()||{}).map(([id,c])=>({id,...(c||{})})).filter(c=>c.nombre&&c.activa!==false).sort((a,b)=>(Number(a.orden)||0)-(Number(b.orden)||0));
    const select=$('loja-categoria-principal'); if(!select)return;
    const atual=lojaDados?.categoriaId||lojaDados?.categoria||'';
    select.innerHTML='<option value="">Selecione...</option>'+categoriasLoja.map(c=>`<option value="${escapeHtml(c.id)}">${escapeHtml(c.nombre)}</option>`).join('');
    const porId=categoriasLoja.find(c=>c.id===atual);
    const porNome=categoriasLoja.find(c=>normalizarCategoriaNome(c.nombre)===normalizarCategoriaNome(atual));
    if(porId)select.value=porId.id; else if(porNome)select.value=porNome.id;
  }catch(err){console.warn('Não foi possível carregar as categorias globais:',err);}
}
// V75.72 — cidades cadastradas pelo Master (cidades/{id}, leitura pública). Sem cidades, o campo continua texto livre.
let cidadesCfg={};
async function carregarCidades(){
  try{cidadesCfg=(await get(ref(db,'cidades'))).val()||{}}catch(err){cidadesCfg={};console.warn('Cidades não carregadas:',err.message)}
}
function desenharSeletorCidade(d){
  const sel=$('loja-cidade-id'),txt=$('loja-cidade'),dica=$('loja-cidade-dica');
  if(!sel||!txt)return;
  const plano=planejarSeletorCidade({cidades:cidadesCfg,lojaCidadeId:d?.cidadeId||'',textoAntigo:d?.cidade||d?.ciudad||''});
  if(plano.modo==='texto'){sel.hidden=true;sel.innerHTML='';txt.hidden=false;dica.hidden=true;return}
  sel.innerHTML='<option value="">Escolha a cidade…</option>'+plano.opcoes.map(o=>`<option value="${escapeHtml(o.id)}">${escapeHtml(o.rotulo)}</option>`).join('');
  sel.value=plano.selecionada;sel.disabled=plano.travada;sel.hidden=false;
  txt.hidden=true;dica.textContent=plano.dica;dica.hidden=false;
}
async function desenharSeletorCriacao(){
  await carregarCidades();
  const wrap=$('nova-loja-cidade-wrap'),sel=$('nova-loja-cidade');
  const plano=planejarSeletorCidade({cidades:cidadesCfg});
  wrap.hidden=plano.modo!=='seletor';
  sel.required=plano.modo==='seletor';
  sel.innerHTML='<option value="">Escolha a cidade…</option>'+plano.opcoes.map(o=>`<option value="${escapeHtml(o.id)}">${escapeHtml(o.rotulo)}</option>`).join('');
  // V75.83: link/QR da divulgação (admin-loja.html?cidade=uberlandia-mg) já deixa a cidade marcada
  try{const pedida=(new URLSearchParams(location.search).get('cidade')||'').toLowerCase();if(pedida&&plano.opcoes.some(o=>o.id===pedida))sel.value=pedida}catch{/* sem URLSearchParams: segue sem marcar */}
}
async function criarLoja(user,nome,cidadeId=''){
  const nomeLimpo=String(nome||'').trim();
  if(!nomeLimpo)throw new Error('Digite o nome da loja.');
  if(cidadesCfg&&Object.keys(cidadesCfg).length&&!cidadesCfg[cidadeId])throw new Error('Escolha a cidade da loja.');
  const existente=await descobrirLoja(user);
  if(existente)return existente;
  const novaRef=push(ref(db,'restaurantes'));
  const id=novaRef.key;
  const dados={nombre:nomeLimpo,ownerUid:user.uid,ownerEmail:user.email||'',activo:true,destaque:false,precioEnvio:0,tiempoEntrega:'',radioMaximoKm:5,aceitaRetirada:true,logo:'',categoria:'',categoriaId:'',direccion:'',telefono:'',menu:{},cupones:{},criadoEm:new Date().toISOString(),criadoPor:user.uid};
  if(cidadeId&&cidadesCfg[cidadeId]){dados.cidadeId=cidadeId;dados.cidade=rotuloCidade(cidadesCfg[cidadeId])}
  await set(novaRef,dados);
  const perfilRef=ref(db,`usuarios/${user.uid}`);
  const perfilSnap=await get(perfilRef);
  const perfilAtual=perfilSnap.exists()?perfilSnap.val():{};
  await update(perfilRef,{...perfilAtual,nome:perfilAtual.nome||user.displayName||nomeLimpo,email:perfilAtual.email||user.email||'',foto:perfilAtual.foto||user.photoURL||'',lojaId:id,atualizadoEm:new Date().toISOString()});
  return id;
}

let publicidadeLoja=[],unsubPublicidade=null;
let agregadoLoja=null,unsubPedidos=null,pedidosLojaId=null,pedidosConhecidos=null,liberadosConhecidos=null;
async function carregarLoja(id){
  limparErro();
  const snap=await get(ref(db,`restaurantes/${id}`));
  if(!snap.exists())throw new Error('Não encontramos a loja vinculada à sua conta.');
  lojaId=id;lojaDados=snap.val()||{};
  try{const ag=await get(ref(db,`lojas/${id}`));agregadoLoja=ag.exists()?ag.val():null}catch{agregadoLoja=null}
  await carregarSegredos(id);
  await carregarCidades();
  await preencherTela(lojaDados);
  await carregarAvaliacoesLoja();
  if(pedidosLojaId!==id)iniciarPedidos(); // listener em tempo real, iniciado uma única vez por loja
  iniciarSaldosLoja(id); // V75.145
  loading.hidden=true;painel.hidden=false;
}

// SEGURANÇA: o Access Token do Mercado Pago NUNCA pode ficar em /restaurantes (nó de leitura pública: qualquer visitante o baixava).
// Fica em /restaurantes_privado/{lojaId}. Tokens legados são migrados automaticamente na primeira abertura pelo dono.
async function carregarSegredos(id){
  // Legado: se existir mp_token no nó público, move para o privado (e recomenda trocar o token).
  try{
    if(lojaDados.mp_token){
      const priv=(await get(ref(db,`restaurantes_privado/${id}`))).val()||{};
      if(!priv.mp_token)await update(ref(db,`restaurantes_privado/${id}`),{mp_token:lojaDados.mp_token});
      await remove(ref(db,`restaurantes/${id}/mp_token`));delete lojaDados.mp_token;
      alert('Por segurança, movemos seu Access Token do Mercado Pago para uma área privada. Recomendamos conectar sua conta pelo botão "Conectar Mercado Pago" e revogar o token antigo.');
    }
  }catch(err){console.warn('Não foi possível migrar o token legado:',err)}
  atualizarStatusMP();
}

// ---------- Conexão com o Mercado Pago (OAuth) ----------
async function chamarMP(rota){
  const idToken=await auth.currentUser?.getIdToken(true);
  if(!idToken)throw new Error('Sessão expirada. Entre novamente.');
  const r=await fetch(`${MP_API}${rota}`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${idToken}`},body:JSON.stringify({lojaId})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok||d.error)throw new Error(d.error||'Falha na comunicação com o servidor de pagamentos.');
  return d;
}
function mostrarStatusMP({titulo,texto,icone,conectar,desconectar,cor}){
  $('mp-conexao-titulo').textContent=titulo;$('mp-conexao-texto').textContent=texto;
  const i=$('mp-conexao-icone');i.className=`fa-solid ${icone}`;i.style.color=cor||'';
  $('btn-mp-conectar').hidden=!conectar;$('btn-mp-conectar').textContent='';
  $('btn-mp-conectar').innerHTML=`<i class="fa-solid fa-link"></i> ${conectar===true?'Conectar Mercado Pago':conectar||''}`;
  $('btn-mp-desconectar').hidden=!desconectar;
}
async function atualizarStatusMP(){
  if(!$('mp-conexao'))return;
  mostrarStatusMP({titulo:'Verificando conexão…',texto:'Aguarde um instante.',icone:'fa-spinner fa-spin'});
  try{
    const d=await chamarMP('/oauth/mp/status');
    if(d.conectado&&d.via==='oauth'){
      const exp=d.expiraEm?` · renovação automática (vence em ${new Date(d.expiraEm).toLocaleDateString('pt-BR')} se não for usada)`:'';
      mostrarStatusMP({titulo:'Mercado Pago conectado',texto:`Conta nº ${d.mpUserId||'—'}${exp}.`,icone:'fa-circle-check',cor:'#278b55',desconectar:true});
    }else if(d.conectado){
      mostrarStatusMP({titulo:'Conectado com token manual (antigo)',texto:'Funciona, mas recomendamos reconectar pelo botão abaixo para renovação automática e mais segurança.',icone:'fa-triangle-exclamation',cor:'#a16b00',conectar:'Reconectar com Mercado Pago',desconectar:true});
    }else{
      mostrarStatusMP({titulo:'Mercado Pago não conectado',texto:'Conecte sua conta para receber pagamentos por PIX e cartão direto na sua conta.',icone:'fa-plug',cor:'#a33b42',conectar:d.oauthDisponivel!==false});
      if(d.oauthDisponivel===false)$('mp-conexao-texto').textContent='A conexão ainda não foi habilitada no servidor. Fale com o suporte da plataforma.';
    }
  }catch(err){
    console.warn('Status MP:',err);
    mostrarStatusMP({titulo:'Não foi possível verificar a conexão',texto:err.message||'Tente novamente em instantes.',icone:'fa-circle-exclamation',cor:'#a33b42',conectar:true});
  }
}
$('btn-mp-conectar')?.addEventListener('click',async e=>{
  const btn=e.currentTarget;btn.disabled=true;
  try{const d=await chamarMP('/oauth/mp/iniciar');if(!d.url)throw new Error('Resposta inválida do servidor.');location.href=d.url}
  catch(err){toast(err.message||'Não foi possível iniciar a conexão.','error',6000);btn.disabled=false}
});
$('btn-mp-desconectar')?.addEventListener('click',async e=>{
  if(!await confirmar({titulo:'Desconectar o Mercado Pago?',texto:'Sua loja deixará de receber pagamentos online até conectar novamente.',rotulo:'Desconectar',perigo:true}))return;
  const btn=e.currentTarget;btn.disabled=true;
  try{await chamarMP('/oauth/mp/desconectar');toast('Mercado Pago desconectado.','success');if(lojaDados)delete lojaDados.mp_public_key}
  catch(err){toast(err.message||'Não foi possível desconectar.','error',6000)}
  btn.disabled=false;atualizarStatusMP();
});
// Retorno do Mercado Pago: ?mp=ok | ?mp=erro&motivo=...
(function(){
  const q=new URLSearchParams(location.search);if(!q.has('mp'))return;
  const ok=q.get('mp')==='ok',motivo=q.get('motivo');
  const msgs={negado:'Você não autorizou a conexão.',expirado:'O pedido de conexão expirou. Tente novamente.',dono:'Apenas o dono da loja pode conectar.',parametros:'Resposta inválida do Mercado Pago.',falha:'O Mercado Pago recusou a conexão. Tente novamente.'};
  history.replaceState(null,'',location.pathname);
  setTimeout(()=>{
    try{navegarAba('modulo-configuracao')}catch(e){}
    const txt=ok?'Mercado Pago conectado com sucesso! 🎉':`${msgs[motivo]||'Não foi possível conectar o Mercado Pago.'}${motivo?` (código: ${motivo})`:''}`;
    if(ok)toast(txt,'success',8000);else alert(txt);
  },800);
})();

async function preencherTela(d){
  const nome=d.nombre||d.nome||'Minha loja';
  const ativa=d.activo!==false;
  $('store-name-display').textContent=nome;
  $('overview-title').textContent=nome;
  $('sidebar-store-name').textContent=nome;
  $('store-status-text').textContent=ativa?'Gerencie sua operação em um só lugar.':'A loja está fechada temporariamente.';
  $('sidebar-store-status').textContent=ativa?'Aceitando pedidos':'Datada temporariamente';
  const logo=d.logo||d.logoUrl||d.imagenLogo||d.imagemLogo||'';
  const headerLogo=$('header-store-logo');
  const headerPlaceholder=$('header-store-logo-placeholder');
  if(logo){headerLogo.src=logo;headerLogo.hidden=false;if(headerPlaceholder)headerPlaceholder.hidden=true}else{headerLogo.hidden=true;headerLogo.removeAttribute('src');if(headerPlaceholder)headerPlaceholder.hidden=false}
  const sidebarLogo=$('sidebar-store-logo');
  const sidebarPlaceholder=$('sidebar-store-logo-placeholder');
  if(sidebarLogo){if(logo){sidebarLogo.src=logo;sidebarLogo.hidden=false;if(sidebarPlaceholder)sidebarPlaceholder.hidden=true}else{sidebarLogo.hidden=true;sidebarLogo.removeAttribute('src');if(sidebarPlaceholder)sidebarPlaceholder.hidden=false}}
  $('store-id-badge').textContent=`ID ${lojaId}`;
  const pill=$('header-store-pill');pill.innerHTML=`<i class="fa-solid fa-circle"></i> ${ativa?'Aceitando pedidos':'Loja fechada'}`;pill.classList.toggle('closed',!ativa);
  $('loja-nome').value=d.nombre||d.nome||'';
  await carregarCategoriasLoja();
  if(!categoriasLoja.length) $('loja-categoria-principal').value=d.categoria||'';
  $('loja-telefone').value=d.telefono||d.telefone||'';
  $('loja-endereco').value=d.direccion||d.endereco||'';
  $('loja-cidade').value=d.cidade||d.ciudad||d.uf||'';
  desenharSeletorCidade(d);
  $('loja-envio').value=d.precioEnvio??d.taxaEntrega??0;
  $('loja-tempo').value=d.tiempoEntrega||d.tempoEntrega||'';
  $('loja-raio').value=d.radioMaximoKm??5; $('loja-retirada').checked=d.aceitaRetirada!==false; atualizarEstadoRetirada();
  $('loja-logo').value=d.logo||'';
  $('loja-capa').value=d.capa||''; atualizarPreviaCapa(); // V75.142
  moedaLoja='BRL';
  $('loja-status-ativo').checked=!!ativa; atualizarStatusSwitch();
  $('aceitacao-automatica').checked=d.aceitacaoAutomatica===true;
  if($('aceita-cartao-online'))$('aceita-cartao-online').checked=d.aceitaCartaoOnline!==false;
  pintarConfigSaldo(d); // V75.145
  const preview=$('img-preview-loja');const placeholder=document.querySelector('.logo-placeholder');
  if(d.logo){preview.src=d.logo;preview.hidden=false;if(placeholder)placeholder.hidden=true}else{preview.hidden=true;preview.removeAttribute('src');if(placeholder)placeholder.hidden=false}
  renderizarHorarios(d.horarios||{});
  renderizarModelosHorario(d.horariosModelos); // V75.149
  renderizarCardapio(d.menu||{});
  renderizarProdutosCupom(d.menu||{});
  renderizarCupons(d.cupones||{},d.menu||{});
  usoCuponsPublicado='';try{sincronizarUsoCupons()}catch(_){}
  renderizarFidelidade(d.fidelidade);
  atualizarVisaoGeral();
}
function normalizarHora(v, fallback='11:00'){
  if(v===undefined||v===null||v==='') return fallback;
  let s=String(v).trim().toLowerCase();
  s=s.replace(/\s+/g,'').replace(/h/g,':').replace(/[^0-9:]/g,'');
  if(/^\d{1,2}$/.test(s)) s=s.padStart(2,'0')+':00';
  if(/^\d{1,2}:\d{1,2}$/.test(s)){const [hh,mm]=s.split(':');s=hh.padStart(2,'0')+':'+mm.padStart(2,'0')}
  if(/^\d{2}:\d{2}:\d{2}$/.test(s)) s=s.slice(0,5);
  const m=s.match(/^(\d{2}):(\d{2})$/);
  if(!m) return fallback;
  const hh=Number(m[1]),mm=Number(m[2]);
  if(hh>23||mm>59) return fallback;
  return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
}
function extrairFaixaHorario(x){
  if(typeof x!=='string') return null;
  const m=x.match(/(\d{1,2}(?::|h)\d{2}|\d{1,2})\s*(?:-|–|—|a|às|até)\s*(\d{1,2}(?::|h)\d{2}|\d{1,2})/i);
  return m?{abre:normalizarHora(m[1],'11:00'),fecha:normalizarHora(m[2],'22:00')}:null;
}
function obterHorarioDia(horarios,k){
  const aliases={
    segunda:['segunda','segunda-feira','segundaFeira','lunes','lunes-feira','monday'],
    terca:['terca','terça','terça-feira','terca-feira','tercaFeira','martes','tuesday'],
    quarta:['quarta','quarta-feira','quartaFeira','miercoles','miércoles','wednesday'],
    quinta:['quinta','quinta-feira','quintaFeira','jueves','thursday'],
    sexta:['sexta','sexta-feira','sextaFeira','viernes','friday'],
    sabado:['sabado','sábado','sabado-feira','sábado-feira','sabadoFeira','sábadoFeira','sábado','saturday'],
    domingo:['domingo','sunday']
  };
  for(const key of aliases[k]||[k]) if(horarios && horarios[key]!==undefined) return horarios[key];
  return {};
}
function normalizarHorario(h,k){
  const raw=obterHorarioDia(h,k);
  const x=raw && typeof raw==='object' ? raw : {};
  const faixa=typeof raw==='string'?extrairFaixaHorario(raw):null;
  const abre=normalizarHora(
    x.abre??x.abertura??x.horaAbertura??x.hora_abertura??x.open??x.inicio??x.start??x.desde??faixa?.abre,
    '11:00'
  );
  const horaFim=normalizarHora(
    x.fecha??x.fechamento??x.horaDatamento??x.hora_fechamento??x.close??x.fim??x.end??x.hasta??faixa?.fecha,
    '22:00'
  );
  const aberto=x.aberto??x.aberta??x.opened??x.ativo??x.activo??true;
  return {aberto:aberto!==false && aberto!=='false' && aberto!=='0',abre,fecha:horaFim};
}
// V75.149: horário livre (qualquer minuto) em vez de lista de 30 em 30 min.
function campoHora(classe,rotulo,valor,ativo){
  return `<input type="time" class="${classe}" step="60" value="${valor||''}" aria-label="${rotulo}" ${ativo?'':'disabled'}>`;
}
function horariosPadrao(){const o={};DAYS.forEach(([k])=>o[k]={aberto:true,abre:'11:00',fecha:'22:00'});return o}
function renderizarHorarios(horarios){
  const dados=horarios&&typeof horarios==='object'?horarios:{};
  const container=$('horarios-loja');
  container.innerHTML=DAYS.map(([k,n])=>{
    const h=normalizarHorario(dados,k);
    return `<div class="hour-row ${h.aberto?'':'is-closed'}" data-day="${k}">
      <strong>${n}</strong>
      <label class="switch day-switch" title="${h.aberto?'Fechar':'Abrir'} ${n}"><input type="checkbox" class="dia-aberto" ${h.aberto?'checked':''} aria-label="${n} aberto"><span></span></label>
      <div class="hour-control"><span>Abre</span>${campoHora('hora-abre','Abertura de '+n,h.abre,h.aberto)}</div>
      <div class="hour-control"><span>Fecha</span>${campoHora('hora-fechamento','Fechamento de '+n,h.fecha,h.aberto)}</div>
    </div>`;
  }).join('');
  container.querySelectorAll('.dia-aberto').forEach(c=>c.addEventListener('change',()=>{
    const r=c.closest('.hour-row');
    r.classList.toggle('is-closed',!c.checked);
    r.querySelectorAll('.hora-abre,.hora-fechamento').forEach(i=>i.disabled=!c.checked);
  }));
}
// ---- V75.149: horários prontos (café, almoço, janta) + aplicar a vários dias ----
const MODELOS_HORARIO=[
  {id:'cafe',nome:'Café',icone:'fa-mug-hot',abre:'06:00',fecha:'10:00'},
  {id:'almoco',nome:'Almoço',icone:'fa-utensils',abre:'11:00',fecha:'15:00'},
  {id:'janta',nome:'Janta',icone:'fa-moon',abre:'18:00',fecha:'23:00'}
];
function renderizarModelosHorario(salvos){
  const box=$('horarios-modelos'); if(!box) return;
  const dados=salvos&&typeof salvos==='object'?salvos:{};
  box.innerHTML=MODELOS_HORARIO.map(m=>{
    const abre=normalizarHora(dados[m.id]?.abre,m.abre),fecha=normalizarHora(dados[m.id]?.fecha,m.fecha);
    return `<div class="hb-modelo" data-modelo="${m.id}">
      <span class="hb-modelo-nome"><i class="fa-solid ${m.icone}"></i> ${m.nome}</span>
      <input type="time" class="hb-m-abre" step="60" value="${abre}" aria-label="${m.nome}: abre">
      <span class="hb-ate">às</span>
      <input type="time" class="hb-m-fecha" step="60" value="${fecha}" aria-label="${m.nome}: fecha">
      <button type="button" class="btn-secondary hb-usar" data-usar="${m.id}">Usar</button>
    </div>`;
  }).join('');
}
function coletarModelosHorario(){
  const o={};
  document.querySelectorAll('#horarios-modelos .hb-modelo').forEach(r=>{
    const m=MODELOS_HORARIO.find(x=>x.id===r.dataset.modelo); if(!m) return;
    o[m.id]={abre:normalizarHora(r.querySelector('.hb-m-abre')?.value,m.abre),fecha:normalizarHora(r.querySelector('.hb-m-fecha')?.value,m.fecha)};
  });
  return o;
}
function diasMarcadosHorario(){
  return [...document.querySelectorAll('#hb-dias .hb-dia.ativo')].map(b=>b.dataset.dia);
}
function marcarDiasHorario(lista){
  document.querySelectorAll('#hb-dias .hb-dia').forEach(b=>{
    const on=lista.includes(b.dataset.dia);
    b.classList.toggle('ativo',on); b.setAttribute('aria-pressed',on?'true':'false');
  });
}
function aplicarHorarioEmLote(){
  const abre=$('hb-abre')?.value,fecha=$('hb-fecha')?.value,dias=diasMarcadosHorario();
  if(!abre||!fecha){toast('Informe o horário de abrir e de fechar.','error');return}
  if(abre===fecha){toast('Abrir e fechar não podem ser no mesmo horário.','error');return}
  if(!dias.length){toast('Marque pelo menos um dia.','error');return}
  dias.forEach(k=>{
    const r=document.querySelector(`#horarios-loja .hour-row[data-day="${k}"]`); if(!r) return;
    const sw=r.querySelector('.dia-aberto'); sw.checked=true;
    r.classList.remove('is-closed');
    const a=r.querySelector('.hora-abre'),f=r.querySelector('.hora-fechamento');
    a.disabled=false; f.disabled=false; a.value=abre; f.value=fecha;
    r.classList.add('hb-flash'); setTimeout(()=>r.classList.remove('hb-flash'),1200);
  });
  toast(`Horário ${abre} às ${fecha} aplicado em ${dias.length} ${dias.length===1?'dia':'dias'}. Toque em Salvar dados da loja para guardar.`,'success');
}
$('horarios-bulk')?.addEventListener('click',e=>{
  const dia=e.target.closest('.hb-dia');
  if(dia){const on=!dia.classList.contains('ativo');dia.classList.toggle('ativo',on);dia.setAttribute('aria-pressed',on?'true':'false');return}
  const at=e.target.closest('[data-hb-atalho]');
  if(at){marcarDiasHorario(at.dataset.hbAtalho==='semana'?['segunda','terca','quarta','quinta','sexta']:at.dataset.hbAtalho==='fds'?['sabado','domingo']:DAYS.map(([k])=>k));return}
  const usar=e.target.closest('[data-usar]');
  if(usar){
    const r=usar.closest('.hb-modelo');
    const a=r.querySelector('.hb-m-abre').value,f=r.querySelector('.hb-m-fecha').value;
    if(a)$('hb-abre').value=a; if(f)$('hb-fecha').value=f;
    return
  }
  if(e.target.closest('#hb-aplicar')) aplicarHorarioEmLote();
});

function coletarHorarios(){
  const h={};
  document.querySelectorAll('.hour-row').forEach(r=>{
    const abre=r.querySelector('.hora-abre')?.value;
    const fechamento=r.querySelector('.hora-fechamento')?.value;
    h[r.dataset.day]={
      aberto:r.querySelector('.dia-aberto')?.checked===true,
      abre:normalizarHora(abre,'11:00'),
      fecha:normalizarHora(fechamento,'22:00')
    };
  });
  return h;
}

async function uploadImagem(inputId,hiddenId,statusId,previewId){
  const input=$(inputId),file=input?.files?.[0];if(!file)return;
  const status=$(statusId);status.textContent='Enviando imagem...';
  try{const fn=typeof window.uploadImagemCloudinaryPub==='function'?window.uploadImagemCloudinaryPub:window.uploadImagemCloudinary;if(typeof fn!=='function')throw new Error('O upload do Cloudinary não está disponível.');const result=await fn(file);if(!result?.url)throw new Error('O Cloudinary não retornou uma URL.');$(hiddenId).value=result.url;if(previewId){$(previewId).src=result.url;$(previewId).hidden=false;const p=previewId==='img-preview-loja'?document.querySelector('.logo-placeholder'):document.querySelector('.item-placeholder');if(p)p.hidden=true}status.textContent='Imagem enviada com sucesso.'}catch(err){console.error(err);status.textContent='Não foi possível enviar a imagem.';alert(err.message||'Erro ao enviar a imagem.')}}
$('loja-logo-file').addEventListener('change',async()=>{await uploadImagem('loja-logo-file','loja-logo','status-upload-loja','img-preview-loja');atualizarPreviaCapa()});
$('item-imagem-file').addEventListener('change',()=>uploadImagem('item-imagem-file','item-imagem','status-upload-item','img-preview-item'));
// V75.142 — foto de capa (cartão da home e topo da página da loja). A prévia imita o cartão: capa com a logo por cima.
function atualizarPreviaCapa(){
  const capa=$('loja-capa').value.trim(),logo=$('loja-logo').value.trim();
  const foto=$('img-preview-capa'),vazia=$('capa-vazia'),lg=$('capa-previa-logo'),rem=$('btn-remover-capa');
  if(capa){foto.src=capa;foto.hidden=false;vazia.hidden=true}else{foto.hidden=true;foto.removeAttribute('src');vazia.hidden=false}
  if(capa&&logo){lg.src=logo;lg.hidden=false}else{lg.hidden=true;lg.removeAttribute('src')}
  rem.hidden=!capa;
}
$('loja-capa-file').addEventListener('change',async()=>{await uploadImagem('loja-capa-file','loja-capa','status-upload-capa',null);$('loja-capa-file').value='';atualizarPreviaCapa()});
$('btn-remover-capa').addEventListener('click',()=>{$('loja-capa').value='';atualizarPreviaCapa();$('status-upload-capa').textContent='Capa removida. Toque em "Salvar dados da loja" para confirmar.'});

async function geocodificarEndereco(endereco, cidade='') {
  const base = String(endereco || '').trim();
  const localidade = String(cidade || '').trim();
  if (!base) return null;

  // O endereço sem cidade é frequentemente ambíguo (ex.: "João Naves de Ávila, 6720").
  // Tentamos primeiro a combinação completa e depois variações mais tolerantes.
  const consultas = [
    [base + (localidade ? `, ${localidade}` : '') + ', Brasil', 'nominatim'],
    [base + ', Brasil', 'nominatim'],
    [base + (localidade ? `, ${localidade}` : ''), 'photon']
  ];

  const numero = (base.match(/(?:^|\s|,)(\d{1,6})(?:\s|,|$)/) || [])[1] || '';
  const rua = base.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');

  const pontuar = (item) => {
    const texto = String(item?.display_name || item?.properties?.name || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    let score = 0;
    if (numero && texto.includes(numero)) score += 8;
    const partes = rua.split(/[\s,]+/).filter(x => x.length >= 4).slice(0, 5);
    for (const parte of partes) if (texto.includes(parte)) score += 2;
    return score;
  };

  for (const [q, provider] of consultas) {
    try {
      let resultados = [];
      if (provider === 'nominatim') {
        const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=5&countrycodes=br&accept-language=pt-BR&q=${encodeURIComponent(q)}`;
        const r = await fetch(url, { headers: { Accept: 'application/json' } });
        if (!r.ok) continue;
        resultados = await r.json();
        resultados = (Array.isArray(resultados) ? resultados : []).map(x => ({...x, _score: pontuar(x)}));
        resultados.sort((a,b) => b._score - a._score);
        const item = resultados[0];
        const lat = Number(item?.lat), lng = Number(item?.lon);
        if (Number.isFinite(lat) && Number.isFinite(lng)) return { lat, lng, fonte: 'OpenStreetMap' };
      } else {
        const url = `https://photon.komoot.io/api/?limit=5&lang=pt&q=${encodeURIComponent(q)}`;
        const r = await fetch(url, { headers: { Accept: 'application/json' } });
        if (!r.ok) continue;
        const data = await r.json();
        resultados = (data?.features || []).map(f => ({
          lat: f?.geometry?.coordinates?.[1], lon: f?.geometry?.coordinates?.[0],
          display_name: [f?.properties?.name, f?.properties?.street, f?.properties?.city, f?.properties?.state].filter(Boolean).join(', '),
          properties: f?.properties || {}
        })).map(x => ({...x, _score: pontuar(x)}));
        resultados.sort((a,b) => b._score - a._score);
        const item = resultados[0];
        const lat = Number(item?.lat), lng = Number(item?.lon);
        if (Number.isFinite(lat) && Number.isFinite(lng)) return { lat, lng, fonte: 'Photon' };
      }
    } catch (err) {
      console.warn(`Falha na geocodificação (${provider}):`, err);
    }
  }
  return null;
}

function dCategoriaLegada(v){
  const atual=lojaDados?.categoria||'';
  const encontrada=categoriasLoja.find(c=>c.id===v);
  return encontrada?.nombre||atual;
}


function atualizarEstadoRetirada(){
  const input=$('loja-retirada');
  const estado=$('loja-retirada-estado');
  if(!input) return;
  if(estado){ estado.textContent=input.checked?'Ativada':'Desactivada'; estado.classList.toggle('off',!input.checked); }
}

$('loja-retirada')?.addEventListener('change',async()=>{
  atualizarEstadoRetirada();
  if(!lojaId) return;
  const input=$('loja-retirada');
  input.disabled=true;
  try{
    await update(ref(db,`restaurantes/${lojaId}`),{aceitaRetirada:input.checked});
    toast(input.checked?'Retirada na loja activada.':'Retirada na loja desactivada.','success');
  }catch(err){
    console.error(err);
    input.checked=!input.checked;
    atualizarEstadoRetirada();
    toast('Não foi possível salvar a configuração de retirada.','error');
  }finally{ input.disabled=false; }
});

// V75.145 — reembolso em saldo (salvo ao mudar): restaurantes/{id}/saldoReembolso = { ativo, bonusPct }
function pintarConfigSaldo(d){
  const c=configSaldoLoja(d),at=$('saldo-reembolso-ativo'),bn=$('saldo-reembolso-bonus');if(!at||!bn)return;
  at.checked=c.ativo;bn.value=String(c.bonusPct);exemploSaldo();
}
function exemploSaldo(){
  const at=$('saldo-reembolso-ativo'),bn=$('saldo-reembolso-bonus'),ex=$('saldo-reembolso-exemplo');if(!at||!bn||!ex)return;
  bn.disabled=!at.checked;bn.closest('.saldo-bonus-campo')?.classList.toggle('off',!at.checked);
  const b=Number(bn.value)||0;
  ex.textContent=!at.checked?'Desligado: o reembolso volta como dinheiro, como sempre.':b>0?`Ex.: um reembolso de R$ 50,00 vira R$ ${(50*(1+b/100)).toFixed(2).replace('.',',')} de saldo. O bônus é um desconto da sua loja.`:'Ex.: um reembolso de R$ 50,00 vira R$ 50,00 de saldo.';
}
async function salvarConfigSaldo(){
  if(!lojaId)return;
  const at=$('saldo-reembolso-ativo'),bn=$('saldo-reembolso-bonus'),st=$('saldo-reembolso-status');
  const cfg=montarConfigSaldo({ativo:at.checked,bonusPct:Number(bn.value)});
  exemploSaldo();at.disabled=true;bn.disabled=true;if(st)st.textContent='Salvando…';
  try{await set(ref(db,`restaurantes/${lojaId}/saldoReembolso`),cfg);if(lojaDados)lojaDados.saldoReembolso=cfg;if(st)st.textContent='Salvo';setTimeout(()=>{if(st&&st.textContent==='Salvo')st.textContent=''},3000)}
  catch(err){console.error(err);if(st)st.textContent='';pintarConfigSaldo(lojaDados||{});toast(erroBanco(err,'Não foi possível salvar o reembolso em saldo.'),'error',8000)}
  finally{at.disabled=false;bn.disabled=!at.checked}
}
$('saldo-reembolso-ativo')?.addEventListener('change',salvarConfigSaldo);
$('saldo-reembolso-bonus')?.addEventListener('change',salvarConfigSaldo);

$('form-dados-loja').addEventListener('submit',async e=>{
  e.preventDefault();
  if(!lojaId)return;
  const endereco=$('loja-endereco').value.trim();
  let cidade=$('loja-cidade').value.trim(),cidadeId='';
  if(!$('loja-cidade-id').hidden){
    cidadeId=$('loja-cidade-id').value;
    if(!cidadeId||!cidadesCfg[cidadeId]){alert('Escolha a cidade da loja.');return}
    cidade=rotuloCidade(cidadesCfg[cidadeId]);
  }
  const dados={
    nombre:$('loja-nome').value.trim(),
    categoriaId:$('loja-categoria-principal').value,
    categoria:(categoriasLoja.find(c=>c.id===$('loja-categoria-principal').value)?.nombre || dCategoriaLegada($('loja-categoria-principal').value)),
    telefono:$('loja-telefone').value.trim(),
    direccion:endereco,
    cidade,
    ...(cidadeId?{cidadeId}:{}),
    precioEnvio:parseFloat($('loja-envio').value)||0,
    tiempoEntrega:$('loja-tempo').value.trim(),
    radioMaximoKm:parseFloat($('loja-raio').value)||0,
    aceitaRetirada:$('loja-retirada').checked,
    logo:$('loja-logo').value.trim(),
    capa:$('loja-capa').value.trim()||null, // V75.142: null apaga a capa
    horarios:coletarHorarios(),
    horariosModelos:coletarModelosHorario() // V75.149
  };
  const btn=e.submitter;
  if(btn){btn.disabled=true;btn.dataset.oldHtml=btn.innerHTML;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Buscando endereço...';}
  try{
    const coordenadas=await geocodificarEndereco(endereco,cidade);
    if(!coordenadas){
      // Não deixa coordenadas antigas apontando para outro endereço.
      dados.lat=null;
      dados.lng=null;
      throw new Error('Não foi possível localizar este endereço. Informe rua, número e cidade/estado.');
    }
    dados.lat=coordenadas.lat;
    dados.lng=coordenadas.lng;
    await update(ref(db,`restaurantes/${lojaId}`),dados);
    await carregarLoja(lojaId);
    alert(`Dados salvos. Coordenadas gravadas: ${coordenadas.lat.toFixed(6)}, ${coordenadas.lng.toFixed(6)}.`);
  }catch(err){
    console.error(err);
    alert(err.message||'Não foi possível salvar os dados da loja.');
  }finally{
    if(btn){btn.disabled=false;btn.innerHTML=btn.dataset.oldHtml||'<i class="fa-solid fa-floppy-disk"></i> Salvar dados da loja';}
  }
});

function resetFormItem(){
  $('form-add-item').reset();$('item-imagem').value='';$('item-estoque').value=0;$('item-controla-estoque').checked=false;$('item-disponivel').checked=true;$('status-upload-item').textContent='JPG, PNG ou WEBP.';itemEditandoId=null;$('produto-modal-titulo').textContent='Adicionar produto';
  $('item-info').value='';$('item-sugerir').checked=false;montarEditorExtras($('item-extras'));montarEditorCombo($('item-combo'),{menu:lojaDados?.menu||{},precoInput:$('item-preco')});
  const p=$('img-preview-item'),ph=document.querySelector('.item-placeholder');p.hidden=true;p.removeAttribute('src');if(ph)ph.hidden=false;
}
function abrirFormItem(item=null,key=null,opts={}){
  resetFormItem();itemEditandoId=key;
  if(!item&&opts.combo){$('produto-modal-titulo').textContent='Novo combo';$('item-categoria').value='Combos';montarEditorCombo($('item-combo'),{menu:lojaDados?.menu||{},precoInput:$('item-preco'),ligado:true});}
  if(item){$('produto-modal-titulo').textContent='Editar produto';$('item-nome').value=item.nombre||'';$('item-categoria').value=item.categoria||'';$('item-preco').value=item.precio??0;$('item-estoque').value=item.estoque??item.stock??item.quantidadeEstoque??item.cantidadEstoque??0;$('item-descricao').value=item.descripcion||'';$('item-imagem').value=item.imagen||item.imagem||'';$('item-disponivel').checked=item.disponible!==false;$('item-controla-estoque').checked=item.controlaEstoque===true;$('item-info').value=item.info||'';$('item-sugerir').checked=item.sugerir===true;montarEditorExtras($('item-extras'),item);montarEditorCombo($('item-combo'),{item,menu:lojaDados?.menu||{},proprioId:key,precoInput:$('item-preco')});if($('item-imagem').value){$('img-preview-item').src=$('item-imagem').value;$('img-preview-item').hidden=false;const ph=document.querySelector('.item-placeholder');if(ph)ph.hidden=true}}
  $('produto-modal').hidden=false;document.body.classList.add('modal-open');setTimeout(()=>$('item-nome').focus(),50);
}
function fecharFormItem(){resetFormItem();$('produto-modal').hidden=true;document.body.classList.remove('modal-open')}
$('btn-novo-item').addEventListener('click',()=>abrirFormItem());
$('btn-novo-combo')?.addEventListener('click',()=>abrirFormItem(null,null,{combo:true}));
$('btn-cancelar-item').addEventListener('click',fecharFormItem);
$('btn-fechar-produto').addEventListener('click',fecharFormItem);
$('produto-modal').addEventListener('click',e=>{if(e.target.id==='produto-modal')fecharFormItem()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('produto-modal').hidden)fecharFormItem()});

let categoriaCardapioFiltro='todas';
function categoriaNormalizada(v){const s=String(v||'').trim();return s||'Sem categoria'}
function renderizarCardapio(menu){
  const c=$('lista-itens-cardapio'),cats=$('categorias-cardapio'),entries=Object.entries(menu||{});
  if(!entries.length){cats.innerHTML='';c.innerHTML='<div class="empty-state"><i class="fa-solid fa-utensils"></i><p>Seu cardápio ainda está vazio.</p><button class="btn-primary" type="button" onclick="document.getElementById(\'btn-novo-item\').click()">Adicionar o primeiro produto</button></div>';return}
  const categorias=[...new Set(entries.map(([,x])=>categoriaNormalizada(x?.categoria)))].sort((a,b)=>a.localeCompare(b,'pt-BR'));
  if(categoriaCardapioFiltro!=='todas'&&!categorias.includes(categoriaCardapioFiltro)) categoriaCardapioFiltro='todas';
  cats.innerHTML=`<button type="button" class="category-chip ${categoriaCardapioFiltro==='todas'?'active':''}" data-category="todas">Todos</button>`+categorias.map(cat=>`<button type="button" class="category-chip ${categoriaCardapioFiltro===cat?'active':''}" data-category="${escapeHtml(cat)}">${escapeHtml(cat)}</button>`).join('');
  const grupos={};
  entries.forEach(([k,x])=>{const cat=categoriaNormalizada(x?.categoria);if(categoriaCardapioFiltro==='todas'||categoriaCardapioFiltro===cat)(grupos[cat]??=[]).push([k,x])});
  c.innerHTML=Object.entries(grupos).map(([cat,itens])=>`<section class="product-category"><div class="product-category-head"><h3>${escapeHtml(cat)}</h3><span>${itens.length} ${itens.length===1?'produto':'produtos'}</span></div><div class="product-grid">${itens.map(([k,x])=>{const im=x.imagen||x.imagem||'';const estoqueRaw=x.estoque??x.stock??x.quantidadeEstoque??x.cantidadEstoque;const estoque=Number.isFinite(Number(estoqueRaw))?Number(estoqueRaw):0;return `<article class="product-card">${im?`<img class="product-image" src="${escapeHtml(im)}" alt="${escapeHtml(x.nombre||'Produto')}">`:`<div class="product-image product-placeholder"><i class="fa-solid fa-image"></i></div>`}<div><div class="product-title">${escapeHtml(x.nombre||'Sem nome')}</div><div class="product-meta">${x.disponible===false?'Pausado':'Disponível'}${x.controlaEstoque===true?` · Estoque: ${estoque}${estoque<=0?' (esgotado)':''}`:''}</div><div class="product-price">${moeda(x.precio)}</div>${x.descripcion?`<div class="product-description">${escapeHtml(x.descripcion)}</div>`:''}</div><div class="product-actions"><button class="mini-btn ${x.disponible===false?'pause':''}" data-action="toggle" data-key="${escapeHtml(k)}" type="button" title="${x.disponible===false?'Ativar':'Pausar'}"><i class="fa-solid ${x.disponible===false?'fa-play':'fa-pause'}"></i></button><button class="mini-btn" data-action="edit" data-key="${escapeHtml(k)}" type="button" title="Editar"><i class="fa-solid fa-pen"></i></button><button class="mini-btn danger" data-action="delete" data-key="${escapeHtml(k)}" type="button" title="Excluir"><i class="fa-solid fa-trash"></i></button></div></article>`}).join('')}</div></section>`).join('');
}
$('categorias-cardapio').addEventListener('click',e=>{const b=e.target.closest('[data-category]');if(!b)return;categoriaCardapioFiltro=b.dataset.category||'todas';renderizarCardapio(lojaDados?.menu||{})});
$('lista-itens-cardapio').addEventListener('click',async e=>{const b=e.target.closest('[data-action]');if(!b)return;const k=b.dataset.key,a=b.dataset.action,item=lojaDados?.menu?.[k];if(!item)return;if(a==='delete'){if(!await confirmar({titulo:'Excluir produto?',texto:`"${item.nombre||'este produto'}" será removido do cardápio.`,rotulo:'Excluir',perigo:true}))return;await remove(ref(db,`restaurantes/${lojaId}/menu/${k}`));await carregarLoja(lojaId);return}if(a==='toggle'){await update(ref(db,`restaurantes/${lojaId}/menu/${k}`),{disponible:item.disponible===false});await carregarLoja(lojaId);return}if(a==='edit')abrirFormItem(item,k)});
$('form-add-item').addEventListener('submit',async e=>{e.preventDefault();if(!lojaId)return;const extras=lerEditorExtras($('item-extras'));if(!extras.ok){toast(extras.erro,'error');return}const combo=lerEditorCombo($('item-combo'));if(!combo.ok){toast(combo.erro,'error');return}const item={nombre:$('item-nome').value.trim(),categoria:$('item-categoria').value.trim(),precio:parseFloat($('item-preco').value)||0,estoque:Math.max(0,parseInt($('item-estoque').value,10)||0),controlaEstoque:$('item-controla-estoque').checked,descripcion:$('item-descricao').value.trim(),imagen:$('item-imagem').value.trim(),disponible:$('item-disponivel').checked,info:$('item-info').value.trim().slice(0,160)||null,sugerir:$('item-sugerir').checked||null,opcoes:extras.opcoes,adicionais:extras.adicionais,combo:combo.combo};try{if(itemEditandoId)await update(ref(db,`restaurantes/${lojaId}/menu/${itemEditandoId}`),item);else await set(push(ref(db,`restaurantes/${lojaId}/menu`)),item);fecharFormItem();await carregarLoja(lojaId)}catch(err){console.error(err);alert('Não foi possível salvar o produto.')}});

// V75.38 — Limite de usos: o painel conta os pedidos da loja e publica o total em cupons_uso/{loja}/{CODIGO} (os clientes leem).
// Só cupons com limite entram; o contador volta a baixar sozinho quando um pedido é cancelado.
let usoCuponsPublicado='',pedidosCarregados=false;
function usoDosCupons(){
  const out={},agora=new Date();
  for(const c of Object.values(lojaDados?.cupones||{})){
    if(!c?.codigo)continue;const l=limitesDoCupom(c);if(!l.maxUsos&&!l.maxPorCliente)continue;
    out[String(c.codigo).toUpperCase()]=contarUsoCupom(pedidosDaLoja,c.codigo,lojaId,null,agora).total;
  }
  return out;
}
function sincronizarUsoCupons(){
  if(!lojaId||!lojaDados||!pedidosCarregados)return;
  const uso=usoDosCupons(),chave=JSON.stringify(uso);
  atualizarListaUsoCupons(uso);
  if(chave===usoCuponsPublicado)return;
  usoCuponsPublicado=chave;
  set(ref(db,`cupons_uso/${lojaId}`),Object.keys(uso).length?uso:null).catch(err=>{usoCuponsPublicado='';console.warn('Contador de cupons não publicado:',err)});
}
function atualizarListaUsoCupons(uso){
  document.querySelectorAll('[data-uso-cupom]').forEach(el=>{
    const cod=el.dataset.usoCupom,max=Number(el.dataset.max)||0,n=uso[cod]??0;
    el.textContent=` · usos: ${n}${max?` de ${max}`:''}`;
  });
}
// V75.49 — Produtos participantes: switch por item, busca e categorias. A seleção fica num Set (não no HTML),
// assim ela não se perde quando a busca ou a categoria escondem itens.
let menuCupom={},produtosCupomSel=new Set(),produtosCupomBusca='',produtosCupomCat='todas';
function renderizarProdutosCupom(menu){
  menuCupom=menu||{};
  produtosCupomSel=new Set(selecaoValida(menuCupom,produtosCupomSel));
  const cats=categoriasDoMenu(menuCupom);
  if(produtosCupomCat!=='todas'&&!cats.some(c=>c.nome===produtosCupomCat))produtosCupomCat='todas';
  desenharCategoriasCupom();desenharListaProdutosCupom();atualizarResumoProdutosCupom();
}
function desenharCategoriasCupom(){
  const el=$('cupom-produtos-categorias');if(!el)return;
  const cats=categoriasDoMenu(menuCupom,produtosCupomSel);
  el.hidden=cats.length<2;
  const chip=(id,rotulo,n,ativo)=>`<button type="button" class="category-chip ${ativo?'active':''}" data-cupom-cat="${escapeHtml(id)}">${escapeHtml(rotulo)}${n?` <b class="cupom-cat-n">${n}</b>`:''}</button>`;
  el.innerHTML=chip('todas','Todos',produtosCupomSel.size,produtosCupomCat==='todas')+cats.map(c=>chip(c.nome,c.nome,c.ligados,produtosCupomCat===c.nome)).join('');
}
function desenharListaProdutosCupom(){
  const box=$('cupom-produtos-lista');if(!box)return;
  const total=Object.keys(menuCupom).length;
  const vis=filtrarProdutos(menuCupom,{busca:produtosCupomBusca,categoria:produtosCupomCat});
  const acoes=$('cupom-produtos-acoes');if(acoes)acoes.hidden=!total;
  const marcar=$('cupom-produtos-marcar');if(marcar){marcar.hidden=!vis.length;marcar.textContent=produtosCupomBusca||produtosCupomCat!=='todas'?`Ligar os ${vis.length} que aparecem`:'Ligar todos'}
  const limpar=$('cupom-produtos-limpar');if(limpar)limpar.hidden=!produtosCupomSel.size;
  if(!total){box.innerHTML='<p class="item-sub">Cadastre produtos no cardápio para escolher.</p>';return}
  if(!vis.length){box.innerHTML='<p class="item-sub">Nenhum produto encontrado.</p>';return}
  box.innerHTML=vis.map(p=>`<label class="switch-label cupom-prod"><input type="checkbox" value="${escapeHtml(p.id)}"${produtosCupomSel.has(p.id)?' checked':''}><span class="switch-track" aria-hidden="true"><span class="switch-thumb"></span></span><span class="cupom-prod-nome">${escapeHtml(p.nome)}<small>${escapeHtml(p.categoria)}</small></span><small class="cupom-prod-preco">${moeda(p.preco)}</small></label>`).join('');
}
function atualizarResumoProdutosCupom(){const r=$('cupom-produtos-resumo');if(r)r.textContent=resumoSelecao(produtosCupomSel.size)}
function limparProdutosCupom(){produtosCupomSel=new Set();produtosCupomBusca='';produtosCupomCat='todas';if($('cupom-produtos-busca'))$('cupom-produtos-busca').value='';desenharCategoriasCupom();desenharListaProdutosCupom();atualizarResumoProdutosCupom()}
$('cupom-produtos-lista')?.addEventListener('change',e=>{
  const i=e.target.closest('input[type=checkbox]');if(!i)return;
  i.checked?produtosCupomSel.add(i.value):produtosCupomSel.delete(i.value);
  atualizarResumoProdutosCupom();desenharCategoriasCupom();const l=$('cupom-produtos-limpar');if(l)l.hidden=!produtosCupomSel.size;
});
$('cupom-produtos-busca')?.addEventListener('input',e=>{produtosCupomBusca=e.target.value;desenharListaProdutosCupom()});
$('cupom-produtos-busca')?.addEventListener('keydown',e=>{if(e.key==='Enter')e.preventDefault()});   // Enter na busca não pode enviar o cupom
$('cupom-produtos-categorias')?.addEventListener('click',e=>{const b=e.target.closest('[data-cupom-cat]');if(!b)return;produtosCupomCat=b.dataset.cupomCat||'todas';desenharCategoriasCupom();desenharListaProdutosCupom()});
$('cupom-produtos-marcar')?.addEventListener('click',()=>{produtosCupomSel=alternarVarios(produtosCupomSel,filtrarProdutos(menuCupom,{busca:produtosCupomBusca,categoria:produtosCupomCat}).map(p=>p.id),true);desenharCategoriasCupom();desenharListaProdutosCupom();atualizarResumoProdutosCupom()});
$('cupom-produtos-limpar')?.addEventListener('click',()=>{produtosCupomSel=new Set();desenharCategoriasCupom();desenharListaProdutosCupom();atualizarResumoProdutosCupom()});
function infoValidadeCupom(x,menu){
  const est=estadoValidadeCupom(x),ids=produtosDoCupom(x),lim=limitesDoCupom(x),partes=[];
  if(x.inicioEm&&x.fimEm)partes.push(`${dataBR(x.inicioEm)} a ${dataBR(x.fimEm)}`);else if(x.fimEm)partes.push(`até ${dataBR(x.fimEm)}`);else if(x.inicioEm)partes.push(`a partir de ${dataBR(x.inicioEm)}`);
  if(ids.length)partes.push(ids.length===1?`só ${escapeHtml(menu?.[ids[0]]?.nombre||'1 produto')}`:`${ids.length} produtos participantes`);
  if(lim.maxPorCliente)partes.push(`${lim.maxPorCliente} por cliente`);
  const chip=est==='expirado'?'<span class="cupom-chip exp">Expirado</span>':est==='agendado'?'<span class="cupom-chip ag">Agendado</span>':'';
  const usoHtml=lim.maxUsos||lim.maxPorCliente?`<span data-uso-cupom="${escapeHtml(String(x.codigo||'').toUpperCase())}" data-max="${lim.maxUsos}"></span>`:'';
  return {texto:partes.length?` · ${partes.join(' · ')}`:'',chip,usoHtml};
}
function renderizarCupons(obj,menu){const c=$('lista-cupons-loja'),keys=Object.keys(obj||{});if(!keys.length){c.innerHTML='<div class="empty-state"><i class="fa-solid fa-ticket"></i><p>Não há cupons criados.</p></div>';return}c.innerHTML=keys.map(k=>{const x=obj[k]||{},v=infoValidadeCupom(x,menu);return `<div class="list-item"><div><span class="item-title">${escapeHtml(x.codigo||'SEM CÓDIGO')}${v.chip}</span><span class="item-sub">${escapeHtml(x.titulo||'')} · ${x.tipo==='porcentagem'?'Porcentagem':x.tipo==='fixo'?'Valor fixo':'Entrega grátis'} · mínimo ${moeda(x.minimo||0)}${v.texto}${v.usoHtml}</span></div><span class="item-acoes" style="display:flex;gap:6px"><button class="mini-btn" type="button" data-cupom-avisar="${escapeHtml(k)}" title="Avisar clientes por notificação" aria-label="Avisar clientes por notificação"><i class="fa-solid fa-bell"></i></button><button class="mini-btn danger" type="button" data-cupom="${escapeHtml(k)}" aria-label="Excluir cupom"><i class="fa-solid fa-trash"></i></button></span></div>`}).join('')}
$('lista-cupons-loja').addEventListener('click',async e=>{const av=e.target.closest('[data-cupom-avisar]');if(av){av.disabled=true;mostrarResultadoAviso(await avisarClientesCupom(av.dataset.cupomAvisar));av.disabled=false;return}const b=e.target.closest('[data-cupom]');if(!b)return;if(!await confirmar({titulo:'Excluir cupom?',texto:'Os clientes deixam de poder usar este cupom.',rotulo:'Excluir',perigo:true}))return;await remove(ref(db,`restaurantes/${lojaId}/cupones/${b.dataset.cupom}`));await carregarLoja(lojaId)});
$('form-add-cupom').addEventListener('submit',async e=>{e.preventDefault();if(!lojaId)return;const codigoNovo=$('cupom-codigo').value.toUpperCase().replace(/\s+/g,'').trim();const x={codigo:codigoNovo,titulo:$('cupom-titulo').value.trim(),tipo:$('cupom-tipo').value,valor:parseFloat($('cupom-valor').value)||0,minimo:parseFloat($('cupom-minimo').value)||0,ativo:true};const ini=$('cupom-inicio')?.value||'',fim=$('cupom-fim')?.value||'';if(ini)x.inicioEm=ini;if(fim)x.fimEm=fim;if(ini&&fim&&fim<ini)return alert('A data final não pode ser antes da data inicial.');if(fim&&fim<dataISOlocal(new Date()))return alert('A data final já passou. Escolha hoje ou uma data futura.');const mu=parseInt($('cupom-max-usos')?.value,10)||0,mc=parseInt($('cupom-max-cliente')?.value,10)||0;if(mu<0||mc<0)return alert('Os limites de uso devem ser números positivos.');if(mu)x.maxUsos=mu;if(mc)x.maxPorCliente=mc;if(mu&&mc&&mc>mu)return alert('O limite por cliente não pode ser maior que o limite total.');const prods=produtosParaCupom(menuCupom,produtosCupomSel);if(prods)x.produtos=prods;if(!/^[A-Z0-9_-]{3,20}$/.test(x.codigo))return alert('O código deve ter de 3 a 20 letras ou números (sem espaços).');if(Object.values(lojaDados?.cupones||{}).some(c=>String(c.codigo).toUpperCase()===x.codigo))return alert('Já existe um cupom com esse código.');if(x.tipo==='porcentagem'&&(x.valor<=0||x.valor>100))return alert('A porcentagem deve estar entre 1 e 100.');if(x.tipo==='fixo'&&x.valor<=0)return alert('O valor do desconto deve ser maior que 0.');let avisar=$('cupom-avisar')?.checked!==false;if(avisar&&estadoValidadeCupom(x)==='agendado'){avisar=false;toast('Cupom agendado: o aviso por notificação não foi enviado. Use o sininho quando ele começar a valer.','info',7000)}try{const nova=push(ref(db,`restaurantes/${lojaId}/cupones`));await set(nova,x);e.target.reset();limparProdutosCupom();$('cupom-valor').value=0;$('cupom-minimo').value=0;if($('cupom-avisar'))$('cupom-avisar').checked=true;await carregarLoja(lojaId);toast('Cupom criado.','success');if(avisar)mostrarResultadoAviso(await avisarClientesCupom(nova.key))}catch(err){console.error(err);alert('Não foi possível criar o cupom.')}});

let filtroPedido='todos';
let buscaPedido='';
let filtroDataPedido=dataISOlocal(new Date());
let filtroDataPedidoAtivo=true;
let filtroFimanceiro='today';
const exigePagamentoOnline = p => {
  const forma = String(p?.formaPagamento || '').trim().toLowerCase();
  return forma.includes('mercado') || forma.includes('pix');
};
const pagamentoConfirmado = p => exigePagamentoOnline(p)
  ? normalizarPagamento(p.pagoStatus) === PAGO.APROVADO
  : normalizarStatus(p.status) === STATUS.ENTREGUE;
const aguardandoPagamentoOnline = p =>
  exigePagamentoOnline(p) &&
  normalizarPagamento(p.pagoStatus) !== PAGO.APROVADO &&
  normalizarStatus(p.status) !== STATUS.CANCELADO;
// V75.113: pedido Pix/cartão é gravado ANTES do pagamento. Enquanto o pagamento não for aprovado, ele não é "pedido novo":
// sem alerta, sem aceitação automática, sem contar no "Pedidos (n)" e sem poder aceitar. Pago depois → aí sim vira pedido novo.
const pedidoLiberado=p=>normalizarStatus(p.status)===STATUS.PENDENTE&&!aguardandoPagamentoOnline(p);
const pagamentoRecusado=p=>{const a=String(p?.pagoStatus||'').toLowerCase(),b=String(p?.paymentStatusMP||'').toLowerCase();return a.startsWith('rech')||a.startsWith('recus')||['rejected','cancelled','expired','refunded','charged_back'].includes(b)};
const pedidoValidoFimanceiro=p=>normalizarStatus(p.status)!==STATUS.CANCELADO && (!exigePagamentoOnline(p) || pagamentoConfirmado(p));
const pedidoRecebido=p=>pedidoValidoFimanceiro(p) && pagamentoConfirmado(p);
const pedidoAReceber=p=>pedidoValidoFimanceiro(p) && !pagamentoConfirmado(p);
const devolvidoDoPedido=p=>p?.reembolso?.status==='aprovado'?Math.min(Number(p.reembolso.valor)||0,Number(p.total)||0):0; // V75.99: reembolso aprovado sai do faturamento (antes o total inteiro continuava somado)
const receitaTotal=()=>pedidosDaLoja.filter(pedidoRecebido).reduce((s,p)=>s+Math.max(0,(Number(p.total)||0)-devolvidoDoPedido(p)),0);
function dataPedido(p){
  const valores=[p?.criadoEm,p?.dataCriacao,p?.createdAt,p?.criado_at,p?.atualizadoEm];
  for(const valor of valores){
    if(valor===null||valor===undefined||valor==='')continue;
    if(typeof valor==='number' || /^\d+$/.test(String(valor).trim())){
      const n=Number(valor); const d=new Date(n<1e12?n*1000:n); if(!Number.isNaN(d.getTime()))return d;
    }
    const texto=String(valor).trim();
    let d=new Date(texto);
    if(!Number.isNaN(d.getTime()))return d;
    const m=texto.match(/^(\d{2})[\/.-](\d{2})[\/.-](\d{4})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/);
    if(m){d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]),Number(m[4]||0),Number(m[5]||0),Number(m[6]||0));if(!Number.isNaN(d.getTime()))return d;}
  }
  return null;
}
function mesmoDia(a,b){return a&&b&&a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate()}
function mesmoMes(a,b){return a&&b&&a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()}
function pedidosFimanceiro(){return pedidosDaLoja.filter(pedidoValidoFimanceiro)}
function resumoFimanceiro(lista){
  const bruto=lista.reduce((s,p)=>s+(Number(p.subtotal)||Number(p.total)||0)+(Number(p.precioEnvio)||0),0);
  const descontos=lista.reduce((s,p)=>s+(Number(p.desconto)||0),0);
  const liquido=lista.reduce((s,p)=>s+Math.max(0,(Number(p.total)||0)-devolvidoDoPedido(p)),0);
  const taxas=lista.reduce((s,p)=>s+(Number(p.taxaGateway)||Number(p.taxa)||0),0);
  const liquidoComTaxa=liquido-taxas;
  const recebido=lista.filter(pedidoRecebido).reduce((s,p)=>s+Math.max(0,(Number(p.total)||0)-devolvidoDoPedido(p)),0);
  const aReceber=lista.filter(pedidoAReceber).reduce((s,p)=>s+(Number(p.total)||0),0);
  return {bruto,descontos,liquido, taxas, liquidoComTaxa, recebido, aReceber, vendas:lista.length, ticket:lista.length?liquido/lista.length:0};
}
function rotuloPagamento(v){
  const s=String(v||'Não informado').trim();
  const l=s.toLowerCase();
  if(l.includes('pix'))return 'PIX'; if(l.includes('cart'))return 'Cartão'; if(l.includes('dinheiro')||l.includes('efectivo')||l.includes('efetivo'))return 'Dinheiro';
  if(l.includes('mercado'))return 'Mercado Pago'; return s||'Não informado';
}
function iconePagamento(v){const l=String(v||'').toLowerCase();if(l.includes('pix'))return 'fa-qrcode';if(l.includes('cart'))return 'fa-credit-card';if(l.includes('dinheiro')||l.includes('efectivo')||l.includes('efetivo'))return 'fa-money-bill-wave';if(l.includes('mercado'))return 'fa-wallet';return 'fa-money-check-dollar'}
function renderizarPagamentos(lista){
  const el=$('fin-pagamentos');if(!el)return;
  const mapa={}; lista.forEach(p=>{const nome=rotuloPagamento(p.formaPagamento);if(!mapa[nome])mapa[nome]={count:0,value:0,icon:iconePagamento(p.formaPagamento)};mapa[nome].count++;mapa[nome].value+=Number(p.total)||0});
  const entries=Object.entries(mapa).sort((a,b)=>b[1].value-a[1].value);
  el.innerHTML=entries.length?entries.map(([nome,x])=>`<div class="payment-method"><div class="payment-method-main"><span class="payment-method-icon"><i class="fa-solid ${x.icon}"></i></span><div><span class="payment-method-name">${escapeHtml(nome)}</span><span class="payment-method-count">${x.count} ${x.count===1?'venda':'vendas'}</span></div></div><strong class="payment-method-value">${moeda(x.value)}</strong></div>`).join(''):'<div class="empty-state"><i class="fa-solid fa-credit-card"></i><p>Não há ventas no período.</p></div>';
}
function dataLocalInput(v){
  const s=String(v||'').trim();
  const m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m?new Date(Number(m[1]),Number(m[2])-1,Number(m[3]),12,0,0):null;
}
function dataISOlocal(d){
  const x=d||new Date();
  return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`;
}
function mesmoDiaInput(p,iso){return mesmoDia(dataPedido(p),dataLocalInput(iso))}
function nomeDiaSemana(d){return ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'][d.getDay()]}
function renderizarRankingSemana(lista){
  const el=$('ranking-semana-pedidos'); if(!el)return;
  const base=lista||pedidosFimanceiro();
  const nomes=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'];
  const mapa={}; nomes.forEach(n=>mapa[n]={count:0,value:0});
  base.forEach(p=>{const d=dataPedido(p);if(!d)return;const n=nomeDiaSemana(d);mapa[n].count++;mapa[n].value+=Number(p.total)||0});
  const arr=nomes.map(n=>({nome:n,...mapa[n]}));
  const maxCount=Math.max(1,...arr.map(x=>x.count));
  el.innerHTML=arr.map(x=>`<div class="weekday-row"><div class="weekday-main"><strong>${x.nome}</strong><span>${x.count} ${x.count===1?'pedido':'pedidos'}</span></div><div class="weekday-bar"><i style="width:${Math.round(x.count/maxCount*100)}%"></i></div><strong class="weekday-value">${moeda(x.value)}</strong></div>`).join('');
}
function renderizarDiaSelecionado(){
  const input=$('fin-data-selecionada'),label=$('fin-dia-selecionado-label'),el=$('fin-dia-selecionado');if(!input||!label||!el)return;
  const iso=input.value||dataISOlocal(new Date()),d=dataLocalInput(iso),lista=pedidosDaLoja.filter(p=>mesmoDiaInput(p,iso));
  const r=resumoFimanceiro(lista); label.textContent=d?`${nomeDiaSemana(d)}, ${d.toLocaleDateString('pt-BR')}`:'Dia selecionado';
  el.innerHTML=`<div class="selected-day-grid"><div><span>Pedidos</span><strong>${r.vendas}</strong></div><div><span>Faturamento</span><strong>${moeda(r.liquido)}</strong></div><div><span>Recebido</span><strong>${moeda(r.recebido)}</strong></div><div><span>A receber</span><strong>${moeda(r.aReceber)}</strong></div><div><span>Ticket médio</span><strong>${moeda(r.ticket)}</strong></div><div><span>Cancelados</span><strong>${pedidosDaLoja.filter(p=>mesmoDiaInput(p,iso)&&normalizarStatus(p.status)===STATUS.CANCELADO).length}</strong></div></div>`;
  renderizarHistoricoFimanceiro(lista);
}
function atualizarFimanceiro(){
  const validos=pedidosFimanceiro(),agora=new Date();
  const hoje=validos.filter(p=>mesmoDia(dataPedido(p),agora));
  // V75.60: "mês" = ciclo de 30 dias corridos a partir do cadastro da loja (sem data de cadastro, começa pelo pedido mais antigo)
  const inicioCiclo=Date.parse(lojaDados?.criadoEm)||Math.min(...validos.map(p=>dataPedido(p)?.getTime()).filter(Number.isFinite),agora.getTime());
  const ciclo=cicloAtual(inicioCiclo,agora.getTime());
  const mes=validos.filter(p=>{const d=dataPedido(p);return d&&noCiclo(d.getTime(),ciclo)});
  const dataCustom=$('fin-data-selecionada')?.value||dataISOlocal(agora);
  const custom=validos.filter(p=>mesmoDiaInput(p,dataCustom));
  const mesEscolhido=$('fin-mes-selecionado')?.value||`${agora.getFullYear()}-${String(agora.getMonth()+1).padStart(2,'0')}`;
  const [anoEsc,mesEsc]=mesEscolhido.split('-').map(Number);
  const mesCustom=validos.filter(p=>{const d=dataPedido(p);return d&&d.getFullYear()===anoEsc&&d.getMonth()===mesEsc-1});
  const atual=filtroFimanceiro==='month'?mes:filtroFimanceiro==='all'?validos:filtroFimanceiro==='custom'?custom:filtroFimanceiro==='mescustom'?mesCustom:hoje;
  const rotuloPeriodo=filtroFimanceiro==='month'?'Este mês':filtroFimanceiro==='all'?'Todo o histórico':filtroFimanceiro==='custom'?(dataLocalInput(dataCustom)?dataLocalInput(dataCustom).toLocaleDateString('pt-BR'):'Dia selecionado'):filtroFimanceiro==='mescustom'?`${String(mesEsc).padStart(2,'0')}/${anoEsc}`:'Hoje';
  const r=resumoFimanceiro(atual),rh=resumoFimanceiro(hoje),rm=resumoFimanceiro(mes);
  $('fin-hoje').textContent=moeda(rh.liquido);$('fin-mes').textContent=moeda(rm.liquido);{const ms=$('fin-mes-info');if(ms)ms.textContent=`${rotuloCiclo(ciclo)} · faltam ${ciclo.diasRestantes} dia(s)`}$('fin-faturamento').textContent=moeda(r.liquido);$('fin-recebido').textContent=moeda(r.recebido);$('fin-a-receber').textContent=moeda(r.aReceber);$('fin-descontos').textContent=moeda(r.descontos);{const cm=resumoComissao(atual);const el=$('fin-comissao');if(el){el.textContent=moeda(cm.split+cm.aAcertar);$('fin-comissao-detalhe').textContent=`Já separada no split: ${moeda(cm.split)} · A acertar com a plataforma: ${moeda(cm.aAcertar)}`}}$('fin-liquido').textContent=moeda(r.liquidoComTaxa);$('fin-total-vendas').textContent=String(r.vendas);$('fin-ticket-medio').textContent=`Ticket: ${moeda(r.ticket)}`;
  const sel=document.querySelector(`[data-fin-period="${filtroFimanceiro}"]`);document.querySelectorAll('[data-fin-period]').forEach(b=>b.classList.toggle('active',b===sel));
  $('fin-moeda-venda').textContent=`Venda em ${moedaLoja}`;$('fin-moeda-recebimento').textContent=`A moeda exibida segue a configuração da loja (${moedaLoja}). A moeda real de recebimento depende do meio de pagamento.`;
  renderizarPagamentos(atual);renderizarRankingSemana(atual);renderizarDinheiro(atual,rotuloPeriodo);
  const lblPeriodo=$('fin-periodo-label');if(lblPeriodo)lblPeriodo.textContent=`${rotuloPeriodo} · pedidos válidos`;
  const lblRanking=$('fin-ranking-periodo');if(lblRanking)lblRanking.textContent=`Período: ${rotuloPeriodo}. Agrupado pelo dia da semana em que cada pedido foi criado.`;
  const input=$('fin-data-selecionada');if(input&&!input.value)input.value=dataISOlocal(new Date());renderizarDiaSelecionado();
  if(filtroFimanceiro!=='custom')renderizarHistoricoFimanceiro(atual);
}
function renderizarHistoricoFimanceiro(lista){
  const hist=$('lista-financas-pedidos'); if(!hist)return;
  const ordenados=[...lista].sort((a,b)=>String(b.criadoEm||'').localeCompare(String(a.criadoEm||'')));
  hist.innerHTML=ordenados.length?ordenados.map(p=>{const d=dataPedido(p);const status=normalizarStatus(p.status);const pagamento=rotuloPagamento(p.formaPagamento);const desconto=Number(p.desconto)||0;const bruto=(Number(p.subtotal)||Number(p.total)||0)+(Number(p.precioEnvio)||0);const cls=status===STATUS.CANCELADO?'cancelado':pagamentoConfirmado(p)?'':'pendente';const pagoTexto=pagamentoConfirmado(p)?'Pago':'A receber';return `<div class="finance-row"><div><span class="finance-row-title">Pedido #${escapeHtml(p.numeroPedido||p.id||p.key)}</span><span class="finance-row-sub">${d?escapeHtml(d.toLocaleString('pt-BR')):'Data não informada'} · ${escapeHtml(pagamento)}</span></div><div><span class="finance-row-label">Bruto</span><strong class="finance-row-value">${moeda(bruto)}</strong></div><div><span class="finance-row-label">Desconto / líquido</span><strong class="finance-row-value">${desconto?`−${moeda(desconto)} · `:''}${moeda(Number(p.total)||0)}</strong></div><div class="finance-row-status"><span class="finance-status ${cls}">${pagoTexto}</span></div></div>`}).join(''):'<div class="empty-state"><i class="fa-solid fa-chart-line"></i><p>Não há movimentações no período selecionado.</p></div>';
}

document.querySelectorAll('[data-fin-period]').forEach(b=>b.addEventListener('click',()=>{filtroFimanceiro=b.dataset.finPeriod||'today';atualizarFimanceiro()}));
$('btn-fin-data')?.addEventListener('click',()=>{filtroFimanceiro='custom';atualizarFimanceiro();});
const ativarMesFinanceiro=()=>{const i=$('fin-mes-selecionado');if(i&&!i.value){const h=new Date();i.value=`${h.getFullYear()}-${String(h.getMonth()+1).padStart(2,'0')}`}filtroFimanceiro='mescustom';atualizarFimanceiro();};
$('btn-fin-mes')?.addEventListener('click',ativarMesFinanceiro);
$('fin-mes-selecionado')?.addEventListener('change',ativarMesFinanceiro);
$('fin-data-selecionada')?.addEventListener('change',()=>{filtroFimanceiro='custom';atualizarFimanceiro();});

async function sincronizarVendasCardapio(pedidos){
  if(!lojaId || !lojaDados?.menu) return;
  const vendas={};
  Object.keys(lojaDados.menu).forEach(id=>vendas[id]=0);
  for(const p of pedidos||[]){
    if(normalizarStatus(p.status)===STATUS.CANCELADO) continue;
    for(const item of (p.itens||[])){
      if(item?.id && vendas[item.id]!==undefined) vendas[item.id]+=Math.max(0,Number(item.qtd)||0);
    }
  }
  const updates={}; let changed=false;
  for(const [id,n] of Object.entries(vendas)){
    const atual=Number(lojaDados.menu[id]?.vendas)||0;
    if(atual!==n){updates[`restaurantes/${lojaId}/menu/${id}/vendas`]=n; changed=true;}
  }
  if(!changed)return;
  try{
    await update(ref(db),updates);
    Object.entries(vendas).forEach(([id,n])=>{if(lojaDados.menu[id])lojaDados.menu[id].vendas=n;});
  }catch(err){console.warn('Não foi possível sincronizar as vendas do cardápio:',err);}
}

// V75.40 — anúncios que a loja contratou com o YAPOOD (só leitura; quem cadastra é o Master). Ficam fora do faturamento.
function iniciarPublicidade(){
  if(unsubPublicidade){unsubPublicidade();unsubPublicidade=null}
  publicidadeLoja=[];
  try{
    unsubPublicidade=onValue(query(ref(db,'publicidade'),orderByChild('lojaId'),equalTo(String(lojaId))),snap=>{
      publicidadeLoja=registrosDePublicidade(snap.val());
      try{atualizarFimanceiro()}catch(err){console.warn('Financeiro:',err)}
    },err=>{publicidadeLoja=[];console.warn('Publicidade não carregada:',err.message)});
  }catch(err){console.warn('Publicidade:',err)}
}
function renderizarDinheiro(lista,rotuloPeriodo){
  const d=resumoDinheiro(lista),set_=(id,v)=>{const e=$(id);if(e)e.textContent=moeda(v)};
  if(!$('fin-dinheiro'))return;
  set_('fd-produtos',d.produtos);set_('fd-entrega',d.entrega);set_('fd-descontos',d.descontos);set_('fd-reembolsos',d.reembolsos);set_('fd-cobrado',d.cobrado);
  set_('fd-split',d.comissaoSplit);set_('fd-acertar',d.comissaoAcertar);set_('fd-comissao',d.comissao);
  set_('fd-liquido',d.liquidoLoja);set_('fd-mp',d.noMercadoPago);set_('fd-maos',d.emMaos);
  const p=resumoPublicidade(publicidadeLoja);set_('fd-pub-pago',p.pago);set_('fd-pub-pendente',p.pendente);
  const lp=$('fd-pub-lista');if(lp)lp.innerHTML=publicidadeLoja.slice(0,5).map(x=>`<li><span>${escapeHtml(x.descricao||x.anunciante||'Anúncio')} · ${escapeHtml(dataBR(x.data))}</span><span><b>${moeda(x.valor)}</b> <span class="pub-st ${escapeHtml(x.status||'pendente')}">${escapeHtml(ROTULO_PUB[x.status]||'A receber')}</span></span></li>`).join('')||'<li><span>Nenhum anúncio contratado.</span></li>';
  const n=$('fd-acertar-nota');if(n)n.textContent=d.comissaoAcertar>0?`Você deve ${moeda(d.comissaoAcertar)} ao YAPOOD neste período (pedidos pagos na entrega).`:'Pedidos pagos na entrega: a loja recebe o valor cheio do cliente e acerta a comissão com o YAPOOD.';
  const t=$('fin-din-periodo');if(t)t.textContent=`${rotuloPeriodo}. A comissão do YAPOOD e a publicidade nunca se misturam com as suas vendas.`;
}
function iniciarPedidos(){
  iniciarPublicidade();
  try{iniciarAcertoLoja(lojaId)}catch(err){console.warn('Acerto de comissão:',err)}
  if(unsubPedidos)unsubPedidos();
  detenerAlertaSonora();
  pedidosEmAlerta.clear();
  pedidosLojaId=lojaId;pedidosConhecidos=null;liberadosConhecidos=null;pedidosEstadosConhecidos.clear();relatosVistos=null;
  unsubPedidos=onValue(query(ref(db,'pedidos'),orderByChild('lojaId'),equalTo(String(lojaId))),snap=>{
    const dados=snap.val()||{};
    pedidosDaLoja=Object.entries(dados).map(([key,p])=>({key,...(p||{})})).sort((a,b)=>String(b.criadoEm||b.dataCriacao||b.createdAt||'').localeCompare(String(a.criadoEm||a.dataCriacao||a.createdAt||'')));
    const conhecidosAntes=pedidosConhecidos;
    pedidosConhecidos=new Set(pedidosDaLoja.map(p=>p.key));
    // Renderizar primeiro: um erro secundário de financeiro/sincronização nunca pode esconder os pedidos.
    try{renderizarPedidos();atualizarVisaoGeral();atualizarBadgePedidos();}catch(err){
      console.error('Renderização /pedidos:',err);
      const lista=$('lista-pedidos-loja');
      if(lista)lista.innerHTML='<div class="store-error"><strong>Os pedidos foram carregados, mas houve um erro ao montar a lista.</strong><span>Abra o console para o detalhe técnico.</span></div>';
    }
    try{
      // V75.113: "novo" = acabou de ficar liberado (pedido em dinheiro que chegou, ou Pix/cartão que acabou de ser aprovado)
      const liberadosAntes=liberadosConhecidos;
      liberadosConhecidos=new Set(pedidosDaLoja.filter(pedidoLiberado).map(p=>p.key));
      if(conhecidosAntes&&liberadosAntes){
        const novos=pedidosDaLoja.filter(p=>liberadosConhecidos.has(p.key)&&!liberadosAntes.has(p.key));
        if(novos.length)avisarNovoPedido(novos.map(p=>p.key));
      }
      const pendentes=liberadosConhecidos;
      for(const id of [...pedidosEmAlerta]) if(!pendentes.has(id)) pedidosEmAlerta.delete(id);
      if(pedidosEmAlerta.size && audioLiberado) iniciarAlertaSonora();
      else if(!pedidosEmAlerta.size) detenerAlertaSonora();
    }catch(err){console.warn('Alerta de pedidos:',err)}
    try{sincronizarReembolsos()}catch(err){console.warn('Reembolsos:',err)}
    try{atualizarFaixaRelatos();avisarNovosRelatos()}catch(err){console.warn('Relatos:',err)}
    try{
      for(const p of pedidosDaLoja){
        const atual=normalizarStatus(p.status),antes=pedidosEstadosConhecidos.get(p.key);
        if(antes&&antes!==STATUS.CANCELADO&&atual===STATUS.CANCELADO){
          if(cancelamentosLocais.has(p.key))cancelamentosLocais.delete(p.key);
          else registrarCancelamentoDeOutro(p);
        }
        pedidosEstadosConhecidos.set(p.key,atual);
      }
    }catch(err){console.warn('Aviso de cancelamento:',err)}
    try{atualizarFimanceiro()}catch(err){console.warn('Financeiro de pedidos:',err)}
    try{atualizarAcertoPedidos(pedidosDaLoja)}catch(err){console.warn('Acerto de comissão:',err)}
    try{sincronizarVendasCardapio(pedidosDaLoja)}catch(err){console.warn('Sincronização de vendas:',err)}
    pedidosCarregados=true;try{sincronizarUsoCupons()}catch(err){console.warn('Uso de cupons:',err)}
  },err=>{console.error('Firebase /pedidos listener:',err);const lista=$('lista-pedidos-loja');if(lista)lista.innerHTML='<div class="store-error"><strong>Não foi possível carregar os pedidos.</strong><span>O Firebase recusou a leitura. Verifique as regras de leitura de /pedidos para a loja.</span></div>'});
}

function atualizarBadgePedidos(){
  const n=pedidosDaLoja.filter(pedidoLiberado).length;
  document.querySelectorAll('.nav-btn[data-tab="modulo-pedidos"] span').forEach(s=>s.textContent=n?`Pedidos (${n})`:'Pedidos');
  document.title=n?`(${n}) Central da loja`:'Central da loja';
}
function prepararAudio(){
  if(contextoAudio)return contextoAudio;
  const AudioCtx=window.AudioContext||window.webkitAudioContext;
  if(!AudioCtx){atualizarEstadoSom('O navegador não oferece suporte a áudio');return null;}
  try{contextoAudio=new AudioCtx();}catch{atualizarEstadoSom('Não foi possível ativar o áudio');return null;}
  return contextoAudio;
}
function preferenciaSom(){return localStorage.getItem(CHAVE_SOM_ATIVADO)==='1'}
function atualizarEstadoSom(texto,ativo=audioLiberado){
  const el=$('estado-som');
  if(el)el.textContent=texto;
  const btn=$('btn-ativar-som');
  if(btn){btn.disabled=false;btn.innerHTML=ativo?'<i class="fa-solid fa-circle-check"></i> Som ativado':'<i class="fa-solid fa-volume-high"></i> Ativar som';}
}
function tocarSemoCampana(){
  const c=prepararAudio();
  if(!c||!audioLiberado||c.state!=='running')return false;
  try{
    const agora=c.currentTime;
    const notas=[{f:1046,d:0.72,v:.22},{f:1568,d:0.58,v:.16},{f:2093,d:0.38,v:.08}];
    notas.forEach(({f,d,v},i)=>{
      const o=c.createOscillator(),g=c.createGain(),inicio=agora+i*.055;
      o.type='sine';o.frequency.setValueAtTime(f,inicio);
      o.connect(g);g.connect(c.destination);
      g.gain.setValueAtTime(.0001,inicio);
      g.gain.exponentialRampToValueAtTime(v,inicio+.012);
      g.gain.exponentialRampToValueAtTime(.0001,inicio+d);
      o.start(inicio);o.stop(inicio+d+.03);
    });
    return true;
  }catch{return false;}
}
async function liberarAudio(){
  const c=prepararAudio();
  if(!c)return false;
  try{if(c.state!=='running')await c.resume();audioLiberado=c.state==='running';}catch{audioLiberado=false;}
  if(audioLiberado){
    localStorage.setItem(CHAVE_SOM_ATIVADO,'1');
    atualizarEstadoSom('Som ativado',true);
    if(sonsAutomaticosPendentes){const n=sonsAutomaticosPendentes;sonsAutomaticosPendentes=0;for(let i=0;i<n;i++)tocarSomTresSegundos();}
    if(sonsPendentes){sonsPendentes=0;}
    if(cancelamentosEmAlerta.size){renderizarFaixaCancelamento();iniciarAlarmeCancelamento();}
    if(pedidosEmAlerta.size)iniciarAlertaSonora();
  }else{
    atualizarEstadoSom('Clique em “Ativar som” para permitir o áudio',false);
  }
  return audioLiberado;
}
function pedidoParaAlerta(){
  const ids=[...pedidosEmAlerta];
  return pedidosDaLoja.find(p=>ids.includes(p.key)&&pedidoLiberado(p))||null;
}
function renderizarOverlayPedido(){
  const overlay=$('overlay-novo-pedido');
  const pedido=pedidoParaAlerta();
  if(!overlay||!pedido){if(overlay)overlay.hidden=true;return;}
  const itensArray=pedido.itens||[];
  const itens=itensArray.map(i=>`<li><span>${Number(i.qtd)||0}× ${escapeHtml(i.nombre||'Produto')}${detalhesDaLinha(i).length?`<small class="extras-item">${escapeHtml(detalhesDaLinha(i).join(' · '))}</small>`:''}</span><strong>${moeda((Number(i.precio)||0)*(Number(i.qtd)||0))}</strong></li>`).join('');
  const subtotalRaw=Number(pedido.subtotal);
  const subtotal=Number.isFinite(subtotalRaw)?subtotalRaw:itensArray.reduce((s,i)=>s+(Number(i.precio)||0)*(Number(i.qtd)||0),0);
  const envioRaw=pedido.precioEnvio??pedido.taxaEntrega??0;
  const envio=Math.max(0,Number(envioRaw)||0);
  const desconto=Math.max(0,Number(pedido.desconto)||0);
  const total=Number(pedido.total)||Math.max(0,subtotal+envio-desconto);
  const fone=String(pedido.cliente?.telefono||'').replace(/\D/g,'');
  $('overlay-pedido-numero').textContent=`Pedido #${pedido.numeroPedido||pedido.key}`;
  $('overlay-pedido-cliente').textContent=pedido.cliente?.nombre||'Cliente';
  $('overlay-pedido-telefone').innerHTML=fone?`<a href="https://wa.me/${fone}" target="_blank" rel="noopener">${escapeHtml(pedido.cliente?.telefono||fone)}</a>`:'Não informado';
  $('overlay-pedido-endereco').textContent=pedido.cliente?.direccion||'Não informada';
  $('overlay-pedido-pagamento').textContent=rotuloPagamento(pedido.formaPagamento);
  {const el=$('overlay-pedido-troco');if(el){const tt=textoTroco(trocoSeguro(pedido.troco),moeda);el.textContent=tt;el.closest('div').hidden=!tt}}
  $('overlay-pedido-subtotal').textContent=moeda(subtotal);
  $('overlay-pedido-envio').textContent=envio>0?moeda(envio):'Grátis';
  const boxDesconto=$('overlay-pedido-desconto-row');
  if(boxDesconto){boxDesconto.hidden=desconto<=0;boxDesconto.querySelector('strong').textContent=desconto>0?`−${moeda(desconto)}`:'';}
  const linhaFid=$('overlay-pedido-fidelidade-row');
  if(linhaFid){const f=pedido.premioFidelidade?textoFidelidadePedido(pedido):null;linhaFid.hidden=!f;if(f){$('overlay-pedido-fidelidade').innerHTML=f.html;linhaFid.style.color=f.classe==='alerta'?'#a32a2a':''}}
  $('overlay-pedido-total').textContent=moeda(total);
  {const box=$('overlay-pedido-saldo');if(box){const L=linhasSaldo(pedido,moeda);box.hidden=!L.length;box.innerHTML=L.map(l=>`<div class="${l.forte?'forte':''}"><span>${escapeHtml(l.rotulo)}</span><strong>${escapeHtml(l.valor)}</strong></div>`).join('');}} // V75.156: saldo da loja usado e quanto cobrar
  $('overlay-pedido-itens').innerHTML=itens||'<li><span>Sem produtos detalhados</span></li>';
  const obs=pedido.cliente?.observacion||pedido.observacao||'';
  $('overlay-pedido-observacao').textContent=obs||'Sem observações';
  const n=pedidosEmAlerta.size;
  $('overlay-pedido-contador').textContent=n>1?`${n} pedidos pendentes de decisão`:'Aguardando sua decisão';
  overlay.hidden=false;
}
function fecharOverlayPedido(){const overlay=$('overlay-novo-pedido');if(overlay)overlay.hidden=true;}
function tocarSomTresSegundos(){
  if(!audioLiberado)return false;
  detenerAlertaSonora();
  tocarSemoCampana();
  let ciclos=1;
  somTresSegTimer=setInterval(()=>{
    if(ciclos>=3){clearInterval(somTresSegTimer);somTresSegTimer=null;return;}
    tocarSemoCampana();ciclos++;
  },1000);
  setTimeout(()=>{if(somTresSegTimer){clearInterval(somTresSegTimer);somTresSegTimer=null;}},3050);
  return true;
}
// V75.156 — Aviso de cancelamento: "plun plun" (duas gotas suaves, tom descendente), bem diferente da campainha de novo pedido.
function tocarSomCancelado(){
  const c=prepararAudio();
  if(!c||!audioLiberado||c.state!=='running')return false;
  try{
    const t0=c.currentTime+.02;
    const gota=(f0,f1,ini,dur,vol)=>{
      const o=c.createOscillator(),g=c.createGain();
      o.type='sine';o.frequency.setValueAtTime(f0,ini);o.frequency.exponentialRampToValueAtTime(f1,ini+dur*.8);
      o.connect(g);g.connect(c.destination);
      g.gain.setValueAtTime(.0001,ini);
      g.gain.exponentialRampToValueAtTime(vol,ini+.012);
      g.gain.exponentialRampToValueAtTime(.0001,ini+dur);
      o.start(ini);o.stop(ini+dur+.02);
    };
    gota(560,310,t0,.24,.34);        // plun
    gota(470,260,t0+.30,.26,.34);    // plun
    return true;
  }catch{return false}
}
function iniciarAlarmeCancelamento(){
  if(somCancelTimer)return true;
  if(!audioLiberado||!cancelamentosEmAlerta.size)return false;
  detenerAlertaSonora(); // o alarme de problema tem prioridade sobre a campainha; ela volta quando ele parar
  tocarSomCancelado();
  if(navigator.vibrate)navigator.vibrate([400,120,400,120,400]);
  somCancelTimer=setInterval(()=>{
    if(!audioLiberado||!cancelamentosEmAlerta.size){pararAlarmeCancelamento();return;}
    tocarSomCancelado();
    if(navigator.vibrate)navigator.vibrate([400,120,400]);
  },SOM_CANCEL_INTERVALO);
  return true;
}
function pararAlarmeCancelamento(){
  if(somCancelTimer){clearInterval(somCancelTimer);somCancelTimer=null;}
  cancelamentosEmAlerta.clear();
  renderizarFaixaCancelamento();
  if(pedidosEmAlerta.size&&audioLiberado)iniciarAlertaSonora(); // volta a campainha dos pedidos pendentes
}
function registrarCancelamentoDeOutro(p){
  const quem=p.cancelamentoMaster?'pela plataforma':'pelo cliente';
  cancelamentosEmAlerta.set(p.key,{numero:p.numeroPedido||String(p.key).slice(-6),quem,cliente:p.cliente?.nombre||'Cliente',total:Number(p.total)||0});
  renderizarFaixaCancelamento();
  iniciarAlarmeCancelamento(); // sem áudio liberado fica pendente: toca assim que o som for ativado
}
function renderizarFaixaCancelamento(){
  let el=$('faixa-cancelamento');
  if(!cancelamentosEmAlerta.size){if(el)el.remove();return;}
  if(!el){
    el=document.createElement('div');el.id='faixa-cancelamento';el.setAttribute('role','alert');
    el.innerHTML='<i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i><div class="faixa-cancel-texto"><strong></strong><span></span></div><button type="button" class="faixa-cancel-btn">Entendi, parar alarme</button>';
    el.querySelector('button').addEventListener('click',pararAlarmeCancelamento);
    document.body.appendChild(el);
  }
  const itens=[...cancelamentosEmAlerta.values()];
  el.querySelector('strong').textContent=itens.length>1?`${itens.length} pedidos cancelados`:`Pedido #${itens[0].numero} cancelado ${itens[0].quem}`;
  el.querySelector('span').textContent=itens.length>1?itens.map(i=>`#${i.numero}`).join(' · '):`${itens[0].cliente} · ${moeda(itens[0].total)}. Confira antes de preparar ou entregar.`;
  el.classList.toggle('sem-som',!audioLiberado);
  if(!audioLiberado)el.querySelector('span').textContent+=' · Ative o som para ouvir o alarme.';
}
function mostrarNotificacaoVisual(ids){
  renderizarOverlayPedido();
  if('Notification' in window && Notification.permission==='granted'){
    const pedido=pedidoParaAlerta(), numero=pedido?.numeroPedido||pedido?.key||'', cliente=pedido?.cliente?.nombre||'Cliente';
    try{new Notification('Novo pedido',{body:numero?`Pedido #${numero} · ${cliente}`:'Há um pedido pendente',tag:'delivery-pedido'});}catch{}
  }
}
function abrirDialogoPedido(){renderizarOverlayPedido();}
function iniciarAlertaSonora(){
  if(!audioLiberado||!pedidosEmAlerta.size)return false;
  if(somCancelTimer)return false; // volta quando o alarme de cancelamento parar
  if(somLoopAtivo)return true;
  somLoopAtivo=true;
  tocarSemoCampana();
  if(navigator.vibrate)navigator.vibrate([180,90,180]);
  somLoopTimer=setInterval(()=>{
    if(!audioLiberado||!pedidosEmAlerta.size){detenerAlertaSonora();return;}
    if(somCancelTimer)return; // alarme de cancelamento em andamento tem prioridade
    tocarSemoCampana();
    if(navigator.vibrate)navigator.vibrate([160,80,160]);
  },SOM_LOOP_INTERVALO);
  return true;
}
function detenerAlertaSonora(){
  if(somLoopTimer){clearInterval(somLoopTimer);somLoopTimer=null;}
  if(somTresSegTimer){clearInterval(somTresSegTimer);somTresSegTimer=null;}
  somLoopAtivo=false;
}
function testarSomCancelamento(){liberarAudio().then(ok=>{if(!ok)return;tocarSomCancelado();setTimeout(tocarSomCancelado,2400);if(navigator.vibrate)navigator.vibrate([400,120,400]);});}
function testarSom(){liberarAudio().then(ok=>{if(!ok)return;tocarSemoCampana();if(navigator.vibrate)navigator.vibrate([120,70,120]);});}

// ---- Controle de estoque (V75.14) ----
// Baixa feita pelo ADM ao aceitar o pedido (as regras do Firebase não deixam o cliente alterar o cardápio).
// A marca em restaurantes_privado garante que o mesmo pedido nunca baixe duas vezes (aceite manual, automático ou outra aba).
async function ajustarEstoquePedido(p,sinal){
  // V75.128: combo baixa o estoque dele e o de cada produto que ele inclui (lista gravada na linha do pedido)
  const baixas=[];
  for(const it of (p.itens||[])){
    const q=Math.max(1,parseInt(it.qtd,10)||1);
    if(it?.id)baixas.push({id:it.id,qtd:q});
    for(const c of (Array.isArray(it?.combo)?it.combo:[]))if(c?.id)baixas.push({id:c.id,qtd:q*Math.max(1,parseInt(c.qtd,10)||1)});
  }
  for(const it of baixas){
    const qtd=it.qtd;
    if(!it.id)continue;
    try{
      await runTransaction(ref(db,`restaurantes/${lojaId}/menu/${it.id}`),m=>{
        if(m===null||m.controlaEstoque!==true)return m;
        m.estoque=Math.max(0,(Number(m.estoque)||0)+sinal*qtd);
        return m;
      });
      const local=lojaDados?.menu?.[it.id];
      if(local&&local.controlaEstoque===true)local.estoque=Math.max(0,(Number(local.estoque)||0)+sinal*qtd);
    }catch(err){console.error('Estoque: falha ao ajustar',it.id,err)}
  }
  try{renderizarCardapio(lojaDados?.menu||{})}catch{}
}
async function baixarEstoquePedido(p){
  try{
    if(!lojaId||!p?.key||!Array.isArray(p.itens)||!p.itens.length)return;
    const r=await runTransaction(ref(db,`restaurantes_privado/${lojaId}/estoque_baixas/${p.key}`),v=>v===null?{em:new Date().toISOString()}:undefined);
    if(r.committed)await ajustarEstoquePedido(p,-1);
  }catch(err){console.error('Estoque: baixa não concluída',err)}
}
async function devolverEstoquePedido(p){
  try{
    if(!lojaId||!p?.key||!Array.isArray(p.itens)||!p.itens.length)return;
    const r=await runTransaction(ref(db,`restaurantes_privado/${lojaId}/estoque_baixas/${p.key}`),v=>(v&&!v.devolvido)?{...v,devolvido:true}:undefined);
    if(r.committed)await ajustarEstoquePedido(p,1);
  }catch(err){console.error('Estoque: devolução não concluída',err)}
}

// ---- Presente fidelidade (V75.17) ----
let fidelidadeCfgRaw=null;
const cfgFidAtual=()=>configFidelidade(fidelidadeCfgRaw);
function lerFormFidelidade(){
  return{ativo:$('fid-ativo').checked,meta:Math.floor(Number($('fid-meta').value)||0),tipo:$('fid-tipo').value,
    valor:Math.max(0,Number($('fid-valor').value)||0),valorMaximo:Math.max(0,Number($('fid-max').value)||0),minimoPedido:Math.max(0,Number($('fid-minimo').value)||0)};
}
function ajustarCamposFidelidade(){
  const t=$('fid-tipo').value;
  $('fid-valor-wrap').hidden=!(t==='fixo'||t==='porcentagem');
  $('fid-max-wrap').hidden=!(t==='porcentagem'||t==='pedido_gratis');
  $('fid-valor-label').textContent=t==='porcentagem'?'Desconto (%)':'Valor do desconto (R$)';
  $('fid-max-label').textContent=t==='pedido_gratis'?'Valor máximo do pedido grátis (R$) *':'Teto do desconto (R$, opcional)';
  const f=lerFormFidelidade();
  const c=configFidelidade({...f,ativo:true});
  $('fid-resumo').textContent=c
    ?`A cada ${c.meta} pedidos concluídos${c.minimoPedido>0?` (de pelo menos R$ ${c.minimoPedido.toFixed(2).replace('.',',')})`:''} o cliente ganha: ${c.titulo}. O presente não soma com cupom, só vale para o cliente que o ganhou e pedidos que usam presente não avançam a meta.`
    :'Complete os campos: meta de 2 a 30, e o valor do presente (pedido grátis exige um valor máximo para proteger a loja).';
}
function renderizarFidelidade(raw){
  fidelidadeCfgRaw=raw||null;
  const r=raw||{};
  $('fid-ativo').checked=r.ativo===true;
  $('fid-meta').value=r.meta||10;
  $('fid-minimo').value=r.minimoPedido||0;
  $('fid-tipo').value=TIPOS_PREMIO[r.tipo]?r.tipo:'frete_gratis';
  $('fid-valor').value=r.valor||0;
  $('fid-max').value=r.valorMaximo||0;
  ajustarCamposFidelidade();
}
['fid-meta','fid-minimo','fid-tipo','fid-valor','fid-max'].forEach(id=>$(id)?.addEventListener('input',ajustarCamposFidelidade));
$('form-fidelidade')?.addEventListener('submit',async e=>{
  e.preventDefault();if(!lojaId)return;
  const f=lerFormFidelidade();
  const status=$('fid-status');
  if(f.ativo&&!configFidelidade({...f,ativo:true})){alert('Confira os campos: meta de 2 a 30 pedidos e o valor do presente. Pedido grátis exige um valor máximo.');return}
  const antes=fidelidadeCfgRaw||{};
  const dados={ativo:f.ativo,meta:f.meta>=2?Math.min(30,f.meta):10,tipo:f.tipo,valor:f.valor,valorMaximo:f.valorMaximo,minimoPedido:f.minimoPedido,
    // A contagem começa quando o programa é ligado (não vale retroativo); editar o presente não reinicia.
    inicioEm:f.ativo?((antes.ativo===true&&antes.inicioEm)?antes.inicioEm:new Date().toISOString()):(antes.inicioEm||'')};
  try{
    await set(ref(db,`restaurantes/${lojaId}/fidelidade`),dados);
    fidelidadeCfgRaw=dados;
    if(status){status.textContent='Salvo';setTimeout(()=>{status.textContent=''},2500)}
    toast(f.ativo?'Presente fidelidade salvo. A contagem vale para pedidos feitos a partir de agora.':'Presente fidelidade desligado.','success',6000);
  }catch(err){console.error(err);alert('Não foi possível salvar o presente fidelidade.')}
});
function textoFidelidadePedido(p){
  if(!p?.premioFidelidade)return '';
  const c=conferePremioPedido(p,pedidosDaLoja,cfgFidAtual());
  const base=`<i class="fa-solid fa-gift" aria-hidden="true" style="color:#e0a100"></i> Presente fidelidade: ${escapeHtml(p.premioFidelidade.titulo||'')} · −${moeda(Number(p.premioFidelidade.desconto)||Number(p.desconto)||0)}`;
  if(!c)return{classe:'',html:base};
  return c.ok?{classe:'ok',html:`${base} · confere: ${c.concluidos} pedido(s) concluído(s)`}:{classe:'alerta',html:`${base} · ⚠ não confere. ${escapeHtml(c.motivo)} Confirme com o cliente antes de aceitar.`};
}

// ---- Reembolso (V75.16) ----
// Pedido de reembolso do cliente: som em loop + overlay até aceitar ou recusar. Aceitar cancela o pedido.
// Loja cancelou pedido já pago: o reembolso nasce aprovado (a devolução do dinheiro é manual no Mercado Pago).
const reembolsosEmAlerta=new Set();let somReembolsoTimer=null;
function tocarSomReembolso(){
  const c=prepararAudio();
  if(!c||!audioLiberado||c.state!=='running')return false;
  try{
    [0,.22,.55,.77].forEach((t,i)=>{
      const o=c.createOscillator(),g=c.createGain(),ini=c.currentTime+t;
      o.type='square';o.frequency.setValueAtTime(i%2?1175:880,ini);o.connect(g);g.connect(c.destination);
      g.gain.setValueAtTime(.0001,ini);g.gain.exponentialRampToValueAtTime(.09,ini+.015);g.gain.exponentialRampToValueAtTime(.0001,ini+.17);
      o.start(ini);o.stop(ini+.19);
    });
    return true;
  }catch{return false}
}
function reembolsoParaAlerta(){return pedidosDaLoja.find(p=>reembolsosEmAlerta.has(p.key)&&p.reembolso?.status===REEMBOLSO.SOLICITADO)||null}
function renderizarOverlayReembolso(){
  const overlay=$('overlay-reembolso');if(!overlay)return;
  const p=reembolsoParaAlerta();
  if(!p){overlay.hidden=true;return}
  const r=p.reembolso||{};
  const fone=String(p.cliente?.telefono||'').replace(/\D/g,'');
  $('overlay-reembolso-numero').textContent=`Pedido #${p.numeroPedido||p.key}`;
  $('overlay-reembolso-cliente').textContent=p.cliente?.nombre||'Cliente';
  $('overlay-reembolso-telefone').innerHTML=fone?`<a href="https://wa.me/${fone}" target="_blank" rel="noopener">${escapeHtml(p.cliente?.telefono||fone)}</a>`:'Não informado';
  $('overlay-reembolso-pagamento').textContent=r.formaPagamento||rotuloPagamento(p.formaPagamento)||'Não informado';
  $('overlay-reembolso-valor').textContent=moeda(Number(r.valor)||Number(p.total)||0);
  $('overlay-reembolso-motivo').textContent=r.motivo||'Não informado';
  $('overlay-reembolso-comentario').textContent=r.comentario||'Sem comentário';
  const n=reembolsosEmAlerta.size;
  $('overlay-reembolso-contador').textContent=n>1?`${n} solicitações aguardando decisão`:'Aguardando sua decisão';
  const h=historicoCliente(pedidosDaLoja,p.clienteUid,p.key);
  const partes=[`${h.pedidos} pedido(s) anteriores`,`${h.entregues} entregue(s)`,`${h.cancelados} cancelado(s)`,`${h.reembolsos} reembolso(s) (${h.aprovados} aprovado(s), ${h.recusados} recusado(s))`];
  if(h.valorReembolsado>0)partes.push(`${moeda(h.valorReembolsado)} já reembolsado`);
  $('overlay-reembolso-historico').textContent=(h.alerta?'Atenção · ':'')+partes.join(' · ');
  const resp=$('overlay-reembolso-resposta');
  if(resp&&overlay.dataset.pedido!==p.key){resp.value='';overlay.dataset.pedido=p.key}
  overlay.hidden=false;
}
function sincronizarReembolsos(){
  const pendentes=new Set(pedidosDaLoja.filter(p=>p.reembolso?.status===REEMBOLSO.SOLICITADO).map(p=>p.key));
  for(const id of [...reembolsosEmAlerta])if(!pendentes.has(id))reembolsosEmAlerta.delete(id);
  pendentes.forEach(id=>reembolsosEmAlerta.add(id));
  renderizarOverlayReembolso();
  if(reembolsosEmAlerta.size){
    if(!somReembolsoTimer){
      tocarSomReembolso();
      somReembolsoTimer=setInterval(()=>{
        if(!reembolsosEmAlerta.size){clearInterval(somReembolsoTimer);somReembolsoTimer=null;return}
        tocarSomReembolso();
      },3500);
    }
  }else if(somReembolsoTimer){clearInterval(somReembolsoTimer);somReembolsoTimer=null}
}

// Executa a devolução pelo Mercado Pago e avisa o resultado. A decisão (aprovar) já foi gravada antes.
async function executarDevolucao(p,manual=false){
  if(!p?.paymentIdMP&&!devolveSoEmSaldo(p))return {semPagamentoOnline:true};
  // V75.145: loja com reembolso em saldo → o cliente tem 48 h para escolher (dinheiro ou saldo); a devolução automática espera
  if(!manual&&aguardandoEscolha(p,lojaDados)){toast(`Reembolso de ${moeda(Number(p.reembolso?.valor)||0)} aprovado. O cliente escolhe entre o dinheiro de volta e o saldo na sua loja (até 48 h).`,'info',9000);return {aguardando:true}}
  try{
    const r=await devolverPeloMercadoPago(p.key);
    toast(r.valorMP>0?`Reembolso de ${moeda(r.valorMP)} devolvido ao cliente pelo Mercado Pago${r.valorSaldo>0?` e ${moeda(r.valorSaldo)} como saldo na loja`:''}.`:`Reembolso de ${moeda(r.valorSaldo||r.valor)} devolvido como saldo na loja.`,'success',8000);
    return {ok:true};
  }catch(err){
    console.warn('Devolução:',err);
    toast(`Reembolso aprovado, mas a devolução falhou: ${err.message} Use o botão "Devolver pelo Mercado Pago" no pedido.`,'error',10000);
    return {ok:false};
  }
}
async function decidirReembolso(aceitar){
  const p=reembolsoParaAlerta();if(!p)return;
  const agora=new Date().toISOString();
  const resposta=($('overlay-reembolso-resposta')?.value||'').trim().slice(0,300);
  if(!aceitar&&resposta.length<5){
    toast('Informe o motivo da recusa (mínimo de 5 caracteres). Ele fica registrado.','error',6000);
    $('overlay-reembolso-resposta')?.focus();
    return;
  }
  const botoes=[$('btn-reembolso-aceitar'),$('btn-reembolso-recusar')];
  botoes.forEach(b=>{if(b)b.disabled=true});
  try{
    await update(ref(db,`pedidos/${p.key}/reembolso`),{status:aceitar?REEMBOLSO.APROVADO:REEMBOLSO.RECUSADO,respondidoEm:agora,statusPedidoNaDecisao:normalizarStatus(p.status),entregaConfirmadaNaDecisao:p.entregaConfirmada===true,...(usuarioAtual?.uid?{decididoPor:usuarioAtual.uid}:{}),...(resposta?{resposta}:{})});
    if(aceitar&&normalizarStatus(p.status)!==STATUS.CANCELADO){
      cancelamentosLocais.add(p.key);
      await update(ref(db,`pedidos/${p.key}`),{status:STATUS.CANCELADO,atualizadoEm:agora});
      void devolverEstoquePedido(p);
    }
    reembolsosEmAlerta.delete(p.key);
    renderizarOverlayReembolso();
    if(!reembolsosEmAlerta.size&&somReembolsoTimer){clearInterval(somReembolsoTimer);somReembolsoTimer=null}
    if(!aceitar)toast('Reembolso recusado.','info',7000);
    else{const e=await executarDevolucao({...p,reembolso:{...(p.reembolso||{}),status:REEMBOLSO.APROVADO}});if(e.semPagamentoOnline)toast('Reembolso aprovado. Este pedido não foi pago online: devolva o valor direto ao cliente.','success',8000)}
  }catch(err){console.error(err);alert('Não foi possível registrar a decisão do reembolso.')}
  finally{botoes.forEach(b=>{if(b)b.disabled=false})}
}
// V75.145 — Finanças: saldo dos clientes nesta loja (saldos_mov/{lojaId}, só a API grava)
let unsubSaldos=null,saldosLojaId=null;
function iniciarSaldosLoja(id){
  if(saldosLojaId===id)return;
  unsubSaldos?.();saldosLojaId=id;
  unsubSaldos=onValue(ref(db,`saldos_mov/${id}`),snap=>pintarSaldosLoja(snap.val()||{}),err=>console.warn('Saldos da loja:',err));
}
function pintarSaldosLoja(movs){
  const card=$('card-saldo-clientes');if(!card)return;
  const r=resumoSaldos(movs);
  card.hidden=!r.movimentos&&!configSaldoLoja(lojaDados).ativo;
  $('fs-aberto').textContent=moeda(r.emAberto);$('fs-emitido').textContent=moeda(r.emitido);$('fs-bonus').textContent=moeda(r.bonus);$('fs-usado').textContent=moeda(r.usado);
  $('fs-clientes').textContent=r.clientes?`${r.clientes} cliente${r.clientes>1?'s':''} com saldo para usar na sua loja.${r.devolvido>0?` ${moeda(r.devolvido)} voltaram como saldo em pedidos cancelados.`:''}`:'Nenhum cliente com saldo agora.';
}
// V75.145: pedido cancelado que usou saldo e não foi pago (Pix pendente, pagar na entrega): o saldo volta ao cliente
function devolverSaldoSeNaoPago(p){
  if(!p||!(saldoUsado(p)>0)||normalizarPagamento(p.pagoStatus)===PAGO.APROVADO)return;
  devolverSaldoDoPedido(p.key).then(r=>toast(`${moeda(r.valor)} voltaram para o saldo do cliente.`,'info',6000)).catch(err=>console.warn('Saldo do pedido cancelado:',err));
}
async function registrarReembolsoLoja(p){
  try{
    devolverSaldoSeNaoPago(p);
    if(!p||normalizarPagamento(p.pagoStatus)!==PAGO.APROVADO)return;
    const r=p.reembolso;
    if(r&&r.status!==REEMBOLSO.SOLICITADO)return;
    let dados;
    if(r){dados={...r,status:REEMBOLSO.APROVADO};await update(ref(db,`pedidos/${p.key}/reembolso`),{status:REEMBOLSO.APROVADO,respondidoEm:new Date().toISOString()})}
    else{dados=montarReembolsoLoja(p);await set(ref(db,`pedidos/${p.key}/reembolso`),dados)}
    const e=await executarDevolucao({...p,reembolso:dados});
    if(e.semPagamentoOnline)toast('Pedido pago fora do app cancelado: devolva o valor direto ao cliente.','info',8000);
  }catch(err){console.warn('Reembolso da loja não registrado:',err)}
}

// Reembolso decidido pela loja (V75.16.1): pedido já aceito, valor total ou parcial.
let reembolsoLojaKey=null;
function abrirModalReembolsoLoja(p){
  const m=$('modal-reembolso-loja');if(!m||!p)return;
  reembolsoLojaKey=p.key;
  $('modal-reembolso-loja-titulo').textContent=`Pedido #${p.numeroPedido||p.key}`;
  $('modal-reembolso-loja-info').textContent=pagoNaEntrega(p)?`Total pago na entrega: ${moeda(Number(p.total)||0)} · ${p.formaPagamento||''}. Você devolve o valor direto ao cliente; ele sai das Finanças e a comissão do YAPOOD diminui na mesma proporção.`:`Total pago: ${moeda(Number(p.total)||0)} · ${p.formaPagamento||''}`;
  $('reembolso-loja-valor').value=(Number(p.total)||0).toFixed(2);
  $('reembolso-loja-motivo').value=p.relato&&p.relato.status===RELATO.ABERTO?`Relato do cliente: ${p.relato.motivo||''}`.slice(0,120):'';
  const cancelado=normalizarStatus(p.status)===STATUS.CANCELADO,entregue=normalizarStatus(p.status)===STATUS.ENTREGUE;
  // V75.101: reembolso total cancela o pedido também depois de entregue (antes ficava "Entregue" com o valor integral nas Finanças)
  $('reembolso-loja-cancelar').checked=!cancelado;
  $('reembolso-loja-cancelar').disabled=cancelado;
  const sincronizar=()=>{if(cancelado)return;const total=Number(p.total)||0,v=Number(String($('reembolso-loja-valor').value).replace(',','.'))||0,cheio=v>=total-0.009;$('reembolso-loja-cancelar').checked=cheio||!entregue}; // parcial em pedido entregue: segue "Entregue"
  $('reembolso-loja-valor').oninput=sincronizar;sincronizar();
  $('reembolso-loja-erro').hidden=true;
  m.hidden=false;
}
function fecharModalReembolsoLoja(){const m=$('modal-reembolso-loja');if(m)m.hidden=true;reembolsoLojaKey=null}
async function confirmarReembolsoLoja(){
  const p=pedidosDaLoja.find(x=>x.key===reembolsoLojaKey);if(!p)return;
  const erro=$('reembolso-loja-erro'),btn=$('btn-reembolso-loja-confirmar');
  erro.hidden=true;
  try{
    const dados=montarReembolsoLojaManual(p,{valor:$('reembolso-loja-valor').value,motivo:$('reembolso-loja-motivo').value,por:usuarioAtual?.uid});
    btn.disabled=true;
    await set(ref(db,`pedidos/${p.key}/reembolso`),dados);
    if(p.relato&&p.relato.status===RELATO.ABERTO){
      try{await update(ref(db,`pedidos/${p.key}/relato`),montarReembolsoDoRelato({valor:dados.valor,resposta:dados.motivo,por:usuarioAtual?.uid,porTipo:'loja'}))}
      catch(err){console.warn('Relato não atualizado após o reembolso:',err)}
    }
    if(deveCancelarNoReembolso(p,dados,$('reembolso-loja-cancelar').checked)){
      cancelamentosLocais.add(p.key);
      await update(ref(db,`pedidos/${p.key}`),{status:STATUS.CANCELADO,atualizadoEm:dados.respondidoEm});
      void devolverEstoquePedido(p);
    }
    fecharModalReembolsoLoja();
    const e=await executarDevolucao({...p,reembolso:dados});
    if(e.semPagamentoOnline)toast(`Reembolso de ${moeda(dados.valor)} registrado. Este pedido não foi pago online: devolva o valor direto ao cliente e toque em "Já devolvi ao cliente".`,'success',9000)
  }catch(err){
    console.warn('Reembolso da loja:',err);
    erro.textContent=err?.message&&!/permission/i.test(err.message)?err.message:'Não foi possível registrar o reembolso.';
    erro.hidden=false;
  }finally{btn.disabled=false}
}
// ---- Relato de problema do cliente (V75.35) ----
let relatoLojaKey=null;
function abrirModalRelatoLoja(p){
  const m=$('modal-relato-loja');if(!m||!p?.relato)return;
  relatoLojaKey=p.key;const r=p.relato;
  $('relato-loja-titulo').textContent=`Pedido #${p.numeroPedido||p.key}`;
  $('relato-loja-info').textContent=`${p.cliente?.nombre||'Cliente'} · ${moeda(Number(p.total)||0)} · ${p.formaPagamento||''}`;
  $('relato-loja-motivo').textContent=r.motivo||'—';
  $('relato-loja-comentario').textContent=r.comentario||'Sem comentário';
  const foto=$('relato-loja-foto-row');foto.hidden=!r.foto;
  if(r.foto){$('relato-loja-foto').src=r.foto;$('relato-loja-foto-link').href=r.foto}
  $('relato-loja-contestacao-row').hidden=!r.contestacao;
  if(r.contestacao)$('relato-loja-contestacao').textContent=r.contestacao.comentario||'';
  $('relato-loja-resposta').value='';
  $('relato-loja-erro').hidden=true;
  $('btn-relato-loja-reembolsar').hidden=!lojaPodeReembolsar(p);
  m.hidden=false;
}
function fecharModalRelatoLoja(){const m=$('modal-relato-loja');if(m)m.hidden=true;relatoLojaKey=null}
async function responderRelatoLoja(decisao){
  const p=pedidosDaLoja.find(x=>x.key===relatoLojaKey);if(!p?.relato)return;
  const erro=$('relato-loja-erro'),botoes=['btn-relato-loja-recusar','btn-relato-loja-resolver','btn-relato-loja-reembolsar'].map($);
  erro.hidden=true;
  try{
    const patch=montarRespostaRelato(p.relato,{decisao,resposta:$('relato-loja-resposta').value,por:usuarioAtual?.uid,porTipo:'loja'});
    botoes.forEach(b=>{if(b)b.disabled=true});
    await update(ref(db,`pedidos/${p.key}/relato`),patch);
    fecharModalRelatoLoja();
    toast('Resposta enviada ao cliente.','success',6000);
  }catch(err){
    console.warn('Relato:',err);
    erro.textContent=err?.message&&!/permission/i.test(err.message)?err.message:erroBanco(err,'Não foi possível responder agora.');
    erro.hidden=false;
  }finally{botoes.forEach(b=>{if(b)b.disabled=false})}
}
$('btn-relato-loja-fechar')?.addEventListener('click',fecharModalRelatoLoja);
$('btn-relato-loja-recusar')?.addEventListener('click',()=>responderRelatoLoja(RELATO.RECUSADO));
$('btn-relato-loja-resolver')?.addEventListener('click',()=>responderRelatoLoja(RELATO.RESOLVIDO));
$('btn-relato-loja-reembolsar')?.addEventListener('click',()=>{const p=pedidosDaLoja.find(x=>x.key===relatoLojaKey);fecharModalRelatoLoja();if(p)abrirModalReembolsoLoja(p)});
$('btn-ver-relato')?.addEventListener('click',()=>{
  const p=pedidosDaLoja.find(lojaDeveResponder);if(!p)return;
  document.querySelector('.nav-btn[data-tab="modulo-pedidos"]')?.click();
  setTimeout(()=>{const card=document.querySelector(`[data-pedido="${CSS.escape(p.key)}"][data-acao="expandir"]`);if(card){if(card.getAttribute('aria-expanded')!=='true')card.click();card.scrollIntoView({block:'center'})}},120);
});
let relatosVistos=null;
function atualizarFaixaRelatos(){
  const n=pedidosDaLoja.filter(lojaDeveResponder).length,f=$('faixa-relatos');if(!f)return;
  f.hidden=!n;
  if(n)$('faixa-relatos-texto').textContent=n===1?'1 cliente relatou um problema e aguarda sua resposta (prazo de 24 h).':`${n} clientes relataram problemas e aguardam sua resposta (prazo de 24 h).`;
}
function avisarNovosRelatos(){
  const abertos=pedidosDaLoja.filter(lojaDeveResponder);
  if(relatosVistos){const novos=abertos.filter(p=>!relatosVistos.has(p.key));if(novos.length)toast(novos.length===1?`Novo problema relatado no pedido #${novos[0].numeroPedido||novos[0].key}. Responda em até 24 h.`:`${novos.length} novos problemas relatados por clientes. Responda em até 24 h.`,'error',12000)}
  relatosVistos=new Set(abertos.map(p=>p.key));
}
$('btn-reembolso-loja-fechar')?.addEventListener('click',fecharModalReembolsoLoja);
$('btn-reembolso-loja-confirmar')?.addEventListener('click',confirmarReembolsoLoja);
$('btn-reembolso-aceitar')?.addEventListener('click',()=>decidirReembolso(true));
$('btn-reembolso-recusar')?.addEventListener('click',()=>decidirReembolso(false));
async function aceitarPedidoAlerta(){
  const pedido=pedidoParaAlerta(); if(!pedido)return;
  const btn=$('btn-overlay-aceitar'); if(btn)btn.disabled=true;
  try{await update(ref(db,`pedidos/${pedido.key}`),{status:STATUS.PREPARANDO,atualizadoEm:new Date().toISOString()});void notificarClientePedido(pedido.key,STATUS.PREPARANDO);void baixarEstoquePedido(pedido);imprimirAutomatico(pedido);pedidosEmAlerta.delete(pedido.key);detenerAlertaSonora();renderizarOverlayPedido();if(pedidosEmAlerta.size)iniciarAlertaSonora();}
  catch(err){console.error(err);toast(erroBanco(err,'Não foi possível aceitar o pedido.'),'error',9000);if(btn)btn.disabled=false;}
}
async function recusarPedidoAlerta(){
  const pedido=pedidoParaAlerta(); if(!pedido)return;
  const btn=$('btn-overlay-recusar'); if(btn)btn.disabled=true;
  try{cancelamentosLocais.add(pedido.key);await update(ref(db,`pedidos/${pedido.key}`),{status:STATUS.CANCELADO,atualizadoEm:new Date().toISOString()});pedidosEmAlerta.delete(pedido.key);void registrarReembolsoLoja(pedido);detenerAlertaSonora();renderizarOverlayPedido();if(pedidosEmAlerta.size)iniciarAlertaSonora();}
  catch(err){console.error(err);toast(erroBanco(err,'Não foi possível recusar o pedido.'),'error',9000);if(btn)btn.disabled=false;}
}
function avisarNovoPedido(ids){
  const lista=Array.isArray(ids)?ids:[];
  if(!lista.length)return;
  const automatico=lojaDados?.aceitacaoAutomatica===true;
  if(automatico){
    const pedidosParaAceiter=lista
      .map(id=>pedidosDaLoja.find(p=>p.key===id))
      .filter(p=>p&&pedidoLiberado(p));
    if(!pedidosParaAceiter.length)return;
    Promise.all(pedidosParaAceiter.map(p=>
      update(ref(db,`pedidos/${p.key}`),{status:STATUS.PREPARANDO,atualizadoEm:new Date().toISOString()}).then(()=>{void baixarEstoquePedido(p);imprimirAutomatico(p);return notificarClientePedido(p.key,STATUS.PREPARANDO)})
    )).then(()=>{
      if(audioLiberado)tocarSomTresSegundos();
      else sonsAutomaticosPendentes=Math.min(sonsAutomaticosPendentes+1,5);
      pedidosParaAceiter.forEach(p=>pedidosEmAlerta.delete(p.key));
      fecharOverlayPedido();
    }).catch(err=>{
      console.error('Não foi possível aceitar automaticamente:',err);
      // Se o Firebase recusar a atualização, não ocultamos a decisão do operador.
      pedidosParaAceiter.forEach(p=>pedidosEmAlerta.add(p.key));
      mostrarNotificacaoVisual(pedidosParaAceiter.map(p=>p.key));
      if(!audioLiberado)sonsPendentes=Math.min(sonsPendentes+pedidosParaAceiter.length,5);
      else iniciarAlertaSonora();
    });
    return;
  }
  lista.forEach(id=>pedidosEmAlerta.add(id));
  mostrarNotificacaoVisual(lista);
  if('Notification' in window && Notification.permission==='default'){try{Notification.requestPermission().catch(()=>{});}catch{}}
  if(!audioLiberado){sonsPendentes=Math.min(sonsPendentes+Math.max(1,lista.length),5);return;}
  iniciarAlertaSonora();
}
$('btn-overlay-aceitar')?.addEventListener('click',aceitarPedidoAlerta);
$('btn-overlay-recusar')?.addEventListener('click',recusarPedidoAlerta);
$('btn-ativar-som')?.addEventListener('click',()=>liberarAudio());
$('btn-testar-som')?.addEventListener('click',testarSom);
$('btn-testar-som-cancelamento')?.addEventListener('click',testarSomCancelamento);
$('btn-sair-topo')?.addEventListener('click',()=>{signOut(auth).catch(err=>{console.error(err);alert('Não foi possível sair.')})});
const somJaAtivado=preferenciaSom();
atualizarEstadoSom(somJaAtivado?'Som ativado · aguardando permissão do navegador':'Som bloqueado',false);
if(somJaAtivado)liberarAudio();
['pointerdown','keydown','touchstart'].forEach(evt=>document.addEventListener(evt,()=>{if(preferenciaSom()&&!audioLiberado)liberarAudio();},{passive:true}));

function relatoLojaHtml(p,k){
  const r=p.relato;if(!r)return '';
  const quem=r.respondidoPorTipo==='master'?'pelo YAPOOD':'pela loja';
  return `<div class="order-relato ${escapeHtml(r.status||'aberto')}"><strong><i class="fa-solid fa-triangle-exclamation"></i> Problema relatado pelo cliente · ${escapeHtml(rotuloRelato(r))}</strong>
      <p>${escapeHtml(r.motivo||'')}${r.comentario?` · “${escapeHtml(r.comentario)}”`:''}</p>
      ${r.foto?`<a class="relato-foto" href="${escapeHtml(r.foto)}" target="_blank" rel="noopener"><img src="${escapeHtml(r.foto)}" alt="Foto enviada pelo cliente" loading="lazy"></a>`:''}
      ${r.resposta?`<p><b>Resposta ${quem}:</b> ${escapeHtml(r.resposta)}${r.valorReembolso?` · reembolso de ${moeda(r.valorReembolso)}`:''}</p>`:(r.valorReembolso?`<p>Reembolso de ${moeda(r.valorReembolso)} ${quem}.</p>`:'')}
      ${r.contestacao?`<p><b>O cliente contestou:</b> “${escapeHtml(r.contestacao.comentario)}”${r.respondidoPorTipo==='master'?'':' — o YAPOOD vai decidir.'}</p>`:''}
      ${r.status===RELATO.ABERTO?`<div class="relato-acoes"><button type="button" class="btn-primary" data-pedido="${k}" data-acao="relato"><i class="fa-solid fa-comment-dots"></i> Responder</button></div>`:''}</div>`;
}
const ROTULO_PROXIMO={[STATUS.PREPARANDO]:'Aceitar e preparar',[STATUS.ENTREGA]:'Enviar para entrega',[STATUS.ENTREGUE]:'Marcar como entregue'};
// V75.110: cartões abertos continuam abertos quando a lista é redesenhada (toda ação grava no Firebase e a lista refaz; antes o cartão fechava a cada toque)
const pedidosExpandidos=new Set();
function pedidoHtml(p,compact=false){
  const status=normalizarStatus(p.status),pago=normalizarPagamento(p.pagoStatus),prox=proximoStatus(status);
  const quando=p.criadoEm?new Date(p.criadoEm).toLocaleString('pt-BR'):'';
  if(compact)return `<div class="list-item"><div><span class="item-title">Pedido #${escapeHtml(p.numeroPedido||p.id||p.key)}</span><span class="item-sub">${escapeHtml(rotuloStatus(status))} · ${escapeHtml(quando)}</span></div><strong>${moeda(p.total)}</strong></div>`;
  const itens=(p.itens||[]).map(i=>`<li>${Number(i.qtd)||0}× ${escapeHtml(i.nombre)}${detalhesDaLinha(i).length?`<small class="extras-item">${escapeHtml(detalhesDaLinha(i).join(' · '))}</small>`:''} <span>${moeda((Number(i.precio)||0)*(Number(i.qtd)||0))}</span></li>`).join('');
  const fone=String(p.cliente?.telefono||'').replace(/\D/g,'');
  const espera=aguardandoPagamentoOnline(p);
  const retirada=p.tipoEntrega==='retirada';
  const encerrado=status===STATUS.ENTREGUE||status===STATUS.CANCELADO;
  const dinheiroPago=p.entregaConfirmada===true&&pago===PAGO.NA_ENTREGA; // entregador digitou o código = recebeu do cliente
  const k=escapeHtml(p.key);
  const aberto=pedidosExpandidos.has(p.key);
  return `<article class="order-card${aberto?' expanded':''} status-${FLUXO_STATUS.includes(status)?FLUXO_STATUS.indexOf(status):'x'}" data-pedido-search="${escapeHtml([p.numeroPedido,p.key,p.cliente?.nome,p.cliente?.nombre,p.cliente?.telefone,p.cliente?.telefono].filter(Boolean).join(' '))}">
    <button type="button" class="order-summary" data-pedido="${k}" data-acao="expandir" aria-expanded="${aberto}">
      <span class="order-summary-main"><strong>Pedido #${escapeHtml(p.numeroPedido||p.key)}${lojaDeveResponder(p)?'<span class="order-pill-relato">Relato</span>':''}</strong><small>${escapeHtml(p.cliente?.nombre||'Cliente')} · ${escapeHtml(quando)}</small></span>
      <span class="order-summary-side"><b>${moeda(p.total)}</b><span class="order-status">${escapeHtml(rotuloStatus(status))}</span><i class="fa-solid fa-chevron-down order-chevron" aria-hidden="true"></i></span>
    </button>
    <div class="order-details"${aberto?'':' hidden'}>
      <div class="order-client"><strong>${escapeHtml(p.cliente?.nombre||'Cliente')}</strong>${retirada?'<br><small><i class="fa-solid fa-store"></i> RETIRADA NA LOJA</small>':''}${fone?` · <a href="https://wa.me/${fone}" target="_blank" rel="noopener">${escapeHtml(p.cliente.telefono)}</a>`:''}<br><small>${retirada?escapeHtml('Cliente retira na loja'):escapeHtml(p.cliente?.direccion||'')}</small>${p.cliente?.observacion?`<br><small><em>${escapeHtml(p.cliente.observacion)}</em></small>`:''}${fone?`<div class="order-chat-action"><a class="btn-secondary" href="https://wa.me/${fone}" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Conversar com o cliente</a></div>`:''}</div>
      <ul class="order-items">${itens}</ul>
      ${retirada?'':`<div class="order-entrega"><i class="fa-solid fa-motorcycle" aria-hidden="true"></i> Entrega${p.bairro?` · Bairro ${escapeHtml(p.bairro)}`:''} · <b>${Number(p.precioEnvio??p.taxaEntrega)>0?moeda(Number(p.precioEnvio??p.taxaEntrega)):'Grátis'}</b></div>`}
      <div class="order-foot"><span>${dinheiroPago?'':escapeHtml(p.formaPagamento||'')+' · '}<b class="${(pago===PAGO.APROVADO||dinheiroPago)?'pay-ok':'pay-pend'}">${dinheiroPago?escapeHtml(rotuloPagamento(p.formaPagamento))+': pago':escapeHtml(rotuloPagamentoStatus(pago))}</b>${p.desconto>0?` · cupom ${escapeHtml(p.cupomCodigo||'')} −${moeda(p.desconto)}`:''}</span><strong>${moeda(p.total)}</strong></div>${saldoUsado(p)>0?`<div class="order-saldo"><i class="fa-solid fa-wallet" aria-hidden="true"></i> Saldo da loja: −${moeda(saldoUsado(p))} · ${valorACobrar(p)>0?`${pago===PAGO.NA_ENTREGA?'cobrar':'a pagar'} <b>${moeda(valorACobrar(p))}</b>`:'<b>pago com saldo</b>'}</div>`:''}${(()=>{const tt=trocoSeguro(p.troco)?.precisa?textoTroco(trocoSeguro(p.troco),moeda):'';return tt?`<div class="order-troco"><i class="fa-solid fa-money-bill-wave"></i> ${escapeHtml(tt)}</div>`:''})()}
      ${espera?(pagamentoRecusado(p)?'<div class="order-warn pay-recusado"><i class="fa-solid fa-circle-xmark"></i> Pagamento online recusado. Não prepare este pedido: o cliente pode tentar pagar de novo; se não pagar, cancele.</div>':'<div class="order-warn"><i class="fa-solid fa-hourglass-half"></i> Aguardando confirmação do pagamento online. Não prepare este pedido ainda.</div>'):''}
      ${p.premioFidelidade?(()=>{const f=textoFidelidadePedido(p);return `<div class="order-warn order-fid ${f.classe}">${f.html}</div>`})():''}
      ${p.reembolso?`<div class="order-warn order-refund ${escapeHtml(p.reembolso.status||'')}"><i class="fa-solid fa-rotate-left"></i> Reembolso ${escapeHtml(rotuloReembolso(p.reembolso).toLowerCase())} · ${moeda(Number(p.reembolso.valor)||Number(p.total)||0)}${p.reembolso.motivo?` · ${escapeHtml(p.reembolso.motivo)}`:''}${textoDevolucao(p,lojaDados)}</div>`:''}
      ${relatoLojaHtml(p,k)}
      <div class="order-actions">${encerrado?'':(prox?`<button type="button" class="btn-primary" data-pedido="${k}" data-acao="avancar" data-para="${escapeHtml(prox)}" ${espera?'disabled':''}>${ROTULO_PROXIMO[prox]}</button>`:'')}${encerrado?'':`<button type="button" class="mini-btn danger" data-pedido="${k}" data-acao="cancelar" title="Cancelar pedido"><i class="fa-solid fa-ban"></i></button>`}${devolucaoPossivel(p,lojaDados)?`<button type="button" class="btn-secondary" data-pedido="${k}" data-acao="devolver"><i class="fa-solid fa-${devolveSoEmSaldo(p)?'wallet':'money-bill-transfer'}"></i> ${devolveSoEmSaldo(p)?'Devolver em saldo':'Devolver pelo Mercado Pago'}</button>`:''}${devolucaoDiretaPendente(p)?`<button type="button" class="btn-secondary" data-pedido="${k}" data-acao="devolvido-direto"><i class="fa-solid fa-hand-holding-dollar"></i> Já devolvi ao cliente</button>`:''}${lojaPodeReembolsar(p)?`<button type="button" class="btn-secondary" data-pedido="${k}" data-acao="reembolsar"><i class="fa-solid fa-rotate-left"></i> Reembolso</button>`:''}<button type="button" class="btn-secondary order-print-btn" data-pedido="${k}" data-acao="imprimir"><i class="fa-solid fa-print"></i> Imprimir</button></div>
    </div>
  </article>`;
}
let avaliacoesLoja={};
function renderizarAvaliações(){
  const el=$('lista-avaliacoes-loja');if(!el)return;
  const entries=Object.entries(avaliacoesLoja||{}).sort((a,b)=>String(b[1]?.criadoEm||'').localeCompare(String(a[1]?.criadoEm||'')));
  el.innerHTML=entries.length?entries.map(([key,a])=>{const p=pedidosDaLoja.find(x=>x.key===key)||{};const media=Number(a.notaMedia)||((Number(a.notaComida||0)+Number(a.notaEntrega||0))/2);const resposta=String(a.respostaLoja||a.respuestaTienda||'').trim();return `<article class="evaluation-admin-card"><div class="evaluation-admin-head"><div><strong>Pedido #${escapeHtml(p.numeroPedido||key)}</strong><span>${a.criadoEm?escapeHtml(new Date(a.criadoEm).toLocaleString('pt-BR')):'Data não informada'} · ${escapeHtml(p.cliente?.nome||p.cliente?.nombre||'Cliente')}</span></div><strong class="evaluation-stars">${'★'.repeat(Math.max(0,Math.min(5,Math.round(media))))}${'☆'.repeat(Math.max(0,5-Math.round(media)))} <small>${media.toFixed(1)}</small></strong></div><div class="evaluation-scores"><span>Comida: <b>${Number(a.notaComida)||0}★</b></span><span>Entrega: <b>${Number(a.notaEntrega)||0}★</b></span></div>${a.comentario?`<p class="evaluation-comment">“${escapeHtml(a.comentario)}”</p>`:''}<div class="evaluation-tags">${[...(a.tagsComida||[]),...(a.tagsEntrega||[])].map(t=>`<span>${escapeHtml(t)}</span>`).join('')}</div><div class="evaluation-response">${a.comentario ? (resposta?`<label>Resposta da loja</label><textarea data-eval-response="${escapeHtml(key)}" maxlength="500" disabled readonly>${escapeHtml(resposta)}</textarea><small class="evaluation-answered"><i class="fa-solid fa-check"></i> Resposta enviada · avaliação publicada</small>`:`<label>Resposta da loja</label><textarea data-eval-response="${escapeHtml(key)}" maxlength="500" placeholder="Agradeça o comentário ou responda ao cliente..."></textarea><button type="button" class="btn-primary btn-save-eval" data-eval-save="${escapeHtml(key)}"><i class="fa-solid fa-reply"></i> Responder e publicar</button>`) : `<small class="evaluation-answered"><i class="fa-solid fa-circle-check"></i> Avaliação sem comentário · publicada automaticamente</small>`}</div></article>`}).join(''):'<div class="empty-state"><i class="fa-solid fa-star"></i><p>Ainda não há avaliações.</p></div>';
}
window.renderizarAvaliações=renderizarAvaliações;
async function carregarAvaliacoesLoja(){
  if(!lojaId)return;
  try{const s=await get(ref(db,`avaliacoes/${lojaId}`));avaliacoesLoja=s.exists()?s.val()||{}:{};renderizarAvaliações();}catch(err){console.error('Avaliações:',err);avaliacoesLoja={};renderizarAvaliações();}
}
async function responderAvaliacao(key,button){
  const area=document.querySelector(`[data-eval-response="${CSS.escape(key)}"]`);if(!area)return;const texto=area.value.trim();button.disabled=true;
  try{await update(ref(db,`avaliacoes/${lojaId}/${key}`),{respostaLoja:texto,respuestaTienda:texto,respostaLojaEm:new Date().toISOString()});avaliacoesLoja[key]={...(avaliacoesLoja[key]||{}),respostaLoja:texto,respuestaTienda:texto};renderizarAvaliações();}
  catch(err){console.error(err);alert('Não foi possível salvar a resposta.');button.disabled=false;}
}
$('lista-avaliacoes-loja')?.addEventListener('click',e=>{const b=e.target.closest('[data-eval-save]');if(b)responderAvaliacao(b.dataset.evalSave,b)});
function pedidoConcluidoVisivel(p){
  if(lojaDeveResponder(p))return true; // relato aguardando resposta nunca some da lista
  if(normalizarStatus(p.status)!==STATUS.ENTREGUE)return true;
  const fim=new Date(p.atualizadoEm||p.entregadoEm||p.finalizadoEm||p.criadoEm||0).getTime();
  return !Number.isFinite(fim)||Date.now()-fim<=24*60*60*1000;
}
function renderizarPedidos(){
  const lista=$('lista-pedidos-loja'),hist=$('lista-financas-pedidos'),overview=$('overview-pedidos-list');
  // V75.110: guarda a rolagem do quadro (lateral e de cada coluna) para o redesenho não "pular" a tela
  const rolagem={x:lista?.querySelector('.kds-board')?.scrollLeft||0,cols:[...(lista?.querySelectorAll('.kds-column-list')||[])].map(c=>c.scrollTop)};
  // Quando uma data específica está selecionada, o histórico daquele dia deve ser completo.
  // A regra de 24h vale apenas para a visão operacional sem filtro de data.
  const operacionais=filtroDataPedidoAtivo
    ? pedidosDaLoja
    : pedidosDaLoja.filter(pedidoConcluidoVisivel);
  const porData=filtroDataPedidoAtivo
    ? operacionais.filter(p=>lojaDeveResponder(p)||mesmoDiaInput(p,filtroDataPedido)) // relato aguardando resposta aparece em qualquer dia
    : operacionais;
  const mapaFiltroStatus={pendente:STATUS.PENDENTE,preparando:STATUS.PREPARANDO,entrega:STATUS.ENTREGA,entregue:STATUS.ENTREGUE,cancelado:STATUS.CANCELADO};
  let filtrados=filtroPedido==='todos'?porData:filtroPedido==='avaliacoes'?porData:porData.filter(p=>normalizarStatus(p.status)===mapaFiltroStatus[filtroPedido]);
  const busca=normalizarTexto(buscaPedido);
  if(busca) filtrados=filtrados.filter(p=>normalizarTexto([p.numeroPedido,p.key,p.cliente?.nome,p.cliente?.nombre,p.cliente?.telefone,p.cliente?.telefono].filter(Boolean).join(' ')).includes(busca));
  const dataLabel=filtroDataPedidoAtivo&&dataLocalInput(filtroDataPedido)?dataLocalInput(filtroDataPedido).toLocaleDateString('pt-BR'):'todos os dias';
  const activeStatuses=[STATUS.PENDENTE,STATUS.PREPARANDO,STATUS.ENTREGA,STATUS.ENTREGUE];
  if(!busca && filtroPedido==='todos' && !filtroDataPedidoAtivo){
    const colunas=activeStatuses.map(st=>{const items=filtrados.filter(p=>normalizarStatus(p.status)===st);return `<section class="kds-column"><header><strong>${escapeHtml(rotuloStatus(st))}</strong><span>${items.length}</span></header><div class="kds-column-list">${items.length?items.map(p=>pedidoHtml(p)).join(''):'<div class="kds-empty">Nenhum pedido</div>'}</div></section>`}).join('');
    const cancelados=filtrados.filter(p=>normalizarStatus(p.status)===STATUS.CANCELADO);
    lista.innerHTML=`<div class="kds-board">${colunas}${cancelados.length?`<section class="kds-column kds-cancelados"><header><strong>Cancelados</strong><span>${cancelados.length}</span></header><div class="kds-column-list">${cancelados.map(p=>pedidoHtml(p)).join('')}</div></section>`:''}</div>`;
  }else {
    lista.innerHTML=filtrados.length?`<div class="order-grid">${filtrados.map(p=>pedidoHtml(p)).join('')}</div>`:`<div class="empty-state"><i class="fa-solid fa-receipt"></i><p>Nenhum pedido encontrado.</p><small>Mostrando ${escapeHtml(dataLabel)}. Os pedidos anteriores continuam salvos no Firebase.</small></div>`;
  }
  hist.innerHTML=pedidosDaLoja.length?pedidosDaLoja.map(p=>pedidoHtml(p,true)).join(''):'<div class="empty-state"><i class="fa-solid fa-receipt"></i><p>Não há pedidos registrados.</p></div>';
  overview.innerHTML=operacionais.length?operacionais.slice(0,5).map(p=>pedidoHtml(p,true)).join(''):'<div class="empty-state"><i class="fa-solid fa-receipt"></i><p>Ainda não há pedidos.</p></div>';
  {const q=lista?.querySelector('.kds-board');if(q)q.scrollLeft=rolagem.x;lista?.querySelectorAll('.kds-column-list').forEach((c,i)=>{if(rolagem.cols[i])c.scrollTop=rolagem.cols[i]})}
  if(filtroPedido==='avaliacoes')renderizarAvaliações();
  $('pedidos-lista-panel')?.toggleAttribute('hidden',filtroPedido==='avaliacoes');$('avaliacoes-panel')?.toggleAttribute('hidden',filtroPedido!=='avaliacoes');
}
function comandaHtml(p){
  // V75.62: layout novo em js/comanda.js (logo, dados da loja, 58/80 mm, destaque do que cobrar e do troco)
  const pago=normalizarPagamento(p.pagoStatus);
  const loja={nome:lojaDados?.nombre||lojaDados?.nome||'',telefone:lojaDados?.telefono||lojaDados?.telefone||'',endereco:lojaDados?.direccion||lojaDados?.endereco||'',cidade:lojaDados?.cidade||lojaDados?.ciudad||''};
  return montarComanda({pedido:p,loja,moeda,forma:rotuloPagamento(p.formaPagamento)||'',pagamento:pago===PAGO.APROVADO?'online':pago===PAGO.NA_ENTREGA?'entrega':'pendente',troco:trocoSeguro(p.troco)});
}
function imprimirPedido(p,opts={}){
  // iframe oculto: não depende de pop-up (bloqueado em muitos celulares) e não fecha a janela sozinho.
  const f=document.createElement('iframe');
  f.setAttribute('aria-hidden','true');
  f.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
  document.body.appendChild(f);
  const remover=()=>setTimeout(()=>f.remove(),1000);
  try{
    const d=f.contentDocument||f.contentWindow.document;
    d.open();d.write(comandaHtmlCopias(p,copiasEfetivas()));d.close();
    const w=f.contentWindow;
    w.addEventListener('afterprint',remover);
    setTimeout(()=>{try{w.focus();w.print()}catch(err){console.warn('Impressão da comanda:',err);if(opts.silencioso)toast('Não foi possível imprimir o pedido automaticamente.','error',6000);else alert('Não foi possível abrir a impressão deste pedido.')}setTimeout(remover,60000)},250);
  }catch(err){console.warn('Impressão da comanda:',err);f.remove();alert('Não foi possível gerar a comanda.')}
}

// Mensagem de erro do banco: deixa claro quando a causa é regra do Firebase desatualizada.
const erroBanco=(e,padrao)=>/permission[_ -]?denied/i.test(String(e?.code||e?.message||''))?`${padrao} O banco recusou a gravação: confirme se as regras mais recentes do Firebase foram publicadas.`:padrao;
// Fluxo de status: o painel não tinha NENHUM controle para mudar o estado do pedido (o cliente ficava eternamente em "Pendente").
$('lista-pedidos-loja').addEventListener('click',async e=>{
  const b=e.target.closest('[data-acao]');if(!b)return;
  if(b.dataset.acao==='expandir'){
    const card=b.closest('.order-card'),details=card?.querySelector('.order-details');
    if(!card||!details)return;
    const aberto=!details.hidden;
    if(aberto)pedidosExpandidos.delete(b.dataset.pedido);else pedidosExpandidos.add(b.dataset.pedido);
    details.hidden=aberto;
    card.classList.toggle('expanded',!aberto);
    b.setAttribute('aria-expanded',String(!aberto));
    return;
  }
  const key=b.dataset.pedido;
  if(b.dataset.acao==='devolver'){
    const pedido=pedidosDaLoja.find(x=>x.key===key);
    const vr=Number(pedido?.reembolso?.valor)||Number(pedido?.total)||0;
    const txt=!pedido?'':devolveSoEmSaldo(pedido)?`Devolver ${moeda(vr)} ao cliente como saldo na sua loja (ele pagou com saldo)?`:saldoUsado(pedido)>0?`Devolver ao cliente: ${moeda(Math.min(vr,valorACobrar(pedido)))} pelo Mercado Pago${vr>valorACobrar(pedido)?` e ${moeda(arredSaldo(vr-valorACobrar(pedido)))} como saldo (a parte que ele pagou com saldo)`:''}?`:`Devolver ${moeda(vr)} ao cliente pelo Mercado Pago?`;
    if(pedido&&await confirmar({titulo:devolveSoEmSaldo(pedido)?'Devolver em saldo?':'Devolver o dinheiro?',texto:txt,rotulo:'Devolver agora'})){b.disabled=true;await executarDevolucao(pedido,true);b.disabled=false}
    return;
  }
  if(b.dataset.acao==='devolvido-direto'){ // V75.109: pedido pago na entrega — a loja confirma que devolveu o valor ao cliente
    const pedido=pedidosDaLoja.find(x=>x.key===key);
    const vr=Number(pedido?.reembolso?.valor)||0,emDinheiro=pedido?Math.min(vr,valorACobrar(pedido)):0,emSaldo=arredSaldo(vr-emDinheiro); // V75.145: a parte paga com saldo volta como saldo
    if(pedido&&devolucaoDiretaPendente(pedido)&&await confirmar({titulo:'Você já devolveu o valor?',texto:`Confirme só depois de devolver ${moeda(emDinheiro)} ao cliente.${emSaldo>0?` Os outros ${moeda(emSaldo)} (pagos com saldo) voltam sozinhos como saldo.`:''} O cliente verá que a devolução foi feita.`,rotulo:'Sim, já devolvi',cancelar:'Voltar'})){
      b.disabled=true;
      try{await update(ref(db,`pedidos/${key}/reembolso`),{devolvidoDiretoEm:new Date().toISOString()});toast('Devolução registrada.','success');if(emSaldo>0)devolverSaldoDoPedido(key).catch(err=>console.warn('Saldo da devolução direta:',err))}
      catch(err){console.warn('Devolução direta:',err);toast('Não foi possível registrar agora. Tente de novo.','error')}
      b.disabled=false;
    }
    return;
  }
  if(b.dataset.acao==='relato'){
    abrirModalRelatoLoja(pedidosDaLoja.find(x=>x.key===key));
    return;
  }
  if(b.dataset.acao==='reembolsar'){
    abrirModalReembolsoLoja(pedidosDaLoja.find(x=>x.key===key));
    return;
  }
  if(b.dataset.acao==='imprimir'){
    const pedido=pedidosDaLoja.find(x=>x.key===key);
    if(pedido) imprimirPedido(pedido);
    return;
  }
  const para=b.dataset.acao==='cancelar'?STATUS.CANCELADO:b.dataset.para;
  if(para===STATUS.CANCELADO&&!await confirmar({titulo:'Cancelar este pedido?',texto:'O cliente será notificado na tela de acompanhamento.',rotulo:'Cancelar pedido',perigo:true}))return;
  b.disabled=true;
  if(para===STATUS.ENTREGA){ // V75.57: lembra de atribuir o entregador (pode ter esquecido); nunca trava se a consulta falhar
    let lembrar=false;
    try{const pe=pedidosDaLoja.find(x=>x.key===key);lembrar=!!(pe&&!window.__yapoodParceira?.temCorridaAtiva?.(key)&&await window.__yapoodEntregadores?.lembrar?.(pe))}catch{lembrar=false}
    if(lembrar&&!await confirmar({titulo:'Nenhum entregador atribuído',texto:'Este pedido ainda não tem entregador. Se você esqueceu, toque em Voltar e atribua na aba Entregadores. Se a entrega é por conta própria ou de terceiro, pode enviar assim mesmo.',rotulo:'Enviar mesmo assim',cancelar:'Voltar'})){b.disabled=false;return}
  }
  // V75.99: confere o status mais recente que a loja recebeu antes de gravar. Tela antiga aberta não reaviva um pedido que o cliente cancelou
  // (nem refaz um já entregue); as regras do Firebase (rascunho V75.99) fazem a mesma barreira do lado do servidor.
  {
    const pe=pedidosDaLoja.find(x=>x.key===key),atual=pe?normalizarStatus(pe.status):null;
    if(atual===STATUS.CANCELADO&&para!==STATUS.CANCELADO){toast('Este pedido foi cancelado.','error',7000);b.disabled=false;return}
    if(atual===STATUS.ENTREGUE&&para!==STATUS.CANCELADO){toast('Este pedido já foi entregue.','info',6000);b.disabled=false;return}
    if(pe&&para!==STATUS.CANCELADO&&aguardandoPagamentoOnline(pe)){toast(pagamentoRecusado(pe)?'O pagamento online deste pedido foi recusado. Não prepare.':'O pagamento online ainda não foi confirmado. Não prepare este pedido ainda.','error',8000);b.disabled=false;return}
  }
  try{if(para===STATUS.CANCELADO)cancelamentosLocais.add(key);await update(ref(db,`pedidos/${key}`),{status:para,atualizadoEm:new Date().toISOString()});void notificarClientePedido(key,para);{const pe=pedidosDaLoja.find(x=>x.key===key);if(pe){if(para===STATUS.PREPARANDO){void baixarEstoquePedido(pe);imprimirAutomatico(pe)}else if(para===STATUS.CANCELADO){void devolverEstoquePedido(pe);void registrarReembolsoLoja(pe)}}}}
  catch(err){console.error(err);toast(erroBanco(err,'Não foi possível atualizar o pedido.'),'error',9000);b.disabled=false}
});
function atualizarVisaoGeral(){const menu=lojaDados?.menu||{},total=Object.keys(menu).length,fat=receitaTotal();$('overview-pedidos').textContent=String(pedidosDaLoja.length);$('overview-faturamento').textContent=moeda(fat);$('overview-produtos').textContent=String(total);const av=agregadoLoja?.avaliacaoMedia??lojaDados?.evaluacion??lojaDados?.avaliacao??lojaDados?.rating;const n=Number(av);if(Number.isFinite(n)&&n>0){$('overview-avaliacao').textContent=n.toFixed(1);$('overview-avaliacao-label').textContent=agregadoLoja?.totalAvaliacoes?`avaliação média · ${agregadoLoja.totalAvaliacoes} opiniões`:'avaliação média'}else{$('overview-avaliacao').textContent='—';$('overview-avaliacao-label').textContent='sem avaliações'}$('overview-cardapio-list').innerHTML=total?Object.entries(menu).slice(0,5).map(([k,x])=>`<div class="list-item"><div><span class="item-title">${escapeHtml(x.nombre||'Sem nome')}</span><span class="item-sub">${x.disponible===false?'Pausado':'Disponível'} · ${moeda(x.precio)}</span></div></div>`).join(''):'<div class="empty-state"><i class="fa-solid fa-utensils"></i><p>Não há produtos registrados.</p></div>'}

// V75.60: só os chips de STATUS dos pedidos (os chips de período das Finanças também têm a classe filter-chip e, antes, zeravam o filtro e esvaziavam a lista de pedidos)
document.querySelectorAll('.filter-chip[data-status]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.filter-chip[data-status]').forEach(x=>x.classList.remove('active'));b.classList.add('active');filtroPedido=b.dataset.status;renderizarPedidos()}));
const pedidosBusca=$('pedidos-busca');
const btnLimparBusca=$('btn-limpar-busca');
pedidosBusca?.addEventListener('input',()=>{buscaPedido=pedidosBusca.value||'';renderizarPedidos()});
btnLimparBusca?.addEventListener('click',()=>{if(pedidosBusca){pedidosBusca.value='';pedidosBusca.focus()}buscaPedido='';renderizarPedidos()});
const pedidosDataInput=$('pedidos-data');
if(pedidosDataInput){
  pedidosDataInput.value=filtroDataPedido;
  pedidosDataInput.addEventListener('change',()=>{filtroDataPedido=pedidosDataInput.value||dataISOlocal(new Date());filtroDataPedidoAtivo=true;renderizarPedidos()});
}
$('btn-pedidos-hoje')?.addEventListener('click',()=>{filtroDataPedido=dataISOlocal(new Date());filtroDataPedidoAtivo=true;if(pedidosDataInput)pedidosDataInput.value=filtroDataPedido;renderizarPedidos()});
$('btn-pedidos-todos')?.addEventListener('click',()=>{filtroDataPedidoAtivo=false;renderizarPedidos()});
function atualizarStatusSwitch(){const ativo=$('loja-status-ativo').checked;const label=$('loja-status-label');const help=$('loja-status-help');if(label)label.textContent=ativo?'Aberta — aceitando pedidos':'Datada temporariamente';if(help)help.textContent=ativo?'A loja está disponível para receber pedidos.':'A loja não aceitará novos pedidos.'}
$('loja-status-ativo').addEventListener('change',atualizarStatusSwitch);

// A aceitação automática é uma preferência operacional: ao mudar o switch,
// ela é salva imediatamente. Assim não depende do botão geral de configuração
// e continua ativa após atualizar/reabrir o painel.
$('aceitacao-automatica')?.addEventListener('change',async e=>{
  if(!lojaId)return;
  const checkbox=e.currentTarget;
  const anterior=lojaDados?.aceitacaoAutomatica===true;
  const novo=checkbox.checked===true;
  const status=$('config-save-status');
  checkbox.disabled=true;
  if(status)status.textContent=novo?'Salvando aceitação automática...':'Salvando alterações...';
  try{
    await update(ref(db,`restaurantes/${lojaId}`),{aceitacaoAutomatica:novo});
    if(lojaDados)lojaDados.aceitacaoAutomatica=novo;
    if(status)status.textContent=novo?'Aceitação automática ativada':'Aceitação automática desativada';
    setTimeout(()=>{if(status)status.textContent='';},2500);
  }catch(err){
    console.error('Não foi possível salvar a aceitação automática:',err);
    checkbox.checked=anterior;
    if(status)status.textContent='Não foi possível salvar a preferência.';
    alert(err.message||'Não foi possível salvar a aceitação automática.');
  }finally{
    checkbox.disabled=false;
  }
});


// ---- Impressão (V75.15): configuração por computador, só no desktop ----
const CHAVE_IMPRESSAO='yapood_impressao_v1';
const CHAVE_IMPRESSOS='yapood_impressos_v1';
const ehDesktop=()=>window.matchMedia('(min-width:1024px) and (hover:hover) and (pointer:fine)').matches;
function configImpressao(){
  let c={};try{c=JSON.parse(localStorage.getItem(CHAVE_IMPRESSAO)||'{}')||{}}catch{}
  const copias=Math.min(5,Math.max(1,parseInt(c.copias,10)||1));
  const modo=c.modo==='direta'?'direta':'perguntar';
  return{modo,copias,auto:c.auto===true&&modo==='direta'};
}
function salvarConfigImpressao(parcial){
  const c={...configImpressao(),...parcial};
  if(c.modo!=='direta')c.auto=false;
  try{localStorage.setItem(CHAVE_IMPRESSAO,JSON.stringify({modo:c.modo,copias:c.copias,auto:c.auto}))}catch(err){console.warn('Impressão: não foi possível salvar a preferência',err)}
}
// No celular nada muda: 1 cópia, sem impressão automática.
const copiasEfetivas=()=>ehDesktop()?configImpressao().copias:1;
function comandaHtmlCopias(p,n){
  const html=comandaHtml(p);
  if(n<=1)return html;
  const i=html.indexOf('<body>'),f=html.lastIndexOf('</body>');
  if(i<0||f<0)return html;
  const miolo=html.slice(i+6,f);
  const quebra='<div style="page-break-after:always;break-after:page;height:0"></div>';
  return html.slice(0,i+6)+Array.from({length:n},()=>miolo).join(quebra)+html.slice(f);
}
function imprimirAutomatico(p){
  try{
    if(!ehDesktop()||!configImpressao().auto||!p?.key)return;
    let vistos=[];try{vistos=JSON.parse(localStorage.getItem(CHAVE_IMPRESSOS)||'[]')}catch{}
    if(vistos.includes(p.key))return; // cada pedido imprime uma única vez neste computador
    vistos.push(p.key);
    try{localStorage.setItem(CHAVE_IMPRESSOS,JSON.stringify(vistos.slice(-200)))}catch{}
    imprimirPedido(p,{silencioso:true});
  }catch(err){console.warn('Impressão automática:',err)}
}
function iniciarConfigImpressao(){
  const bloco=$('config-impressao');if(!bloco)return;
  const modo=$('impressao-modo'),copias=$('impressao-copias'),auto=$('impressao-auto');
  const mostrar=()=>{bloco.hidden=!ehDesktop()};
  const aplicar=()=>{
    const c=configImpressao();
    modo.value=c.modo;copias.value=String(c.copias);auto.checked=c.auto;auto.disabled=c.modo!=='direta';
  };
  mostrar();aplicar();
  window.matchMedia('(min-width:1024px) and (hover:hover) and (pointer:fine)').addEventListener?.('change',mostrar);
  modo.addEventListener('change',()=>{salvarConfigImpressao({modo:modo.value});aplicar()});
  copias.addEventListener('change',()=>{salvarConfigImpressao({copias:parseInt(copias.value,10)||1});aplicar()});
  auto.addEventListener('change',()=>{salvarConfigImpressao({auto:auto.checked});aplicar()});
  $('btn-impressao-teste')?.addEventListener('click',()=>imprimirPedido({
    key:'TESTE',numeroPedido:'TESTE',criadoEm:new Date().toISOString(),tipoEntrega:'delivery',
    cliente:{nombre:'Cliente de teste',telefono:'(00) 00000-0000',direccion:'Rua de Teste, 123',referencia:'Perto da padaria'},
    itens:[{nombre:'Produto de teste',precio:10,qtd:1}],subtotal:10,precioEnvio:0,desconto:0,total:10,formaPagamento:'Teste'
  }));
}
iniciarConfigImpressao();

$('form-config-loja').addEventListener('submit',async e=>{
  e.preventDefault();
  if(!lojaId)return;
  const btn=e.submitter;
  const status=$('config-save-status');
  const ativo=$('loja-status-ativo')?.checked===true;
  moedaLoja='BRL';
  if(btn){btn.disabled=true;btn.dataset.oldHtml=btn.innerHTML;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Salvando...';}
  if(status)status.textContent='Salvando alterações...';
  try{
    await update(ref(db,`restaurantes/${lojaId}`), {
    activo: ativo, // <-- Aqui está a correção
    moeda: moedaLoja,
    aceitacaoAutomatica: $('aceitacao-automatica')?.checked===true,
    aceitaCartaoOnline: $('aceita-cartao-online')?.checked!==false
});

    definirMoedaAtual(moedaLoja);
    moedaLoja=normalizarMoeda(moedaLoja);
    await carregarLoja(lojaId);
    if(status)status.textContent=`Salvo · ${MOEDAS_SUPORTADAS[moedaLoja].codigo}`;
    setTimeout(()=>{if(status)status.textContent='';},3500);
  }catch(err){
    console.error('Erro ao salvar configuração:',err);
    if(status)status.textContent='Não foi possível salvar as alterações.';
    alert(err.message||'Não foi possível salvar a configuração.');
  }finally{
    if(btn){btn.disabled=false;btn.innerHTML=btn.dataset.oldHtml||'<i class="fa-solid fa-floppy-disk"></i> Salvar configuração';delete btn.dataset.oldHtml;}
  }
});

function navegarAba(id){
  const alvo=$(id);
  if(!alvo)return;
  document.querySelectorAll('.tab-content').forEach(x=>{
    const ativo=x===alvo;
    x.classList.toggle('active',ativo);
    x.setAttribute('aria-hidden',ativo?'false':'true');
  });
  document.querySelectorAll('.nav-btn').forEach(x=>x.classList.toggle('active',x.dataset.tab===id));
  // Não Android/Samsung não fazemos scroll síncrono ao trocar de aba.
  // Isso evita o efeito de deslocamento/"zoom" que pode ocorrer ao mudar o visual viewport.
  requestAnimationFrame(()=>{
    try { window.scrollTo({top:0,left:0,behavior:'auto'}); }
    catch { window.scrollTo(0,0); }
  });
  document.activeElement?.blur?.();
}
document.querySelectorAll('.nav-btn').forEach(b=>b.addEventListener('click',(e)=>{e.preventDefault();navegarAba(b.dataset.tab);}));
document.querySelectorAll('[data-tab-link]').forEach(b=>b.addEventListener('click',(e)=>{e.preventDefault();navegarAba(b.dataset.tabLink);}));


$('btn-login-google').addEventListener('click',async()=>{const btn=$('btn-login-google');btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Entrando...';try{const result=await signInWithPopup(auth,googleProvider);const user=result.user;const uref=ref(db,`usuarios/${user.uid}`);const snap=await get(uref);if(!snap.exists())await set(uref,{nome:user.displayName||'',email:user.email||'',foto:user.photoURL||'',criadoEm:new Date().toISOString()});}catch(err){console.error(err);alert('Não foi possível entrar com Google. Tente novamente.')}finally{btn.disabled=false;btn.innerHTML='<i class="fa-brands fa-google"></i> Entrar / criar conta com Google'}});
$('form-criar-loja').addEventListener('submit',async e=>{e.preventDefault();if(!usuarioAtual)return;const btn=e.submitter;btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Criando...';try{const id=await criarLoja(usuarioAtual,$('nova-loja-nome').value,$('nova-loja-cidade').value);$('nova-loja-nome').value='';showOnly('admin-app');loading.hidden=false;painel.hidden=true;await carregarLoja(id);navegarAba('modulo-loja')}catch(err){console.error(err);alert(err.message||'Não foi possível criar a loja.')}finally{btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-plus"></i> Criar minha loja'}});
$('btn-sair-criacao').addEventListener('click',()=>signOut(auth));$('btn-sair-cadastro').addEventListener('click',()=>signOut(auth));$('btn-sair').addEventListener('click',()=>signOut(auth));

onAuthStateChanged(auth,async user=>{usuarioAtual=user;fecharCadastro();if(!user){if(unsubPedidos){unsubPedidos();unsubPedidos=null}if(unsubPublicidade){unsubPublicidade();unsubPublicidade=null}pedidosLojaId=null;showOnly('auth-gate');return}prepararUsuário(user);showOnly('admin-app');loading.hidden=false;painel.hidden=true;limparErro();try{const id=await descobrirLoja(user);if(!id){showOnly('cadastro-gate');abrirCadastro({user,aprovado:(cad)=>{if(usuarioAtual?.uid!==user.uid)return;$('nova-loja-nome').value=cad?.nomeLoja||'';desenharSeletorCriacao();showOnly('create-store-gate')}});return}await carregarLoja(id)}catch(err){console.error(err);mostrarErro('Não foi possível carregar sua loja.',err.message||'Verifique a configuração do Firebase.')}});

// V75.12: leitura somente para o módulo de entregadores (js/entregadores-admin.js).
window.__yapood={get lojaId(){return lojaId},get pedidos(){return pedidosDaLoja},get loja(){return lojaDados}};
try{iniciarParceira()}catch(err){console.warn('Entrega parceira:',err)} // V75.112: botão "Chamar entregador parceiro" nos pedidos de entrega (módulo isolado)
