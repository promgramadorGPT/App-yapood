// js/master-rede.js — aba "Entrega parceira" do Master (V75.111 + V75.115).
// 1) Liberação para lojas (/rede/liberacao): desligada · só lojas de teste · todas; e se o cadastro novo de entregador passa por análise.
// 2) Entregadores: análise do cadastro (aprovar, recusar, bloquear, reativar) pela API 2.19 — o navegador não grava a situação.
// 3) Regras (/rede/config): os números da entrega parceira.
// Contas e validações em master-rede-util.js (testado). Aqui só há tela, leitura e gravação.
// Os dados de 1 e 2 chegam ao vivo pelos ouvintes do master.js (S.redeLib, S.redeEnts); as regras são lidas sob demanda.
import {
  GRUPOS, CAMPOS, PADRAO_REDE_MESTRE, mesclarConfig, paraTexto, lerFormulario, diferencas, resumoDiferencas, paraGravar, resumirEntregadores, fmtDuracao, formatarValor,
  MODOS_LIBERACAO, normalizarLiberacao, paraGravarLiberacao, validarLiberacao, diferencasLiberacao, resumoLiberacao, lojasParaEscolher,
  SITUACOES, acoesDaSituacao, ACAO_PARA_STATUS, FILTROS_ENTREGADOR, filtrarEntregadores, situacaoDocs,
  listarRelatos, listarExclusoes, diasDesde, PRAZO_LGPD_DIAS
} from './master-rede-util.js?v=75.144';

const API = 'https://api-mp-yapoodbr.onrender.com';

const ESTILO = `
#rede-raiz .rede-grupo{margin:18px 0 6px}
#rede-raiz .rede-grupo h3{font-size:1rem;margin:0 0 2px}
#rede-raiz .rede-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px 18px;margin-top:10px}
#rede-raiz .rede-campo{display:flex;flex-direction:column;gap:4px;min-width:0}
#rede-raiz .rede-rotulo{font-weight:700;font-size:.88rem}
#rede-raiz .rede-entrada{display:flex;align-items:center;gap:8px}
#rede-raiz .rede-entrada input{flex:1 1 auto;min-width:0}
#rede-raiz .rede-entrada em{font-style:normal;color:var(--m-suave);font-size:.85rem;white-space:nowrap}
#rede-raiz .rede-campo small{display:block}
#rede-raiz .rede-campo.invalido input{border-color:var(--m-erro)}
#rede-raiz .rede-campo.alterado input{border-color:var(--m-tinta);box-shadow:0 0 0 2px rgba(0,0,0,.06)}
#rede-raiz .rede-acoes{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:18px}
#rede-raiz .rede-chips{margin:6px 0 12px}
#rede-raiz .rede-modos{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;margin:12px 0}
#rede-raiz .rede-modo{display:flex;gap:10px;align-items:flex-start;padding:12px 14px;border:1px solid var(--m-linha);border-radius:12px;cursor:pointer;background:#fff}
#rede-raiz .rede-modo input{margin-top:3px;flex:none}
#rede-raiz .rede-modo b{display:block}
#rede-raiz .rede-modo span{font-size:.86rem;color:var(--m-suave)}
#rede-raiz .rede-modo.sel{border-color:var(--m-tinta);box-shadow:0 0 0 2px rgba(0,0,0,.08)}
#rede-raiz .rede-lojas{border:1px solid var(--m-linha);border-radius:12px;padding:12px;margin:6px 0 12px}
#rede-raiz .rede-lojas-lista{max-height:260px;overflow:auto;display:grid;gap:4px;margin-top:8px}
#rede-raiz .rede-loja{display:flex;gap:10px;align-items:center;padding:8px 6px;border-radius:8px;cursor:pointer}
#rede-raiz .rede-loja:hover{background:var(--m-fundo,#f5f6f8)}
#rede-raiz .rede-loja small{color:var(--m-suave)}
#rede-raiz .rede-chave{display:flex;gap:10px;align-items:center;font-weight:700;margin-top:6px;cursor:pointer}
#rede-raiz .rede-ent-acoes{display:flex;gap:6px;flex-wrap:wrap}
#rede-raiz .rede-ent-acoes .m-btn{min-height:36px;padding:0 12px}
#rede-raiz .rede-cpf{font-variant-numeric:tabular-nums;white-space:nowrap}
#rede-raiz .rede-link{background:none;border:0;padding:0;color:var(--m-tinta);text-decoration:underline;cursor:pointer;font:inherit;font-size:.82rem}
#rede-raiz .rede-motivo{display:block;margin-top:4px;font-size:.82rem;color:var(--m-suave)}
/* o master.css põe todo label em coluna: aqui rádio e caixinha ficam ao lado do texto */
#rede-raiz label.rede-modo,#rede-raiz label.rede-loja,#rede-raiz label.rede-chave{flex-direction:row;text-align:left}
#rede-raiz .rede-modo input,#rede-raiz .rede-loja input,#rede-raiz .rede-chave input{width:20px;height:20px;min-height:0;flex:none;margin:2px 0 0;accent-color:var(--m-marca)}
#rede-raiz .rede-modo>span{display:flex;flex-direction:column;gap:2px;font-weight:400}
#rede-raiz .rede-modo>span>b{color:var(--m-tinta)}
#rede-raiz .rede-loja>span{font-weight:600}
#rede-raiz .rede-chave{align-items:flex-start}
#rede-docs-modal{position:fixed;inset:0;background:rgba(15,20,25,.72);display:flex;align-items:center;justify-content:center;padding:16px;z-index:60}
#rede-docs-modal[hidden]{display:none}
#rede-docs-modal .rede-docs-caixa{background:#fff;border-radius:16px;max-width:980px;width:100%;max-height:calc(100vh - 32px);overflow:auto;padding:18px}
#rede-docs-modal .rede-docs-topo{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}
#rede-docs-modal h2{margin:0;font-size:1.1rem}
#rede-docs-modal .rede-docs-grade{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px;margin-top:12px}
#rede-docs-modal figure{margin:0;display:grid;gap:6px}
#rede-docs-modal figcaption{font-weight:700;font-size:.9rem}
#rede-docs-modal img{width:100%;max-height:60vh;object-fit:contain;background:#f2f4f6;border:1px solid var(--m-linha);border-radius:10px;cursor:zoom-in}
#rede-docs-modal img.ampliada{max-height:none;cursor:zoom-out}
#rede-raiz .rede-pedidos{display:grid;gap:10px;margin-top:10px}
#rede-raiz .rede-pedido{border:1px solid var(--m-linha);border-radius:12px;padding:12px 14px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;background:#fff}
#rede-raiz .rede-pedido.feito{opacity:.7}
#rede-raiz .rede-pedido>div:first-child{min-width:0;flex:1 1 320px}
#rede-raiz .rede-pedido b{display:block}
#rede-raiz .rede-pedido p{margin:4px 0 0}
#rede-raiz .rede-sub-titulo{display:flex;align-items:center;gap:8px;margin:16px 0 4px;font-size:1rem}
#rede-raiz .rede-prazo-vencendo{color:var(--m-erro);font-weight:700}
@media (max-width:760px){#rede-raiz .m-tabela td[data-label="Entregador"]{display:block;text-align:left}#rede-raiz .m-tabela td[data-label="Entregador"]::before{display:none}}
`;

/**
 * ctx: { S, $, esc, aviso, executar, confirmar, logar, db, ref, get, set, auth }  (todos já existem no master.js)
 * Devolve { render, pendentes }. Cria o conteúdo dentro de <div id="rede-raiz">.
 */
export function iniciarRedeMaster(ctx) {
  const { S, $, esc, aviso, executar, confirmar, logar, db, ref, get, set, auth } = ctx;
  const raiz = $('rede-raiz');
  if (!raiz) return { render() {}, pendentes: () => 0 };
  if (!document.getElementById('rede-estilo')) { const st = document.createElement('style'); st.id = 'rede-estilo'; st.textContent = ESTILO; document.head.appendChild(st); }

  // regras (/rede/config)
  let salva = null, carregando = false, carregadoEm = 0, falhouRegras = '', sujo = false;
  // liberação
  let libSalva = null, libEdit = null, libSujo = false, buscaLoja = '', chaveLojas = '', chaveLib = '';
  // entregadores
  let filtro = null, chaveEnts = '';
  const ocupados = new Set();
  const cpfs = {};

  const agoraIso = () => new Date().toISOString();
  const selo = (cls, txt) => `<span class="m-selo m-selo-${cls}">${esc(txt)}</span>`;
  const nomeLoja = (id) => String(S.lojas?.[id]?.nombre || S.lojas?.[id]?.nome || id);

  async function api(rota, corpo) {
    const token = await auth?.currentUser?.getIdToken();
    if (!token) throw new Error('Sessão Master não encontrada. Entre novamente.');
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 60000); // a API gratuita do Render pode demorar para acordar
    try {
      const r = await fetch(API + rota, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(corpo), signal: ctl.signal });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || d.error) {
        if (r.status === 404 && !d.error) throw new Error('A API ainda não tem esta função. Atualize a API no Render (2.28.0 ou mais nova).');
        const e = new Error(d.error || 'Não foi possível concluir.'); e.status = r.status; e.codigo = d.codigo || ''; e.dados = d; throw e;
      }
      return d;
    } catch (e) {
      if (e.name === 'AbortError') throw new Error('O servidor demorou para responder (pode estar acordando). Tente de novo em instantes.');
      if (e instanceof TypeError) throw new Error('Sem conexão com o servidor. Confira a internet e tente de novo.');
      throw e;
    } finally { clearTimeout(t); }
  }

  // ====================== desenho base ======================
  const campoHtml = (c) => {
    const id = `rede-f-${c.path.replace(/\./g, '-')}`;
    const padrao = formatarValor(c, c.path.includes('.') ? c.path.split('.').reduce((o, k) => o?.[k], PADRAO_REDE_MESTRE) : PADRAO_REDE_MESTRE[c.path]);
    const un = c.un && c.un !== 'HH:MM' ? `<em>${esc(c.un)}</em>` : '';
    const modo = c.tipo === 'dec' ? 'decimal' : c.tipo === 'int' ? 'numeric' : 'text';
    return `<label class="rede-campo" data-campo="${esc(c.path)}" for="${id}">
      <span class="rede-rotulo">${esc(c.rotulo)}</span>
      <span class="rede-entrada"><input id="${id}" data-path="${esc(c.path)}" type="text" inputmode="${modo}" autocomplete="off" spellcheck="false">${un}</span>
      <small class="m-nota">${esc(c.ajuda)} Padrão: ${esc(padrao)}.</small>
      <small class="m-nota m-nota-erro" data-erro role="alert" hidden></small>
      <small class="m-nota" data-dica></small>
    </label>`;
  };
  function desenharBase() {
    raiz.innerHTML = `
      <article class="m-card" id="rede-lib-card">
        <div class="m-card-topo"><div><h2>Liberação para lojas</h2><p class="m-sub" id="rede-lib-resumo">Carregando…</p></div></div>
        <p id="rede-lib-falha" class="m-nota m-nota-erro" role="alert" hidden></p>
        <form id="rede-lib-form" novalidate>
          <div class="rede-modos" role="radiogroup" aria-label="Quem vê a entrega parceira">
            ${MODOS_LIBERACAO.map((m) => `<label class="rede-modo" data-modo="${m.id}"><input type="radio" name="rede-lib-modo" value="${m.id}"><span><b>${esc(m.titulo)}</b><span>${esc(m.texto)}</span></span></label>`).join('')}
          </div>
          <div class="rede-lojas" id="rede-lib-lojas" hidden>
            <label class="rede-rotulo" for="rede-lib-busca">Lojas de teste</label>
            <input id="rede-lib-busca" type="search" placeholder="Buscar loja pelo nome ou cidade" autocomplete="off">
            <div class="rede-lojas-lista" id="rede-lib-lista"></div>
            <small class="m-nota" id="rede-lib-contagem"></small>
          </div>
          <label class="rede-chave"><input type="checkbox" id="rede-lib-analise"> Cadastro novo de entregador passa pela minha análise</label>
          <p class="m-nota">Ligado: quem se cadastra fica <b>em análise</b> e só recebe corridas depois que você aprovar (lista abaixo). Desligado: já entra ativo. Não muda quem já está cadastrado.</p>
          <p id="rede-lib-erro" class="m-nota m-nota-erro" role="alert" hidden></p>
          <div class="rede-acoes">
            <button type="submit" class="m-btn m-btn-principal" id="rede-lib-salvar"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar liberação</button>
            <button type="button" class="m-btn m-btn-leve" id="rede-lib-desfazer">Desfazer mudanças</button>
            <span class="m-nota" id="rede-lib-estado"></span>
          </div>
          <p class="m-nota">Desligar ou tirar uma loja do teste não interrompe as corridas que já estão acontecendo: a loja ainda acompanha e termina essas, só não chama novas.</p>
        </form>
      </article>
      <article class="m-card" id="rede-pedidos-card">
        <div class="m-card-topo"><div><h2>Pedidos e relatos dos entregadores</h2><p class="m-sub">Pedidos de exclusão de conta (LGPD) e problemas com lojas enviados pelo app YAPOOD Entrega.</p></div></div>
        <p id="rede-pedidos-falha" class="m-nota m-nota-erro" role="alert" hidden></p>
        <h3 class="rede-sub-titulo">Pedidos de exclusão <span id="rede-exc-qtd"></span></h3>
        <div id="rede-exclusoes" class="rede-pedidos"></div>
        <h3 class="rede-sub-titulo">Relatos sobre lojas <span id="rede-rel-qtd"></span></h3>
        <div id="rede-relatos" class="rede-pedidos"></div>
      </article>
      <article class="m-card">
        <div class="m-card-topo"><div><h2>Entregadores</h2><p class="m-sub">Quem se cadastrou no app YAPOOD Entrega. Aprove quem pode receber corridas. Ao recusar ou bloquear, o entregador vê o motivo no app.</p></div></div>
        <p id="rede-falha" class="m-nota m-nota-erro" role="alert" hidden></p>
        <div id="rede-ents-filtros" class="m-chips rede-chips" role="group" aria-label="Filtrar entregadores"></div>
        <div id="rede-ents"></div>
      </article>
      <article class="m-card">
        <div class="m-card-topo"><div><h2>Regras da entrega parceira</h2><p class="m-sub">Valem para as corridas novas. O app do entregador lê estes números ao abrir. <span id="rede-estado"></span></p></div></div>
        <p id="rede-regras-falha" class="m-nota m-nota-erro" role="alert" hidden></p>
        <form id="rede-form" novalidate>
          ${GRUPOS.map((g) => `<section class="rede-grupo"><h3>${esc(g.titulo)}</h3><p class="m-nota">${esc(g.nota)}</p><div class="rede-grade">${CAMPOS.filter((c) => c.grupo === g.id).map(campoHtml).join('')}</div></section>`).join('')}
          <p id="rede-erro" class="m-nota m-nota-erro" role="alert" hidden></p>
          <div class="rede-acoes">
            <button type="submit" class="m-btn m-btn-principal" id="rede-salvar"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar regras</button>
            <button type="button" class="m-btn m-btn-leve" id="rede-desfazer">Desfazer mudanças</button>
            <button type="button" class="m-btn m-btn-leve" id="rede-padrao">Voltar aos padrões</button>
          </div>
          <p class="m-nota">“Voltar aos padrões” só preenche os campos; nada muda no banco até você clicar em <b>Salvar regras</b>.</p>
        </form>
      </article>`;
    // regras
    $('rede-form').addEventListener('submit', (e) => { e.preventDefault(); salvar(); });
    $('rede-form').addEventListener('input', aoDigitar);
    $('rede-desfazer').addEventListener('click', () => { if (salva) preencher(paraTexto(salva)); sujo = false; marcar(); });
    $('rede-padrao').addEventListener('click', () => { preencher(paraTexto(mesclarConfig(null))); sujo = true; marcar(); });
    // liberação
    $('rede-lib-form').addEventListener('submit', (e) => { e.preventDefault(); salvarLiberacao(); });
    $('rede-lib-form').addEventListener('change', aoMudarLiberacao);
    $('rede-lib-busca').addEventListener('input', (e) => { buscaLoja = e.target.value; desenharLojas(true); });
    $('rede-lib-desfazer').addEventListener('click', () => { libEdit = libSalva ? { ...libSalva, lojas: { ...libSalva.lojas } } : null; libSujo = false; erroLib(''); desenharLiberacao(true); });
    // entregadores
    $('rede-ents-filtros').addEventListener('click', (e) => { const b = e.target.closest('[data-filtro]'); if (!b) return; filtro = b.dataset.filtro; desenharEntregadores(true); });
    $('rede-ents').addEventListener('click', aoClicarEntregador);
    $('rede-pedidos-card').addEventListener('click', aoClicarPedido);
  }

  // ====================== 1) liberação ======================
  function erroLib(msg) { const e = $('rede-lib-erro'); if (!e) return; e.hidden = !msg; e.textContent = msg; }
  function desenharLiberacao(forcar = false) {
    const falha = $('rede-lib-falha');
    const lido = S.redeLibOk === true;
    const semPermissao = S.falhas?.has?.('rede/liberacao');
    falha.hidden = !semPermissao;
    falha.textContent = semPermissao ? 'Não foi possível ler a liberação. Publique as regras do Firebase V75.115 (elas criam o nó rede/liberacao).' : '';
    if (!lido) { $('rede-lib-resumo').textContent = semPermissao ? '' : 'Carregando…'; $('rede-lib-salvar').disabled = true; return; }
    const atual = normalizarLiberacao(S.redeLib);
    const chave = JSON.stringify(atual);
    if (chave !== chaveLib || forcar) {
      chaveLib = chave; libSalva = atual;
      if (!libSujo || !libEdit) libEdit = { ...atual, lojas: { ...atual.lojas } };
    }
    $('rede-lib-salvar').disabled = false;
    const resumo = resumoLiberacao(libSalva, nomeLoja) + (libSalva.existe ? '' : ' (ainda não foi salva: vale "Desligada").');
    $('rede-lib-resumo').textContent = resumo;
    raiz.querySelectorAll('input[name="rede-lib-modo"]').forEach((i) => { i.checked = i.value === libEdit.modo; i.closest('.rede-modo').classList.toggle('sel', i.checked); });
    $('rede-lib-analise').checked = libEdit.analiseEntregador;
    $('rede-lib-lojas').hidden = libEdit.modo !== 'teste';
    $('rede-lib-estado').textContent = libSujo ? 'Há mudanças ainda não salvas.' : (libSalva.atualizadoEm ? `Última gravação: ${new Date(libSalva.atualizadoEm).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}.` : '');
    desenharLojas(forcar);
  }
  function desenharLojas(forcar = false) {
    if (!libEdit || libEdit.modo !== 'teste') return;
    const lista = lojasParaEscolher(S.lojas, libEdit.lojas, buscaLoja);
    const chave = JSON.stringify([lista, buscaLoja]);
    if (chave === chaveLojas && !forcar) return; // não redesenha à toa (os ouvintes do Master chamam render a cada mudança)
    chaveLojas = chave;
    const alvo = $('rede-lib-lista');
    alvo.innerHTML = lista.length ? lista.map((l) => `<label class="rede-loja"><input type="checkbox" data-loja="${esc(l.id)}" ${l.marcada ? 'checked' : ''}><span>${esc(l.nome)}${l.cidade ? ` <small>· ${esc(l.cidade)}</small>` : ''}</span></label>`).join('')
      : `<p class="m-nota">${buscaLoja ? 'Nenhuma loja com esse nome.' : 'Nenhuma loja cadastrada.'}</p>`;
    const n = Object.keys(libEdit.lojas).length;
    $('rede-lib-contagem').textContent = n ? `${n} loja${n > 1 ? 's' : ''} marcada${n > 1 ? 's' : ''}.` : 'Nenhuma loja marcada.';
  }
  function aoMudarLiberacao(e) {
    if (!libEdit) return;
    const t = e.target;
    if (t.name === 'rede-lib-modo') libEdit.modo = t.value;
    else if (t.id === 'rede-lib-analise') libEdit.analiseEntregador = t.checked;
    else if (t.dataset.loja) { if (t.checked) libEdit.lojas[t.dataset.loja] = true; else delete libEdit.lojas[t.dataset.loja]; }
    else return;
    libSujo = true; erroLib('');
    desenharLiberacao(true);
  }
  async function salvarLiberacao() {
    if (!libEdit || !libSalva) { aviso('Espere a liberação atual carregar e tente de novo.', 'erro'); return; }
    const erro = validarLiberacao(libEdit); if (erro) { erroLib(erro); return; }
    const difs = diferencasLiberacao(libSalva, libEdit, nomeLoja);
    if (!difs.length && libSalva.existe) { aviso('Nada mudou em relação ao que já está salvo.'); libSujo = false; desenharLiberacao(true); return; }
    const liga = libEdit.modo === 'todas' && libSalva.modo !== 'todas';
    const c = await confirmar({
      titulo: liga ? 'Liberar a entrega parceira para TODAS as lojas?' : 'Salvar a liberação da entrega parceira?',
      texto: difs.length ? `${difs.join(' · ')}.` : 'A configuração atual passa a ficar gravada no banco.',
      aviso: liga ? 'Todas as lojas passam a ver o botão "Chamar entregador parceiro". Confira se já há entregadores aprovados na região.' : 'Vale na hora: o painel das lojas lê isto ao abrir e a API confere a cada chamada.',
      rotulo: liga ? 'Liberar para todas' : 'Salvar'
    });
    if (!c.ok) return;
    const obj = paraGravarLiberacao(libEdit, S.user?.uid, agoraIso());
    const ok = await executar(() => set(ref(db, 'rede/liberacao'), obj), 'Liberação salva.');
    if (!ok) return;
    await logar('rede.liberacao', 'rede/liberacao', (difs.join(' · ') || 'gravada').slice(0, 300));
    libSujo = false;
  }

  // ====================== 2) entregadores ======================
  function resumoEnts() { return S.redeEntsOk ? resumirEntregadores(S.redeEnts) : null; }
  function desenharEntregadores(forcar = false) {
    const alvo = $('rede-ents'), chips = $('rede-ents-filtros'), falha = $('rede-falha'); if (!alvo) return;
    const semPermissao = S.falhas?.has?.('rede/entregadores');
    falha.hidden = !semPermissao; falha.textContent = semPermissao ? 'Não foi possível ler os entregadores. Confira se as regras do Firebase foram publicadas.' : '';
    const ents = resumoEnts();
    if (!ents) { chips.innerHTML = ''; alvo.innerHTML = semPermissao ? '' : '<p class="m-nota">Carregando…</p>'; return; }
    const { lista, tot } = ents;
    if (!filtro) filtro = tot.emAnalise ? 'em_analise' : 'todos';
    const chave = JSON.stringify([lista, filtro, [...ocupados], cpfs, S.redeExclusoes]);
    if (chave === chaveEnts && !forcar) return;
    chaveEnts = chave;
    const qtd = { em_analise: tot.emAnalise, ativo: tot.ativos, recusado: tot.recusados, bloqueado: tot.bloqueados, todos: tot.total };
    chips.innerHTML = FILTROS_ENTREGADOR.map(([id, rot]) => `<button type="button" class="m-chip${filtro === id ? ' ativo' : ''}" data-filtro="${id}" aria-pressed="${filtro === id}">${esc(rot)} <b>${qtd[id]}</b></button>`).join('')
      + `<span class="m-nota" style="align-self:center">Com Mercado Pago: <b>${tot.mp}</b> · Online agora: <b>${tot.online}</b></span>`;
    const vis = filtrarEntregadores(lista, filtro);
    const dt = (ms) => (ms ? new Date(ms).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '—');
    const fone = (c) => { const d = String(c || '').replace(/\D/g, ''); return d.length >= 10 ? `<a href="https://wa.me/55${d}" target="_blank" rel="noopener">${esc(c)}</a>` : esc(c); };
    const ROT = { aprovar: ['Aprovar', 'm-btn-principal'], reativar: ['Reativar', 'm-btn-leve'], recusar: ['Recusar', 'm-btn-perigo'], bloquear: ['Bloquear', 'm-btn-perigo'] };
    if (!vis.length) { alvo.innerHTML = `<p class="m-nota">${lista.length ? 'Nenhum entregador nesta situação.' : 'Nenhum entregador cadastrado ainda.'}</p>`; return; }
    alvo.innerHTML = `<div class="m-lista"><table class="m-tabela"><thead><tr><th>Entregador</th><th>Veículo</th><th>CPF</th><th>Documentos</th><th>Mercado Pago</th><th>Situação</th><th>Cadastro</th><th>Ações</th></tr></thead><tbody>${vis.map((e) => {
      const sit = SITUACOES[e.status];
      const pausa = e.pausadoAte > Date.now() ? ` · em pausa até ${new Date(e.pausadoAte).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', dateStyle: 'short', timeStyle: 'short' })}` : '';
      const ocup = ocupados.has(e.uid);
      const cpf = cpfs[e.uid] ? esc(cpfs[e.uid]) : `•••.•••.•••-${esc(e.cpfFinal || '••')} <button type="button" class="rede-link" data-ver-cpf="${esc(e.uid)}" ${ocup ? 'disabled' : ''}>Ver</button>`;
      const botoes = acoesDaSituacao(e.status).map((a) => `<button type="button" class="m-btn ${ROT[a][1]}" data-acao-ent="${a}" data-uid="${esc(e.uid)}" ${ocup ? 'disabled' : ''}>${ROT[a][0]}</button>`).join('')
        + `<button type="button" class="m-btn m-btn-leve" data-excluir-ent="${esc(e.uid)}" ${ocup ? 'disabled' : ''} title="Apaga os dados pessoais (LGPD)">Excluir (LGPD)</button>`;
      return `<tr data-ent="${esc(e.uid)}"><td data-label="Entregador">${esc(e.nome)}<small class="m-nota">${fone(e.celular)}</small></td>`
        + `<td data-label="Veículo">${e.veiculo === 'moto' ? 'Moto' : 'Bicicleta'}${e.placa ? `<small class="m-nota">${esc(e.placa)}</small>` : ''}</td>`
        + `<td data-label="CPF" class="rede-cpf">${cpf}</td>`
        + `<td data-label="Documentos">${docsHtml(e, ocup)}</td>`
        + `<td data-label="Mercado Pago">${e.mpConectado ? 'Conectado' : 'Não conectado'}${e.online ? '<small class="m-nota">Online agora</small>' : ''}</td>`
        + `<td data-label="Situação">${selo(sit.selo, sit.rotulo)}${e.exclusaoPedidaEm ? ` ${selo('erro', 'Pediu exclusão')}` : ''}${esc(pausa)}${e.statusMotivo && e.status !== 'ativo' ? `<span class="rede-motivo">Motivo: ${esc(e.statusMotivo)}</span>` : ''}${e.statusEm ? `<span class="rede-motivo">desde ${dt(e.statusEm)}</span>` : ''}</td>`
        + `<td data-label="Cadastro" class="num">${dt(e.criadoEm)}</td>`
        + `<td data-label="Ações"><div class="rede-ent-acoes">${ocup ? '<span class="m-nota">Enviando…</span>' : botoes}</div></td></tr>`;
    }).join('')}</tbody></table></div>`;
  }
  // ---------- V75.116: documentos da análise (as fotos só existem até a decisão; a API apaga ao aprovar/recusar) ----------
  function docsHtml(e, ocup) {
    const d = situacaoDocs(e), dt = (ms) => new Date(ms).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' });
    if (d.id === 'enviados') return `${selo('info', 'Enviados')}<span class="rede-motivo">${esc(d.tipo)} · ${dt(d.quando)}</span><button type="button" class="m-btn m-btn-leve" style="min-height:34px;margin-top:6px" data-ver-docs="${esc(e.uid)}" ${ocup ? 'disabled' : ''}>Ver documentos</button>`;
    if (d.id === 'apagados') return `<span class="m-nota">Conferidos e apagados em ${dt(d.quando)}</span>`;
    if (d.id === 'falta') return selo('aviso', 'Não enviou');
    return '<span class="m-nota">—</span>';
  }
  function modalDocs() {
    let m = document.getElementById('rede-docs-modal');
    if (m) return m;
    m = document.createElement('div'); m.id = 'rede-docs-modal'; m.hidden = true;
    m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true'); m.setAttribute('aria-labelledby', 'rede-docs-titulo');
    m.innerHTML = '<div class="rede-docs-caixa"><div class="rede-docs-topo"><div><h2 id="rede-docs-titulo"></h2><p class="m-nota" id="rede-docs-sub"></p></div><button type="button" class="m-btn m-btn-leve" id="rede-docs-fechar">Fechar</button></div><div class="rede-docs-grade" id="rede-docs-grade"></div><p class="m-nota">Confira: o nome e o CPF batem com o cadastro, a foto do documento é a mesma pessoa da selfie e, na moto, a CNH tem a categoria A e está na validade. As fotos são apagadas quando você aprovar ou recusar.</p></div>';
    document.body.appendChild(m);
    const fechar = () => { m.hidden = true; m.querySelector('#rede-docs-grade').innerHTML = ''; }; // tira as fotos da tela ao fechar
    m.addEventListener('click', (ev) => { if (ev.target === m || ev.target.id === 'rede-docs-fechar') fechar(); else if (ev.target.tagName === 'IMG') ev.target.classList.toggle('ampliada'); });
    document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !m.hidden) fechar(); });
    return m;
  }
  async function verDocs(uid) {
    const e = resumoEnts()?.lista.find((x) => x.uid === uid); if (!e || ocupados.has(uid)) return;
    ocupados.add(uid); desenharEntregadores(true);
    const d = await executar(() => api('/rede/master/entregador/documentos', { uid }));
    ocupados.delete(uid); desenharEntregadores(true);
    if (!d || !d.documento) return;
    const foto = (v) => (typeof v === 'string' && v.startsWith('data:image/jpeg;base64,') ? v : '');
    const nomeDoc = d.tipo === 'cnh' ? 'CNH' : 'Documento com foto';
    const m = modalDocs();
    m.querySelector('#rede-docs-titulo').textContent = `Documentos de ${e.nome}`;
    m.querySelector('#rede-docs-sub').textContent = `${e.veiculo === 'moto' ? 'Moto' : 'Bicicleta'}${e.placa ? ' · placa ' + e.placa : ''} · CPF final ${e.cpfFinal || '—'} · enviados em ${new Date(d.enviadoEm || e.docs.enviadoEm).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}`;
    m.querySelector('#rede-docs-grade').innerHTML = `<figure><figcaption>${esc(nomeDoc)}</figcaption><img src="${foto(d.documento)}" alt="${esc(nomeDoc)} de ${esc(e.nome)}"></figure><figure><figcaption>Selfie segurando o documento</figcaption><img src="${foto(d.selfie)}" alt="Selfie de ${esc(e.nome)} segurando o documento"></figure>`;
    m.hidden = false; m.querySelector('#rede-docs-fechar').focus();
    await logar('rede.documentos', uid, `${e.nome}: viu os documentos da análise`);
  }

  const TEXTOS_ACAO = {
    aprovar: (e) => ({ titulo: `Aprovar ${e.nome}?`, texto: (e.status === 'recusado' ? 'O cadastro tinha sido recusado. Aprovando, ele passa a poder ficar online e aceitar corridas.' : 'Ele passa a poder ficar online e aceitar corridas (precisa ter o Mercado Pago conectado). Ele recebe um aviso no app.') + (situacaoDocs(e).id === 'enviados' ? ' Os documentos são apagados em seguida.' : ''),
      aviso: situacaoDocs(e).id === 'falta' ? 'Ele ainda não enviou os documentos (CNH/documento e selfie).' : '', rotulo: 'Aprovar' }),
    reativar: (e) => ({ titulo: `Reativar ${e.nome}?`, texto: 'Ele volta a poder ficar online e aceitar corridas. Ele recebe um aviso no app.', rotulo: 'Reativar' }),
    recusar: (e) => ({ titulo: `Recusar o cadastro de ${e.nome}?`, texto: 'Escreva o motivo: o entregador vê esse texto no app. Os documentos são apagados; ele pode enviar novos, e dá para aprovar depois.', motivo: true, rotulo: 'Recusar', perigo: true }),
    bloquear: (e) => ({ titulo: `Bloquear ${e.nome}?`, texto: 'Escreva o motivo: o entregador vê esse texto no app. Ele sai do online e não aceita corrida nova.', aviso: 'Se estiver no meio de uma entrega, ele consegue terminar essa.', motivo: true, rotulo: 'Bloquear', perigo: true })
  };
  const MSG_OK = { aprovar: 'Entregador aprovado.', reativar: 'Entregador reativado.', recusar: 'Cadastro recusado.', bloquear: 'Entregador bloqueado.' };
  async function aoClicarEntregador(ev) {
    const v = ev.target.closest('[data-ver-cpf]');
    if (v) return verCpf(v.dataset.verCpf);
    const vd = ev.target.closest('[data-ver-docs]');
    if (vd) return verDocs(vd.dataset.verDocs);
    const ex = ev.target.closest('[data-excluir-ent]');
    if (ex) return excluirEntregador(ex.dataset.excluirEnt);
    const b = ev.target.closest('[data-acao-ent]'); if (!b) return;
    const uid = b.dataset.uid, acao = b.dataset.acaoEnt;
    const e = resumoEnts()?.lista.find((x) => x.uid === uid); if (!e || ocupados.has(uid)) return;
    if (!acoesDaSituacao(e.status).includes(acao)) return;
    const t = TEXTOS_ACAO[acao](e);
    const c = await confirmar(t); if (!c.ok) return;
    if (t.motivo && c.motivo.length < 3) { aviso('Escreva o motivo (pelo menos 3 letras): o entregador vê esse texto.', 'erro'); return; }
    const para = ACAO_PARA_STATUS[acao];
    ocupados.add(uid); desenharEntregadores(true);
    const ok = await executar(() => api('/rede/master/entregador/status', { uid, status: para, motivo: c.motivo || '' }), MSG_OK[acao]);
    ocupados.delete(uid);
    if (ok) await logar('rede.entregador', uid, `${e.nome}: ${SITUACOES[e.status].rotulo} → ${SITUACOES[para].rotulo}${c.motivo ? ` · ${c.motivo}` : ''}`.slice(0, 300));
    desenharEntregadores(true); // o ouvinte de rede/entregadores traz a situação nova
  }
  async function verCpf(uid) {
    if (cpfs[uid] || ocupados.has(uid)) return;
    ocupados.add(uid); desenharEntregadores(true);
    const d = await executar(() => api('/rede/master/entregador/dados', { uid }));
    ocupados.delete(uid);
    if (d && d.cpf) {
      const n = String(d.cpf).replace(/\D/g, '');
      cpfs[uid] = n.length === 11 ? `${n.slice(0, 3)}.${n.slice(3, 6)}.${n.slice(6, 9)}-${n.slice(9)}` : n;
      await logar('rede.cpf', uid, 'consultou o CPF do entregador para a análise');
    }
    desenharEntregadores(true);
  }

  // ====================== V75.144: pedidos de exclusão (LGPD) e relatos ======================
  let chavePedidos = '';
  function desenharPedidos(forcar = false) {
    const ex = $('rede-exclusoes'), rl = $('rede-relatos'), falha = $('rede-pedidos-falha'); if (!ex) return;
    const sem = ['rede_relatos', 'rede_exclusoes'].some((k) => S.falhas?.has?.(k));
    falha.hidden = !sem; falha.textContent = sem ? 'Não foi possível ler os pedidos e relatos. Publique as regras do Firebase V75.144 e atualize a API para a 2.28.' : '';
    const chave = JSON.stringify([S.redeRelatos, S.redeExclusoes, S.redeRelatosOk, S.redeExclusoesOk, [...ocupados], sem]);
    if (chave === chavePedidos && !forcar) return;
    chavePedidos = chave;
    const quando = (ms) => (ms ? new Date(ms).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', dateStyle: 'short', timeStyle: 'short' }) : '—');
    const fone = (c) => { const d = String(c || '').replace(/\D/g, ''); return d.length >= 10 ? `<a href="https://wa.me/${d.length <= 11 ? '55' + d : d}" target="_blank" rel="noopener">${esc(c)}</a>` : ''; };
    const reais = (v) => `R$ ${Number(v || 0).toFixed(2).replace('.', ',')}`;
    if (!S.redeExclusoesOk) { ex.innerHTML = sem ? '' : '<p class="m-nota">Carregando…</p>'; $('rede-exc-qtd').innerHTML = ''; }
    else {
      const { pedidos, concluidos } = listarExclusoes(S.redeExclusoes);
      $('rede-exc-qtd').innerHTML = pedidos.length ? selo('erro', `${pedidos.length} em aberto`) : '';
      ex.innerHTML = (pedidos.length ? pedidos.map((p) => {
        const dias = diasDesde(p.em), ocup = ocupados.has(p.uid);
        return `<div class="rede-pedido" data-exc="${esc(p.uid)}"><div><b>${esc(p.nome)}</b><span class="m-nota">${fone(p.celular)}${p.email ? ` · ${esc(p.email)}` : ''}</span>
          <p class="m-nota">Pedido em ${esc(quando(p.em))} · <span class="${dias >= PRAZO_LGPD_DIAS - 3 ? 'rede-prazo-vencendo' : ''}">há ${dias} dia${dias === 1 ? '' : 's'} (prazo da LGPD: ${PRAZO_LGPD_DIAS} dias)</span></p>
          ${p.aReceber > 0 ? `<p class="m-nota">As lojas deviam ${esc(reais(p.aReceber))} a ele quando pediu.</p>` : ''}</div>
          <div class="rede-ent-acoes">${ocup ? '<span class="m-nota">Enviando…</span>' : `<button type="button" class="m-btn m-btn-perigo" data-excluir-ent="${esc(p.uid)}">Excluir dados</button>`}</div></div>`;
      }).join('') : '<p class="m-nota">Nenhum pedido de exclusão em aberto.</p>')
        + (concluidos.length ? `<details><summary class="m-nota">Exclusões feitas (${concluidos.length})</summary>${concluidos.slice(0, 50).map((c) => `<p class="m-nota">Excluído em ${esc(quando(c.concluidoEm))}${c.motivo ? ` · ${esc(c.motivo)}` : ''} · código ${esc(c.uid.slice(0, 8))}…</p>`).join('')}</details>` : '');
    }
    if (!S.redeRelatosOk) { rl.innerHTML = sem ? '' : '<p class="m-nota">Carregando…</p>'; $('rede-rel-qtd').innerHTML = ''; return; }
    const { lista, abertos } = listarRelatos(S.redeRelatos);
    $('rede-rel-qtd').innerHTML = abertos ? selo('aviso', `${abertos} em aberto`) : '';
    rl.innerHTML = lista.length ? lista.slice(0, 100).map((r) => `<div class="rede-pedido${r.aberto ? '' : ' feito'}" data-relato="${esc(r.id)}"><div>
        <b>${esc(r.loja)} · ${esc(r.motivo)}</b>
        <span class="m-nota">${esc(r.entregador)} ${fone(r.celular)}${r.corridaId ? ` · entrega ${esc(r.corridaId)}` : ''} · ${esc(quando(r.em))}</span>
        ${r.detalhe ? `<p>${esc(r.detalhe)}</p>` : ''}
        ${!r.aberto ? `<p class="m-nota">Resolvido em ${esc(quando(r.resolvidoEm))}${r.nota ? ` · ${esc(r.nota)}` : ''}</p>` : ''}</div>
        <div class="rede-ent-acoes">${ocupados.has('r:' + r.id) ? '<span class="m-nota">Enviando…</span>' : r.aberto ? `<button type="button" class="m-btn m-btn-principal" data-resolver="${esc(r.id)}">Marcar como resolvido</button>` : `<button type="button" class="m-btn m-btn-leve" data-reabrir="${esc(r.id)}">Reabrir</button>`}</div></div>`).join('')
      : '<p class="m-nota">Nenhum relato ainda.</p>';
  }
  async function aoClicarPedido(ev) {
    const ex = ev.target.closest('[data-excluir-ent]'); if (ex) return excluirEntregador(ex.dataset.excluirEnt);
    const rs = ev.target.closest('[data-resolver]'); if (rs) return mudarRelato(rs.dataset.resolver, 'resolvido');
    const ra = ev.target.closest('[data-reabrir]'); if (ra) return mudarRelato(ra.dataset.reabrir, 'aberto');
  }
  async function mudarRelato(id, estado) {
    const r = listarRelatos(S.redeRelatos).lista.find((x) => x.id === id); if (!r || ocupados.has('r:' + id)) return;
    let nota = '';
    if (estado === 'resolvido') {
      const c = await confirmar({ titulo: 'Marcar o relato como resolvido?', texto: `${r.loja} · ${r.motivo}. Anote o que foi feito (opcional), por exemplo "loja pagou" ou "loja advertida".`, motivo: true, rotulo: 'Marcar como resolvido' });
      if (!c.ok) return; nota = c.motivo;
    }
    ocupados.add('r:' + id); desenharPedidos(true);
    const ok = await executar(() => api('/rede/master/relato', { id, estado, nota }), estado === 'resolvido' ? 'Relato resolvido.' : 'Relato reaberto.');
    ocupados.delete('r:' + id);
    if (ok) await logar('rede.relato', id, `${r.loja}: ${estado === 'resolvido' ? 'resolvido' : 'reaberto'}${nota ? ` · ${nota}` : ''}`.slice(0, 300));
    desenharPedidos(true);
  }
  async function excluirEntregador(uid) {
    if (ocupados.has(uid)) return;
    const e = resumoEnts()?.lista.find((x) => x.uid === uid), p = listarExclusoes(S.redeExclusoes).pedidos.find((x) => x.uid === uid);
    const nome = e?.nome || p?.nome || 'este entregador';
    const c = await confirmar({ titulo: `Excluir os dados de ${nome}?`, texto: 'Apaga o cadastro, CPF, e-mail, documentos, conexão com o Mercado Pago, histórico e avisos. Os registros de pagamento com as lojas ficam, sem os dados pessoais. Escreva o motivo (ex.: "pedido do entregador").',
      aviso: 'Não dá para desfazer. Ele poderá se cadastrar de novo no futuro.', motivo: true, rotulo: 'Excluir dados', perigo: true });
    if (!c.ok) return;
    if (c.motivo.length < 3) { aviso('Escreva o motivo da exclusão (pelo menos 3 letras).', 'erro'); return; }
    const mandar = async (mesmoComPendencias) => {
      ocupados.add(uid); desenharEntregadores(true); desenharPedidos(true);
      try { await api('/rede/master/entregador/excluir', { uid, motivo: c.motivo, mesmoComPendencias }); return { ok: true }; }
      catch (err) { return { ok: false, err }; }
      finally { ocupados.delete(uid); }
    };
    let r = await mandar(false);
    if (!r.ok && r.err.codigo === 'pendencias') {
      const v = Number(r.err.dados?.aReceber || 0).toFixed(2).replace('.', ',');
      const c2 = await confirmar({ titulo: 'As lojas ainda devem a ele', texto: `As lojas ainda devem R$ ${v} a ${nome}. Excluindo agora, as dívidas continuam registradas para as lojas, mas ele perde o acesso ao app para acompanhar.`, rotulo: 'Excluir mesmo assim', perigo: true });
      if (!c2.ok) { desenharEntregadores(true); desenharPedidos(true); return; }
      r = await mandar(true);
    }
    if (r.ok) { aviso('Dados do entregador excluídos.'); await logar('rede.excluir', uid, `Entregador excluído (LGPD) · ${c.motivo}`.slice(0, 300)); }
    else aviso(r.err.message || 'Não foi possível excluir.', 'erro');
    desenharEntregadores(true); desenharPedidos(true);
  }

  // ====================== 3) regras (/rede/config) ======================
  const input = (path) => raiz.querySelector(`input[data-path="${CSS.escape(path)}"]`);
  const lerTextos = () => Object.fromEntries(CAMPOS.map((c) => [c.path, input(c.path)?.value ?? '']));
  function preencher(textos) { for (const c of CAMPOS) { const i = input(c.path); if (i) i.value = textos[c.path]; } limparErros(); dicas(); }
  function limparErros() {
    raiz.querySelectorAll('.rede-campo').forEach((l) => { l.classList.remove('invalido'); const e = l.querySelector('[data-erro]'); e.hidden = true; e.textContent = ''; });
    const g = $('rede-erro'); if (g) { g.hidden = true; g.textContent = ''; }
  }
  function mostrarErros(erros) {
    limparErros();
    let primeiro = null;
    for (const [path, msg] of Object.entries(erros)) {
      const l = raiz.querySelector(`.rede-campo[data-campo="${CSS.escape(path)}"]`); if (!l) continue;
      l.classList.add('invalido'); const e = l.querySelector('[data-erro]'); e.textContent = msg; e.hidden = false;
      primeiro = primeiro || l;
    }
    const g = $('rede-erro'); g.hidden = false; g.textContent = `Corrija ${Object.keys(erros).length === 1 ? 'o campo marcado' : 'os campos marcados'} para salvar.`;
    primeiro?.querySelector('input')?.focus();
  }
  function dicas() {
    for (const c of CAMPOS) {
      const l = raiz.querySelector(`.rede-campo[data-campo="${CSS.escape(c.path)}"]`), i = input(c.path); if (!l || !i) continue;
      const n = Number(String(i.value).replace(',', '.'));
      const d = l.querySelector('[data-dica]');
      d.textContent = c.fmt === 'min' && /^\d+$/.test(i.value.trim()) && n >= 60 ? `= ${fmtDuracao(n)}` : '';
      const base = salva ? paraTexto(salva)[c.path] : null;
      l.classList.toggle('alterado', base !== null && i.value.trim() !== base);
    }
  }
  function marcar() {
    dicas();
    const e = $('rede-estado'); if (!e) return;
    if (sujo) e.textContent = 'Há mudanças ainda não salvas.';
    else if (salva?._origem === 'padrao') e.textContent = 'Ainda não foi salvo nenhum número: valem os padrões.';
    else e.textContent = salva?._quando ? `Última gravação: ${new Date(salva._quando).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}.` : '';
    const f = $('rede-regras-falha'); if (f) { f.hidden = !falhouRegras; f.textContent = falhouRegras; }
  }
  function aoDigitar() { sujo = true; const g = $('rede-erro'); if (g && !g.hidden) limparErros(); marcar(); }

  async function carregarRegras(forcar = false) {
    if (carregando) return;
    if (!forcar && carregadoEm && Date.now() - carregadoEm < 60000) return;
    carregando = true; falhouRegras = '';
    try {
      const v = (await get(ref(db, 'rede/config'))).val();
      salva = mesclarConfig(v);
      salva._origem = v ? 'banco' : 'padrao'; salva._quando = typeof v?.atualizadoEm === 'string' ? v.atualizadoEm : '';
      if (!sujo) preencher(paraTexto(salva));
      carregadoEm = Date.now();
    } catch (err) { console.warn('Regras da entrega parceira:', err); falhouRegras = 'Não foi possível ler as regras atuais. Confira se as regras do Firebase foram publicadas.'; }
    carregando = false;
    marcar();
  }

  async function salvar() {
    if (!salva) { aviso('Espere as regras atuais carregarem e tente de novo.', 'erro'); return; }
    const r = lerFormulario(lerTextos());
    if (!r.ok) { mostrarErros(r.erros); return; }
    limparErros();
    const difs = diferencas(salva, r.cfg);
    if (!difs.length && salva._origem === 'banco') { aviso('Nada mudou em relação ao que já está salvo.'); sujo = false; marcar(); return; }
    const texto = difs.length ? `Vão mudar ${difs.length} regra${difs.length > 1 ? 's' : ''}: ${resumoDiferencas(difs)}.` : 'Os números atuais (padrões) passam a ficar gravados no banco.';
    const c = await confirmar({ titulo: 'Salvar as regras da entrega parceira?', texto, aviso: 'Vale para as corridas novas. Lojas e entregadores veem os novos números ao abrir o app.', rotulo: 'Salvar' });
    if (!c.ok) return;
    const obj = paraGravar(r.cfg, S.user?.uid, agoraIso());
    const ok = await executar(() => set(ref(db, 'rede/config'), obj), 'Regras salvas.');
    if (!ok) return;
    await logar('rede.config', 'rede/config', difs.length ? resumoDiferencas(difs).slice(0, 300) : 'padrões gravados');
    salva = mesclarConfig(obj); salva._origem = 'banco'; salva._quando = obj.atualizadoEm;
    sujo = false; carregadoEm = 0;
    preencher(paraTexto(salva)); marcar();
  }

  desenharBase();
  return {
    render() { desenharLiberacao(); desenharEntregadores(); desenharPedidos(); carregarRegras(); },
    /** Quantos cadastros esperam análise (selo no menu). */
    pendentes() { return (S.redeEntsOk ? resumirEntregadores(S.redeEnts).tot.emAnalise : 0) + (S.redeExclusoesOk ? listarExclusoes(S.redeExclusoes).pedidos.length : 0) + (S.redeRelatosOk ? listarRelatos(S.redeRelatos).abertos : 0); }
  };
}
