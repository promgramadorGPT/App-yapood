// js/termos-lojista.js — V75.47: TEXTO PROVISÓRIO dos termos do lojista.
// >>> Substituir pelo texto revisado pelo advogado. Ao trocar o texto, mude TERMOS_VERSAO em cadastro-lojista.js:
// >>> o cadastro guarda a versão aceita e a data, e assim dá para provar qual texto cada lojista aceitou.

export const TERMOS_LOJISTA = Object.freeze({
  titulo: 'Termos para lojistas (versão provisória)',
  aviso: 'Texto provisório, ainda em revisão jurídica. Ele pode ser atualizado e, se mudar de forma relevante, você será avisado.',
  itens: [
    ['Dados verdadeiros', 'Declaro ter 18 anos ou mais e que o CPF ou CNPJ, o nome e a foto do documento que estou enviando são meus (ou da empresa que represento) e verdadeiros. Dados falsos podem levar à recusa ou ao bloqueio da loja.'],
    ['Análise do cadastro', 'Entendo que meu cadastro será analisado pelo YaPOOD e que ele pode ser recusado ou, mais tarde, a loja pode ser suspensa, sempre que houver dúvida sobre os dados ou descumprimento destes termos.'],
    ['Minha loja, minha responsabilidade', 'Sou responsável pelos produtos, preços, estoque, qualidade, preparo, entrega e atendimento aos clientes, e por cumprir as leis aplicáveis (como vigilância sanitária, tributos e Código de Defesa do Consumidor).'],
    ['Pagamentos e comissão', 'Os pagamentos online são feitos na minha conta do Mercado Pago, conectada por mim. O YaPOOD cobra uma comissão percentual sobre os produtos, definida na plataforma, e posso consultá-la no painel.'],
    ['Cancelamentos e reembolsos', 'Vou responder aos pedidos de cancelamento, reembolso e relatos de problema dentro do prazo do aplicativo. Em caso de disputa, a decisão do Master do YaPOOD é final dentro da plataforma.'],
    // V75.116: aviso (LGPD) em vez de "autorizo": diz para que serve, quem vê, por quanto tempo e como pedir correção ou exclusão
    ['Como o YaPOOD trata os meus dados', 'O YaPOOD usa os dados do cadastro para verificar a minha identidade, prevenir fraudes, cobrar a comissão e falar comigo. A foto do documento só é vista pela equipe do YaPOOD que analisa os cadastros e é apagada assim que o cadastro é aprovado ou recusado. Esses dados não aparecem para clientes. Posso pedir para ver, corrigir ou apagar os meus dados pelo contato indicado no cadastro.']
  ]
});

/** V75.116: frase do contato para assuntos de dados pessoais (e-mail definido pelo Master em Configuração). */
export function textoContatoDados(email) {
  const e = String(email || '').trim();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) ? `Para ver, corrigir ou apagar os seus dados: ${e}.` : 'Para ver, corrigir ou apagar os seus dados, fale com o suporte do YaPOOD.';
}
