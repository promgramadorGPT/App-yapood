// js/saldo-api.js — V75.145: chamadas da API 2.29 para o saldo na loja (só a API grava saldo; as regras só deixam ler).
import { auth, db, ref, get } from './firebase.js';

const API = 'https://api-mp-yapoodbr.onrender.com';

async function post(caminho, body) {
  const token = await auth.currentUser?.getIdToken();
  if (!token) throw new Error('Sessão expirada. Entre novamente.');
  const r = await fetch(`${API}${caminho}`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'Não foi possível falar com o servidor agora.'), { status: r.status });
  return d;
}

/** Usa o saldo da loja no pedido recém-criado → { usado, aPagar, pago }. */
export const aplicarSaldo = (pedidoKey) => post('/saldo/aplicar', { pedidoKey });
/** Pedido cancelado (ou devolvido direto, pago na entrega) que usou saldo: o saldo volta. */
export const devolverSaldoDoPedido = (pedidoKey) => post('/saldo/devolver-pedido', { pedidoKey });
/** O cliente escolhe receber o reembolso aprovado em saldo (com o bônus da loja). */
export const receberReembolsoEmSaldo = (pedidoKey) => post('/saldo/receber-reembolso', { pedidoKey });

/** O cliente escolhe o dinheiro de volta: ele mesmo dispara a devolução pelo Mercado Pago (só com a loja oferecendo saldo). */
export const pedirDinheiroDeVolta = (pedidoKey) => post('/reembolso/executar', { pedidoKey });

/** Saldo do cliente nesta loja (0 se não houver ou se a leitura falhar). */
export async function buscarSaldo(uid, lojaId) {
  try { return (await get(ref(db, `saldos/${uid}/${lojaId}`))).val() || null; } catch (e) { console.warn('Saldo:', e); return null; }
}
export async function buscarSaldos(uid) {
  try { return (await get(ref(db, `saldos/${uid}`))).val() || {}; } catch (e) { console.warn('Saldos:', e); return {}; }
}
