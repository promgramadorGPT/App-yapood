// V75.19 — Tela de carregamento: o app só aparece quando os dados e as imagens principais chegaram.
// Nunca trava: há um limite de tempo geral e por tarefa; passado o limite, o app abre com o que já carregou.
export const LIMITE_GERAL_MS = 8000;
export const LIMITE_IMAGENS_MS = 3000;

// Controlador puro (testável): conta tarefas pendentes e avisa quando acabam ou o tempo estoura.
export function criarControlador({ limiteMs = LIMITE_GERAL_MS, aoConcluir = () => {}, agendar = setTimeout, cancelar = clearTimeout } = {}) {
  const pendentes = new Set();
  const timers = new Map();
  let concluido = false, iniciouEspera = false, geral = null;
  const concluir = (motivo) => { if (concluido) return; concluido = true; if (geral) cancelar(geral); timers.forEach((t) => cancelar(t)); timers.clear(); aoConcluir(motivo); };
  const verificar = () => { if (iniciouEspera && !pendentes.size) concluir('ok'); };
  return {
    exigir(nome, maxMs) {
      if (concluido) return;
      pendentes.add(nome);
      if (maxMs) timers.set(nome, agendar(() => { timers.delete(nome); pendentes.delete(nome); verificar(); }, maxMs));
      if (!geral) geral = agendar(() => concluir('tempo'), limiteMs);
    },
    pronto(nome) {
      pendentes.delete(nome);
      if (timers.has(nome)) { cancelar(timers.get(nome)); timers.delete(nome); }
      verificar();
    },
    // Chamado depois de registrar todas as tarefas da página.
    aguardar() { iniciouEspera = true; verificar(); },
    pendentes: () => [...pendentes],
    concluido: () => concluido
  };
}

// ---- Parte do navegador ----
function aguardarImagens(seletor, max = 12) {
  // só as imagens da primeira tela (as de baixo carregam depois, sem segurar a abertura)
  const limite = window.innerHeight * 1.2;
  const imgs = [...document.querySelectorAll(seletor)].filter((i) => i.src && !i.complete && i.getBoundingClientRect().top < limite).slice(0, max);
  if (!imgs.length) return Promise.resolve();
  return Promise.race([
    Promise.all(imgs.map((i) => new Promise((ok) => { i.addEventListener('load', ok, { once: true }); i.addEventListener('error', ok, { once: true }); }))),
    new Promise((ok) => setTimeout(ok, LIMITE_IMAGENS_MS))
  ]);
}
// V75.43.2: na primeira abertura de cada sessão, a tela fica até a animação terminar (sorriso + covinha + piscadela ≈ 1,8 s; mínimo de 2 s CONTADO DO INÍCIO DA ANIMAÇÃO, não da navegação).
// `?splash=1` na URL força a animação completa (para testar).
// Nas aberturas seguintes (e ao voltar de outra tela) não espera nada. Para desligar: MINIMO_PRIMEIRA_ABERTURA_MS = 0.
export const MINIMO_PRIMEIRA_ABERTURA_MS = 2000;
export function esperaMinima(jaViu, decorridoMs, minimo = MINIMO_PRIMEIRA_ABERTURA_MS) { return jaViu ? 0 : Math.max(0, minimo - decorridoMs); }
function esconderDepoisDoMinimo() {
  let jaViu = true;
  try { jaViu = sessionStorage.getItem('splash_vista') === '1'; sessionStorage.setItem('splash_vista', '1'); } catch { /* sem storage: não espera */ }
  try { if (/[?&]splash=1(&|$)/.test(location.search)) jaViu = false; } catch { /* sem location */ }
  const inicio = typeof window !== 'undefined' && Number.isFinite(window.__splashT0) ? window.__splashT0 : 0;   // marcado no HTML, junto da logo
  const falta = esperaMinima(jaViu, typeof performance !== 'undefined' ? performance.now() - inicio : Infinity);
  if (falta > 0) setTimeout(esconder, falta); else esconder();
}
function esconder() {
  const el = document.getElementById('splash-app');
  if (!el) return;
  el.classList.add('saindo');
  document.documentElement.classList.remove('splash-ativa');
  setTimeout(() => el.remove(), 350);
}

let ctrl = null, seletorImagens = 'img';
function garantir() {
  if (ctrl || typeof document === 'undefined') return ctrl;
  ctrl = criarControlador({
    aoConcluir: () => {
      // dá um quadro para a página desenhar o que chegou e espera as imagens do topo
      requestAnimationFrame(() => requestAnimationFrame(() => {
        // V75.44.2: nas trocas de tela (versão "curta") não espera as fotos do topo (até 3 s): sai assim que os dados chegam.
        if (document.documentElement.classList.contains('splash-curta')) { esconderDepoisDoMinimo(); return; }
        aguardarImagens(seletorImagens).then(esconderDepoisDoMinimo, esconderDepoisDoMinimo);
      }));
    }
  });
  // Se a página for restaurada do histórico (voltar), não mostra a tela de novo.
  window.addEventListener('pageshow', (e) => { if (e.persisted) esconder(); });
  return ctrl;
}

export function splashConfigurar({ imagens } = {}) { if (imagens) seletorImagens = imagens; garantir(); }
export function splashExigir(nome, maxMs) { garantir()?.exigir(nome, maxMs); }
export function splashPronto(nome) { garantir()?.pronto(nome); }
// Depois de registrar todas as tarefas: a partir daqui, zerar as pendências abre o app.
export function splashAguardar() { garantir()?.aguardar(); }
