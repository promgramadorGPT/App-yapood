// ================= CLOUDINARY (upload não assinado) =================
// Removido: deleteItem()/deletarImagemNoCloudinary() — referenciavam funções inexistentes (window.getPubId, dbRef, dbRemove,
// showToast) e uma URL placeholder de backend; nunca funcionaram. Excluir imagens exige backend com API secret.
// Segurança: o upload preset deve ser "unsigned" com formatos/tamanho restritos no painel do Cloudinary.
const CLOUD_NAME = "dkbhdasfh";
const MAX_BYTES = 5 * 1024 * 1024;
const TIPOS = ["image/jpeg", "image/png", "image/webp"];
// V75.147: banner animado do Master. GIF só entra por uploadImagemCloudinaryGif (os envios das lojas continuam sem GIF).
// 8 MB fica abaixo do limite de 10 MB por imagem do Cloudinary gratuito; o ideal é 3 a 4 MB (cada visualização gasta banda/créditos).
const MAX_GIF_BYTES = 8 * 1024 * 1024;
// V75.148: vídeo curto (MP4/WebM) no banner e no popup do Master. Mesmo teto do GIF; o ideal é 2 a 4 MB (720p, sem áudio, 5 a 10 s).
const TIPOS_VIDEO = ["video/mp4", "video/webm"];
const MAX_VIDEO_BYTES = 8 * 1024 * 1024;
// Alguns aparelhos/computadores mandam o arquivo sem tipo; nesse caso vale a extensão.
function tipoDoArquivo(file) {
  if (file?.type) return file.type;
  const n = String(file?.name || "").toLowerCase();
  return n.endsWith(".mp4") ? "video/mp4" : n.endsWith(".webm") ? "video/webm" : "";
}

// V75.118: tudo que o YAPOOD envia fica na pasta "yapood" do Cloudinary. Assim a Faxina de imagens (Master) separa o que é
// do YAPOOD do que é de outros projetos que usam a mesma conta.
const PASTA = "yapood";

// V75.119: contas no modo novo de pastas usam "asset_folder"; as antigas, "folder". Manda os dois; se o Cloudinary recusar,
// tenta só "folder" e, por último, sem pasta (o envio nunca quebra por causa da pasta).
const FORMAS_PASTA = [{ folder: PASTA, asset_folder: PASTA }, { folder: PASTA }, {}];

async function postar(file, preset, pasta, recurso = "image") {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("upload_preset", preset);
  for (const [k, v] of Object.entries(pasta || {})) fd.append(k, v);
  let res;
  try { res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/${recurso}/upload`, { method: "POST", body: fd }); }
  catch { throw new Error(recurso === "video" ? "Sem conexão para enviar o vídeo. Confira a internet e tente de novo." : "Sem conexão para enviar a foto. Confira a internet e tente de novo."); }
  const data = await res.json().catch(() => ({}));
  return { res, data };
}

async function enviar(file, preset, { gif = false, video = false } = {}) {
  if (!file) throw new Error(video ? "Selecione uma imagem ou vídeo." : "Selecione uma imagem.");
  const tipo = tipoDoArquivo(file);
  const aceitos = [...TIPOS, ...(gif || video ? ["image/gif"] : []), ...(video ? TIPOS_VIDEO : [])];
  if (!aceitos.includes(tipo)) throw new Error(video ? "Formato não permitido. Use JPG, PNG, WEBP, GIF, MP4 ou WEBM." : gif ? "Formato não permitido. Use JPG, PNG, WEBP ou GIF." : "Formato não permitido. Use JPG, PNG ou WEBP.");
  const ehVideo = TIPOS_VIDEO.includes(tipo);
  const limite = ehVideo ? MAX_VIDEO_BYTES : (gif || video) && tipo === "image/gif" ? MAX_GIF_BYTES : MAX_BYTES;
  if (file.size > limite) throw new Error(`${ehVideo ? "O vídeo" : "A imagem"} ultrapassa ${limite / 1048576} MB.${ehVideo ? " Comprima (720p, sem áudio, 5 a 10 segundos) e tente de novo." : tipo === "image/gif" ? " Reduza o GIF (largura de 1000 px e menos quadros) e tente de novo." : ""}`);

  let res, data;
  for (let i = 0; i < FORMAS_PASTA.length; i++) {
    ({ res, data } = await postar(file, preset, FORMAS_PASTA[i], ehVideo ? "video" : "image"));
    if (res.ok || !/folder/i.test(String(data?.error?.message || ""))) break; // erro que não é da pasta: não adianta tentar de outro jeito
    console.warn("Cloudinary não aceitou a pasta assim; tentando de outro jeito:", preset, FORMAS_PASTA[i], data?.error?.message);
  }
  if (!res.ok) {
    // V75.106: mostra o motivo que o Cloudinary devolveu (antes era sempre a mesma frase, sem pista do que configurar).
    const motivo = String(data?.error?.message || `HTTP ${res.status}`).slice(0, 160);
    console.error("Cloudinary recusou:", preset, res.status, data);
    const dica = ehVideo ? " Confira no Cloudinary (Settings → Upload → preset upload_pub) se vídeo e os formatos mp4/webm estão liberados." : "";
    const e = new Error(`O Cloudinary rejeitou ${ehVideo ? "o vídeo" : "a imagem"} (${motivo}).${dica}`); e.cloudinary = true; e.preset = preset; throw e;
  }
  return { url: data.secure_url, public_id: data.public_id, tipo: ehVideo ? "video" : "imagem" };
}

// Mantém a API global usada pelo admin (retorna null em falha, como antes)
window.uploadImagemCloudinary = (file) => enviar(file, "upload_").catch((e) => { console.error("Erro upload:", e); return null; });
window.uploadImagemCloudinaryPub = (file) => enviar(file, "upload_pub").catch((e) => { console.error("Erro upload pub:", e); return null; });
// V75.147: banner do Master, aceita GIF. Diferente das duas acima, NÃO engole o erro: quem chama mostra o motivo real (formato, tamanho ou resposta do Cloudinary).
window.uploadImagemCloudinaryGif = (file) => enviar(file, "upload_pub", { gif: true });
// V75.148: banner e popup do Master aceitam imagem, GIF e vídeo curto (MP4/WebM). Também não engole o erro.
window.uploadMidiaCloudinary = (file) => enviar(file, "upload_pub", { gif: true, video: true });

// V75.35 — foto do relato de problema (cliente). Mesmo preset do app; devolve só a URL e explica o erro (não engole a falha).
// V75.106: se o preset "upload_" recusar, tenta o "upload_pub" (o outro preset sem assinatura do app) antes de desistir.
window.uploadImagemRelato = async (file) => {
  try { return (await enviar(file, "upload_")).url; }
  catch (e) { if (!e.cloudinary) throw e; return (await enviar(file, "upload_pub").catch(() => { throw e; })).url; }
};
