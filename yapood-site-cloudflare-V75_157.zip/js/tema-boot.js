/* V75.41 — Aplica a cor do app ANTES da tela aparecer (sem "piscar" a cor antiga). Script clássico, sem imports.
   Lê a cor em teste deste aparelho (se houver) ou a última cor oficial guardada; js/tema.js confere com o banco depois. */
(function () {
  try {
    var j = localStorage.getItem('yapood_tema_teste') || localStorage.getItem('yapood_tema_v1');
    if (!j) return;
    var t = JSON.parse(j), v = { primaria: '--cor-primaria', escura: '--cor-primaria-escura', suave: '--cor-primaria-suave', sobre: '--cor-sobre-primaria', texto: '--cor-primaria-texto', rgb: '--cor-primaria-rgb' };
    var st = document.documentElement.style;
    for (var k in v) if (t[k] && /^[#0-9a-f, ]+$/i.test(t[k])) st.setProperty(v[k], t[k]);
    // logo da tela de carregamento: cores ORIGINAIS da logo (letras brancas, olhos e sorriso mostarda). Só quando a cor do app é clara (letras escuras) os olhos e o sorriso viram brancos, para não sumirem no fundo mostarda.
    if (t.sobre) st.setProperty('--cor-acento-logo', /^#f{3,6}$/i.test(t.sobre) ? '#efb638' : '#ffffff');
    var m = document.querySelector('meta[name="theme-color"][data-tema]');
    if (m && t.primaria) m.setAttribute('content', t.primaria);
  } catch (e) { /* modo privado ou dado antigo: vale a cor padrão do CSS */ }
  // V75.131 — cores da barra do carrinho e da sacola (Master), guardadas da última vez
  try {
    var s = JSON.parse(localStorage.getItem('yapood_sacola_v1') || 'null'), ds = document.documentElement.style;
    if (s && /^#[0-9a-f]{6}$/i.test(s.barra || '')) ds.setProperty('--barra-carrinho', s.barra);
    if (s && /^#[0-9a-f]{6}$/i.test(s.sacola || '')) ds.setProperty('--sacola-cor', s.sacola);
  } catch (e) { /* vale o padrão do CSS */ }
})();
