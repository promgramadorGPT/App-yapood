// js/admin-combo.js — V75.128: no painel da loja, montar um combo com produtos do cardápio.
// A regra (validar e gravar) é a de combo.js (comboParaBanco); aqui só desenha o editor e mostra a soma "de / por" ao vivo.
import { comboParaBanco, ehCombo, COMBO } from './combo.js?v=75.128';

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const reais = (n) => `R$ ${(Math.round((Number(n) || 0) * 100) / 100).toFixed(2).replace('.', ',')}`;

let ctx = { menu: {}, proprioId: null, precoInput: null };

/** Produtos que podem entrar num combo: os do cardápio que não são combos (nem o próprio). */
function opcoesDeProduto(selecionado) {
  const lista = Object.entries(ctx.menu || {}).filter(([id, p]) => p && id !== ctx.proprioId && !ehCombo(p))
    .sort((a, b) => String(a[1].categoria || '').localeCompare(String(b[1].categoria || ''), 'pt-BR') || String(a[1].nombre || '').localeCompare(String(b[1].nombre || ''), 'pt-BR'));
  return `<option value="">Escolha o produto</option>` + lista.map(([id, p]) => `<option value="${esc(id)}"${id === selecionado ? ' selected' : ''}>${esc(p.nombre || 'Produto')} · ${reais(p.precio)}${p.disponible === false ? ' (pausado)' : ''}</option>`).join('');
}
const htmlLinha = (id = '', qtd = 1) => `<div class="combo-linha">
  <select class="combo-prod" aria-label="Produto do combo">${opcoesDeProduto(id)}</select>
  <input class="combo-qtd" inputmode="numeric" value="${esc(qtd)}" aria-label="Quantidade" title="Quantidade">
  <button type="button" class="ext-x" data-rem-combo aria-label="Tirar do combo"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button></div>`;

function linhas(caixa) {
  return [...caixa.querySelectorAll('.combo-linha')].map((l) => ({ id: l.querySelector('.combo-prod')?.value || '', qtd: l.querySelector('.combo-qtd')?.value || '' }));
}

function atualizarResumo(caixa) {
  const corpo = caixa.querySelector('.combo-corpo'), ligado = caixa.querySelector('#item-eh-combo')?.checked;
  if (corpo) corpo.hidden = !ligado;
  const el = caixa.querySelector('.combo-resumo'); if (!el || !ligado) return;
  const de = linhas(caixa).reduce((s, l) => s + (Number(ctx.menu?.[l.id]?.precio) || 0) * Math.max(1, parseInt(l.qtd, 10) || 1), 0);
  const por = parseFloat(ctx.precoInput?.value) || 0;
  if (!de) { el.textContent = 'Escolha os produtos para ver a soma.'; el.className = 'combo-resumo'; return; }
  el.className = 'combo-resumo' + (por > 0 && por < de ? ' ok' : ' aviso');
  el.textContent = por > 0 && por < de
    ? `Soma dos produtos: ${reais(de)} · Combo: ${reais(por)} · O cliente economiza ${reais(de - por)}`
    : `Soma dos produtos: ${reais(de)}. Coloque no "Preço" um valor menor para o cliente ver a economia.`;
}

/**
 * Desenha o editor. opts: { item, menu, proprioId, precoInput, ligado } (ligado força o combo, ex.: botão "Novo combo").
 */
export function montarEditorCombo(caixa, { item = null, menu = {}, proprioId = null, precoInput = null, ligado = false } = {}) {
  if (!caixa) return;
  ctx = { menu, proprioId, precoInput };
  const atual = ehCombo(item) ? Object.entries(item.combo.itens) : [];
  const on = ligado || atual.length > 0;
  caixa.innerHTML = `<section class="ext-bloco combo-bloco">
      <label class="ext-check combo-liga"><input type="checkbox" id="item-eh-combo"${on ? ' checked' : ''}> <strong>Este produto é um combo</strong></label>
      <small class="combo-ajuda">Junte produtos do cardápio por um preço só. O cliente vê a soma riscada e quanto economiza. Para deixar escolher (ex.: a bebida), use "Opções de escolha" logo abaixo.</small>
      <div class="combo-corpo"${on ? '' : ' hidden'}>
        <div class="combo-linhas">${(atual.length ? atual : [['', 1], ['', 1]]).map(([id, q]) => htmlLinha(id, q)).join('')}</div>
        <button type="button" class="ext-add" data-add-combo><i class="fa-solid fa-plus" aria-hidden="true"></i> Produto</button>
        <p class="combo-resumo" aria-live="polite"></p>
      </div>
    </section>`;
  atualizarResumo(caixa);
  if (caixa.dataset.ligado) return;
  caixa.dataset.ligado = '1';
  caixa.addEventListener('click', (ev) => {
    const b = ev.target.closest('button'); if (!b) return;
    if (b.hasAttribute('data-add-combo')) {
      const l = caixa.querySelector('.combo-linhas');
      if (l.children.length >= COMBO.maxItens) return;
      l.insertAdjacentHTML('beforeend', htmlLinha());
      l.lastElementChild.querySelector('select')?.focus();
    } else if (b.hasAttribute('data-rem-combo')) b.closest('.combo-linha').remove();
    atualizarResumo(caixa);
  });
  caixa.addEventListener('change', () => atualizarResumo(caixa));
  caixa.addEventListener('input', () => atualizarResumo(caixa));
  precoInput?.addEventListener('input', () => atualizarResumo(caixa));
}

/** Lê o editor → { ok, combo: {itens}|null } | { ok:false, erro }. Desligado = não é combo (null apaga). */
export function lerEditorCombo(caixa) {
  if (!caixa || !caixa.querySelector('#item-eh-combo')?.checked) return { ok: true, combo: null };
  return comboParaBanco(linhas(caixa).filter((l) => l.id), ctx.menu, ctx.proprioId);
}
