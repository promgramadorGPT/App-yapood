// V75.62 — confere a foto do documento ANTES de enviar (só avisa; quem decide é o Master).
// Funções puras sobre os pixels em tons de cinza, testadas em tests/foto-qualidade.test.mjs.
export const MIN_LADO = 600;      // menor lado da foto (px)
export const ESCURA = 70;         // brilho médio (0–255) abaixo disto = escura
export const CLARA = 225;         // brilho médio acima disto = clara demais
export const REFLEXO_FRACAO = 0.3; // fração de pixels quase brancos que indica reflexo/estourado
export const NITIDEZ_MIN = 45;    // variância do Laplaciano abaixo disto = tremida/desfocada

/** Variância do Laplaciano (medida clássica de nitidez). `cinza` = Uint8Array largura*altura. */
export function nitidez(cinza, largura, altura) {
  if (largura < 3 || altura < 3) return 0;
  let soma = 0, soma2 = 0, n = 0;
  for (let y = 1; y < altura - 1; y++) {
    for (let x = 1; x < largura - 1; x++) {
      const i = y * largura + x;
      const l = 4 * cinza[i] - cinza[i - 1] - cinza[i + 1] - cinza[i - largura] - cinza[i + largura];
      soma += l; soma2 += l * l; n++;
    }
  }
  const media = soma / n;
  return soma2 / n - media * media;
}

/** @returns {{ avisos: {codigo:string, texto:string}[], metricas: object }} */
export function analisarQualidade({ largura, altura, cinza }) {
  const avisos = [];
  const total = largura * altura;
  let soma = 0, brancos = 0;
  for (let i = 0; i < total; i++) { soma += cinza[i]; if (cinza[i] >= 250) brancos++; }
  const brilho = total ? soma / total : 0, fracBranco = total ? brancos / total : 0;
  const nit = nitidez(cinza, largura, altura);
  if (Math.min(largura, altura) < MIN_LADO) avisos.push({ codigo: 'pequena', texto: 'A foto está pequena. Chegue mais perto do documento, sem cortar as bordas.' });
  if (brilho < ESCURA) avisos.push({ codigo: 'escura', texto: 'A foto está escura. Tire de novo com mais luz.' });
  else if (brilho > CLARA || fracBranco > REFLEXO_FRACAO) avisos.push({ codigo: 'reflexo', texto: 'A foto está muito clara ou com reflexo. Evite a luz direta em cima do documento.' });
  if (nit < NITIDEZ_MIN) avisos.push({ codigo: 'tremida', texto: 'A foto parece tremida ou fora de foco. Apoie o celular e espere focar antes de tirar.' });
  return { avisos, metricas: { brilho: Math.round(brilho), fracBranco: +fracBranco.toFixed(2), nitidez: Math.round(nit) } };
}

/** Navegador: decodifica a foto (data URL) em tons de cinza com no máximo 480 px de largura. */
export async function lerCinza(dataUrl, larguraMax = 480) {
  const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error('imagem')); i.src = dataUrl; });
  const ow = img.naturalWidth, oh = img.naturalHeight;
  const f = Math.min(1, larguraMax / ow), largura = Math.max(1, Math.round(ow * f)), altura = Math.max(1, Math.round(oh * f));
  const tela = document.createElement('canvas'); tela.width = largura; tela.height = altura;
  const ctx = tela.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(img, 0, 0, largura, altura);
  const { data } = ctx.getImageData(0, 0, largura, altura);
  const cinza = new Uint8Array(largura * altura);
  for (let i = 0, p = 0; i < cinza.length; i++, p += 4) cinza[i] = (data[p] * 299 + data[p + 1] * 587 + data[p + 2] * 114) / 1000;
  return { largura, altura, cinza, origLargura: ow, origAltura: oh };
}

/** Navegador: analisa a foto já comprimida. Nunca lança — se não der para analisar, devolve sem avisos. */
export async function avisosDaFoto(dataUrl) {
  try {
    const { largura, altura, cinza, origLargura, origAltura } = await lerCinza(dataUrl);
    const r = analisarQualidade({ largura, altura, cinza });
    if (Math.min(origLargura, origAltura) >= MIN_LADO) r.avisos = r.avisos.filter((a) => a.codigo !== 'pequena');
    return r.avisos;
  } catch { return []; }
}
