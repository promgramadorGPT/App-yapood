// js/rastreio-adm.js — V75.137: rastreio dentro do card do pedido no painel da loja. Módulo isolado: se falhar, os pedidos seguem normais.
// Fechado: uma etiqueta curta no resumo ("Carlos · 1,3 km · chega ~19:08"). Aberto: bloco no topo com quem leva, ligar (entregador
// da loja), distância, hora prevista e a pista. Lê rastreio/{pedido} (as regras deixam o dono da loja ler) e quem está atribuído
// (entregadores-admin.js). A posição do entregador nunca chega aqui: só a distância que a API grava.
import { db, ref, onValue } from './firebase.js';
import { normalizarStatus, escapeHtml as esc } from './regras.js';
import { painelRastreio, linkLigar } from './rastreio.js?v=75.137';
import { svgMotoYapood } from './icone-moto.js?v=75.137';

const LOJA = '<svg viewBox="0 0 24 24" width="12" height="12" aria-hidden="true"><path fill="currentColor" d="M4 9 5 4h14l1 5v1a3 3 0 0 1-5 2 3 3 0 0 1-6 0 3 3 0 0 1-5-2zM5 14h14v6H5z"/></svg>';
const FONE = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z"/></svg>';
const MINI = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="currentColor" d="M5 14a3 3 0 1 0 .01 0zM19 14a3 3 0 1 0 .01 0zM8 13h6.5l3-4.5h-4l-1-2h-3l1 2H9z"/></svg>';
const MOTO = svgMotoYapood(40);

const regs = new Map();   // pedidoKey -> último registro de rastreio
const ouvindo = new Map(); // pedidoKey -> função para parar de ouvir

function htmlChip(r) { return `<span class="ra-chip ra-${r.tom}">${MINI} ${esc(r.chip)}</span>`; }
function htmlBloco(r) {
  const tag = r.tipo === 'parceiro' ? '<span class="ra-tag ra-parc"><span class="ra-ponto"></span> Parceiro YaPOOD</span>' : `<span class="ra-tag ra-loja">${LOJA} Entregador da loja</span>`;
  const tel = r.tipo === 'loja' ? linkLigar(r.telefone) : '';
  const quem = `<span class="ra-quem"><b>${esc(r.nome)}</b> ${esc(r.acao)}${r.detalhe ? ` <small>· ${esc(r.detalhe)}</small>` : ''}${tel ? ` · <a href="${tel}" class="ra-ligar">${FONE} ligar</a>` : ''}</span>`;
  const dist = r.dist && r.eta ? `<div class="ra-dist">A cerca de <b>${esc(r.dist)}</b> · chega em ~${r.eta.min} min (${esc(r.eta.hora)})</div>` : '';
  const pista = r.progresso !== null && r.progresso !== undefined ? `<div class="ra-pista" aria-hidden="true"><span class="ra-linha"><span class="ra-feito" style="width:${Math.min(92, Math.max(0, r.progresso))}%"></span></span><span class="ra-moto" style="left:${Math.min(92, Math.max(4, r.progresso))}%">${MOTO}</span></div>` : '';
  return `<div class="ra-top">${tag}${quem}</div>${dist}${pista}${r.nota ? `<small class="ra-nota">${esc(r.nota)}</small>` : ''}`;
}

/** Põe (ou tira) a etiqueta e o bloco de um card. Só mexe no DOM quando o conteúdo mudou (o MutationObserver chama de novo). */
function pintarCard(card, r) {
  const resumo = card.querySelector('.order-summary-main'), det = card.querySelector('.order-details');
  let chip = card.querySelector('.ra-chip-host'), bloco = card.querySelector('.ra');
  if (!r) { chip?.remove(); bloco?.remove(); return; }
  const hc = htmlChip(r), hb = htmlBloco(r);
  if (resumo) {
    if (!chip) { chip = document.createElement('span'); chip.className = 'ra-chip-host'; resumo.append(chip); }
    if (chip.dataset.h !== hc) { chip.dataset.h = hc; chip.innerHTML = hc; }
  }
  if (det) {
    if (!bloco) { bloco = document.createElement('div'); bloco.className = 'ra'; bloco.setAttribute('role', 'status'); det.prepend(bloco); }
    if (bloco.dataset.h !== hb) { bloco.dataset.h = hb; bloco.innerHTML = hb; bloco.className = `ra ra-${r.tom}`; }
  }
}

function ouvir(k) {
  if (ouvindo.has(k)) return;
  ouvindo.set(k, onValue(ref(db, `rastreio/${k}`), (s) => { regs.set(k, s.exists() ? s.val() : null); agendar(); }, () => { regs.set(k, null); agendar(); }));
}
function parar(k) { ouvindo.get(k)?.(); ouvindo.delete(k); regs.delete(k); }

function atualizar() {
  const lista = document.getElementById('lista-pedidos-loja'), pedidos = window.__yapood?.pedidos || [];
  if (!lista) return;
  const aCaminho = new Set();
  lista.querySelectorAll('.order-card').forEach((card) => {
    const k = card.querySelector('[data-pedido]')?.dataset.pedido, p = pedidos.find((x) => x.key === k);
    if (!p || p.tipoEntrega !== 'delivery' || p.entregaConfirmada === true) { pintarCard(card, null); return; }
    const status = normalizarStatus(p.status);
    if (status === 'En camino') { aCaminho.add(k); ouvir(k); }
    const r = painelRastreio({ status, reg: regs.get(k) || null, atribuido: window.__yapoodEntregadores?.atribuidoDe?.(k) || null });
    pintarCard(card, r);
  });
  [...ouvindo.keys()].forEach((k) => { if (!aCaminho.has(k)) parar(k); });
}

let pendente = false;
function agendar() { if (pendente) return; pendente = true; requestAnimationFrame(() => { pendente = false; try { atualizar(); } catch (e) { console.warn('Rastreio no card:', e); } }); }

const lista = document.getElementById('lista-pedidos-loja');
if (lista) new MutationObserver(agendar).observe(lista, { childList: true, subtree: true });
document.addEventListener('yapood:entregas', agendar);
setInterval(() => { if (!document.hidden) agendar(); }, 20000); // hora prevista e "sem sinal" mudam com o tempo
agendar();
