// js/mapa-nav.js — motor de navegação do mapa do entregador (V75.90). Só funções puras: sem DOM, sem rede, sem Firebase.
// Nasceu do laboratório YaMaps e foi validado com rota real: construir a rota, achar a posição na linha, anunciar manobras
// (voz no estilo Waze), semáforos no caminho, ordem das paradas e a moto que não troca de lado.
// A tela (mapa, painel, GPS, voz) fica em mapa-ui.js.
const R = 6371000, rad = d => d*Math.PI/180, deg = r => r*180/Math.PI;

function haversine(a, b){
  const dLat = rad(b[1]-a[1]), dLng = rad(b[0]-a[0]);
  const s = Math.sin(dLat/2)**2 + Math.cos(rad(a[1]))*Math.cos(rad(b[1]))*Math.sin(dLng/2)**2;
  return 2*R*Math.asin(Math.min(1, Math.sqrt(s)));
}
function rumoEntre(a, b){
  const y = Math.sin(rad(b[0]-a[0]))*Math.cos(rad(b[1]));
  const x = Math.cos(rad(a[1]))*Math.sin(rad(b[1])) - Math.sin(rad(a[1]))*Math.cos(rad(b[1]))*Math.cos(rad(b[0]-a[0]));
  return (deg(Math.atan2(y, x)) + 360) % 360;
}
function deslocar(p, rumoGraus, metros){ // [lng,lat] deslocado
  const br = rad(rumoGraus);
  return [p[0] + deg(metros*Math.sin(br)/(R*Math.cos(rad(p[1])))), p[1] + deg(metros*Math.cos(br)/R)];
}

function formatarDist(m){
  if (!Number.isFinite(m) || m < 0) return '—';
  if (m < 1000) return Math.max(10, Math.round(m/10)*10) + ' m';
  const km = Math.round(m/100)/10;
  return (km < 10 ? String(km).replace('.', ',') : String(Math.round(km))) + ' km';
}
function formatarTempo(s){
  if (!Number.isFinite(s) || s < 0) return '—';
  const min = Math.max(1, Math.round(s/60));
  if (min < 60) return min + ' min';
  return Math.floor(min/60) + ' h ' + String(min%60).padStart(2, '0') + ' min';
}

/** Feature do Geoapify Routing -> rota pronta para navegar. */
function construirRota(feature){
  const g = feature && feature.geometry;
  if (!g) return null;
  const coords = [], legOffsets = [];
  if (g.type === 'LineString') { legOffsets.push(0); g.coordinates.forEach(p => coords.push(p)); }
  else if (g.type === 'MultiLineString') g.coordinates.forEach(leg => { legOffsets.push(coords.length); leg.forEach(p => coords.push(p)); });
  else return null;
  if (coords.length < 2) return null;
  const cum = [0];
  for (let i = 1; i < coords.length; i++) cum.push(cum[i-1] + haversine(coords[i-1], coords[i]));
  const props = feature.properties || {}, legs = props.legs || [];
  const passos = [];
  legs.forEach((leg, li) => (leg.steps || []).forEach(st => {
    const idx = Math.min(coords.length-1, (legOffsets[li] || 0) + (st.from_index || 0));
    const ins = st.instruction || {};
    passos.push({ idx, inicioM: cum[idx], distancia: st.distance || 0, tempo: st.time || 0, tipo: ins.type || '', textoApi: ins.text || '', nome: (st.name || '').trim(), perna: li, parada: li + 1, final: li === legs.length - 1 });
  }));
  if (!passos.length) passos.push({ idx: 0, inicioM: 0, distancia: cum[cum.length-1], tempo: props.time || 0, tipo: 'StartAt', textoApi: '', nome: '', perna: 0, parada: 1, final: true });
  // fim de cada trecho (parada) em metros ao longo da linha; o último é o destino
  const paradasM = legOffsets.map((_, li) => cum[(li + 1 < legOffsets.length ? legOffsets[li + 1] : coords.length) - 1]);
  // Cada trecho termina numa chegada. Se a API não mandou o passo de chegada (ou mandou com outro nome), cria um aqui.
  const nLegs = legOffsets.length;
  for (let li = 0; li < nLegs; li++) {
    const fimIdx = (li + 1 < nLegs ? legOffsets[li + 1] : coords.length) - 1;
    const doTrecho = passos.filter(p => p.perna === li), ult = doTrecho[doTrecho.length - 1];
    if (ult && /^destination/i.test(ult.tipo)) continue;
    if (ult && ult.idx === fimIdx && ult.distancia === 0 && doTrecho.length > 1) { ult.tipo = 'DestinationReached'; continue; }
    const novo = { idx: fimIdx, inicioM: paradasM[li], distancia: 0, tempo: 0, tipo: 'DestinationReached', textoApi: '', nome: '', perna: li, parada: li + 1, final: li === nLegs - 1, sintetico: true };
    let pos = passos.length; for (let j = passos.length - 1; j >= 0; j--) { if (passos[j].perna <= li) { pos = j + 1; break; } }
    passos.splice(pos, 0, novo);
  }
  const pernas = legOffsets.map((_, li) => ({ distancia: (legs[li] && legs[li].distance) || 0, tempo: (legs[li] && legs[li].time) || 0 }));
  return { coords, cum, total: cum[cum.length-1], passos, paradasM, pernas, apiDist: props.distance || null, tempoS: props.time || 0 };
}

/** Parada (0, 1, ...) que o entregador está indo atender, a partir dos metros percorridos. */
function paradaAlvo(rota, m, concl){ let k = 0; while (k < rota.paradasM.length - 1 && (m > rota.paradasM[k] + 10 || (concl && concl.has(k)))) k++; return k; }

function posicaoAoLongo(rota, m){
  const c = rota.coords, cum = rota.cum, total = rota.total;
  const d = Math.max(0, Math.min(total, m));
  let lo = 0, hi = cum.length - 1;
  while (lo < hi - 1) { const mid = (lo + hi) >> 1; if (cum[mid] <= d) lo = mid; else hi = mid; }
  const seg = cum[hi] - cum[lo], t = seg > 0 ? (d - cum[lo])/seg : 0;
  const a = c[lo], b = c[hi];
  return { lng: a[0] + (b[0]-a[0])*t, lat: a[1] + (b[1]-a[1])*t, rumo: rumoEntre(a, b), idx: lo };
}

/** Projeta um ponto na rota -> metros percorridos e distância até a linha. */
function projetar(rota, lng, lat, aPartirDe){
  const c = rota.coords, cum = rota.cum, k = Math.cos(rad(lat));
  const busca = (de, ate) => {
    const cand = []; let minD = Infinity;
    for (let i = 0; i < c.length - 1; i++) {
      if (cum[i+1] < de || cum[i] > ate) continue;
      const ax = (c[i][0]-lng)*k*R*Math.PI/180, ay = (c[i][1]-lat)*R*Math.PI/180;
      const bx = (c[i+1][0]-lng)*k*R*Math.PI/180, by = (c[i+1][1]-lat)*R*Math.PI/180;
      const dx = bx-ax, dy = by-ay, len2 = dx*dx + dy*dy;
      let t = len2 > 0 ? (-ax*dx - ay*dy)/len2 : 0;
      t = Math.max(0, Math.min(1, t));
      const px = ax + dx*t, py = ay + dy*t, dist = Math.hypot(px, py);
      cand.push({ m: cum[i] + (cum[i+1]-cum[i])*t, desvioM: dist });
      if (dist < minD) minD = dist;
    }
    if (!cand.length) return { m: 0, desvioM: Infinity };
    // V75.101: rota que volta ao ponto de partida (retorno no quarteirão, paradas no mesmo endereço): vários trechos ficam a poucos metros do GPS.
    // Vale o PRIMEIRO deles (o que vem logo depois de onde a moto estava); antes valia sempre o mais próximo e a moto "pulava" para o fim da rota.
    return cand.find((x) => x.desvioM <= minD + 6);
  };
  // Rotas com várias paradas passam duas vezes pela mesma rua: perto de onde a moto estava vale mais do que o ponto mais próximo da rota inteira.
  if (typeof aPartirDe === 'number') {
    const local = busca(aPartirDe - 40, aPartirDe + 250);
    if (local.desvioM <= 40) return local;
  }
  return busca(-Infinity, Infinity);
}

function passoAtual(rota, m){
  let i = 0;
  for (let j = 0; j < rota.passos.length; j++) if (rota.passos[j].inicioM <= m + 1) i = j;
  return i;
}

const FEM = /^(rua|avenida|av\.?|travessa|alameda|estrada|rodovia|pra[cç]a|ladeira|via|marginal|vila|passarela|ponte)\b/i;
const MASC = /^(beco|viaduto|largo|t[uú]nel|caminho|parque|anel|corredor|elevado|acesso|trevo|contorno)\b/i;
function com(nome, fem, masc, neutro){ // "na Rua X" / "no Beco Y" / "em BR-116"
  if (!nome) return '';
  if (FEM.test(nome)) return ' ' + fem + ' ' + nome;
  if (MASC.test(nome)) return ' ' + masc + ' ' + nome;
  return ' ' + neutro + ' ' + nome;
}
function textoLocal(p){
  const t = String(p.tipo || '').toLowerCase(), n = (p.nome || '').trim();
  const lado = t.includes('right') ? 'à direita' : t.includes('left') ? 'à esquerda' : '';
  const em = com(n, 'na', 'no', 'em');
  if (t.startsWith('start')) return n ? 'Siga' + com(n, 'pela', 'pelo', 'por') : 'Siga em frente';
  if (t.startsWith('destination')) {
    if (p.final === false) return 'Você chegou à parada ' + p.parada + (p.rotuloParada ? ', ' + p.rotuloParada : '');
    return 'Você chegou ao destino' + (lado ? ', ' + lado : '');
  }
  if (t.includes('uturn') || t.includes('turnaround')) return 'Faça o retorno' + em;
  if (t.includes('roundabout')) return p.textoApi ? corrigirGenero(falaCurta(p.textoApi)) : (t.includes('exit') ? 'Saia da rotatória' : 'Entre na rotatória') + em; // o texto da API diz qual saída pegar
  if (t.startsWith('ramp') || t.startsWith('exit')) return 'Pegue a saída ' + (lado || 'em frente') + em;
  if (t.startsWith('merge')) return 'Entre na via' + em;
  if (t.startsWith('sharp')) return 'Faça uma curva fechada ' + lado + em;
  if (t.startsWith('slight')) return 'Curva leve ' + lado + em;
  if (t === 'right' || t === 'left') return 'Vire ' + lado + em;
  if (t.startsWith('stay')) return 'Mantenha-se ' + (lado || 'em frente') + em;
  if (t.startsWith('continue') || t.includes('straight')) return 'Siga em frente' + (n ? com(n, 'pela', 'pelo', 'por') : '');
  return p.textoApi || ('Siga em frente' + em);
}
/** O texto da API erra o artigo ("no Avenida"). Conserta pelo tipo de via. */
const ORD = ['', 'primeira', 'segunda', 'terceira', 'quarta', 'quinta', 'sexta', 'sétima', 'oitava', 'nona', 'décima'];
function corrigirGenero(txt){
  return String(txt || '')
    .replace(/\brotundas?\b/gi, m => (m[0] === 'R' ? 'R' : 'r') + 'otatória' + (/s$/i.test(m) ? 's' : '')) // pt-PT -> pt-BR
    .replace(/\b(?:e\s+)?(?:saia|sair)\s+na\s+sa[ií]da\s+(\d+)\s*[ºª°]?/gi, (m, n) => (/^e\s/i.test(m) ? 'e ' : '') + 'pegue a ' + (ORD[+n] || n + 'ª') + ' saída')
    .replace(/\bna\s+sa[ií]da\s+(\d+)\s*[ºª°]/gi, (m, n) => 'na ' + (ORD[+n] || n + 'ª') + ' saída')
    .replace(/\bConduza para (norte|sul|leste|oeste|nordeste|noroeste|sudeste|sudoeste)\b/g, 'Siga para o $1')
    .replace(/\b(no|na|do|da|ao|à|pelo|pela)\s+(Rua|Avenida|Av\.|Travessa|Alameda|Estrada|Rodovia|Pra[cç]a|Ladeira|Via|Marginal|Vila|Passarela|Ponte)\b/gi, (m, art, via) => ({ no: 'na', do: 'da', ao: 'à', pelo: 'pela', na: 'na', da: 'da', 'à': 'à', pela: 'pela' })[art.toLowerCase()] + ' ' + via)
    .replace(/\b(na|da|à|pela|no|do|ao|pelo)\s+(Beco|Viaduto|Largo|T[uú]nel|Caminho|Parque|Anel|Corredor|Elevado|Acesso|Trevo|Contorno)\b/gi, (m, art, via) => ({ na: 'no', da: 'do', 'à': 'ao', pela: 'pelo', no: 'no', do: 'do', ao: 'ao', pelo: 'pelo' })[art.toLowerCase()] + ' ' + via);
}
/** Tira o "em direção a ..." do final: na voz e no painel só atrapalha. */
function falaCurta(txt){ return String(txt || '').replace(/[,.]?\s+em dire[cç][aã]o\s+(?!ao\s+(norte|sul|leste|oeste|nordeste|noroeste|sudeste|sudoeste)\b)(a|à|ao|aos|às)\s+.*$/i, '').replace(/\s+$/, ''); } // \"Siga em direção ao norte na Rua X\" (largada) fica inteiro
function textoPasso(p, modo){ return (modo === 'api' && p.textoApi && !(/^destination/i.test(p.tipo) && (p.final === false || p.sintetico)) ? corrigirGenero(falaCurta(p.textoApi)) : textoLocal(p)).replace(/[.,;\s]+$/, ''); } // sem ponto no fim: senão sai "bifurcação., e logo depois"

const minuscula = s => s ? s.charAt(0).toLowerCase() + s.slice(1) : s;
function metrosFalados(m){ return m < 100 ? Math.round(m/10)*10 : Math.round(m/50)*50; }

const COLADO_M = 150, NUM = ['', '', 'duas', 'três'];
/** "Siga em frente" / mudança de nome de rua não é manobra: não se fala e não aparece no sinal (Waze e Google também não avisam). */
function ehManobra(p){
  const t = String((p && p.tipo) || '').toLowerCase();
  if (!t || t === 'none') return false;
  if (t.startsWith('start') || t.startsWith('destination')) return true;
  if (t === 'continue' || t.includes('straight')) return false;
  return true;
}
/** Passo de rotatória logo depois de outro (entrar e sair): o texto da entrada já diz qual saída pegar, então a saída não vira outra fala. */
function saidaDeRotatoria(passos, i){
  const t = x => String((x && x.tipo) || '').toLowerCase();
  return i > 0 && t(passos[i]).includes('roundabout') && t(passos[i-1]).includes('roundabout') && passos[i].inicioM - passos[i-1].inicioM < COLADO_M;
}
/** Próxima manobra de verdade depois de m (nunca "siga em frente"); se não houver, a chegada. */
function proximaManobra(rota, m){
  const P = rota.passos;
  for (let j = 0; j < P.length; j++) if (P[j].inicioM > m + 1 && ehManobra(P[j]) && !saidaDeRotatoria(P, j) && !/^start/i.test(P[j].tipo)) return P[j];
  return P[P.length - 1];
}
const ehCurva = t => /^(right|left|slight|sharp)/i.test(t || '');
/** Frase de um grupo de curvas coladas: iguais -> "Vire à direita na Rua B, três vezes seguidas"; diferentes -> "..., e logo depois, ...". */
function fraseGrupo(grupo, modo){
  if (grupo.length === 1) return textoPasso(grupo[0], modo);
  if (grupo.every(g => g.tipo === grupo[0].tipo && ehCurva(g.tipo))) return textoPasso(grupo[0], modo) + ', ' + NUM[grupo.length] + ' vezes seguidas';
  return textoPasso(grupo[0], modo) + grupo.slice(1).map(g => ', e logo depois, ' + minuscula(textoPasso(g, modo))).join('');
}
/** Avisos antes da curva: [distância do aviso, trecho mínimo e máximo desde a curva anterior]. No máximo dois por curva (trecho longo: 1 km e 300 m), cada um falado uma vez. */
const AVISOS = [[1000, 1500, Infinity], [300, 600, Infinity], [150, 250, 600]];
const faladoDist = m => m >= 1000 ? (m === 1000 ? '1 quilômetro' : String(Math.round(m/100)/10).replace('.', ',') + ' quilômetros') : metrosFalados(m) + ' metros';
/**
 * Frases a falar agora, no estilo Waze/Google: "Em 300 metros, vire à direita na Rua B" ... "Agora, vire à direita".
 * `feitos` (Set) lembra o que já foi dito; passos já ultrapassados ficam em silêncio.
 * antecipado=false: só fala na hora da curva. Até 3 curvas a menos de 150 m uma da outra viram uma frase só.
 */
function anunciosPendentes(rota, m, feitos, modo, antecipado, detalhes){
  const out = [], dizer = (f, p, q) => { out.push(f); if (detalhes) detalhes.push({ tipo: p.tipo, api: p.textoApi, inicioM: Math.round(p.inicioM), nome: p.nome, quando: q || 'na curva' }); }, P = rota.passos.filter((p, i, a) => i === 0 || (ehManobra(p) && !saidaDeRotatoria(a, i))); // passos "siga em frente" ficam em silêncio
  P.forEach((p, i) => {
    if (i === 0) { if (!feitos.has('0')) { feitos.add('0'); dizer(textoPasso(p, modo), p, 'largada'); } return; }
    const falta = p.inicioM - m;
    if (falta < -30) { feitos.add(i + 'n'); feitos.add(i + 'a'); return; }
    if (feitos.has(i + 'n')) return;
    if (p.final === false && /^destination/i.test(p.tipo)) { feitos.add(i + 'n'); feitos.add(i + 'a'); return; } // quem avisa a chegada na parada é verificarParada
    if (/^start/i.test(p.tipo) && p.perna > 0 && !(rota.concl && rota.concl.has(p.perna - 1)) && falta > -30) return; // só depois de concluir a parada
    const grupo = [p];
    for (let j = i + 1; !/^destination/i.test(p.tipo) && j < P.length && grupo.length < 3; j++) {
      if (P[j].inicioM - P[j-1].inicioM >= COLADO_M || /^(destination|start)/i.test(P[j].tipo)) break;
      grupo.push(P[j]);
    }
    if (falta <= 30) {
      feitos.add(i + 'n');
      for (let j = 1; j < grupo.length; j++) feitos.add((i + j) + 'n');
      if (feitos.has(i + 'a')) dizer('Agora, ' + minuscula(modo === 'api' ? textoPasso(p, modo) : textoLocal({ ...p, nome: '' })), p, 'agora');
      else dizer(fraseGrupo(grupo, modo), p, grupo.length > 1 ? 'curvas juntas' : 'na curva');
      return;
    }
    if (!antecipado || /^destination/i.test(p.tipo)) return;
    const gap = p.inicioM - P[i-1].inicioM;
    for (const [dist, minimo, maximo] of AVISOS) {
      if (gap < minimo || gap >= maximo || falta > dist || feitos.has(i + 't' + dist)) continue;
      AVISOS.forEach(([d]) => { if (d >= Math.min(dist, falta)) feitos.add(i + 't' + d); }); // avisos já ultrapassados não são falados depois
      feitos.add(i + 'a');
      dizer('Em ' + faladoDist(falta > dist - 40 ? dist : falta) + ', ' + minuscula(fraseGrupo(grupo, modo)), p, 'aviso antes');
      break;
    }
  });
  return out;
}

/** Une várias falas do mesmo instante numa só (falar uma por vez cortaria a anterior). */
function juntarFalas(arr){ return arr.map(f => String(f).replace(/[.\s]+$/, '')).join('. '); }
/** Semáforos que ficam em cima da rota: `pontos` [{id, lat, lon}] -> [{id, m}] em ordem, sem repetir o mesmo cruzamento (menos de 25 m entre eles). */
function semaforosNaRota(rota, pontos){
  const lista = [];
  pontos.forEach(p => { const pj = projetar(rota, p.lon, p.lat); if (pj.desvioM <= 25) lista.push({ id: p.id, m: pj.m }); });
  lista.sort((a, b) => a.m - b.m);
  return lista.filter((x, i) => i === 0 || x.m - lista[i-1].m > 25);
}
/** Próximo semáforo à frente (até `alcance` metros) ou null. */
function proximoSemaforo(rota, m, alcance){
  const s = (rota.sem || []).find(x => x.m > m + 5);
  return s && s.m - m <= (alcance || 400) ? { id: s.id, dist: s.m - m } : null;
}
/** Sinal da manobra (para o ícone): 'reto' | 'dir' | 'esq' | 'dir-leve' | 'esq-leve' | 'dir-forte' | 'esq-forte' | 'retorno-dir' | 'retorno-esq' | 'rotatoria' | 'chegada'. */
function sinalDoPasso(tipo){
  const t = String(tipo || '').toLowerCase(), lado = t.includes('left') ? 'esq' : 'dir';
  if (t.startsWith('destination')) return 'chegada';
  if (t.includes('uturn') || t.includes('turnaround')) return 'retorno-' + lado;
  if (t.includes('roundabout')) return 'rotatoria';
  if (t.startsWith('sharp')) return lado + '-forte';
  if (t.startsWith('slight') || t.startsWith('ramp') || t.startsWith('exit') || t.startsWith('stay') || t.startsWith('merge')) return (t.includes('right') || t.includes('left')) ? lado + '-leve' : 'reto';
  if (t === 'right' || t === 'left') return lado;
  return 'reto';
}
/** Ícone da manobra (Font Awesome): seta que gira conforme a curva. Devolve HTML fixo do motor, sem texto vindo de fora. */
function iconeSinal(chave){
  const seta = (graus) => '<i class="fa-solid fa-arrow-up"' + (graus ? ' style="transform:rotate(' + graus + 'deg)"' : '') + ' aria-hidden="true"></i>';
  const fa = (nome) => '<i class="fa-solid fa-' + nome + '" aria-hidden="true"></i>';
  switch (chave) {
    case 'dir': return seta(90);
    case 'esq': return seta(-90);
    case 'dir-leve': return seta(45);
    case 'esq-leve': return seta(-45);
    case 'dir-forte': return seta(135);
    case 'esq-forte': return seta(-135);
    case 'retorno-dir': return fa('rotate-right');
    case 'retorno-esq': return fa('rotate-left');
    case 'rotatoria': return fa('arrows-spin');
    case 'chegada': return fa('flag-checkered');
    default: return seta(0);
  }
}
const horaChegada = s => new Date(Date.now() + s*1000).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

/** Diferença percentual formatada, ex.: "+8%" */
function difPct(meu, ref){ if (!(ref > 0) || !Number.isFinite(meu)) return null; const d = (meu-ref)/ref*100; return (d >= 0 ? '+' : '') + Math.round(d) + '%'; }

function suavizarAngulo(atual, novo, k){
  if (typeof atual !== 'number') return novo;
  const d = ((novo - atual + 540) % 360) - 180;
  return (atual + d*k + 360) % 360;
}

/** V75.152: rumo da rota em `m` metros percorridos, olhando `adiante` metros à frente (a curva não "pisca"). null se não há rota. */
function rumoDaRotaEm(rota, m, adiante = 25){
  if (!rota || !Array.isArray(rota.coords) || rota.coords.length < 2) return null;
  const a = posicaoAoLongo(rota, m), b = posicaoAoLongo(rota, (Number(m) || 0) + adiante);
  if (haversine([a.lng, a.lat], [b.lng, b.lat]) < 2) return a.rumo;
  return rumoEntre([a.lng, a.lat], [b.lng, b.lat]);
}
const difAngulo = (a, b) => Math.abs((((a - b) % 360) + 540) % 360 - 180);
/**
 * V75.152: para onde a moto e o mapa apontam. Antes só valia o rumo do GPS (que some parado/devagar e treme com sinal fraco):
 * parado ou no começo, o mapa ficava com o norte para cima e a moto parecia andar na contramão da rota.
 *  • na rota (até `desvioMax` m da linha): segue o rumo da rota (firme, sem tremer);
 *  • exceção: se o GPS mostra claramente o contrário (mais de `contrarioGraus` de diferença), vale o GPS (a pessoa está indo no sentido oposto);
 *  • fora da rota: rumo do GPS, ou do deslocamento; sem nenhum, null (mantém o que já tinha).
 */
function escolherRumo({ gps = null, deslocado = null, rumoRota = null, desvioM = null, desvioMax = 30, contrarioGraus = 100 } = {}){
  const ok = (v) => typeof v === 'number' && Number.isFinite(v);
  const real = ok(gps) ? gps : ok(deslocado) ? deslocado : null;
  const naRota = ok(rumoRota) && ok(desvioM) && desvioM <= desvioMax;
  if (naRota) return ok(real) && difAngulo(real, rumoRota) > contrarioGraus ? real : rumoRota;
  return ok(real) ? real : null;
}

/** A moto é desenhada de lado, virada para a direita. Vira para a esquerda quando o rumo, na tela, aponta para a esquerda. */
function motoVirada(rumo, giroMapa, atual){
  if (typeof rumo !== 'number' || !Number.isFinite(rumo)) return !!atual;
  const rel = (((rumo - (giroMapa || 0)) % 360) + 360) % 360;
  if (rel > 195 && rel < 345) return true;   // claramente para a esquerda
  if (rel > 15 && rel < 165) return false;   // claramente para a direita
  return !!atual;                            // quase reto (norte/sul) ou no limite: não troca de lado
}

/** Melhor ordem de visita (não volta à loja), por força bruta: com até 5 paradas são só 120 combinações. Usa linha reta. */
function melhorOrdem(o, pts){
  const n = pts.length;
  if (n < 3) return pts.map((_, i) => i);
  const d = (a, b) => haversine([a.lng, a.lat], [b.lng, b.lat]);
  let melhor = null, melhorD = Infinity;
  const usados = new Array(n).fill(false), atual = [];
  (function rec(ult, soma){
    if (soma >= melhorD) return;
    if (atual.length === n) { melhor = atual.slice(); melhorD = soma; return; }
    for (let i = 0; i < n; i++) { if (usados[i]) continue; usados[i] = true; atual.push(i); rec(pts[i], soma + d(ult, pts[i])); atual.pop(); usados[i] = false; }
  })(o, 0);
  return melhor;
}
function distOrdem(o, pts, ordem){ let t = 0, ult = o; ordem.forEach(i => { t += haversine([ult.lng, ult.lat], [pts[i].lng, pts[i].lat]); ult = pts[i]; }); return t; }

export { haversine, rumoEntre, rumoDaRotaEm, escolherRumo, deslocar, formatarDist, formatarTempo, construirRota, paradaAlvo, posicaoAoLongo, projetar, passoAtual, com, textoLocal, ORD, corrigirGenero, falaCurta, textoPasso, minuscula, metrosFalados, COLADO_M, ehManobra, saidaDeRotatoria, proximaManobra, ehCurva, fraseGrupo, AVISOS, faladoDist, anunciosPendentes, juntarFalas, semaforosNaRota, proximoSemaforo, sinalDoPasso, iconeSinal, horaChegada, difPct, suavizarAngulo, motoVirada, melhorOrdem, distOrdem };
