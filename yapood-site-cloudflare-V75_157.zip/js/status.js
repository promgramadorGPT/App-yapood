import { db, auth, ref, onValue, update, set, query, orderByChild, equalTo, onAuthStateChanged } from './firebase.js';
import { escapeHtml, normalizarStatus, normalizarPagamento, rotuloStatus, rotuloPagamento, STATUS, FLUXO_STATUS, PAGO } from './regras.js';
import { formatarMoeda, toast, comTrava, confirmar } from './utils.js';
import { textoTroco, trocoSeguro } from './troco.js';
import { registrarNotaNoAgregado } from './pedido-service.js';
import { nomeDoCliente } from './perfil-nome.js?v=75.106';
import { detalhesDaLinha } from './combo.js?v=75.128';
import { svgMotoYapood } from './icone-moto.js?v=75.137';
import { aplicarBloqueio } from './avaliacao-tags.js?v=75.139';
import { linhasSaldo, saldoUsado } from './saldo-loja.js?v=75.145';
import { devolverSaldoDoPedido } from './saldo-api.js?v=75.145';
import { estadoRastreio, modoRastreio, posicaoMoto, avaliarLocalizacaoCliente, coordParaPedido, textoErroLocalizacao, estimativaChegada, quemLeva, linkLigar, detalheQuemLeva, coordValida } from './rastreio.js?v=75.137';

const $ = (id) => document.getElementById(id);
const inputCodigo = $('input-codigo-pedido');
const containerStatus = $('card-status-container');

let desinscrever = null;   // evita empilhar listeners a cada nova busca (bug da versão anterior)
let pedidoAtual = null;

// V75.86 — rastreio por distância: só o dono do pedido. A API grava rastreio/{pedido}; aqui só se lê.
// Três situações: sem localização salva (botão para ativar), localização salva mas o entregador ainda não saiu, e "a caminho" (distância).
// Pista do entregador: loja -> casa, com a moto andando conforme a distância diminui (ícones inline, sem depender de fonte externa).
const SVG_LOJA = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M4 9 5 4h14l1 5v1a3 3 0 0 1-5 2 3 3 0 0 1-6 0 3 3 0 0 1-5-2zM5 14h14v6H5z"/></svg>';
const SVG_CASA = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M3 11 12 3l9 8v10h-6v-7H9v7H3z"/></svg>';
const SVG_MOTO = svgMotoYapood(60); // V75.136: moto do YaPOOD (js/icone-moto.js)
const pista = (progresso) => `<div class="rastreio-pista" aria-hidden="true"><span class="rp-linha"><span class="rp-feito" style="width:${posicaoMoto(progresso)}%"></span></span>
  <span class="rp-ponto rp-ini">${SVG_LOJA}</span><span class="rp-ponto rp-fim">${SVG_CASA}</span><span class="rp-moto" style="left:${posicaoMoto(progresso)}%">${SVG_MOTO}</span></div>`;
let rastreioKey = null, rastreioOff = null, rastreioReg = null, rastreioRelogio = null, rastreioModo = null, rastreioMsg = '', rastreioBusy = false;
function pararRastreio() { rastreioOff?.(); rastreioOff = null; rastreioKey = null; rastreioReg = null; rastreioModo = null; rastreioMsg = ''; clearInterval(rastreioRelogio); rastreioRelogio = null; }
const botaoAtivar = () => `<button type="button" class="rastreio-btn" id="btn-ativar-rastreio"${rastreioBusy ? ' disabled' : ''}><i class="fa-solid fa-location-crosshairs" aria-hidden="true"></i> ${rastreioBusy ? 'Buscando o GPS…' : 'Ative para acompanhar a entrega em tempo real'}</button>
      ${rastreioMsg ? `<small class="rastreio-erro" role="alert">${escapeHtml(rastreioMsg)}</small>` : ''}`;
// V75.136 — quem leva: etiqueta "Entregador da loja" (com o botão de ligar) ou "Parceiro YaPOOD"
const SVG_FONE = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z"/></svg>';
function htmlQuem(q) {
  if (!q) return '';
  const loja = q.tipo === 'loja';
  const tag = loja ? `<span class="rq-tag rq-tag-loja">${SVG_LOJA.replace(/22/g, '13')} Entregador da loja</span>` : '<span class="rq-tag rq-tag-parceiro"><span class="rq-ponto" aria-hidden="true"></span> Parceiro YaPOOD</span>';
  const det = detalheQuemLeva(q), tel = loja ? linkLigar(q.telefone) : '';
  return `${tag}<div class="rastreio-quem rq-${loja ? 'loja' : 'parceiro'}"><span class="rq-avatar" aria-hidden="true">${escapeHtml(q.nome.charAt(0).toUpperCase())}</span>
    <span class="rq-tx"><b>${escapeHtml(q.nome)}</b> está levando seu pedido${det ? `<br><small>${escapeHtml(det).replace(/placa ([A-Z0-9]+)/, 'placa <b class="rq-placa">$1</b>')}</small>` : ''}</span>
    ${tel ? `<a class="rq-ligar" href="${tel}" aria-label="Ligar para ${escapeHtml(q.nome)}">${SVG_FONE}</a>` : ''}</div>`;
}
function desenharRastreio() {
  const box = document.getElementById('rastreio-card');
  if (!box) return;
  const semGps = !coordValida(pedidoAtual?.entregaCoord) && pedidoAtual?.entregaParceira !== true;
  // V75.136: a caminho sem registro ainda e sem o GPS do cliente: continua oferecendo o botão
  if (rastreioModo === 'ativar' || (rastreioModo === 'ao-vivo' && !rastreioReg && semGps)) {
    box.innerHTML = `<div class="rastreio rastreio-ativar">
      <div class="rastreio-topo"><i class="fa-solid fa-location-dot" aria-hidden="true"></i><strong>Acompanhe a entrega em tempo real</strong></div>
      <small>Veja a que distância o entregador está de você. Use só se estiver no local da entrega.</small>
      ${botaoAtivar()}</div>`;
    return;
  }
  if (rastreioModo === 'aguardar') {
    box.innerHTML = `<div class="rastreio rastreio-aguardando"><div class="rastreio-topo"><i class="fa-solid fa-circle-check" aria-hidden="true"></i><strong>Acompanhamento ativado</strong></div>
      <small>Quando o entregador sair com o seu pedido, a distância aparece aqui, ao vivo.</small></div>`;
    return;
  }
  const e = estadoRastreio(rastreioReg);
  const icone = e.estado === 'chegando' ? 'fa-bell-concierge' : e.estado === 'sem-sinal' ? 'fa-signal' : e.estado === 'aguardando' ? 'fa-hourglass-half' : 'fa-motorcycle';
  // V75.124: quem leva e a previsão de chegada. V75.136: também o entregador da loja (com o botão de ligar)
  const q = quemLeva(rastreioReg);
  const quem = htmlQuem(q);
  const eta = ['a-caminho', 'perto'].includes(e.estado) ? estimativaChegada(e.distanciaM, q && q.veiculo ? q.veiculo : 'moto') : null;
  const linhaEta = eta ? `<div class="rastreio-eta"><i class="fa-regular fa-clock" aria-hidden="true"></i><span>Chega em cerca de <b>${eta.min} min</b> · por volta das ${escapeHtml(eta.hora)}</span></div>` : '';
  box.innerHTML = `<div class="rastreio rastreio-${e.estado}" role="status" aria-live="polite">
      ${quem}
      <div class="rastreio-topo"><i class="fa-solid ${icone}" aria-hidden="true"></i><strong>${escapeHtml(e.texto)}</strong></div>
      ${linhaEta}
      ${e.estado === 'aguardando' || e.estado === 'saiu' ? '' : pista(e.progresso)}
      <small>${escapeHtml(e.detalhe)}</small>${e.estado === 'saiu' && semGps ? botaoAtivar() : ''}</div>`;
}
function sincronizarRastreio(p) {
  const dono = !!(auth.currentUser?.uid && auth.currentUser.uid === p.clienteUid);
  const modo = modoRastreio({ ehDono: dono, pedido: { ...p, status: normalizarStatus(p.status) } });
  if (modo !== 'ao-vivo') { // sem assinatura: só mostra o botão ou o aviso
    const m = modo; pararRastreio(); rastreioModo = m; rastreioKey = m ? p._key : null; if (m) desenharRastreio(); return;
  }
  rastreioModo = 'ao-vivo';
  if (rastreioKey !== p._key || !rastreioOff) {
    pararRastreio(); rastreioModo = 'ao-vivo';
    rastreioKey = p._key;
    rastreioOff = onValue(ref(db, `rastreio/${p._key}`), (snap) => { rastreioReg = snap.exists() ? snap.val() : null; desenharRastreio(); }, () => { rastreioReg = null; desenharRastreio(); });
    rastreioRelogio = setInterval(desenharRastreio, 15000); // reavalia "sem sinal" mesmo sem novidade no banco
  }
  desenharRastreio();
}
// Cliente que ainda não marcou a localização: pega o GPS agora e grava no pedido (as regras só deixam o dono, enquanto o pedido não foi entregue).
containerStatus.addEventListener('click', (ev) => {
  const btn = ev.target.closest('#btn-ativar-rastreio'); if (!btn || rastreioBusy || !pedidoAtual) return;
  const chave = pedidoAtual._key;
  if (!navigator.geolocation) { rastreioMsg = 'Este aparelho não permite usar a localização.'; desenharRastreio(); return; }
  rastreioBusy = true; rastreioMsg = ''; desenharRastreio();
  navigator.geolocation.getCurrentPosition(async (pos) => {
    const r = avaliarLocalizacaoCliente(pos);
    if (!r.ok) { rastreioBusy = false; rastreioMsg = r.texto; desenharRastreio(); return; }
    try { await set(ref(db, `pedidos/${chave}/entregaCoord`), coordParaPedido(r.coord, 'delivery')); rastreioMsg = ''; }
    catch (e) { console.warn('Localização não salva:', e); const cod = String(e?.code || '').toLowerCase().replace(/[^a-z_-]/g, '').slice(0, 30); rastreioMsg = `Não foi possível ativar agora${cod ? ` (${cod})` : ''}. Tente de novo em instantes.`; }
    rastreioBusy = false; desenharRastreio();
  }, (err) => { rastreioBusy = false; rastreioMsg = textoErroLocalizacao(err?.code); desenharRastreio(); }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
});

const normalizarCodigo = (v) => String(v || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

const codigoURL = normalizarCodigo(new URLSearchParams(location.search).get('num'));
let querAvaliar = new URLSearchParams(location.search).get('avaliar') === '1';
if (codigoURL) { inputCodigo.value = codigoURL; monitorar(codigoURL); } else mostrarVazio();

$('btn-buscar-pedido').addEventListener('click', () => {
  const cod = normalizarCodigo(inputCodigo.value);
  if (!cod) return;
  history.pushState({}, '', `status.html?num=${cod}`);
  monitorar(cod);
});
inputCodigo.addEventListener('keydown', (e) => { if (e.key === 'Enter') $('btn-buscar-pedido').click(); });
onAuthStateChanged(auth, () => { if (pedidoAtual) renderizar(pedidoAtual); });

function mostrarVazio() {
  containerStatus.innerHTML = '<div class="msg-vazio"><i class="fa-solid fa-receipt fa-2x" style="color:#ccc"></i><p>Digite o código do seu pedido para ver o status em tempo real.</p></div>';
}
function mostrarErro(msg) {
  containerStatus.innerHTML = `<div class="msg-erro"><i class="fa-solid fa-circle-exclamation fa-2x" style="color:#dc3545"></i><p>${escapeHtml(msg)}</p></div>`;
}

// Consulta INDEXADA por código (antes baixava a coleção `pedidos` inteira — dados de todos os clientes — e filtrava no navegador).
function monitorar(codigo) {
  desinscrever?.();
  pararRastreio();
  pedidoAtual = null;
  containerStatus.innerHTML = '<p class="loading"><i class="fa-solid fa-spinner fa-spin"></i> Carregando pedido...</p>';
  desinscrever = onValue(query(ref(db, 'pedidos'), orderByChild('numeroPedido'), equalTo(codigo)), (snap) => {
    if (!snap.exists()) return mostrarErro(`Não encontramos nenhum pedido com o código #${codigo}`);
    const [chave, p] = Object.entries(snap.val())[0];
    pedidoAtual = { ...p, _key: chave };
    renderizar(pedidoAtual);
  }, (err) => {
    console.error(err);
    mostrarErro('Não foi possível consultar o pedido. Verifique o código e tente novamente.');
  });
}

function renderizar(p) {
  const status = normalizarStatus(p.status);
  const cancelado = status === STATUS.CANCELADO;
  const idx = FLUXO_STATUS.indexOf(status);
  const dono = auth.currentUser?.uid && auth.currentUser.uid === p.clienteUid;
  const pago = normalizarPagamento(p.pagoStatus);

  const passos = [
    ['Recebido', 'fa-clipboard-check'], ['Em preparo', 'fa-fire-burner'], [p.tipoEntrega === 'retirada' ? 'Pronto para retirar' : 'Em entrega', p.tipoEntrega === 'retirada' ? 'fa-store' : 'fa-motorcycle'], ['Entregue', 'fa-house-circle-check']
  ];
  const stepper = cancelado ? '<div class="aviso-cancelado"><i class="fa-solid fa-ban"></i> Pedido cancelado</div>' :
    `<div class="stepper-status">${passos.map(([label, icon], i) =>
      `<div class="passo-item ${i < idx ? 'completed' : i === idx ? 'active' : ''}"><div class="passo-icone"><i class="fa-solid ${icon}"></i></div><span class="passo-label">${label}</span></div>`).join('')}</div>`;

  const _f = String(p.formaPagamento || '').toLowerCase(), nomeForma = _f.includes('dinheiro') ? 'Dinheiro' : _f.includes('cart') ? 'Cartão' : 'Pagamento';
  const tagPagamento = (pago === PAGO.NA_ENTREGA && p.entregaConfirmada === true) ? `<span class="badge-pago pago"><i class="fa-solid fa-circle-check"></i> ${nomeForma}: pago</span>`
    : pago === PAGO.APROVADO ? '<span class="badge-pago pago"><i class="fa-solid fa-circle-check"></i> Pago</span>'
    : pago === PAGO.NA_ENTREGA ? '<span class="badge-pago entrega"><i class="fa-solid fa-hand-holding-dollar"></i> Pagar na entrega</span>'
    : '<span class="badge-pago pendente"><i class="fa-solid fa-clock"></i> Pagamento pendente</span>';

  const itens = (p.itens || []).map((i) => `<li><span>${Number(i.qtd) || 0}x ${escapeHtml(i.nombre)}${detalhesDaLinha(i).length ? `<small class="extras-item">${escapeHtml(detalhesDaLinha(i).join(' · '))}</small>` : ''}</span> <strong>${formatarMoeda((i.precio || 0) * (i.qtd || 0))}</strong></li>`).join('');
  const cod = escapeHtml(p.numeroPedido || '');

  // Dados pessoais só aparecem para o dono do pedido; quem tem apenas o código vê o primeiro nome.
  const nome = escapeHtml(dono ? p.cliente?.nombre : String(p.cliente?.nombre || 'Cliente').split(' ')[0]);
  const retirada = p.tipoEntrega === 'retirada';
  const entrega = dono ? (retirada ? `<p><strong><i class="fa-solid fa-store"></i> Modalidade:</strong> Retirada na loja</p>` : `<p><strong><i class="fa-solid fa-location-dot"></i> Endereço:</strong> ${escapeHtml(p.cliente?.direccion)}</p>`) : '';

  let wa = '';
  let linkEnvio = null;
  try { linkEnvio = sessionStorage.getItem(`wa_${p.numeroPedido}`); } catch { /* noop */ }
  if (linkEnvio && dono && !cancelado) wa += `<a class="btn-whatsapp-enviar" href="${escapeHtml(linkEnvio)}" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Falar com a loja pelo WhatsApp</a>`;
  const fone = String(p.lojaTelefone || '').replace(/\D/g, '');
  if (fone) wa += `<a class="btn-whatsapp-contato" href="https://wa.me/${fone}?text=${encodeURIComponent(`Olá, quero consultar sobre meu PEDIDO #${p.numeroPedido}`)}" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> Entrar em contato com o restaurante</a>`;

  const podeCancelar = dono && status === STATUS.PENDENTE && pago !== PAGO.APROVADO;
  const podeAvaliar = dono && status === STATUS.ENTREGUE && !p.avaliado;
  const botaoAvaliacao = podeAvaliar
    ? `<button type="button" class="btn-avaliar-status" id="btn-avaliar-status"><i class="fa-solid fa-star"></i> Avaliar loja</button>`
    : '';

  containerStatus.innerHTML = `
    <div class="card-status ${cancelado ? 'cancelado' : ''}">
      <div class="header-card-status"><div><h3>Pedido #${cod}</h3><small>${escapeHtml(p.lojaNome || 'Restaurante')}</small></div>${tagPagamento}</div>
      ${stepper}
      <div id="rastreio-card"></div>
      <div class="detalhes-status">
        <h4><i class="fa-solid fa-receipt"></i> Detalhes da compra</h4>
        <ul class="lista-itens-status">${itens}</ul>
        <div class="totais-status">
          <p><span>Subtotal:</span> ${formatarMoeda(p.subtotal)}</p>
          <p><span>${retirada ? 'Retirada:' : 'Entrega:'}</span> ${retirada ? 'Grátis' : (p.precioEnvio ? formatarMoeda(p.precioEnvio) : 'Grátis')}</p>
          ${p.desconto > 0 ? `<p><span>Desconto${p.premioFidelidade ? ' (Presente fidelidade)' : (p.cupomCodigo ? ` (${escapeHtml(p.cupomCodigo)})` : '')}:</span> -${formatarMoeda(p.desconto)}</p>` : ''}
          <p class="total-linha"><span>Total:</span> <strong>${formatarMoeda(p.total)}</strong></p>
          ${linhasSaldo(p, formatarMoeda).map((l) => `<p class="${l.forte ? 'total-linha' : 'saldo-linha'}"><span>${escapeHtml(l.rotulo)}:</span> ${l.forte ? `<strong>${l.valor}</strong>` : l.valor}</p>`).join('')}
        </div><hr>
        <div class="info-entrega-status">
          <p><strong><i class="fa-solid fa-user"></i> Cliente:</strong> ${nome}</p>${entrega}
          <p><strong><i class="fa-solid fa-wallet"></i> Forma de Pagamento:</strong> ${escapeHtml(p.formaPagamento)}</p>${(()=>{const tt=textoTroco(trocoSeguro(p.troco), formatarMoeda);return tt?`<p><strong><i class="fa-solid fa-money-bill-wave"></i> Troco:</strong> ${escapeHtml(tt)}</p>`:''})()}
        </div>
        <div class="acoes-status" style="margin-top:20px">${wa}${botaoAvaliacao}${podeCancelar ? '<button type="button" class="btn-cancelar-pedido" id="btn-cancelar-pedido">Cancelar pedido</button>' : ''}</div>
      </div>
    </div>`;
  sincronizarRastreio(p);

  $('btn-avaliar-status')?.addEventListener('click', () => abrirAvaliacaoStatus(p));
  // V75.143: veio do botão "Avaliar" da notificação (status.html?num=…&avaliar=1): abre a avaliação uma vez
  if (querAvaliar && $('btn-avaliar-status') && auth.currentUser) { querAvaliar = false; abrirAvaliacaoStatus(p); }

  $('btn-cancelar-pedido')?.addEventListener('click', async () => {
    if (!await confirmar({ titulo: 'Cancelar este pedido?', texto: 'A loja será avisada do cancelamento.', rotulo: 'Cancelar pedido', cancelar: 'Voltar', perigo: true })) return;
    try {
      await update(ref(db, `pedidos/${p._key}`), { status: STATUS.CANCELADO }); toast('Pedido cancelado.', 'success');
      if (saldoUsado(p) > 0) devolverSaldoDoPedido(p._key).then((r) => toast(`${formatarMoeda(r.valor)} voltaram para o seu saldo na loja.`, 'success', 6000)).catch((e) => console.warn('Saldo do pedido cancelado:', e)); // V75.145
    }
    catch (e) { console.error(e); toast('Não foi possível cancelar. Entre em contato com a loja.', 'error'); }
  });
}


// ---------- Avaliação aberta diretamente na página de status ----------
let pedidoAvaliandoStatus = null;
let notaComidaStatus = 0, notaEntregaStatus = 0;
let tagsComidaStatus = [], tagsEntregaStatus = [];

const modalAvaliacaoStatus = $('modal-avaliacao-status');

function pintarAvaliacaoStatus(id, nota) {
  document.querySelectorAll(`#${id} .estrela`).forEach((e) => {
    e.style.color = Number(e.dataset.valor) <= nota ? '#ffc107' : '#ccc';
  });
}

function abrirAvaliacaoStatus(p) {
  if (!p || !modalAvaliacaoStatus) return;
  if (!auth.currentUser || auth.currentUser.uid !== p.clienteUid) return toast('Entre com a conta que realizou o pedido.', 'error');
  if (normalizarStatus(p.status) !== STATUS.ENTREGUE) return toast('A avaliação estará disponível quando o pedido for entregue.', 'error');
  if (p.avaliado) return toast('Este pedido já foi avaliado.', 'info');

  pedidoAvaliandoStatus = p;
  notaComidaStatus = 0;
  notaEntregaStatus = 0;
  tagsComidaStatus = [];
  tagsEntregaStatus = [];
  $('avaliacao-loja-nome-status').textContent = p.lojaNome || 'Restaurante';
  $('avaliacao-comentario-status').value = '';
  $('qtd-caracteres-status').textContent = '0';
  $('etapa-comida-status').style.display = 'block';
  $('etapa-entrega-status').style.display = 'none';
  $('titulo-etapa-avaliacao-status').textContent = 'Como estava a comida?';
  $('ponto-etapa-1-status').classList.add('ativo');
  $('ponto-etapa-2-status').classList.remove('ativo');
  document.querySelectorAll('#modal-avaliacao-status .tag-opainter').forEach((t) => t.classList.remove('ativa'));
  document.querySelectorAll('#modal-avaliacao-status .tags-container').forEach(aplicarBloqueio);
  pintarAvaliacaoStatus('estrelas-comida-status', 0);
  pintarAvaliacaoStatus('estrelas-entrega-status', 0);
  modalAvaliacaoStatus.style.display = 'flex';
}

function fecharAvaliacaoStatus() {
  if (modalAvaliacaoStatus) modalAvaliacaoStatus.style.display = 'none';
  pedidoAvaliandoStatus = null;
}

$('btn-fechar-avaliacao-status')?.addEventListener('click', fecharAvaliacaoStatus);
$('btn-proximo-avaliacao-status')?.addEventListener('click', () => {
  if (!notaComidaStatus) return toast('Selecione pelo menos uma estrela para a comida.', 'error');
  $('etapa-comida-status').style.display = 'none';
  $('etapa-entrega-status').style.display = 'block';
  $('titulo-etapa-avaliacao-status').textContent = 'Como foi a entrega?';
  $('ponto-etapa-1-status').classList.remove('ativo');
  $('ponto-etapa-2-status').classList.add('ativo');
});
$('btn-voltar-avaliacao-status')?.addEventListener('click', () => {
  $('etapa-entrega-status').style.display = 'none';
  $('etapa-comida-status').style.display = 'block';
  $('titulo-etapa-avaliacao-status').textContent = 'Como estava a comida?';
  $('ponto-etapa-2-status').classList.remove('ativo');
  $('ponto-etapa-1-status').classList.add('ativo');
});

document.querySelectorAll('#estrelas-comida-status .estrela').forEach((e) => e.addEventListener('click', () => {
  notaComidaStatus = Number(e.dataset.valor);
  pintarAvaliacaoStatus('estrelas-comida-status', notaComidaStatus);
}));
document.querySelectorAll('#estrelas-entrega-status .estrela').forEach((e) => e.addEventListener('click', () => {
  notaEntregaStatus = Number(e.dataset.valor);
  pintarAvaliacaoStatus('estrelas-entrega-status', notaEntregaStatus);
}));

document.querySelectorAll('#modal-avaliacao-status .tag-opainter').forEach((el) => el.addEventListener('click', () => {
  if (el.disabled) return; // V75.139: tag bloqueada (contradiz a já marcada)
  const lista = el.dataset.cat === 'comida' ? tagsComidaStatus : tagsEntregaStatus;
  const txt = el.textContent.trim();
  const i = lista.indexOf(txt);
  el.classList.toggle('ativa', i < 0);
  if (i < 0) lista.push(txt); else lista.splice(i, 1);
  aplicarBloqueio(el.closest('.tags-container'));
}));
$('avaliacao-comentario-status')?.addEventListener('input', (e) => { $('qtd-caracteres-status').textContent = e.currentTarget.value.length; });

$('btn-enviar-avaliacao-status')?.addEventListener('click', (ev) => {
  if (!notaEntregaStatus) return toast('Selecione pelo menos uma estrela para a entrega.', 'error');
  if (!pedidoAvaliandoStatus || !auth.currentUser) return;
  comTrava(ev.currentTarget, async () => {
    const p = pedidoAvaliandoStatus;
    const user = auth.currentUser;
    if (user.uid !== p.clienteUid) return toast('Você não pode avaliar este pedido com esta conta.', 'error');
    const notaMedia = (notaComidaStatus + notaEntregaStatus) / 2;
    try {
      await set(ref(db, `avaliacoes/${p.lojaId}/${p._key}`), {
        pedidoId: p._key,
        numeroPedido: p.numeroPedido,
        clienteUid: user.uid,
        clienteNome: (await nomeDoCliente(user)) || p.cliente?.nombre || 'Cliente',
        notaComida: notaComidaStatus,
        notaEntrega: notaEntregaStatus,
        notaMedia,
        tagsComida: tagsComidaStatus,
        tagsEntrega: tagsEntregaStatus,
        comentario: $('avaliacao-comentario-status').value.trim(),
        aprovada: !$('avaliacao-comentario-status').value.trim(),
        criadoEm: new Date().toISOString()
      });
      await update(ref(db, `pedidos/${p._key}`), { avaliado: true, notaMediaAvaliacao: Math.round(notaMedia) });
      await registrarNotaNoAgregado(p.lojaId, { notaComida: notaComidaStatus, notaEntrega: notaEntregaStatus }).catch((e) => console.warn('Agregado no actualizado:', e));
      p.avaliado = true;
      p.notaMediaAvaliacao = Math.round(notaMedia);
      fecharAvaliacaoStatus();
      renderizar(p);
      toast('Muito obrigado pela sua avaliação!', 'success');
    } catch (e) {
      console.error('Erro ao salvar a avaliação:', e);
      toast('Não foi possível enviar sua avaliação. Tente novamente.', 'error');
    }
  });
});

// V75.13: leitura somente para js/codigo-entrega.js.
window.__yapoodStatus={get pedido(){return pedidoAtual}};
