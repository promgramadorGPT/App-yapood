// js/perfil-util.js — regras puras do perfil do cliente (sem DOM, sem Firebase). Testadas em tests/perfil.test.mjs.
export const NOME_MIN = 2, NOME_MAX = 40;

/** Nome limpo: sem marcações HTML, espaços repetidos viram um só, no máximo 40 letras. '' = vazio. */
export const limparNome = (s) => String(s ?? '').replace(/[<>]/g, '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, NOME_MAX).trim();

export function validarNome(s) {
  const nome = limparNome(s);
  if (nome.length < NOME_MIN) return { ok: false, nome, erro: `Escreva um nome com pelo menos ${NOME_MIN} letras.` };
  if (!/\p{L}/u.test(nome)) return { ok: false, nome, erro: 'O nome precisa ter letras.' };
  return { ok: true, nome, erro: '' };
}

/** Nome mostrado no app: o que o cliente escolheu; se nunca editou, o da conta Google (que ele pode trocar); senão "Cliente". */
export function nomeExibicao(user, dados) {
  if (dados && dados.nomeEditado === true) { const n = limparNome(dados.nome); if (n) return n; }
  return limparNome(user?.displayName) || limparNome(dados?.nome) || 'Cliente';
}
export const primeiroNome = (nome) => limparNome(nome).split(' ')[0] || 'Cliente';

/** Imagem padrão do perfil (a foto da conta Google não é usada). É o mascote do YAPOOD, preenchendo todo o círculo. */
export const AVATAR_URL = 'icons/avatar-cliente.png';
export const AVATAR_HTML = `<img src="${AVATAR_URL}" alt="Foto padrão do perfil" width="70" height="70">`;
