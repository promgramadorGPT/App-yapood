// V75.56 — Aviso de "já existe um pedido em andamento nesta loja". Só avisa; nunca impede o pedido.
import { STATUS, PAGO, normalizarStatus, normalizarPagamento } from './regras.js';

export const JANELA_PEDIDO_ABERTO_MS = 12 * 60 * 60 * 1000; // pedidos mais antigos que isso não contam (esquecidos na loja)

/**
 * Pedidos do cliente, na MESMA loja, que ainda não foram entregues nem cancelados.
 * Ficam de fora: pedidos de Pix/cartão que nunca chegaram a ser pagos (tentativas abandonadas) e os que o chamador manda ignorar.
 */
export function pedidosEmAndamentoNaLoja(pedidos, lojaId, { agora = Date.now(), ignorar = [] } = {}) {
  const lista = Array.isArray(pedidos) ? pedidos : [];
  return lista.filter((p) => {
    if (!p || p.lojaId !== lojaId) return false;
    if (ignorar.includes(p.key)) return false;
    const st = normalizarStatus(p.status);
    if (st === STATUS.ENTREGUE || st === STATUS.CANCELADO) return false;
    if (normalizarPagamento(p.pagoStatus) === PAGO.PENDENTE) return false;
    const t = Date.parse(p.criadoEm);
    if (!Number.isFinite(t) || agora - t > JANELA_PEDIDO_ABERTO_MS || t > agora + 5 * 60 * 1000) return false;
    return true;
  });
}

/** Texto do aviso. */
export function textoPedidoAberto(abertos) {
  const n = abertos.length;
  if (n === 1) {
    const num = abertos[0].numeroPedido ? ` #${abertos[0].numeroPedido}` : '';
    return { titulo: 'Você já tem um pedido em andamento', texto: `O pedido${num} desta loja ainda não foi entregue. Quer fazer outro mesmo assim?`, rotulo: 'Fazer outro pedido' };
  }
  return { titulo: 'Você já tem pedidos em andamento', texto: `Você tem ${n} pedidos desta loja que ainda não foram entregues. Quer fazer outro mesmo assim?`, rotulo: 'Fazer outro pedido' };
}
