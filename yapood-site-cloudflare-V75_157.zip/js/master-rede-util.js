// js/master-rede-util.js — regras PURAS da tela "Entrega parceira" do Master (sem DOM, sem Firebase).
// Define os campos editáveis de /rede/config, valida (cada campo e as combinações), compara antes/depois e monta o que vai ao banco.
// Os padrões espelham PADRAO de js/regras.js do app do entregador (YAPOOD Entrega). Se mudar um lado, mude o outro.
// As faixas (min/max) daqui são as mesmas das regras do Firebase (regras/database.rules.RASCUNHO-V75.111.json); o teste confere.

export const PADRAO_REDE_MESTRE = Object.freeze({
  pctApp: 5, pixMPpct: 0.99, procuraMaxMin: 5, 'graçaMin': 30, pausaHoras: 24, tetoFechamentoHoras: 24, prazoEntregadorHoras: 24,
  novaNaHora: 10, limiteNova: 100, limiteConfiavel: 300,
  cancelaAteChegarPct: 25, cancelaAposChegarPct: 50, cancelaAposColetaPct: 100, esperaMaxMin: 20,
  naHoraMin: 30, fimExpediente: 1320, analiseMinMin: 120,
  raiosKm: { moto: [1, 2, 3, 5, 7, 10, 15, 20], bicicleta: [1, 2, 3, 4] },
  raioPadraoKm: { moto: 5, bicicleta: 3 },
  velocidadeKmh: { moto: 25, bicicleta: 12 },
  janelaDesistenciaDias: 7, pesoDesistenciaPronta: 2, perdoaACadaEntregas: 10, pausasDesistenciaMin: [0, 30, 1440, 4320],
  chegadaRaioM: 150, folgaChegadaMin: 5,
  faltasJanelaDias: 30, faltasMax: 3, pausaFaltasMin: 4320,
  codigoErrosMax: 5, codigoBloqueioMin: 10
});

const V = ['moto', 'bicicleta'];

// tipo: 'int' | 'dec' | 'hora' (minutos desde 00:00, digitado como HH:MM) | 'lista' (km inteiros separados por vírgula)
// fmt:  como mostrar o valor nas mensagens ('pct' | 'rs' | 'min' | 'hora' | 'h' | 'plain')
const c = (path, grupo, rotulo, ajuda, tipo, min, max, fmt, un = '') => ({ path, grupo, rotulo, ajuda, tipo, min, max, fmt, un });

export const GRUPOS = [
  { id: 'comissao', titulo: 'Comissão e tarifa do Pix', nota: 'A comissão sai da parte do entregador (é a “application_fee” do Pix criado com a conta dele). O YAPOOD nunca recebe o dinheiro da entrega.' },
  { id: 'cancelamento', titulo: 'Cancelamento pela loja', nota: 'Quanto da taxa a loja deve ao entregador se cancelar a corrida. Quanto mais avançada a corrida, maior a parte.' },
  { id: 'pagamento', titulo: 'Quando a loja paga o entregador', nota: 'Prazos do Pix da taxa, análise da loja, atraso e limites de dívida aberta.' },
  { id: 'desistencia', titulo: 'Desistências, faltas e chegada', nota: 'Pausas e pontos de quem aceita e larga a corrida, ou causa dano na entrega.' },
  { id: 'raio', titulo: 'Raio de atendimento', nota: 'Opções de raio que o entregador pode escolher, por veículo. O teto de cada veículo é a maior opção da lista.' }
];

export const CAMPOS = [
  c('pctApp', 'comissao', 'Comissão do YAPOOD', '% da taxa de entrega, descontado do entregador. Máx. 20%.', 'dec', 0, 20, 'pct', '%'),
  c('pixMPpct', 'comissao', 'Tarifa do Pix (Mercado Pago)', '% que o Mercado Pago cobra do entregador no Pix. Serve para mostrar o líquido; quem cobra é o MP.', 'dec', 0, 5, 'pct', '%'),

  c('cancelaAteChegarPct', 'cancelamento', 'Entregador a caminho da loja', '% da taxa devida se a loja cancelar nesta fase.', 'dec', 0, 100, 'pct', '%'),
  c('cancelaAposChegarPct', 'cancelamento', 'Entregador já chegou na loja', '% da taxa devida se cancelar com ele esperando.', 'dec', 0, 100, 'pct', '%'),
  c('cancelaAposColetaPct', 'cancelamento', 'Depois de coletar o pedido', '% da taxa devida se cancelar depois da coleta.', 'dec', 0, 100, 'pct', '%'),
  c('esperaMaxMin', 'cancelamento', 'Espera máxima na loja', 'Depois disso o entregador pode desistir sem punição.', 'int', 1, 120, 'min', 'min'),

  c('naHoraMin', 'pagamento', 'Pix “na hora”: prazo', 'Minutos depois da entrega para a loja que paga na hora.', 'int', 5, 240, 'min', 'min'),
  c('fimExpediente', 'pagamento', 'Fechamento do dia', 'Horário em que vence o Pix de quem paga no fechamento.', 'hora', 720, 1439, 'hora', 'HH:MM'),
  c('analiseMinMin', 'pagamento', 'Análise mínima da loja', 'Tempo mínimo entre a entrega e o vencimento para a loja contestar.', 'int', 30, 720, 'min', 'min'),
  c('tetoFechamentoHoras', 'pagamento', 'Prazo máximo no fechamento', 'A loja paga no máximo tantas horas depois da entrega.', 'int', 2, 72, 'h', 'h'),
  c('prazoEntregadorHoras', 'pagamento', 'Prazo prometido ao entregador', 'O app diz ao entregador que recebe em até tantas horas (não pode ser menor que o prazo máximo).', 'int', 2, 168, 'h', 'h'),
  c('graçaMin', 'pagamento', 'Tolerância depois do vencimento', 'Antes de a dívida contar como vencida.', 'int', 0, 360, 'min', 'min'),
  c('pausaHoras', 'pagamento', 'Pausa da loja com dívida vencida', 'Vencida há tantas horas, a loja fica sem receber pedidos novos.', 'int', 1, 168, 'h', 'h'),
  c('procuraMaxMin', 'pagamento', 'Procura por entregador', 'Sem ninguém depois disso, a loja decide o que fazer.', 'int', 1, 60, 'min', 'min'),
  c('novaNaHora', 'pagamento', 'Entregas “na hora” para liberar o fechamento', 'Entregas pagas no prazo até a loja poder pagar no fechamento.', 'int', 0, 100, 'plain', 'entregas'),
  c('limiteNova', 'pagamento', 'Dívida aberta máxima — loja nova', 'Acima disso a loja não chama mais entregador até pagar.', 'int', 10, 5000, 'rs', 'R$'),
  c('limiteConfiavel', 'pagamento', 'Dívida aberta máxima — loja com histórico', 'Mesmo limite para lojas com bom histórico.', 'int', 10, 20000, 'rs', 'R$'),

  c('janelaDesistenciaDias', 'desistencia', 'Janela das desistências', 'Só contam as desistências dos últimos dias.', 'int', 1, 60, 'plain', 'dias'),
  c('pesoDesistenciaPronta', 'desistencia', 'Peso se o pedido já estava pronto', '“Em dobro” = 2. Vale para a desistência depois de a loja marcar como pronto.', 'int', 1, 5, 'plain', 'pontos'),
  c('perdoaACadaEntregas', 'desistencia', 'Perdão a cada entregas', 'A cada tantas entregas concluídas na janela, 1 desistência é perdoada.', 'int', 1, 100, 'plain', 'entregas'),
  c('pausasDesistenciaMin.0', 'desistencia', '1ª desistência: pausa', '0 = só um aviso.', 'int', 0, 43200, 'min', 'min'),
  c('pausasDesistenciaMin.1', 'desistencia', '2ª desistência: pausa', 'Não pode ser menor que a anterior.', 'int', 0, 43200, 'min', 'min'),
  c('pausasDesistenciaMin.2', 'desistencia', '3ª desistência: pausa', 'Não pode ser menor que a anterior.', 'int', 0, 43200, 'min', 'min'),
  c('pausasDesistenciaMin.3', 'desistencia', '4ª ou mais: pausa + revisão do Master', 'Não pode ser menor que a anterior.', 'int', 0, 43200, 'min', 'min'),
  c('faltasJanelaDias', 'desistencia', 'Janela das faltas', 'Faltas (contestação procedente) dos últimos dias.', 'int', 1, 180, 'plain', 'dias'),
  c('faltasMax', 'desistencia', 'Faltas para pausar', 'Ao chegar neste número: pausa e revisão do Master.', 'int', 1, 20, 'plain', 'faltas'),
  c('pausaFaltasMin', 'desistencia', 'Pausa por faltas', 'Duração da pausa ao atingir o número de faltas.', 'int', 0, 43200, 'min', 'min'),
  c('chegadaRaioM', 'desistencia', 'Distância para “Cheguei”', 'O botão só libera a até tantos metros da loja (GPS).', 'int', 50, 1000, 'plain', 'm'),
  c('folgaChegadaMin', 'desistencia', 'Folga de chegada', 'Minutos de tolerância sobre o tempo estimado até a loja.', 'int', 0, 30, 'min', 'min'),
  c('codigoErrosMax', 'desistencia', 'Erros de código de entrega', 'Depois deste número de erros o código é bloqueado.', 'int', 1, 20, 'plain', 'erros'),
  c('codigoBloqueioMin', 'desistencia', 'Bloqueio do código', 'Minutos de espera depois dos erros.', 'int', 1, 240, 'min', 'min'),

  ...V.flatMap((v) => {
    const nome = v === 'moto' ? 'Moto' : 'Bicicleta';
    return [
      c(`raiosKm.${v}`, 'raio', `${nome}: opções de raio`, 'km, números inteiros separados por vírgula (até 12 opções).', 'lista', 1, 50, 'plain', 'km'),
      c(`raioPadraoKm.${v}`, 'raio', `${nome}: raio inicial`, 'Raio do entregador recém-cadastrado. Precisa estar na lista.', 'int', 1, 50, 'plain', 'km'),
      c(`velocidadeKmh.${v}`, 'raio', `${nome}: velocidade média`, 'Para estimar o tempo até a loja.', 'int', 5, 80, 'plain', 'km/h')
    ];
  })
];

export const CAMPO = Object.freeze(Object.fromEntries(CAMPOS.map((x) => [x.path, x])));
export const MAX_OPCOES_RAIO = 12;

// ---------- caminhos ("raiosKm.moto", "pausasDesistenciaMin.2") ----------
export function lerCaminho(obj, path) {
  let o = obj;
  for (const k of path.split('.')) { if (o == null || typeof o !== 'object') return undefined; o = o[k]; }
  return o;
}
export function gravarCaminho(obj, path, v) {
  const ks = path.split('.');
  let o = obj;
  ks.slice(0, -1).forEach((k, i) => { if (o[k] == null || typeof o[k] !== 'object') o[k] = /^\d+$/.test(ks[i + 1]) ? [] : {}; o = o[k]; });
  o[ks[ks.length - 1]] = v;
}
const clonar = (x) => JSON.parse(JSON.stringify(x));
const comoLista = (v) => (Array.isArray(v) ? v : (v && typeof v === 'object' ? Object.values(v) : null)); // o RTDB devolve lista (ou objeto, se faltar um índice)

// ---------- formatação ----------
export const fmtNum = (n) => String(Math.round(Number(n) * 100) / 100).replace('.', ',');
export function fmtDuracao(min) {
  const m = Math.round(Number(min));
  if (!Number.isFinite(m) || m < 0) return '—';
  if (m < 60) return `${m} min`;
  if (m % 1440 === 0) { const d = m / 1440; return `${d} ${d === 1 ? 'dia' : 'dias'}`; }
  if (m % 60 === 0) return `${m / 60} h`;
  return `${Math.floor(m / 60)} h ${m % 60} min`;
}
export const fmtHora = (min) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;

export function formatarValor(campo, v) {
  if (v === undefined || v === null) return '—';
  if (campo.tipo === 'lista') return `${v.join(', ')} km`;
  switch (campo.fmt) {
    case 'pct': return `${fmtNum(v)}%`;
    case 'rs': return `R$ ${fmtNum(v)}`;
    case 'min': return fmtDuracao(v);
    case 'h': return `${fmtNum(v)} h`;
    case 'hora': return fmtHora(v);
    default: return `${fmtNum(v)}${campo.un ? ' ' + campo.un : ''}`;
  }
}

// ---------- leitura de um campo digitado ----------
function faixa(campo) {
  if (campo.tipo === 'hora') return `${fmtHora(campo.min)} e ${fmtHora(campo.max)}`;
  const f = (n) => (campo.fmt === 'pct' ? `${fmtNum(n)}%` : campo.fmt === 'rs' ? `R$ ${fmtNum(n)}` : fmtNum(n));
  return `${f(campo.min)} e ${f(campo.max)}${campo.fmt === 'pct' || campo.fmt === 'rs' ? '' : campo.un && campo.un !== 'HH:MM' ? ' ' + campo.un : ''}`;
}

export function lerNumero(texto, campo) {
  const t = String(texto ?? '').trim();
  let n;
  if (campo.tipo === 'hora') {
    const m = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(t);
    if (!m) return { ok: false, erro: 'Use o formato HH:MM, por exemplo 22:00.' };
    n = Number(m[1]) * 60 + Number(m[2]);
  } else if (campo.tipo === 'dec') {
    if (!/^\d+([.,]\d{1,2})?$/.test(t)) return { ok: false, erro: 'Digite um número, com até 2 casas depois da vírgula.' };
    n = Number(t.replace(',', '.'));
  } else {
    if (!/^\d+$/.test(t)) return { ok: false, erro: 'Digite um número inteiro, sem vírgula.' };
    n = Number(t);
  }
  if (!Number.isFinite(n) || n < campo.min || n > campo.max) return { ok: false, erro: `Use um valor entre ${faixa(campo)}.` };
  return { ok: true, valor: n };
}

export function lerLista(texto, campo) {
  const partes = String(texto ?? '').split(/[,;\s]+/).filter(Boolean);
  if (!partes.length) return { ok: false, erro: 'Informe pelo menos uma opção de raio.' };
  if (partes.length > MAX_OPCOES_RAIO) return { ok: false, erro: `No máximo ${MAX_OPCOES_RAIO} opções.` };
  const nums = [];
  for (const p of partes) {
    if (!/^\d+$/.test(p)) return { ok: false, erro: `“${p}” não é um número inteiro. Separe as opções por vírgula, por exemplo: 1, 2, 3, 5.` };
    const n = Number(p);
    if (n < campo.min || n > campo.max) return { ok: false, erro: `Cada opção deve ficar entre ${campo.min} e ${campo.max} km.` };
    nums.push(n);
  }
  if (new Set(nums).size !== nums.length) return { ok: false, erro: 'Há opções repetidas.' };
  return { ok: true, valor: nums.sort((a, b) => a - b) };
}

const valorOk = (campo, v) => {
  if (campo.tipo === 'lista') return Array.isArray(v) && lerLista(v.join(','), campo).ok && v.every((x, i) => i === 0 || v[i - 1] < x);
  return typeof v === 'number' && Number.isFinite(v) && v >= campo.min && v <= campo.max && (campo.tipo === 'dec' || Number.isInteger(v));
};

/** raioKm (teto por veículo) = a maior opção da lista; o app do entregador usa este campo. */
function derivarTeto(cfg) {
  cfg.raioKm = {};
  for (const v of V) cfg.raioKm[v] = Math.max(...cfg.raiosKm[v]);
  return cfg;
}

/** O que está salvo em /rede/config por cima do padrão, campo a campo (valor inválido ou ausente = padrão). Devolve a configuração COMPLETA. */
export function mesclarConfig(salva) {
  const out = clonar(PADRAO_REDE_MESTRE);
  const s = salva && typeof salva === 'object' ? salva : {};
  for (const campo of CAMPOS) {
    let v = lerCaminho(s, campo.path);
    if (campo.tipo === 'lista') v = comoLista(v);
    if (v !== undefined && valorOk(campo, v)) gravarCaminho(out, campo.path, campo.tipo === 'lista' ? [...v] : v);
  }
  for (const v of V) { // o raio inicial precisa estar na lista; senão volta ao padrão, e se este também não está, à maior opção
    const lista = out.raiosKm[v];
    if (!lista.includes(out.raioPadraoKm[v])) out.raioPadraoKm[v] = lista.includes(PADRAO_REDE_MESTRE.raioPadraoKm[v]) ? PADRAO_REDE_MESTRE.raioPadraoKm[v] : lista[lista.length - 1];
  }
  return derivarTeto(out);
}

// ---------- formulário <-> configuração ----------
/** Texto de cada campo, como aparece no formulário. */
export function paraTexto(cfg) {
  const t = {};
  for (const campo of CAMPOS) {
    const v = lerCaminho(cfg, campo.path);
    t[campo.path] = campo.tipo === 'lista' ? v.join(', ') : campo.tipo === 'hora' ? fmtHora(v) : fmtNum(v);
  }
  return t;
}

/** Regras que envolvem mais de um campo. Devolve { caminho: mensagem }. */
export function validarCombinacoes(cfg) {
  const e = {};
  const g = (p) => lerCaminho(cfg, p);
  if (g('cancelaAposChegarPct') < g('cancelaAteChegarPct')) e.cancelaAposChegarPct = 'Não pode ser menor que a fase anterior (a caminho).';
  if (g('cancelaAposColetaPct') < g('cancelaAposChegarPct')) e.cancelaAposColetaPct = 'Não pode ser menor que a fase anterior (já chegou).';
  if (g('limiteConfiavel') < g('limiteNova')) e.limiteConfiavel = 'Não pode ser menor que o limite da loja nova.';
  if (g('analiseMinMin') > g('tetoFechamentoHoras') * 60) e.analiseMinMin = 'A análise não pode ser maior que o prazo máximo no fechamento.';
  if (g('prazoEntregadorHoras') < g('tetoFechamentoHoras')) e.prazoEntregadorHoras = 'Não pode ser menor que o prazo máximo no fechamento: o app prometeria algo que a loja pode não cumprir.';
  for (let i = 1; i < 4; i++) {
    if (g(`pausasDesistenciaMin.${i}`) < g(`pausasDesistenciaMin.${i - 1}`)) e[`pausasDesistenciaMin.${i}`] = 'Não pode ser menor que a pausa anterior.';
  }
  for (const v of V) {
    if (!g(`raiosKm.${v}`).includes(g(`raioPadraoKm.${v}`))) e[`raioPadraoKm.${v}`] = 'O raio inicial precisa ser uma das opções da lista.';
  }
  return e;
}

/** Lê o formulário inteiro. { ok, erros: {caminho: mensagem}, cfg } — cfg só existe se ok. */
export function lerFormulario(textos) {
  const erros = {};
  const cfg = clonar(PADRAO_REDE_MESTRE);
  for (const campo of CAMPOS) {
    const r = campo.tipo === 'lista' ? lerLista(textos[campo.path], campo) : lerNumero(textos[campo.path], campo);
    if (!r.ok) erros[campo.path] = r.erro; else gravarCaminho(cfg, campo.path, r.valor);
  }
  if (Object.keys(erros).length) return { ok: false, erros };
  derivarTeto(cfg);
  const cruz = validarCombinacoes(cfg);
  if (Object.keys(cruz).length) return { ok: false, erros: cruz };
  return { ok: true, erros: {}, cfg };
}

/** O que mudou: [{ path, rotulo, de, para }] já formatado para mostrar na confirmação. */
export function diferencas(antes, depois) {
  const lista = [];
  for (const campo of CAMPOS) {
    const a = lerCaminho(antes, campo.path), b = lerCaminho(depois, campo.path);
    if (JSON.stringify(a) !== JSON.stringify(b)) lista.push({ path: campo.path, rotulo: campo.rotulo, de: formatarValor(campo, a), para: formatarValor(campo, b) });
  }
  return lista;
}
export const resumoDiferencas = (difs) => difs.map((d) => `${d.rotulo}: ${d.de} → ${d.para}`).join(' · ');

/** O objeto que vai para /rede/config (tudo explícito, mais quem e quando). */
export function paraGravar(cfg, uid, iso) {
  const o = clonar(cfg);
  o.atualizadoEm = String(iso);
  o.atualizadoPor = String(uid || '');
  return o;
}

// ---------- lista de entregadores (somente leitura) ----------
/** /rede/entregadores -> linhas ordenadas (mais novos primeiro) e totais. */
export function resumirEntregadores(mapa) {
  const lista = Object.entries(mapa && typeof mapa === 'object' ? mapa : {})
    .filter(([, e]) => e && typeof e === 'object')
    .map(([uid, e]) => ({ uid, nome: String(e.nome || '—'), veiculo: e.veiculo === 'bicicleta' ? 'bicicleta' : 'moto', placa: String(e.placa || ''), celular: String(e.celular || ''),
      status: situacaoDe(e.status), statusMotivo: String(e.statusMotivo || ''), statusEm: Number(e.statusEm) || 0, cpfFinal: String(e.cpfFinal || ''),
      docs: { enviadoEm: Number(e.docs?.enviadoEm) || 0, apagadoEm: Number(e.docs?.apagadoEm) || 0, tipo: e.docs?.tipo === 'cnh' ? 'cnh' : e.docs ? 'documento' : '' },
      mpConectado: !!e.mpConectado, online: !!e.online, raioKm: Number(e.raioKm) || 0, pausadoAte: Number(e.pausadoAte) || 0, criadoEm: Number(e.criadoEm) || 0, exclusaoPedidaEm: Number(e.exclusaoPedidaEm) || 0 }))
    // V75.115: quem espera análise vem primeiro (o mais antigo no topo: foi quem esperou mais); o resto, do mais novo para o mais antigo
    .sort((a, b) => ((b.status === 'em_analise') - (a.status === 'em_analise')) || (a.status === 'em_analise' ? a.criadoEm - b.criadoEm : b.criadoEm - a.criadoEm));
  const conta = (st) => lista.filter((e) => e.status === st).length;
  const tot = { total: lista.length, mp: lista.filter((e) => e.mpConectado).length, online: lista.filter((e) => e.online).length,
    emAnalise: conta('em_analise'), ativos: conta('ativo'), recusados: conta('recusado'), bloqueados: conta('bloqueado') };
  return { lista, tot };
}

// ====================== V75.115: liberação para lojas e análise do entregador ======================
// /rede/liberacao: { modo: 'desligada'|'teste'|'todas', lojas: { [lojaId]: true }, analiseEntregador: bool, atualizadoPor, atualizadoEm }
// A API (2.19) lê o mesmo nó e é quem decide; as regras do Firebase só deixam o Master gravar.
export const MODOS_LIBERACAO = [
  { id: 'desligada', titulo: 'Desligada', texto: 'Nenhuma loja vê a entrega parceira. Os entregadores já podem se cadastrar e ser analisados.' },
  { id: 'teste', titulo: 'Só lojas de teste', texto: 'Só as lojas marcadas abaixo veem o botão "Chamar entregador parceiro".' },
  { id: 'todas', titulo: 'Todas as lojas', texto: 'Lançamento: todas as lojas veem a entrega parceira.' }
];
const MODO_IDS = MODOS_LIBERACAO.map((m) => m.id);

export function normalizarLiberacao(v) {
  const o = v && typeof v === 'object' ? v : {};
  const lojas = {};
  for (const [id, on] of Object.entries(o.lojas && typeof o.lojas === 'object' ? o.lojas : {})) if (on === true) lojas[id] = true;
  return { modo: MODO_IDS.includes(o.modo) ? o.modo : 'desligada', lojas, analiseEntregador: o.analiseEntregador !== false,
    atualizadoEm: typeof o.atualizadoEm === 'string' ? o.atualizadoEm : '', existe: !!v };
}
/** Objeto exato que vai para /rede/liberacao (as regras recusam qualquer outra chave). */
export function paraGravarLiberacao(lib, uid, iso) {
  const lojas = Object.fromEntries(Object.keys(lib.lojas || {}).filter((id) => lib.lojas[id] === true).sort().map((id) => [id, true]));
  return { modo: MODO_IDS.includes(lib.modo) ? lib.modo : 'desligada', ...(Object.keys(lojas).length ? { lojas } : {}), analiseEntregador: lib.analiseEntregador !== false, atualizadoPor: String(uid || ''), atualizadoEm: iso };
}
export const lojaLiberada = (lib, id) => lib.modo === 'todas' || (lib.modo === 'teste' && lib.lojas[id] === true);
/** Erro que impede salvar (null = pode). */
export function validarLiberacao(lib) {
  if (lib.modo === 'teste' && !Object.keys(lib.lojas).length) return 'Marque pelo menos uma loja de teste, ou escolha "Desligada".';
  return null;
}
/** Lista legível do que muda, para a confirmação. `nome(id)` devolve o nome da loja. */
export function diferencasLiberacao(antes, depois, nome = (id) => id) {
  const t = (m) => MODOS_LIBERACAO.find((x) => x.id === m)?.titulo || m;
  const out = [];
  if (antes.modo !== depois.modo) out.push(`Liberação: ${t(antes.modo)} → ${t(depois.modo)}`);
  if (depois.modo === 'teste' || antes.modo === 'teste') {
    const ent = Object.keys(depois.lojas).filter((id) => !antes.lojas[id]).map(nome);
    const sai = Object.keys(antes.lojas).filter((id) => !depois.lojas[id]).map(nome);
    if (ent.length) out.push(`Entram como loja de teste: ${ent.join(', ')}`);
    if (sai.length) out.push(`Saem das lojas de teste: ${sai.join(', ')}`);
  }
  if (antes.analiseEntregador !== depois.analiseEntregador) out.push(depois.analiseEntregador ? 'Cadastro novo de entregador passa por análise' : 'Cadastro novo de entregador entra ativo, sem análise');
  return out;
}
/** Frase do estado atual (topo do cartão). */
export function resumoLiberacao(lib, nome = (id) => id) {
  if (lib.modo === 'todas') return 'Todas as lojas veem a entrega parceira.';
  if (lib.modo === 'teste') { const n = Object.keys(lib.lojas).map(nome); return n.length ? `Só ${n.length === 1 ? 'a loja de teste' : `as ${n.length} lojas de teste`}: ${n.join(', ')}.` : 'Nenhuma loja de teste marcada.'; }
  return 'Nenhuma loja vê a entrega parceira.';
}
/** Lojas para marcar: marcadas primeiro, depois por nome; `busca` filtra por nome/cidade/id. */
export function lojasParaEscolher(mapa, marcadas, busca = '') {
  const b = String(busca || '').trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  return Object.entries(mapa && typeof mapa === 'object' ? mapa : {})
    .filter(([, l]) => l && typeof l === 'object')
    .map(([id, l]) => ({ id, nome: String(l.nombre || l.nome || id), cidade: String(l.cidadeNome || l.cidade || l.cidadeId || ''), marcada: !!marcadas[id] }))
    .filter((l) => !b || `${l.nome} ${l.cidade} ${l.id}`.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(b))
    .sort((a, c) => (c.marcada - a.marcada) || a.nome.localeCompare(c.nome, 'pt-BR'));
}

// ---------- situação do cadastro do entregador ----------
export const SITUACOES = {
  em_analise: { rotulo: 'Em análise', selo: 'aviso' },
  ativo: { rotulo: 'Ativo', selo: 'ok' },
  recusado: { rotulo: 'Recusado', selo: 'off' },
  bloqueado: { rotulo: 'Bloqueado', selo: 'erro' }
};
export const situacaoDe = (st) => (SITUACOES[st] ? st : 'ativo'); // cadastro antigo, sem status = ativo (igual à API)
/** Botões de cada situação (mesmas transições da API 2.19). */
export function acoesDaSituacao(st) {
  return { em_analise: ['aprovar', 'recusar'], ativo: ['bloquear'], bloqueado: ['reativar'], recusado: ['aprovar'] }[situacaoDe(st)] || [];
}
export const ACAO_PARA_STATUS = { aprovar: 'ativo', reativar: 'ativo', recusar: 'recusado', bloquear: 'bloqueado' };
export const FILTROS_ENTREGADOR = [['em_analise', 'Em análise'], ['ativo', 'Ativos'], ['recusado', 'Recusados'], ['bloqueado', 'Bloqueados'], ['todos', 'Todos']];
/** V75.116: situação dos documentos da análise. id: 'enviados' (dá para ver) · 'apagados' (já conferidos) · 'falta' (em análise sem envio) · 'nenhum'. */
export function situacaoDocs(e) {
  const d = e?.docs || {};
  if (d.apagadoEm) return { id: 'apagados', quando: d.apagadoEm };
  if (d.enviadoEm) return { id: 'enviados', quando: d.enviadoEm, tipo: d.tipo === 'cnh' ? 'CNH' : 'documento com foto' };
  if (situacaoDe(e?.status) === 'em_analise' || situacaoDe(e?.status) === 'recusado') return { id: 'falta' };
  return { id: 'nenhum' };
}
export function filtrarEntregadores(lista, filtro) { return filtro === 'todos' ? lista : lista.filter((e) => e.status === filtro); }

// ---------- V75.144 (API 2.28): relatos dos entregadores e pedidos de exclusão (LGPD) ----------
const num2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
/** rede_relatos → lista (abertos primeiro, mais novos primeiro) e quantos estão abertos. */
export function listarRelatos(obj) {
  const lista = Object.entries(obj && typeof obj === 'object' ? obj : {}).filter(([, r]) => r && typeof r === 'object')
    .map(([id, r]) => ({ id, aberto: r.estado !== 'resolvido', em: Number(r.em) || 0, loja: String(r.lojaNome || 'Loja'), lojaId: String(r.lojaId || ''), corridaId: String(r.corridaId || ''),
      motivo: String(r.motivoTexto || r.motivo || ''), detalhe: String(r.detalhe || ''), entregador: String(r.entregadorNome || 'Entregador'), entregadorUid: String(r.entregadorUid || ''),
      celular: String(r.entregadorCelular || ''), nota: String(r.nota || ''), resolvidoEm: Number(r.resolvidoEm) || 0 }))
    .sort((a, b) => (b.aberto - a.aberto) || b.em - a.em);
  return { lista, abertos: lista.filter((r) => r.aberto).length };
}
/** rede_exclusoes → pedidos em aberto (mais antigos primeiro: a LGPD tem prazo) e os concluídos. */
export function listarExclusoes(obj) {
  const todos = Object.entries(obj && typeof obj === 'object' ? obj : {}).filter(([, e]) => e && typeof e === 'object')
    .map(([uid, e]) => ({ uid, estado: e.estado === 'concluido' ? 'concluido' : 'pedido', nome: String(e.nome || 'Entregador removido'), celular: String(e.celular || ''), email: String(e.email || ''),
      aReceber: num2(e.aReceber), em: Number(e.em) || 0, concluidoEm: Number(e.concluidoEm) || 0, motivo: String(e.motivo || '') }));
  const pedidos = todos.filter((e) => e.estado === 'pedido').sort((a, b) => a.em - b.em);
  const concluidos = todos.filter((e) => e.estado === 'concluido').sort((a, b) => b.concluidoEm - a.concluidoEm);
  return { pedidos, concluidos };
}
/** Dias desde o pedido (a LGPD dá 15 dias para responder). */
export const diasDesde = (ms, agora = Date.now()) => (ms ? Math.max(0, Math.floor((agora - ms) / 86400000)) : 0);
export const PRAZO_LGPD_DIAS = 15;
