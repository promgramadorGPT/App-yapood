// js/sacola.js — V75.131: barra do carrinho com a sacola de olhos (modelo A: barra grafite, sacola marrom queimado, olhos mostarda).
// As cores da barra e da sacola vêm do Master (config_plataforma/sacola → --barra-carrinho e --sacola-cor; ver tema.js).
// Depois do "Adicionar": a tela do produto desce, a barra sobe (se ainda não estava na tela) e os olhos piscam duas vezes.

export const SACOLA_PADRAO = Object.freeze({ barra: '#1d1d1d', sacola: '#b85c00' });
export const COR_OLHOS = '#e9a728';

export const SACOLA_SVG = `<svg class="sacola-svg" viewBox="0 0 40 44" width="34" height="37" aria-hidden="true" focusable="false">
  <path class="sacola-alca" d="M13.5 14 V10.5 a6.5 6.5 0 0 1 13 0 V14" fill="none" stroke-width="2.6" stroke-linecap="round"/>
  <path class="sacola-corpo" d="M6.5 13.5 H33.5 L31.6 39.2 a3.4 3.4 0 0 1 -3.4 3.1 H11.8 a3.4 3.4 0 0 1 -3.4 -3.1 Z"/>
  <ellipse class="sacola-olho" cx="15.2" cy="27.6" rx="2.9" ry="4.3"/>
  <circle class="sacola-olho" cx="25" cy="28.3" r="3.6"/></svg>`;

/** "1 item" / "2 itens". */
export const rotuloItens = (n) => (Number(n) === 1 ? 'item' : 'itens');

/** Atualiza "N itens" da barra (o número fica no elemento de id antigo, que outras partes do app já usam). */
export function atualizarSacola(barra, qtd) {
  const r = barra?.querySelector('.qtd-rotulo');
  if (r) r.textContent = rotuloItens(qtd);
}

/**
 * Chamar logo depois de pôr item no carrinho. `apareceu` = a barra estava escondida antes deste item.
 * Espera a tela do produto descer (~0,26 s), faz a barra subir se for o caso e então pisca os olhos.
 * Quem pediu ao celular para reduzir animações: o CSS desliga os movimentos (a barra só aparece).
 */
export function anunciarItem(barra, apareceu = false) {
  if (!barra || barra.hidden) return;
  ['__t1', '__t2', '__t3'].forEach((k) => clearTimeout(barra[k]));
  barra.classList.remove('sobe', 'pisca');
  if (apareceu) barra.classList.add('esperando');
  barra.__t1 = setTimeout(() => {
    barra.classList.remove('esperando');
    if (apareceu) { void barra.offsetWidth; barra.classList.add('sobe'); }
    barra.__t2 = setTimeout(() => {
      void barra.offsetWidth;
      barra.classList.add('pisca');
      barra.__t3 = setTimeout(() => barra.classList.remove('pisca', 'sobe'), 1000);
    }, apareceu ? 420 : 0);
  }, 260);
}
