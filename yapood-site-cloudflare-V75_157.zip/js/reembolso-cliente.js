// V75.16 — Reembolso na tela de status do cliente.
// Módulo isolado (mesmo padrão do código de entrega): se falhar, a tela de status segue igual.
import { db, auth, ref, set, get } from './firebase.js';
import { escapeHtml, normalizarStatus, normalizarPagamento, PAGO, STATUS } from './regras.js';
import { toast, formatarMoeda } from './utils.js';
import { MOTIVOS_REEMBOLSO, REEMBOLSO, podeSolicitarReembolso, montarSolicitacaoReembolso, rotuloReembolso, textoReembolsoCliente } from './reembolso.js?v=75.145';
import { abrirPolitica } from './reembolso-ui.js';
import { opcaoReembolsoEmSaldo, fimEscolha } from './saldo-loja.js?v=75.145';
import { receberReembolsoEmSaldo, pedirDinheiroDeVolta } from './saldo-api.js?v=75.145';

// V75.145 — reembolso em saldo: a configuração da loja (saldoReembolso) é lida uma vez por loja
const cfgLojas = {};
function cfgDaLoja(lojaId) {
  if (!lojaId) return null;
  if (!(lojaId in cfgLojas)) {
    cfgLojas[lojaId] = null;
    get(ref(db, `restaurantes/${lojaId}/saldoReembolso`)).then((s) => { cfgLojas[lojaId] = { saldoReembolso: s.val() || null }; inserir(); }).catch(() => {});
  }
  return cfgLojas[lojaId];
}
const dataHora = (ms) => new Date(ms).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
function htmlEscolha(p, o) {
  const fim = fimEscolha(p);
  const dinheiro = o.deSaldo > 0 ? `${formatarMoeda(o.mp)} de volta + ${formatarMoeda(o.deSaldo)} em saldo` : `${formatarMoeda(o.mp)} de volta`;
  return `<div class="sd-escolha" role="group" aria-label="Como você quer receber o reembolso">
    <p class="sd-tit"><i class="fa-solid fa-wallet" aria-hidden="true"></i> Como você quer receber?</p>
    <button type="button" class="sd-op" data-sd-saldo><strong>${formatarMoeda(o.credito)} em saldo na loja</strong>
      <small>${o.bonusPct > 0 ? `+${o.bonusPct}% de bônus · ` : ''}use no próximo pedido nesta loja · não vence</small></button>
    ${o.direta ? `<p class="sd-nota">Ou espere a loja devolver ${formatarMoeda(o.mp)} em dinheiro, direto a você.</p>`
      : `<button type="button" class="sd-op sec" data-sd-dinheiro><strong>${dinheiro}</strong><small>na forma de pagamento usada · o prazo depende do banco</small></button>
    ${fim ? `<p class="sd-prazo">Se você não escolher até ${dataHora(fim)}, a loja devolve o dinheiro.</p>` : ''}`}
    <p class="rb-erro" hidden></p></div>`;
}

const container = document.getElementById('card-status-container');

function podeInformarFaseAvancada(p) {
  const s = normalizarStatus(p.status);
  return normalizarPagamento(p.pagoStatus) === PAGO.APROVADO && p.entregaConfirmada !== true && s !== STATUS.PENDENTE && s !== STATUS.ENTREGUE && s !== STATUS.CANCELADO;
}

function caixa(p) {
  const el = document.createElement('div');
  el.className = 'rb-box';
  const r = p.reembolso;
  if (r) {
    const op = opcaoReembolsoEmSaldo(p, cfgDaLoja(p.lojaId), auth.currentUser?.uid);
    el.dataset.estado = `r-${r.status}-${r.escolha ? 'e' : ''}-${r.execucao?.status || ''}-${r.devolvidoDiretoEm ? 'd' : ''}-${op.mostrar ? op.credito : ''}`;
    el.classList.add(`rb-${r.status}`);
    el.innerHTML = `<h4><i class="fa-solid fa-rotate-left"></i> Reembolso: ${escapeHtml(rotuloReembolso(r))}</h4>
      <p>${op.mostrar ? `A loja aprovou o reembolso de ${formatarMoeda(op.valor)}. Escolha abaixo como você quer receber.` : escapeHtml(textoReembolsoCliente(r))}</p>
      <p class="rb-meta">${formatarMoeda(r.valor || p.total)}${r.motivo ? ` · ${escapeHtml(r.motivo)}` : ''}</p>
      ${op.mostrar ? htmlEscolha(p, op) : ''}
      ${r.resposta ? `<p class="rb-resposta"><strong>Resposta da loja:</strong> ${escapeHtml(r.resposta)}</p>` : ''}
      <button type="button" class="rb-link" data-politica>Política de cancelamento</button>`;
  } else if (podeSolicitarReembolso(p, auth.currentUser?.uid)) {
    el.dataset.estado = 'pode';
    el.innerHTML = `<h4><i class="fa-solid fa-rotate-left"></i> Cancelamento e reembolso</h4>
      <p>Seu pagamento já foi aprovado e a loja ainda não aceitou o pedido. Precisa cancelar? Envie a solicitação e a loja responde aqui.</p>
      <button type="button" class="rb-btn" data-solicitar>Solicitar cancelamento e reembolso</button>
      <button type="button" class="rb-link" data-politica>Política de cancelamento</button>`;
  } else if (podeInformarFaseAvancada(p)) {
    el.dataset.estado = 'avancado';
    el.innerHTML = `<h4><i class="fa-solid fa-rotate-left"></i> Cancelamento e reembolso</h4>
      <p>A loja já aceitou o seu pedido. Nesta fase o cancelamento não é feito pelo aplicativo: fale com a loja pelo WhatsApp. Se ela aprovar, o reembolso aparece aqui.</p>
      <button type="button" class="rb-link" data-politica>Política de cancelamento</button>`;
  } else {
    el.dataset.estado = 'politica';
    el.innerHTML = '<button type="button" class="rb-link" data-politica>Política de cancelamento e reclamações</button>';
  }
  return el;
}

function inserir() {
  const p = window.__yapoodStatus?.pedido, card = container?.querySelector('.card-status');
  if (!card || !p || !auth.currentUser?.uid || auth.currentUser.uid !== p.clienteUid) return;
  const nova = caixa(p), atual = card.querySelector('.rb-box');
  if (atual) { if (atual.dataset.estado === nova.dataset.estado) return; atual.replaceWith(nova); return; }
  const ancora = card.querySelector('.acoes-status');
  if (ancora) ancora.before(nova); else card.appendChild(nova);
}

function abrirSolicitacao(p) {
  if (document.getElementById('modal-reembolso')) return;
  const el = document.createElement('div');
  el.id = 'modal-reembolso';
  el.className = 'rb-overlay';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-modal', 'true');
  el.innerHTML = `<div class="rb-modal">
    <div class="rb-head"><h3>Cancelamento e reembolso</h3><button type="button" class="rb-fechar" data-fechar aria-label="Fechar">&times;</button></div>
    <p class="rb-sub">Pedido #${escapeHtml(p.numeroPedido || '')} · ${formatarMoeda(p.total)}. Escolha o motivo:</p>
    <div class="rb-motivos">${MOTIVOS_REEMBOLSO.map((m) => `<label class="rb-motivo"><input type="radio" name="rb-motivo" value="${m.id}"><span>${escapeHtml(m.texto)}</span></label>`).join('')}</div>
    <label class="rb-label" for="rb-comentario">Comentário (opcional)</label>
    <textarea id="rb-comentario" maxlength="300" placeholder="Conte rapidamente o que aconteceu..."></textarea>
    <p class="rb-erro" hidden></p>
    <div class="rb-acoes"><button type="button" class="rb-btn rb-btn-sec" data-fechar>Voltar</button><button type="button" class="rb-btn" data-enviar>Enviar solicitação</button></div></div>`;
  el.addEventListener('click', async (e) => {
    if (e.target === el || e.target.closest('[data-fechar]')) return el.remove();
    const enviar = e.target.closest('[data-enviar]'); if (!enviar) return;
    const erro = el.querySelector('.rb-erro'); erro.hidden = true;
    try {
      const motivoId = el.querySelector('input[name="rb-motivo"]:checked')?.value;
      const dados = montarSolicitacaoReembolso(p, { motivoId, comentario: el.querySelector('#rb-comentario').value });
      enviar.disabled = true;
      await set(ref(db, `pedidos/${p._key}/reembolso`), dados);
      el.remove();
      toast('Solicitação enviada. A loja vai responder nesta tela.', 'success');
    } catch (err) {
      console.warn('Reembolso:', err);
      enviar.disabled = false;
      erro.textContent = err?.code === 'PERMISSION_DENIED' || /permission/i.test(err?.message || '')
        ? 'Não foi possível enviar agora. Fale com a loja pelo WhatsApp.'
        : (err?.message || 'Não foi possível enviar. Tente novamente.');
      erro.hidden = false;
    }
  });
  document.body.appendChild(el);
}

async function escolher(botao, saldo) {
  const p = window.__yapoodStatus?.pedido, box = botao.closest('.sd-escolha'), erro = box?.querySelector('.rb-erro');
  if (!p || !box) return;
  const o = opcaoReembolsoEmSaldo(p, cfgDaLoja(p.lojaId), auth.currentUser?.uid);
  if (!o.mostrar) return;
  box.querySelectorAll('button').forEach((b) => { b.disabled = true; });
  if (erro) erro.hidden = true;
  try {
    if (saldo) { const r = await receberReembolsoEmSaldo(p._key); toast(`Pronto! ${formatarMoeda(r.valor)} de saldo nesta loja.`, 'success', 7000); }
    else { await pedirDinheiroDeVolta(p._key); toast('Pronto! O Mercado Pago está devolvendo o valor.', 'success', 7000); }
  } catch (err) {
    console.warn('Escolha do reembolso:', err);
    if (erro) { erro.textContent = err.message || 'Não foi possível agora. Tente de novo.'; erro.hidden = false; }
    box.querySelectorAll('button').forEach((b) => { b.disabled = false; });
  }
}

container?.addEventListener('click', (ev) => {
  if (ev.target.closest('[data-politica]')) return abrirPolitica();
  const bs = ev.target.closest('[data-sd-saldo]'), bd = ev.target.closest('[data-sd-dinheiro]');
  if (bs || bd) return escolher(bs || bd, !!bs);
  if (ev.target.closest('[data-solicitar]')) {
    const p = window.__yapoodStatus?.pedido;
    if (podeSolicitarReembolso(p, auth.currentUser?.uid)) abrirSolicitacao(p);
  }
});
if (container) new MutationObserver(() => { try { inserir(); } catch (e) { console.warn('Reembolso:', e); } }).observe(container, { childList: true, subtree: true });
