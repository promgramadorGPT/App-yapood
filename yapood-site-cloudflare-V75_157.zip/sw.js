/* Firebase Cloud Messaging */
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');
firebase.initializeApp({
  apiKey: 'AIzaSyDJAKE0w6YeGjos9E21SnsLEh0PIEhK5hI',
  authDomain: 'yapoodbr-delivery.firebaseapp.com',
  databaseURL: 'https://yapoodbr-delivery-default-rtdb.firebaseio.com',
  projectId: 'yapoodbr-delivery',
  storageBucket: 'yapoodbr-delivery.firebasestorage.app',
  messagingSenderId: '469832240218',
  appId: '1:469832240218:web:868056b23bf792fc005c63'
});
const messaging = firebase.messaging();
const https = (u) => (typeof u === 'string' && u.startsWith('https://') && u.length <= 400 ? u : '');
// V75.143 — botões da notificação do pedido (NotPush 7.4): só ações conhecidas, no máximo 2
const ACOES_OK = { ver: 1, mapa: 1, avaliar: 1 };
function acoesDoAviso(d) {
  try {
    return JSON.parse(d.acoes || '[]').filter((a) => a && ACOES_OK[a.acao]).slice(0, 2).map((a) => ({ action: a.acao, title: String(a.titulo || '').slice(0, 24) }));
  } catch { return []; }
}
/** Opções do aviso. Etapa do pedido (V75.143): imagem da etapa (Android), botões e a mesma tag do pedido (troca a anterior). */
function opcoesDoAviso(n, d, jaMostrado) {
  const acoes = acoesDoAviso(d);
  const imagem = https(d.imagem) || https(n.image);
  return {
    body: n.body || 'Você tem uma atualização do seu pedido.',
    // O NotPush manda icon/badge também em `data` (o aviso do navegador não os repassa aqui): sem isso o ícone voltava ao padrão.
    icon: https(d.icon) || n.icon || '/icons/icons-192.png',
    badge: https(d.badge) || n.badge || '/icons/badge-96.png',
    ...(d.tag ? { tag: d.tag } : {}),
    ...(imagem ? { image: imagem } : {}),
    ...(acoes.length ? { actions: acoes } : {}),
    // Se o Firebase já mostrou (e já tocou), esta troca é silenciosa; senão, a troca de etapa toca de novo.
    ...(d.etapa && d.tag ? { renotify: !jaMostrado } : {}),
    data: d
  };
}
messaging.onBackgroundMessage(payload => {
  const n = payload.notification || {};
  const d = payload.data || {};
  // A mesma "tag" que o NotPush manda no push: se o Firebase já mostrou o aviso, este o substitui em vez de duplicar.
  self.registration.showNotification(n.title || 'YAPOOD', opcoesDoAviso(n, d, !!payload.notification));
});
/** Link de cada botão: "Avaliar" abre o status já com a avaliação. */
function linkDoClique(dados, acao) {
  const link = dados.link || dados.url || dados.FCM_MSG?.fcmOptions?.link || '/index.html';
  if (acao === 'avaliar' && /status\.html\?/.test(link)) return link + '&avaliar=1';
  return link;
}
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const link = linkDoClique(event.notification.data || {}, event.action || '');
  event.waitUntil(clients.matchAll({type:'window', includeUncontrolled:true}).then(list => {
    for (const c of list) if ('focus' in c) { c.navigate(link); return c.focus(); }
    return clients.openWindow(link);
  }));
});
// Service Worker — YAPOOD Delivery
// Estratégia: app shell em cache (abre offline), HTML network-first, estáticos stale-while-revalidate.
// Firebase / Cloudinary / Mercado Pago / API NUNCA passam pelo cache (dados sempre frescos e seguros).
const VERSAO = 'br-V75.147-banner-gif';
const CACHE = `yapood-${VERSAO}`;
const SHELL = [
  './', 'index.html', 'restaurante.html', 'avaliaciones.html', 'cart.html', 'js/pedido-aberto.js', 'js/troco.js', 'pedidos.html', 'status.html', 'perfil.html', 'icons/avatar-cliente.png', 'icons/selo-yasuper.png', 'cupons.html',
  'css/global.css', 'css/vitrina.css', 'css/home-v2.css', 'js/logo-yapood.js', 'css/restaurante.css', 'css/cart.css', 'css/pedidos.css', 'css/status.css',
  'js/app.js', 'js/carrossel-util.js', 'js/restaurante.js', 'js/avaliaciones.js', 'js/cart.js', 'js/checkout-cartao.js', 'js/pedidos.js', 'js/status.js', 'js/cupons.js',
  'js/regras.js', 'js/rastreio.js', 'js/fidelidade.js', 'js/enderecos.js', 'js/checkout-ui.js', 'js/produto-opcoes.js', 'js/combo.js', 'js/sacola.js', 'js/cupom-etiqueta.js', 'js/perfil-dados.js', 'css/perfil.css', 'css/sacola.css', 'js/produto-tela.js', 'css/produto-tela.css', 'js/bairros.js', 'js/distancia.js', 'js/rota.js', 'js/comissao.js', 'js/reembolso-api.js', 'js/saldo-loja.js', 'js/saldo-api.js', 'js/relato.js', 'js/anuncie.js', 'js/financeiro.js', 'js/tema.js', 'js/tema-boot.js', 'js/tema-cores.js', 'css/tema.css', 'js/fidelidade-presente.js', 'js/cupons-presentes.js', 'js/splash.js', 'css/splash.css', 'css/fidelidade.css', 'js/utils.js', 'js/ui-mensagens.js', 'js/geo.js', 'js/firebase.js', 'js/pedido-service.js', 'js/pwa.js',
  'master.html', 'css/master.css', 'js/master.js', 'js/master-util.js', 'manifest.json', 'icons/icons-192.png', 'icons/badge-96.png', 'icons/badge-entregador-96.png', 'icons/badge-master-96.png', 'js/icones-campanha.js', 'js/icones-app.js', 'js/notificaciones.js', 'js/notificaciones-config.js', 'css/admin-style.css', 'js/admin-loja.js',
  'entregador.html', 'css/entregador.css', 'css/mapa.css', 'js/mapa-ui.js', 'js/mapa-nav.js', 'js/aviso-google.js', 'js/entregador.js', 'js/entregador-util.js', 'js/entregadores-util.js', 'js/pwa-instalar.js', 'js/notpush-evento.js', 'manifest-entregador.json', 'manifest-master.json', 'icons/master-192.png', 'icons/entregador-192.png',
  'admin-loja.html', 'css/admin-parceira.css', 'js/loja-parceira.js', 'js/loja-parceira-util.js', 'js/apps-config.js', 'js/ciclo-comissao.js', 'js/comanda.js', 'js/foto-qualidade.js', 'css/admin-cadastro.css', 'js/avisos-lojista.js', 'js/cadastro-lojista.js', 'js/cadastro-lojista-ui.js', 'js/cadastro-analise.js', 'js/cupom-produtos.js', 'js/acerto-comissao.js', 'js/acerto-loja.js', 'js/qr.js', 'css/acerto.css', 'js/master-acertos.js', 'js/master-cadastros.js', 'js/master-cidades.js', 'js/master-rede.js', 'js/master-rede-util.js', 'js/master-faxina.js', 'js/cidades.js', 'js/cidades-api.js', 'js/cidades-cliente.js', 'js/cidades-bloqueio.js', 'js/logo-yapood.js', 'js/kit-textos.js', 'js/kit-cidade.js', 'js/termos-lojista.js', 'css/admin-entregadores.css', 'css/admin-bairros.css', 'js/entregadores-admin.js', 'js/bairros-admin.js', 'manifest-admin.json', 'icons/adm-192.png'
];
const MESMA_ORIGEM_OU_CDN = [self.location.origin, 'https://cdnjs.cloudflare.com'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith('yapood-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (!MESMA_ORIGEM_OU_CDN.includes(url.origin)) return; // deixa o navegador tratar o resto

  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then((r) => { const cp = r.clone(); caches.open(CACHE).then((c) => c.put(req, cp)); return r; })
        .catch(() => caches.match(req, { ignoreSearch: true }).then((r) => r || caches.match('index.html')))
    );
    return;
  }
  // JS/HTML: rede primeiro para garantir que atualizações de código entrem imediatamente.
  // Se estiver offline, usa o cache da versão atual.
  if (req.destination === 'script' || req.destination === 'style' || req.destination === 'document') {
    e.respondWith(
      fetch(req).then((r) => {
        if (r && r.status === 200) { const cp = r.clone(); caches.open(CACHE).then((c) => c.put(req, cp)); }
        return r;
      }).catch(() => caches.match(req, { ignoreSearch: true }))
    );
    return;
  }

  e.respondWith(
    caches.match(req).then((cached) => {
      const rede = fetch(req).then((r) => {
        if (r && r.status === 200) { const cp = r.clone(); caches.open(CACHE).then((c) => c.put(req, cp)); }
        return r;
      }).catch(() => cached);
      return cached || rede;
    })
  );
});
